"""
VENTRIX Studio - In-App Online Update Engine
Checks a remote URL for updates, downloads update packages, and applies them in-place.
Users never need to re-install — updates happen inside the running app.
Author: VENTRIX
"""

import sys
import os
import re
import json
import time
import shutil
import zipfile
import tempfile
import subprocess
import logging
from pathlib import Path
from typing import Optional, Dict, Any, Callable, Tuple
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

from shared.constants import APP_VERSION, APP_NAME, UPDATE_MANIFEST_URL

logger = logging.getLogger("TouchDeck.UpdateManager")


def parse_version(v: str) -> Tuple[int, ...]:
    """Parse semver string like '2.0.0' or 'v2.1.0' into comparable tuple."""
    clean = re.sub(r"^[^\d]*", "", str(v).strip())
    parts = []
    for chunk in clean.split("."):
        try:
            parts.append(int(re.findall(r"\d+", chunk)[0]))
        except (IndexError, ValueError):
            parts.append(0)
    return tuple(parts) if parts else (0, 0, 0)


def is_version_newer(latest: str, current: str = APP_VERSION) -> bool:
    """Return True if latest is strictly newer than current."""
    return parse_version(latest) > parse_version(current)


class UpdateManager:
    """
    Full online update system:
    1. Checks remote manifest URL for new versions
    2. Shows changelog so user can decide
    3. Downloads update zip package
    4. Extracts over existing files (preserves user config)
    5. Restarts the app
    """

    def __init__(self, project_root: Optional[Path] = None):
        if project_root is not None:
            self.root = project_root
        elif getattr(sys, "frozen", False):
            # In compiled PyInstaller app, root is the installation folder
            self.root = Path(sys.executable).parent.resolve()
        else:
            self.root = Path(__file__).parent.parent.parent.resolve()

        self.manifest_url = UPDATE_MANIFEST_URL
        self.local_manifest = self.root / "update_manifest.json"
        self.downloads_dir = self.root / "updates"
        self.downloads_dir.mkdir(parents=True, exist_ok=True)

    def check_for_updates(self) -> Dict[str, Any]:
        """
        Checks for updates by fetching the remote manifest.
        Falls back to local manifest if offline.
        """
        current = APP_VERSION

        # 1. Try fetching from remote URL
        remote_data = self._fetch_remote_manifest()
        if remote_data:
            latest = remote_data.get("version", current)
            if is_version_newer(latest, current):
                return {
                    "has_update": True,
                    "current_version": current,
                    "latest_version": latest,
                    "changelog": remote_data.get("changelog", []),
                    "download_url": remote_data.get("download_url", ""),
                    "package_file": remote_data.get("package_file", ""),
                    "source": "online"
                }

        # 2. Check local manifests (fallback when offline or when testing a newly packaged local update before remote push)
        manifest_candidates = [
            self.local_manifest,
            Path(__file__).parent.parent.parent / "update_manifest.json",
            Path.home() / "Desktop" / "ventrix-updates" / "update_manifest.json",
            Path.home() / "Desktop" / "TouchDeck" / "update_manifest.json",
            Path.home() / "Documents" / "GitHub" / "ventrix-updates" / "update_manifest.json",
            Path.home() / "Documents" / "GitHub" / "TouchDeck" / "update_manifest.json",
        ]
        for manifest_p in manifest_candidates:
            if manifest_p.exists():
                try:
                    with open(manifest_p, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    latest = data.get("version", current)
                    if is_version_newer(latest, current):
                        return {
                            "has_update": True,
                            "current_version": current,
                            "latest_version": latest,
                            "changelog": data.get("changelog", []),
                            "download_url": data.get("download_url", ""),
                            "package_file": data.get("package_file", ""),
                            "source": "local"
                        }
                except Exception:
                    pass

        # 3. No newer update found
        fallback_changelog = []
        for manifest_p in manifest_candidates:
            if manifest_p.exists():
                try:
                    with open(manifest_p, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    fallback_changelog = data.get("changelog", [])
                    if fallback_changelog:
                        break
                except Exception:
                    pass

        latest_ver = remote_data.get("version", current) if remote_data else current
        changelog = remote_data.get("changelog", fallback_changelog) if remote_data else fallback_changelog
        return {
            "has_update": False,
            "current_version": current,
            "latest_version": latest_ver,
            "changelog": changelog,
            "download_url": "",
            "package_file": "",
            "source": "online" if remote_data else "none"
        }

    def _fetch_remote_manifest(self) -> Optional[Dict[str, Any]]:
        """Fetches update manifest with cache-busting and repository fallback."""
        if not self.manifest_url:
            return None

        # 1. Try real-time GitHub API (instant, bypasses raw CDN 5-minute cache)
        api_url = "https://api.github.com/repos/oliv922222-source/ventrix-updates/contents/update_manifest.json"
        try:
            import base64
            req = Request(api_url, headers={"User-Agent": f"VENTRIX-Studio/{APP_VERSION}"})
            with urlopen(req, timeout=4) as resp:
                raw_json = json.loads(resp.read().decode("utf-8"))
                if "content" in raw_json:
                    decoded = base64.b64decode(raw_json["content"]).decode("utf-8")
                    data = json.loads(decoded)
                    logger.info(f"[Update] Remote manifest fetched instantly via GitHub API: v{data.get('version', '?')}")
                    return data
        except Exception as e:
            logger.debug(f"[Update] GitHub API manifest fetch bypassed: {e}")

        urls = [self.manifest_url]
        if "ventrix-updates" in self.manifest_url:
            urls.append(self.manifest_url.replace("ventrix-updates", "TouchDeck"))
        elif "TouchDeck" in self.manifest_url:
            urls.append(self.manifest_url.replace("TouchDeck", "ventrix-updates"))

        for raw_url in urls:
            try:
                sep = "&" if "?" in raw_url else "?"
                url = f"{raw_url}{sep}_cb={int(time.time())}"
                req = Request(
                    url,
                    headers={
                        "User-Agent": f"VENTRIX-Studio/{APP_VERSION}",
                        "Cache-Control": "no-cache, no-store, must-revalidate",
                        "Pragma": "no-cache",
                    }
                )
                with urlopen(req, timeout=6) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    logger.info(f"[Update] Remote manifest fetched from {raw_url}: v{data.get('version', '?')}")
                    return data
            except (URLError, HTTPError) as e:
                logger.warning(f"[Update] Could not reach {raw_url}: {e}")
            except Exception as e:
                logger.warning(f"[Update] Error parsing remote manifest from {raw_url}: {e}")

        return None

    def download_update(self, download_url: str, progress_cb: Optional[Callable[[int, str], None]] = None) -> Optional[Path]:
        """
        Downloads the update zip from download_url or discovers existing local package.
        Returns the local path to the downloaded file, or None on failure.
        """
        filename = download_url.split("/")[-1] if download_url else ""
        if not filename.endswith(".zip"):
            filename = "VENTRIX_Update.zip"

        # Check local paths first (fast and offline-friendly)
        local_candidates = [
            self.downloads_dir / filename,
            self.root / "updates" / filename,
            Path.home() / "Desktop" / "ventrix-updates" / "updates" / filename,
            Path.home() / "Desktop" / "TouchDeck" / "updates" / filename,
            Path.home() / "Documents" / "GitHub" / "ventrix-updates" / "updates" / filename,
            Path.home() / "Documents" / "GitHub" / "TouchDeck" / "updates" / filename,
        ]
        for cand in local_candidates:
            if cand.exists() and cand.stat().st_size > 1000:
                logger.info(f"[Update] Found local update package: {cand}")
                if progress_cb:
                    progress_cb(100, "Lokal opdateringspakke fundet")
                return cand

        if not download_url:
            if progress_cb:
                progress_cb(0, "Ingen download-URL tilgængelig")
            return None

        try:
            if progress_cb:
                progress_cb(5, "Forbinder til opdateringsserveren...")

            req = Request(download_url, headers={"User-Agent": f"VENTRIX-Studio/{APP_VERSION}"})
            with urlopen(req, timeout=60) as resp:
                total_size = int(resp.headers.get("Content-Length", 0))
                filename = download_url.split("/")[-1]
                if not filename.endswith(".zip"):
                    filename = "VENTRIX_Update.zip"

                dest = self.downloads_dir / filename
                downloaded = 0
                chunk_size = 64 * 1024  # 64 KB chunks

                with open(dest, "wb") as f:
                    while True:
                        chunk = resp.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)

                        if total_size > 0 and progress_cb:
                            pct = min(90, int((downloaded / total_size) * 90))
                            size_mb = downloaded / (1024 * 1024)
                            total_mb = total_size / (1024 * 1024)
                            progress_cb(pct, f"Henter... {size_mb:.1f} / {total_mb:.1f} MB")

                if progress_cb:
                    progress_cb(95, "Download fuldført, forbereder installation...")

                logger.info(f"[Update] Downloaded: {dest} ({downloaded} bytes)")
                return dest

        except Exception as e:
            logger.error(f"[Update] Download failed: {e}")
            if progress_cb:
                progress_cb(0, f"Download fejlede: {e}")
            return None

    def apply_update_from_zip(self, zip_path: Path, progress_cb: Optional[Callable[[int, str], None]] = None) -> bool:
        """
        Extracts updated files in-place while strictly preserving user configuration.
        Protected files: user settings, logs, backups, device config.
        """
        if not zip_path.exists():
            return False

        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                members = zf.infolist()
                total = max(1, len(members))
                for i, member in enumerate(members):
                    # Never overwrite user settings, logs, or backups
                    protected = [
                        "touchdeck_config.json", "touchdeck_settings.json",
                        "touchdeck_devices.json", "google_credentials.json",
                        "logs/", "backups/", "__pycache__/", "user_icons/",
                        "updates/", ".pytest_cache/"
                    ]
                    if any(skip in member.filename for skip in protected):
                        continue

                    dest_path = self.root / member.filename
                    try:
                        zf.extract(member, self.root)
                    except (PermissionError, OSError):
                        try:
                            # If file is locked by the OS, rename the existing file to .old
                            old_path = dest_path.with_name(f"{dest_path.name}.old")
                            if old_path.exists():
                                try:
                                    old_path.unlink()
                                except Exception:
                                    pass
                            if dest_path.exists():
                                dest_path.rename(old_path)
                            zf.extract(member, self.root)
                        except Exception as rename_err:
                            logger.error(f"[Update] Could not replace locked file {dest_path}: {rename_err}")
                    if progress_cb and i % 10 == 0:
                        pct = int((i / total) * 100)
                        progress_cb(pct, f"Installerer filer... {pct}%")

            # Update the local manifest with the new version
            if progress_cb:
                progress_cb(100, "Opdatering fuldført!")

            logger.info(f"[Update] Applied update from {zip_path.name}")
            return True
        except Exception as e:
            logger.error(f"[Update] Install failed: {e}")
            if progress_cb:
                progress_cb(0, f"Fejl: {e}")
            return False

    def restart_app(self):
        """Restarts VENTRIX Studio cleanly."""
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        flags = (DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP) if sys.platform == "win32" else 0

        # 1. Prefer pythonw if main.py exists (ensures latest updated source runs with native Qt)
        main_py = self.root / "editor" / "main.py"
        candidates = [
            Path(sys.executable).parent / "pythonw.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Python" / "Python311" / "pythonw.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Python" / "Python312" / "pythonw.exe",
        ]
        found_pythonw = None
        for c in candidates:
            if c.exists():
                found_pythonw = str(c)
                break

        if main_py.exists() and found_pythonw:
            subprocess.Popen([found_pythonw, str(main_py)], cwd=str(self.root), creationflags=flags)
            sys.exit(0)

        # 2. Fallback: check for standalone exe
        exe_candidates = [
            self.root / "TouchDeck Editor.exe",
            self.root / "VENTRIX.exe",
            self.root / "VENTRIX Studio.exe",
        ]
        for exe in exe_candidates:
            if exe.exists():
                subprocess.Popen([str(exe)], cwd=str(self.root), creationflags=flags)
                sys.exit(0)

    def cleanup_old_downloads(self):
        """Removes old update zip files to save disk space."""
        try:
            for f in self.downloads_dir.glob("*.zip"):
                try:
                    f.unlink()
                except Exception:
                    pass
        except Exception:
            pass
