"""
TouchDeck - Authentic Stream Deck Physical Hardware Preview Canvas
Strict Apple-Grade Physicality, Translucent Glass Buttons & Alpha Logo Rendering.
Author: VENTRIX
"""

import os
from pathlib import Path
from typing import Optional, Dict

from PySide6.QtWidgets import (
    QWidget, QGridLayout, QVBoxLayout, QHBoxLayout, QLabel,
    QFrame, QMenu, QMessageBox
)
from PySide6.QtGui import (
    QPainter, QColor, QFont, QPen, QBrush, QIcon, QPixmap,
    QDrag, QMouseEvent, QPaintEvent, QLinearGradient, QPainterPath,
    QDragEnterEvent, QDropEvent
)
from PySide6.QtCore import Qt, QSize, QPoint, QRect, QRectF, Signal, QMimeData

from shared.models import ButtonModel, PageModel
from shared.constants import (
    COLOR_BG, COLOR_BG_SECONDARY, COLOR_CARD, COLOR_BORDER,
    COLOR_TEXT_MAIN
)
from editor.utils.icon_storage import resolve_icon_path, save_custom_image


class PreviewButtonTile(QFrame):
    """
    Tactile Physical Glass Button Tile on the Stream Deck chassis.
    Pure Apple design: dark translucent surface, hairline rim reflection, no neon.
    Preserves transparent PNG alpha with zero white bounding artifacts.
    """
    clicked = Signal(str)                  # button_id
    right_clicked = Signal(str, QPoint)    # button_id, global_pos
    dropped_on = Signal(str, str)          # source_id, target_slot_or_btn_id

    def __init__(self, button: Optional[ButtonModel], row: int, col: int, is_selected: bool = False,
                 default_radius: int = 28, parent=None):
        super().__init__(parent)
        self.button = button
        self.row = row
        self.col = col
        self.is_selected = is_selected
        self.default_radius = default_radius
        self.is_hovered = False
        self.is_pressed = False

        self.setAcceptDrops(True)
        self.setMouseTracking(True)
        self.setCursor(Qt.PointingHandCursor)

    def enterEvent(self, event):
        self.is_hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.is_hovered = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self.is_pressed = True
            self.update()
            if self.button:
                self.clicked.emit(self.button.id)
            else:
                self.clicked.emit(f"empty_{self.row}_{self.col}")
            self.drag_start_pos = event.pos()
        elif event.button() == Qt.RightButton:
            if self.button:
                self.right_clicked.emit(self.button.id, event.globalPosition().toPoint())

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self.is_pressed = False
            self.update()
        super().mouseReleaseEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent):
        if not (event.buttons() & Qt.LeftButton) or not self.button:
            return
        if (event.pos() - getattr(self, "drag_start_pos", QPoint())).manhattanLength() < 8:
            return

        drag = QDrag(self)
        mime = QMimeData()
        mime.setText(f"touchdeck_btn:{self.button.id}")
        drag.setMimeData(mime)

        pixmap = QPixmap(self.size())
        pixmap.fill(Qt.transparent)
        self.render(pixmap)
        drag.setPixmap(pixmap)
        drag.setHotSpot(event.pos())
        drag.exec(Qt.MoveAction)
        self.is_pressed = False
        self.update()

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            return
        if event.mimeData().hasText() and event.mimeData().text().startswith("touchdeck_btn:"):
            event.acceptProposedAction()
            self.is_hovered = True
            self.update()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls() or (event.mimeData().hasText() and event.mimeData().text().startswith("touchdeck_btn:")):
            event.acceptProposedAction()

    def dragLeaveEvent(self, event):
        self.is_hovered = False
        self.update()

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            p = self.parent()
            while p and not hasattr(p, "handle_file_drop"):
                p = p.parent()
            if p and hasattr(p, "handle_file_drop"):
                p.handle_file_drop(event)
                event.acceptProposedAction()
                return

        if event.mimeData().hasText() and event.mimeData().text().startswith("touchdeck_btn:"):
            source_id = event.mimeData().text().replace("touchdeck_btn:", "")
            target_id = self.button.id if self.button else f"empty_{self.row}_{self.col}"
            self.dropped_on.emit(source_id, target_id)
            event.acceptProposedAction()
            self.is_hovered = False
            self.update()

    def paintEvent(self, event: QPaintEvent):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)

        rect = self.rect().adjusted(2, 2, -2, -2)
        if self.is_pressed:
            rect = rect.adjusted(1, 1, -1, -1)

        # ----------------------------------------------------
        # 1. Empty Slot Placeholder
        # ----------------------------------------------------
        if not self.button:
            r = float(self.default_radius or 28)
            border_col = QColor(255, 255, 255, 45) if self.is_hovered else QColor(255, 255, 255, 18)
            pen = QPen(border_col, 1.2, Qt.DashLine)
            painter.setPen(pen)
            bg_col = QColor(255, 255, 255, 8) if self.is_hovered else QColor(16, 16, 20, 130)
            painter.setBrush(QBrush(bg_col))
            painter.drawRoundedRect(rect, r, r)

            painter.setPen(QColor(255, 255, 255, 95 if self.is_hovered else 45))
            painter.setFont(QFont("Segoe UI Variable Text", 16, QFont.Normal))
            painter.drawText(rect, Qt.AlignCenter, "+")
            return

        # ----------------------------------------------------
        # 2. Configured Physical Tactile Button Tile
        # ----------------------------------------------------
        r = float(self.button.border_radius or self.default_radius or 28)
        if r < 4:
            r = 4.0
        path = QPainterPath()
        path.addRoundedRect(QRectF(rect), r, r)

        # Base Surface Tone (Rich obsidian glass tint or custom color)
        raw_bg = QColor(self.button.bg_color or "#141416")
        if self.is_hovered:
            raw_bg = raw_bg.lighter(114)

        # Subtle Vertical Glass Depth
        fill = QLinearGradient(0, rect.top(), 0, rect.bottom())
        if raw_bg.name().lower() in ["#141416", "#0a0a0c", "#000000", "#18181b", "#1c1c1e"]:
            fill.setColorAt(0.0, QColor(32, 33, 38, 235))
            fill.setColorAt(1.0, QColor(16, 16, 20, 250))
        else:
            fill.setColorAt(0.0, QColor(raw_bg.red(), raw_bg.green(), raw_bg.blue(), 235))
            fill.setColorAt(1.0, QColor(max(0, raw_bg.red() - 14), max(0, raw_bg.green() - 14), max(0, raw_bg.blue() - 14), 245))
        painter.fillPath(path, fill)

        # Hairline Top Light Reflection (Glass Specular Highlight smoothly clipped)
        painter.save()
        painter.setClipPath(path)
        sheen_height = min(36, int(rect.height() * 0.38))
        sheen_rect = QRectF(rect.left(), rect.top(), rect.width(), sheen_height)
        sheen_grad = QLinearGradient(0, rect.top(), 0, rect.top() + sheen_height)
        sheen_grad.setColorAt(0.0, QColor(255, 255, 255, 32 if self.is_hovered else 18))
        sheen_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.fillRect(sheen_rect, sheen_grad)
        painter.restore()

        # Hairline Rim Highlight (Border)
        if self.is_selected:
            # Clean High-Contrast Selection Ring
            border_pen = QPen(QColor(34, 197, 94, 230) if self.button.bg_color and self.button.bg_color != "#141416" else QColor(255, 255, 255, 230), 1.8)
        elif self.is_hovered:
            border_pen = QPen(QColor(255, 255, 255, 80), 1.0)
        else:
            border_grad = QLinearGradient(0, rect.top(), 0, rect.bottom())
            border_grad.setColorAt(0.0, QColor(255, 255, 255, 40))
            border_grad.setColorAt(0.5, QColor(255, 255, 255, 18))
            border_grad.setColorAt(1.0, QColor(255, 255, 255, 8))
            border_pen = QPen()
            border_pen.setWidthF(1.0)
            border_pen.setBrush(border_grad)

        painter.strokePath(path, border_pen)

        # ----------------------------------------------------
        # 3. Custom Logo / Image Rendering (100% Reliable & Transparent)
        # ----------------------------------------------------
        icon_drawn = False
        resolved_icon_path = resolve_icon_path(self.button.icon)

        if resolved_icon_path and resolved_icon_path.exists():
            pix = QPixmap(str(resolved_icon_path))
            if not pix.isNull():
                max_icon_size = min(int(rect.height() * 0.44), int(rect.width() * 0.48), 52)
                scaled_pix = pix.scaled(max_icon_size, max_icon_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                ix = rect.center().x() - scaled_pix.width() // 2
                iy = rect.top() + int(rect.height() * 0.32) - scaled_pix.height() // 2
                painter.drawPixmap(ix, iy, scaled_pix)
                icon_drawn = True

        # ----------------------------------------------------
        # 4. Button Label Typography (Clean White Text)
        # ----------------------------------------------------
        painter.setPen(QColor(self.button.text_color or "#FFFFFF"))
        font_size = self.button.font_size or 12
        font_fam = self.button.font_family or "Segoe UI Variable Text"
        painter.setFont(QFont(font_fam, font_size, QFont.Bold))

        if icon_drawn:
            text_rect = QRect(
                rect.left() + 4,
                rect.top() + int(rect.height() * 0.50),
                rect.width() - 8,
                int(rect.height() * 0.46)
            )
        else:
            text_rect = rect.adjusted(6, 6, -6, -6)

        painter.drawText(text_rect, Qt.AlignCenter | Qt.TextWordWrap, self.button.title or "Button")


class LiveSurfacePreview(QFrame):
    """
    Center Stage Authentic Stream Deck Hardware Housing.
    Encased in a precision matte dark chassis bezel with clean button grid.
    Supports drag & drop custom backgrounds, gap spacing, and corner radius.
    """
    button_selected = Signal(object)        # ButtonModel or None
    button_test_requested = Signal(object)  # ButtonModel
    background_dropped = Signal(str)        # Image path
    layout_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("hardwareChassis")
        self.current_page: Optional[PageModel] = None
        self.selected_button_id: Optional[str] = None
        self.tiles_dict: Dict[str, PreviewButtonTile] = {}
        self._is_drag_hovering_image = False

        self.setAcceptDrops(True)
        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 16, 20, 20)
        main_layout.setSpacing(12)

        # Clean Hardware Header Bezel
        header_row = QHBoxLayout()
        header_row.setContentsMargins(6, 0, 6, 0)

        title = QLabel("STREAM DECK HARDWARE PREVIEW")
        title.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 600; letter-spacing: 1.2px; background: transparent; border: none;")
        header_row.addWidget(title)
        header_row.addStretch()

        self.aspect_badge = QLabel("12-Key Studio")
        self.aspect_badge.setStyleSheet("""
            color: #8E8E93;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 6px;
            padding: 2px 8px;
            font-size: 10px;
            font-weight: 500;
        """)
        header_row.addWidget(self.aspect_badge)

        main_layout.addLayout(header_row)

        # Stream Deck Precision Grid Container
        self.grid_container = QWidget()
        self.grid_container.setStyleSheet("background: transparent; border: none;")
        self.grid_container.setAcceptDrops(True)
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setContentsMargins(16, 16, 16, 16)
        self.grid_layout.setSpacing(14)
        main_layout.addWidget(self.grid_container, stretch=1)

    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                ext = Path(url.toLocalFile()).suffix.lower()
                if ext in (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"):
                    event.acceptProposedAction()
                    self._is_drag_hovering_image = True
                    self.update()
                    return
        event.ignore()

    def dragLeaveEvent(self, event):
        self._is_drag_hovering_image = False
        self.update()

    def handle_file_drop(self, event: QDropEvent):
        self.dropEvent(event)

    def dropEvent(self, event: QDropEvent):
        self._is_drag_hovering_image = False
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                local_path = url.toLocalFile()
                ext = Path(local_path).suffix.lower()
                if ext in (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif") and os.path.exists(local_path):
                    saved = save_custom_image(local_path)
                    if saved and self.current_page:
                        self.current_page.bg_image = saved
                        self.background_dropped.emit(saved)
                        self.layout_changed.emit()
                        self.update()
                        event.acceptProposedAction()
                        return
        self.update()

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            # Clicking chassis background deselects button to show DeckInspector
            self.selected_button_id = None
            self.set_selected_button(None)
            self.button_selected.emit(None)
        super().mousePressEvent(event)

    def paintEvent(self, event: QPaintEvent):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)

        rect = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        radius = 22.0
        path = QPainterPath()
        path.addRoundedRect(rect, radius, radius)

        # Base chassis color fill
        bg_col_str = getattr(self.current_page, "bg_color", "") if self.current_page else ""
        if bg_col_str:
            painter.fillPath(path, QColor(bg_col_str))
        else:
            painter.fillPath(path, QColor(13, 13, 15))

        # Custom background image rendering
        bg_img_str = getattr(self.current_page, "bg_image", "") if self.current_page else ""
        if bg_img_str:
            p_obj = Path(bg_img_str)
            resolved = p_obj if (p_obj.exists() and p_obj.is_file()) else resolve_icon_path(bg_img_str)
            if resolved and resolved.exists():
                pix = QPixmap(str(resolved))
                if not pix.isNull():
                    painter.save()
                    painter.setClipPath(path)
                    scaled = pix.scaled(int(rect.width()), int(rect.height()), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                    sx = int(rect.center().x() - scaled.width() / 2)
                    sy = int(rect.center().y() - scaled.height() / 2)
                    painter.drawPixmap(sx, sy, scaled)

                    # Subtle translucent dark gradient overlay for optimal button legibility
                    overlay = QLinearGradient(0, rect.top(), 0, rect.bottom())
                    overlay.setColorAt(0.0, QColor(0, 0, 0, 105))
                    overlay.setColorAt(1.0, QColor(0, 0, 0, 165))
                    painter.fillRect(rect, overlay)
                    painter.restore()

        # Chassis rim stroke
        painter.strokePath(path, QPen(QColor(40, 40, 46), 1.5))

        # Drag hover visual indicator
        if self._is_drag_hovering_image:
            painter.fillPath(path, QColor(59, 130, 246, 50))
            glow_pen = QPen(QColor(59, 130, 246, 230), 2.0, Qt.DashLine)
            painter.strokePath(path, glow_pen)

            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Segoe UI Variable Text", 15, QFont.Bold))
            painter.drawText(self.rect(), Qt.AlignCenter, "Slip for at sætte som baggrund")

    @property
    def selected_button(self) -> Optional[ButtonModel]:
        if not self.current_page or not self.selected_button_id:
            return None
        return next((b for b in self.current_page.buttons if b.id == self.selected_button_id), None)

    def select_button(self, button: Optional[ButtonModel]):
        bid = button.id if button else None
        self.set_selected_button(bid)

    def set_page(self, page: Optional[PageModel], selected_button_id: Optional[str] = None):
        self.current_page = page
        self.selected_button_id = selected_button_id
        self.rebuild_grid()
        self.update()

    def set_selected_button(self, button_id: Optional[str]):
        self.selected_button_id = button_id
        for bid, tile in self.tiles_dict.items():
            tile.is_selected = (bid == button_id)
            tile.update()

    def rebuild_grid(self):
        # Clear existing tiles
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self.tiles_dict.clear()

        if not self.current_page:
            empty_lbl = QLabel("Ingen side valgt")
            empty_lbl.setAlignment(Qt.AlignCenter)
            empty_lbl.setStyleSheet("color: #8E8E93; font-size: 13px; background: transparent; border: none;")
            self.grid_layout.addWidget(empty_lbl, 0, 0)
            return

        rows = max(1, getattr(self.current_page, "rows", 3) or 3)
        cols = max(1, getattr(self.current_page, "cols", 4) or 4)

        gap = getattr(self.current_page, "button_gap", 14) or 14
        self.grid_layout.setSpacing(gap)

        pad = getattr(self.current_page, "grid_padding", 16) or 16
        self.grid_layout.setContentsMargins(pad, pad, pad, pad)

        default_radius = getattr(self.current_page, "button_radius", 28) or 28

        # Map button positions
        button_map = {}
        for btn in self.current_page.buttons:
            button_map[(btn.row, btn.col)] = btn

        for r in range(rows):
            self.grid_layout.setRowStretch(r, 1)
            for c in range(cols):
                if r == 0:
                    self.grid_layout.setColumnStretch(c, 1)

                btn = button_map.get((r, c))
                is_sel = bool(btn and btn.id == self.selected_button_id)
                tile = PreviewButtonTile(
                    btn, r, c,
                    is_selected=is_sel,
                    default_radius=default_radius,
                    parent=self.grid_container
                )

                if btn:
                    self.tiles_dict[btn.id] = tile

                tile.clicked.connect(self._on_tile_clicked)
                tile.right_clicked.connect(self._on_tile_right_clicked)
                tile.dropped_on.connect(self._on_tile_dropped_on)

                self.grid_layout.addWidget(tile, r, c)

    def _on_tile_clicked(self, tile_key: str):
        if tile_key.startswith("empty_"):
            parts = tile_key.split("_")
            row, col = int(parts[1]), int(parts[2])
            new_btn = self._create_button_at(row, col)
            self.button_selected.emit(new_btn)
        else:
            self.selected_button_id = tile_key
            self.set_selected_button(tile_key)
            for btn in self.current_page.buttons:
                if btn.id == tile_key:
                    self.button_selected.emit(btn)
                    return
            self.button_selected.emit(None)

    def _create_button_at(self, row: int, col: int) -> ButtonModel:
        if not self.current_page:
            return None
        import uuid
        new_btn = ButtonModel(
            id=str(uuid.uuid4())[:8],
            row=row,
            col=col,
            title=f"Knap {len(self.current_page.buttons) + 1}",
            bg_color="#141416",
            text_color="#FFFFFF",
            font_size=11,
            border_radius=28
        )
        self.current_page.buttons.append(new_btn)
        self.rebuild_grid()
        self.set_selected_button(new_btn.id)
        self.layout_changed.emit()
        return new_btn

    def _on_tile_right_clicked(self, button_id: str, global_pos: QPoint):
        menu = QMenu(self)
        test_act = menu.addAction("▶ Test Knap på PC")
        menu.addSeparator()
        clear_act = menu.addAction("Ryd Ikon")
        del_act = menu.addAction("Slet Knap")

        selected_action = menu.exec(global_pos)
        if not selected_action or not self.current_page:
            return

        target_btn = next((b for b in self.current_page.buttons if b.id == button_id), None)
        if not target_btn:
            return

        if selected_action == test_act:
            self.button_test_requested.emit(target_btn)
        elif selected_action == clear_act:
            target_btn.icon = ""
            self.rebuild_grid()
            self.layout_changed.emit()
        elif selected_action == del_act:
            self.current_page.buttons.remove(target_btn)
            if self.selected_button_id == button_id:
                self.selected_button_id = None
                self.button_selected.emit(None)
            self.rebuild_grid()
            self.layout_changed.emit()

    def _on_tile_dropped_on(self, source_id: str, target_id_or_empty: str):
        if not self.current_page:
            return
        source_btn = next((b for b in self.current_page.buttons if b.id == source_id), None)
        if not source_btn:
            return

        if target_id_or_empty.startswith("empty_"):
            parts = target_id_or_empty.split("_")
            source_btn.row = int(parts[1])
            source_btn.col = int(parts[2])
        else:
            target_btn = next((b for b in self.current_page.buttons if b.id == target_id_or_empty), None)
            if target_btn and target_btn != source_btn:
                # Swap positions
                source_btn.row, target_btn.row = target_btn.row, source_btn.row
                source_btn.col, target_btn.col = target_btn.col, source_btn.col

        self.rebuild_grid()
        self.set_selected_button(source_btn.id)
        self.button_selected.emit(source_btn)
        self.layout_changed.emit()

    def refresh_grid(self):
        self.rebuild_grid()

    def _delete_button(self, button: ButtonModel):
        if self.current_page and button in self.current_page.buttons:
            self.current_page.buttons.remove(button)
            if self.selected_button_id == button.id:
                self.selected_button_id = None
                self.button_selected.emit(None)
            self.rebuild_grid()
            self.layout_changed.emit()
