"""
TouchDeck / VENTRIX - Medal.tv Database Auto-Sync Service
Directly configures Medal's SQLite settings database so that each clip duration
(15s, 30s, 1m, 2m, 5m, Full Recording, Bookmark) has its own dedicated hotkey,
bypassing Medal's single-duration dropdown limitation.
"""

import os
import glob
import json
import logging
from typing import Tuple, List, Dict

try:
    import sqlite3
except ImportError:
    sqlite3 = None

logger = logging.getLogger("TouchDeck.MedalSync")

DEFAULT_MEDAL_HOTKEYS: List[Dict[str, str]] = [
    {"action": "clip;length=15", "device": "keyboard", "type": "short_press", "inputs": "CTRL + F8"},
    {"action": "clip;length=30", "device": "keyboard", "type": "short_press", "inputs": "F8"},
    {"action": "clip;length=60", "device": "keyboard", "type": "short_press", "inputs": "CTRL + F9"},
    {"action": "clip;length=120", "device": "keyboard", "type": "short_press", "inputs": "CTRL + F10"},
    {"action": "clip;length=300", "device": "keyboard", "type": "short_press", "inputs": "CTRL + F11"},
    {"action": "segment_toggle", "device": "keyboard", "type": "short_press", "inputs": "ALT + F7"},
    {"action": "bookmark", "device": "keyboard", "type": "short_press", "inputs": "F10"}
]


def find_medal_databases() -> List[str]:
    """Finds active Medal SQLite databases in %APPDATA%/Medal."""
    appdata = os.environ.get("APPDATA", "")
    if not appdata:
        return []
    pattern = os.path.join(appdata, "Medal", "medal-*.db")
    dbs = glob.glob(pattern)
    # Exclude guest databases unless no user db exists
    user_dbs = [d for d in dbs if "guest" not in os.path.basename(d).lower()]
    return user_dbs if user_dbs else dbs


def sync_hotkeys_to_medal() -> Tuple[bool, str]:
    """
    Injects the multi-duration hotkeys into Medal's SQLite database
    using SQLite's native jsonb() function.
    """
    if sqlite3 is None:
        return False, "sqlite3 modul ikke tilgængeligt i denne proces."

    dbs = find_medal_databases()
    if not dbs:
        return False, "Ingen Medal database fundet. Kontroller at Medal er installeret."

    hotkeys_json = json.dumps(DEFAULT_MEDAL_HOTKEYS)
    updated_count = 0

    for db_path in dbs:
        try:
            conn = sqlite3.connect(db_path, timeout=5.0)
            cur = conn.cursor()
            cur.execute("INSERT OR REPLACE INTO key_values VALUES ('Hotkeys', jsonb(?))", (hotkeys_json,))
            conn.commit()
            conn.close()
            updated_count += 1
            logger.info(f"Successfully injected Medal hotkeys into: {db_path}")
        except Exception as e:
            logger.error(f"Error updating Medal database at {db_path}: {e}")

    if updated_count > 0:
        return True, f"Genveje synkroniseret med succes til Medal ({updated_count} profil). Genstart Medal hvis det allerede kører."
    return False, "Kunne ikke skrive til Medal databasen."


def read_medal_hotkeys() -> List[Dict[str, str]]:
    """Reads the current hotkey configuration from Medal's database."""
    if sqlite3 is None:
        return []

    dbs = find_medal_databases()
    if not dbs:
        return []

    for db_path in dbs:
        try:
            conn = sqlite3.connect(db_path, timeout=3.0)
            cur = conn.cursor()
            cur.execute("SELECT json(value) FROM key_values WHERE key = 'Hotkeys'")
            row = cur.fetchone()
            conn.close()
            if row and row[0]:
                return json.loads(row[0])
        except Exception:
            pass
    return []
