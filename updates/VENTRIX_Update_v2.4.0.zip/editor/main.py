"""
VENTRIX - Stream Deck Studio Application Entry Point
"""

import sys
import os
from pathlib import Path
import logging

# Immediately hide any console/terminal window if launched via cmd or python.exe
if sys.platform == "win32":
    try:
        import ctypes
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)  # 0 = SW_HIDE
    except Exception:
        pass

# Ensure real application directory is on sys.path and prioritized
if getattr(sys, "frozen", False):
    PROJECT_ROOT = Path(sys.executable).parent.resolve()
    # Prioritize on-disk files over frozen bundle so in-app updates work seamlessly
    try:
        from importlib.machinery import PathFinder
        if PathFinder in sys.meta_path:
            sys.meta_path.remove(PathFinder)
            sys.meta_path.insert(0, PathFinder)
    except Exception:
        pass
    # Clean up any leftover .old files from previous updates
    for old_file in PROJECT_ROOT.glob("*.old"):
        try:
            old_file.unlink()
        except Exception:
            pass
else:
    PROJECT_ROOT = Path(__file__).parent.parent.resolve()

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon

from shared.config_store import ConfigStore
from shared.constants import APP_NAME, APP_VERSION
from editor.actions.action_engine import ActionEngine
from editor.networking.server import TouchDeckServer
from editor.ui.main_window import MainWindow

# Setup logging (file only when running windowed/pythonw, stream only if stdout exists)
log_dir = PROJECT_ROOT / "logs"
log_dir.mkdir(exist_ok=True)
handlers = [logging.FileHandler(log_dir / "editor.log", encoding="utf-8")]
if sys.stdout is not None:
    handlers.append(logging.StreamHandler(sys.stdout))

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] [%(name)s]: %(message)s",
    handlers=handlers
)
logger = logging.getLogger("TouchDeck.EditorMain")


import ctypes

def ensure_single_instance():
    """Ensures only ONE instance of VENTRIX runs, preventing server port collisions and UI desync."""
    if sys.platform == "win32":
        try:
            mutex_name = "Global\\VENTRIX_SingleInstance_Mutex"
            mutex = ctypes.windll.kernel32.CreateMutexW(None, False, mutex_name)
            last_error = ctypes.windll.kernel32.GetLastError()
            ERROR_ALREADY_EXISTS = 183
            if last_error == ERROR_ALREADY_EXISTS:
                logger.warning("Another instance of TouchDeck is already running. Focusing existing window and exiting.")
                hwnd = ctypes.windll.user32.FindWindowW(None, f"{APP_NAME} — Stream Deck Studio")
                if not hwnd:
                    hwnd = ctypes.windll.user32.FindWindowW(None, "TouchDeck Editor")
                if hwnd:
                    ctypes.windll.user32.ShowWindowAsync(hwnd, 9)
                    ctypes.windll.user32.SetForegroundWindow(hwnd)
                return False, mutex
            return True, mutex
        except Exception as e:
            logger.error(f"Single instance check error: {e}")
    return True, None


def main():
    is_primary, _mutex = ensure_single_instance()
    if not is_primary:
        sys.exit(0)

    logger.info(f"Starting {APP_NAME} Editor v{APP_VERSION}...")

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setQuitOnLastWindowClosed(False)

    # Initialize typography & custom embedded fonts
    try:
        from editor.utils.font_manager import init_application_fonts
        init_application_fonts(PROJECT_ROOT / "assets" / "fonts")
    except Exception as e:
        logger.warning(f"Failed loading custom fonts: {e}")

    # Set App Icon
    icon_path = PROJECT_ROOT / "assets" / "ventrix.ico"
    if not icon_path.exists():
        icon_path = PROJECT_ROOT / "assets" / "touchdeck.ico"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    # Initialize Core Subsystems
    config_store = ConfigStore()
    action_engine = ActionEngine()
    server = TouchDeckServer(config_store, action_engine)

    # Start network server
    server.start()

    # Silently ensure Medal multi-clip hotkeys are registered in background if Medal is installed
    try:
        import threading
        from editor.services.medal_sync import sync_hotkeys_to_medal
        threading.Thread(target=sync_hotkeys_to_medal, daemon=True).start()
    except Exception as e:
        logger.debug(f"Medal auto-sync error: {e}")

    # Create & show main window
    window = MainWindow(config_store, action_engine, server)
    window.show()

    exit_code = app.exec()

    # Cleanup on exit
    logger.info("Stopping TouchDeck server...")
    server.stop()
    sys.exit(exit_code)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        import traceback
        with open(PROJECT_ROOT / "logs" / "crash.log", "w", encoding="utf-8") as f:
            traceback.print_exc(file=f)
        raise
