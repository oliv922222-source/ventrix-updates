"""
TouchDeck - Asset and Icon Generator
Generates multi-resolution Windows touchdeck.ico and built-in button icons.
Author: NEXA
"""

import os
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ASSETS_DIR = Path(__file__).parent.resolve()
ICONS_DIR = ASSETS_DIR / "icons"


def create_touchdeck_icon():
    """Generates the official multi-resolution TouchDeck Windows .ico file."""
    ICONS_DIR.mkdir(parents=True, exist_ok=True)
    sizes = [256, 128, 64, 48, 32, 16]
    images = []

    for size in sizes:
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Outer rounded deck chassis
        pad = int(size * 0.04)
        corner_r = int(size * 0.18)
        
        # Base plate background: dark navy chassis #0D0F14
        draw.rounded_rectangle(
            [pad, pad, size - pad, size - pad],
            radius=corner_r,
            fill=(13, 15, 20, 255),
            outline=(41, 47, 58, 255),
            width=max(1, int(size * 0.03))
        )

        # Draw 2x2 grid of streamdeck buttons with glowing blue and cyan accents
        grid_pad = int(size * 0.18)
        gap = max(2, int(size * 0.08))
        btn_w = (size - 2 * grid_pad - gap) // 2
        btn_r = max(2, int(size * 0.06))

        colors = [
            ((37, 99, 235), (59, 130, 246)),   # Bright Blue
            ((34, 197, 94), (74, 222, 128)),   # Emerald Green
            ((245, 158, 11), (251, 191, 36)),  # Amber
            ((56, 189, 248), (125, 211, 252)), # Cyan
        ]

        idx = 0
        for row in range(2):
            for col in range(2):
                bx = grid_pad + col * (btn_w + gap)
                by = grid_pad + row * (btn_w + gap)
                fill_col, glow_col = colors[idx % len(colors)]
                idx += 1

                # Button base
                draw.rounded_rectangle(
                    [bx, by, bx + btn_w, by + btn_w],
                    radius=btn_r,
                    fill=(24, 28, 38, 255),
                    outline=glow_col,
                    width=max(1, int(size * 0.02))
                )

                # Inner light indicator
                dot_pad = int(btn_w * 0.28)
                draw.rounded_rectangle(
                    [bx + dot_pad, by + dot_pad, bx + btn_w - dot_pad, by + btn_w - dot_pad],
                    radius=max(1, btn_r // 2),
                    fill=fill_col
                )

        images.append(img)

    ico_path = ASSETS_DIR / "touchdeck.ico"
    images[0].save(
        str(ico_path),
        format="ICO",
        sizes=[(s, s) for s in sizes],
        append_images=images[1:]
    )
    print(f"[Assets] Generated {ico_path}")
    return ico_path


def create_vector_icons():
    """Generates crisp 128x128 PNG glyph icons for built-in button actions."""
    ICONS_DIR.mkdir(parents=True, exist_ok=True)
    icon_definitions = [
        ("obs", "OBS", "#3B82F6"),
        ("discord", "DISC", "#5865F2"),
        ("spotify", "SPOT", "#1DB954"),
        ("play_pause", "▶ ❚❚", "#F5F7FA"),
        ("next", "⏭", "#F5F7FA"),
        ("prev", "⏮", "#F5F7FA"),
        ("volume_up", "VOL+", "#38BDF8"),
        ("volume_down", "VOL-", "#38BDF8"),
        ("volume_mute", "MUTE", "#EF4444"),
        ("mic", "MIC", "#22C55E"),
        ("mic_mute", "MIC ✕", "#EF4444"),
        ("desktop", "DESK", "#8B95A7"),
        ("task_manager", "TASK", "#F59E0B"),
        ("settings", "⚙", "#8B95A7"),
        ("lock", "🔒", "#F59E0B"),
        ("sleep", "🌙", "#F59E0B"),
        ("stream_start", "LIVE", "#22C55E"),
        ("stream_stop", "END", "#EF4444"),
        ("record_start", "REC", "#EF4444"),
        ("record_stop", "STOP", "#8B95A7"),
        ("scene_main", "CAM", "#3B82F6"),
        ("game", "GAME", "#8B5CF6"),
        ("clock", "BRB", "#EC4899"),
        ("macro", "⚡", "#F59E0B"),
        ("folder", "DIR", "#FBBF24"),
        ("terminal", ">_", "#22C55E"),
        ("browser", "WEB", "#38BDF8"),
        ("code", "</>", "#A855F7"),
    ]

    for name, symbol, color in icon_definitions:
        size = 128
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Subtle dark circle background
        draw.ellipse([8, 8, size - 8, size - 8], fill=(24, 28, 38, 200), outline=(41, 47, 58, 255), width=2)

        # Draw symbol/text in center
        try:
            # Fallback simple text rendering
            bbox = draw.textbbox((0, 0), symbol)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
            tx = (size - tw) // 2
            ty = (size - th) // 2 - 2
            draw.text((tx, ty), symbol, fill=color)
        except Exception:
            draw.text((32, 48), symbol, fill=color)

        img_path = ICONS_DIR / f"{name}.png"
        img.save(str(img_path), format="PNG")

    print(f"[Assets] Generated {len(icon_definitions)} built-in icons in {ICONS_DIR}")


if __name__ == "__main__":
    create_touchdeck_icon()
    create_vector_icons()
