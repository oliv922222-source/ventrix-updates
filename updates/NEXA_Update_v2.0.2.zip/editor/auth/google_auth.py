"""
TouchDeck - Real Google OAuth 2.0 & OpenID Connect Architecture
RFC 8252 compliant desktop loopback authentication for Google Accounts.
Author: NEXA
"""

import os
import sys
import json
import base64
import hashlib
import secrets
import threading
import webbrowser
import urllib.request
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Optional, Dict, Any, Tuple

from PySide6.QtCore import QObject, Signal

AUTH_DIR = Path(os.environ.get("APPDATA", str(Path.home()))) / "TouchDeck"
AUTH_DIR.mkdir(parents=True, exist_ok=True)

SESSION_FILE = AUTH_DIR / "auth_session.json"
CREDENTIALS_FILE = AUTH_DIR / "google_credentials.json"
AVATAR_FILE = AUTH_DIR / "user_avatar.png"

# Default OAuth constants
DEFAULT_REDIRECT_PORT = 18890
GOOGLE_AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_ENDPOINT = "https://www.googleapis.com/oauth2/v3/userinfo"


def _generate_pkce_pair() -> Tuple[str, str]:
    """Generates PKCE code_verifier and code_challenge (S256)."""
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode("utf-8")).digest()
    challenge = base64.urlsafe_b64encode(digest).decode("utf-8").replace("=", "")
    return verifier, challenge


class GoogleAuthManager(QObject):
    """
    Manages genuine Google OAuth 2.0 login flow for desktop.
    Thread-safe Qt signal communication.
    """
    auth_started = Signal()
    auth_success = Signal(dict)    # {"name": ..., "email": ..., "picture": ..., "avatar_path": ...}
    auth_failed = Signal(str)      # Error message
    auth_logged_out = Signal()

    _instance = None

    @classmethod
    def get_instance(cls) -> "GoogleAuthManager":
        if cls._instance is None:
            cls._instance = GoogleAuthManager()
        return cls._instance

    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_user: Optional[Dict[str, Any]] = None
        self._http_server: Optional[HTTPServer] = None
        self._server_thread: Optional[threading.Thread] = None
        self._pending_state: Optional[str] = None
        self._pending_verifier: Optional[str] = None
        self.load_session()

    def get_credentials(self) -> Tuple[str, str]:
        """Returns (client_id, client_secret) from env or credentials file."""
        env_id = os.environ.get("GOOGLE_CLIENT_ID", "").strip()
        env_sec = os.environ.get("GOOGLE_CLIENT_SECRET", "").strip()
        if env_id:
            return env_id, env_sec

        if CREDENTIALS_FILE.exists():
            try:
                with open(CREDENTIALS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return data.get("client_id", "").strip(), data.get("client_secret", "").strip()
            except Exception:
                pass
        return "", ""

    def save_credentials(self, client_id: str, client_secret: str):
        """Persists Google Client ID & Secret for the desktop app."""
        data = {
            "client_id": client_id.strip(),
            "client_secret": client_secret.strip()
        }
        with open(CREDENTIALS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def load_session(self) -> Optional[Dict[str, Any]]:
        """Loads cached session from disk."""
        if SESSION_FILE.exists():
            try:
                with open(SESSION_FILE, "r", encoding="utf-8") as f:
                    self.current_user = json.load(f)
                    if AVATAR_FILE.exists():
                        self.current_user["avatar_path"] = str(AVATAR_FILE)
                    return self.current_user
            except Exception as e:
                print(f"[GoogleAuth] Error loading session: {e}")
                self.current_user = None
        return None

    def is_logged_in(self) -> bool:
        return self.current_user is not None and bool(self.current_user.get("email"))

    def get_user_display_name(self) -> str:
        if self.current_user:
            return self.current_user.get("name") or self.current_user.get("email", "User")
        return "Not signed in"

    def get_user_avatar_path(self) -> Optional[str]:
        if self.current_user and AVATAR_FILE.exists():
            return str(AVATAR_FILE)
        return None

    def sign_out(self):
        """Signs out the user and clears session files."""
        self.current_user = None
        if SESSION_FILE.exists():
            try:
                SESSION_FILE.unlink(missing_ok=True)
            except Exception:
                pass
        if AVATAR_FILE.exists():
            try:
                AVATAR_FILE.unlink(missing_ok=True)
            except Exception:
                pass
        self.auth_logged_out.emit()

    def start_login_flow(self):
        """Initiates genuine Google OAuth 2.0 sign-in via system browser."""
        client_id, client_secret = self.get_credentials()
        if not client_id:
            self.auth_failed.emit("CREDENTIALS_NEEDED")
            return

        self.auth_started.emit()
        self._pending_state = secrets.token_urlsafe(32)
        verifier, challenge = _generate_pkce_pair()
        self._pending_verifier = verifier

        redirect_uri = f"http://127.0.0.1:{DEFAULT_REDIRECT_PORT}/callback"

        # Start loopback server
        if self._http_server:
            try:
                self._http_server.shutdown()
            except Exception:
                pass

        auth_mgr = self

        class OAuthCallbackHandler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass  # Silent

            def do_GET(self):
                parsed = urllib.parse.urlparse(self.path)
                if parsed.path != "/callback":
                    self.send_response(404)
                    self.end_headers()
                    return

                params = urllib.parse.parse_qs(parsed.query)
                state = params.get("state", [""])[0]
                code = params.get("code", [""])[0]
                error = params.get("error", [""])[0]

                if error:
                    auth_mgr.auth_failed.emit(f"Google login afvist: {error}")
                    self._serve_response(False, f"Login annulleret ({error})")
                    return

                if not code or state != auth_mgr._pending_state:
                    auth_mgr.auth_failed.emit("Sikkerhedsvalidering fejlede (ugyldig state).")
                    self._serve_response(False, "Sikkerhedsvalidering fejlede.")
                    return

                # Success callback — exchange code in background
                self._serve_response(True, "Du er nu logget ind! Du kan lukke dette vindue.")
                threading.Thread(
                    target=auth_mgr._exchange_code_and_finish,
                    args=(code, client_id, client_secret, redirect_uri, verifier),
                    daemon=True
                ).start()

            def _serve_response(self, success: bool, msg: str):
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                status_color = "#10B981" if success else "#EF4444"
                html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>TouchDeck - Google Sign-In</title>
    <style>
        body {{
            background: #0B0E14;
            color: #F8FAFC;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }}
        .card {{
            background: rgba(22, 28, 44, 0.9);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            box-shadow: 0 20px 40px rgba(0,0,0,0.5);
            max-width: 420px;
        }}
        h1 {{ font-size: 22px; margin-bottom: 12px; color: {status_color}; }}
        p {{ color: #94A3B8; font-size: 14px; line-height: 1.5; }}
        .badge {{
            display: inline-block;
            margin-top: 16px;
            padding: 8px 18px;
            background: rgba(255,255,255,0.08);
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }}
    </style>
</head>
<body>
    <div class="card">
        <h1>{"✓ TouchDeck Forbundet" if success else "✕ Fejl"}</h1>
        <p>{msg}</p>
        <div class="badge">TouchDeck v2.0.0 — Du kan vende tilbage til appen</div>
    </div>
</body>
</html>"""
                self.wfile.write(html.encode("utf-8"))

        def run_server():
            try:
                self._http_server = HTTPServer(("127.0.0.1", DEFAULT_REDIRECT_PORT), OAuthCallbackHandler)
                self._http_server.handle_request()  # handle one callback request then finish
            except Exception as e:
                print(f"[GoogleAuth] Loopback server error: {e}")

        self._server_thread = threading.Thread(target=run_server, daemon=True)
        self._server_thread.start()

        # Build Authorization URL
        params = {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": "openid email profile",
            "state": self._pending_state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
            "access_type": "offline",
            "prompt": "select_account"
        }
        auth_url = f"{GOOGLE_AUTH_ENDPOINT}?{urllib.parse.urlencode(params)}"
        webbrowser.open(auth_url)

    def _exchange_code_and_finish(self, code: str, client_id: str, client_secret: str, redirect_uri: str, verifier: str):
        """Exchanges auth code for tokens and queries userinfo."""
        try:
            token_payload = {
                "code": code,
                "client_id": client_id,
                "client_secret": client_secret,
                "redirect_uri": redirect_uri,
                "grant_type": "authorization_code",
                "code_verifier": verifier
            }
            data = urllib.parse.urlencode(token_payload).encode("utf-8")
            req = urllib.request.Request(GOOGLE_TOKEN_ENDPOINT, data=data, method="POST")
            req.add_header("Content-Type", "application/x-www-form-urlencoded")

            with urllib.request.urlopen(req, timeout=10) as resp:
                token_resp = json.loads(resp.read().decode("utf-8"))

            access_token = token_resp.get("access_token")
            if not access_token:
                self.auth_failed.emit("Fik ingen access token fra Google.")
                return

            # Query UserInfo endpoint
            user_req = urllib.request.Request(GOOGLE_USERINFO_ENDPOINT)
            user_req.add_header("Authorization", f"Bearer {access_token}")

            with urllib.request.urlopen(user_req, timeout=10) as resp:
                user_info = json.loads(resp.read().decode("utf-8"))

            # Download avatar image
            avatar_url = user_info.get("picture")
            if avatar_url:
                try:
                    with urllib.request.urlopen(avatar_url, timeout=8) as img_resp:
                        with open(AVATAR_FILE, "wb") as f:
                            f.write(img_resp.read())
                    user_info["avatar_path"] = str(AVATAR_FILE)
                except Exception as e:
                    print(f"[GoogleAuth] Failed to download avatar: {e}")

            # Save session to file
            self.current_user = user_info
            with open(SESSION_FILE, "w", encoding="utf-8") as f:
                json.dump(user_info, f, indent=2)

            self.auth_success.emit(user_info)
        except Exception as e:
            self.auth_failed.emit(f"Fejl under token-udveksling: {str(e)}")
