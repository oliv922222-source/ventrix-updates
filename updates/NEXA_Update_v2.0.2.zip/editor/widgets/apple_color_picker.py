"""
TouchDeck - Apple Glass Color & Depth Picker
A sleek, all-in-one translucent glass color square with 2D spectrum canvas,
depth / brightness control (Lys / Mørk), and curated Apple glass swatches.
Never opens an external OS window.
Author: NEXA
"""

from typing import Optional
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QSlider, QPushButton,
    QFrame, QSizePolicy
)
from PySide6.QtGui import (
    QPainter, QColor, QFont, QPen, QBrush, QLinearGradient,
    QPainterPath, QMouseEvent, QPaintEvent, QImage
)
from PySide6.QtCore import Qt, Signal, QRectF, QPoint, QSize


class GlassSpectrumCanvas(QWidget):
    """
    2D Hue x Saturation color canvas.
    Renders an ultra-smooth 2D spectrum with an Apple-style circular reticle.
    """
    color_changed = Signal(float, float)  # hue (0..1), sat (0..1)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(120)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setCursor(Qt.CrossCursor)

        self.hue: float = 0.6   # 0..1
        self.sat: float = 0.5   # 0..1
        self.value: float = 0.5 # 0..1 (controlled by depth slider)
        self.is_dragging: bool = False

        self._cached_image: Optional[QImage] = None

    def set_hsv(self, h: float, s: float, v: float):
        self.hue = max(0.0, min(1.0, h))
        self.sat = max(0.0, min(1.0, s))
        self.value = max(0.0, min(1.0, v))
        self.update()

    def _render_spectrum(self, width: int, height: int):
        if width <= 0 or height <= 0:
            return
        img = QImage(width, height, QImage.Format_RGB32)
        v = self.value
        # Render a downsampled spectrum for smooth performance
        step = 2
        for x in range(0, width, step):
            h = x / float(width)
            for y in range(0, height, step):
                s = 1.0 - (y / float(height))
                col = QColor.fromHsvF(h, s, max(0.1, v))
                rgb = col.rgb()
                for dx in range(step):
                    for dy in range(step):
                        if x + dx < width and y + dy < height:
                            img.setPixel(x + dx, y + dy, rgb)
        self._cached_image = img

    def resizeEvent(self, event):
        self._cached_image = None
        super().resizeEvent(event)

    def paintEvent(self, event: QPaintEvent):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect().adjusted(1, 1, -1, -1)
        w, h = rect.width(), rect.height()
        if w <= 0 or h <= 0:
            return

        path = QPainterPath()
        path.addRoundedRect(QRectF(rect), 10, 10)
        painter.setClipPath(path)

        if not self._cached_image or self._cached_image.size() != self.size():
            self._render_spectrum(w, h)

        if self._cached_image:
            painter.drawImage(rect.topLeft(), self._cached_image)

        # Hairline specular rim border
        painter.setClipping(False)
        border_pen = QPen(QColor(255, 255, 255, 30), 1.0)
        painter.strokePath(path, border_pen)

        # Apple Circular Reticle Indicator
        rx = rect.left() + int(self.hue * w)
        ry = rect.top() + int((1.0 - self.sat) * h)

        painter.setPen(QPen(QColor(0, 0, 0, 180), 2.5))
        painter.setBrush(Qt.NoBrush)
        painter.drawEllipse(QPoint(rx, ry), 7, 7)

        painter.setPen(QPen(QColor(255, 255, 255, 240), 1.5))
        painter.drawEllipse(QPoint(rx, ry), 6, 6)

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self.is_dragging = True
            self._update_pos(event.pos())

    def mouseMoveEvent(self, event: QMouseEvent):
        if self.is_dragging:
            self._update_pos(event.pos())

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self.is_dragging = False

    def _update_pos(self, pos: QPoint):
        rect = self.rect().adjusted(1, 1, -1, -1)
        w = max(1, rect.width())
        h = max(1, rect.height())

        x = max(0, min(w, pos.x() - rect.left()))
        y = max(0, min(h, pos.y() - rect.top()))

        self.hue = x / float(w)
        self.sat = 1.0 - (y / float(h))
        self.update()
        self.color_changed.emit(self.hue, self.sat)


class AppleGlassColorPicker(QFrame):
    """
    Sleek Apple translucent glass color & depth box.
    Integrates directly into the inspector without opening an external OS window.
    """
    color_selected = Signal(str)  # hex string '#141416'

    def __init__(self, current_color: str = "#141416", parent=None):
        super().__init__(parent)
        self.setObjectName("cardFrame")
        self.current_hex = current_color

        # Parse initial HSV
        col = QColor(current_color)
        if not col.isValid():
            col = QColor("#141416")

        self.cur_h = col.hueF() if col.hueF() >= 0 else 0.0
        self.cur_s = col.saturationF()
        self.cur_v = max(0.08, col.valueF())

        self._init_ui()
        self._update_display(emit=False)

    def _init_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(10)

        # Header Row: Title + Color Pill + Hex Code
        header = QHBoxLayout()
        header.setSpacing(8)

        t_lbl = QLabel("FARVEVÆLGER")
        t_lbl.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 600; letter-spacing: 0.8px;")
        header.addWidget(t_lbl)
        header.addStretch()

        # Mini live color preview pill
        self.preview_pill = QLabel()
        self.preview_pill.setFixedSize(36, 18)
        self.preview_pill.setStyleSheet(f"""
            background-color: {self.current_hex};
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 9px;
        """)
        header.addWidget(self.preview_pill)

        self.hex_lbl = QLabel(self.current_hex.upper())
        self.hex_lbl.setStyleSheet("color: #FFFFFF; font-size: 11px; font-weight: 600; font-family: monospace;")
        header.addWidget(self.hex_lbl)

        lay.addLayout(header)

        # 2D Spectrum Box in the center
        self.spectrum = GlassSpectrumCanvas()
        self.spectrum.set_hsv(self.cur_h, self.cur_s, self.cur_v)
        self.spectrum.color_changed.connect(self._on_spectrum_changed)
        lay.addWidget(self.spectrum)

        # Farvedybde (Lys / Mørk) Section
        depth_header = QHBoxLayout()
        d_lbl = QLabel("FARVEDYBDE")
        d_lbl.setStyleSheet("color: #8E8E93; font-size: 9px; font-weight: 600; letter-spacing: 0.8px;")
        depth_header.addWidget(d_lbl)
        depth_header.addStretch()

        # Depth quick buttons: Mørk, Dyb, Lys
        for name, v_val in [("Mørk", 0.12), ("Dyb", 0.32), ("Lys", 0.80)]:
            btn = QPushButton(name)
            btn.setFixedHeight(18)
            btn.setStyleSheet("""
                QPushButton {
                    background: rgba(255, 255, 255, 0.06);
                    color: #8E8E93;
                    border: 1px solid rgba(255, 255, 255, 0.08);
                    border-radius: 4px;
                    padding: 1px 6px;
                    font-size: 10px;
                }
                QPushButton:hover {
                    background: rgba(255, 255, 255, 0.14);
                    color: #FFFFFF;
                }
            """)
            btn.clicked.connect(lambda checked=False, val=v_val: self._set_depth_value(val))
            depth_header.addWidget(btn)

        lay.addLayout(depth_header)

        # Smooth Depth / Brightness Slider (Mørk ───●─── Lys)
        slider_row = QHBoxLayout()
        slider_row.setSpacing(8)

        dark_icon = QLabel("Mørk")
        dark_icon.setStyleSheet("color: #8E8E93; font-size: 10px;")
        slider_row.addWidget(dark_icon)

        self.depth_slider = QSlider(Qt.Horizontal)
        self.depth_slider.setRange(8, 96)
        self.depth_slider.setValue(int(self.cur_v * 100))
        self.depth_slider.valueChanged.connect(self._on_depth_slider_changed)
        slider_row.addWidget(self.depth_slider, stretch=1)

        light_icon = QLabel("Lys")
        light_icon.setStyleSheet("color: #8E8E93; font-size: 10px;")
        slider_row.addWidget(light_icon)

        lay.addLayout(slider_row)

        # Curated Apple Glass Swatches Row
        swatch_lbl = QLabel("APPLE GLASS PRESETS")
        swatch_lbl.setStyleSheet("color: #A1A1AA; font-size: 10px; font-weight: 700; letter-spacing: 0.8px; margin-top: 4px;")
        lay.addWidget(swatch_lbl)

        swatch_row = QHBoxLayout()
        swatch_row.setSpacing(7)

        apple_presets = [
            ("#0E1015", "Obsidian"),
            ("#181920", "Space Black"),
            ("#282A36", "Titanium Gray"),
            ("#1E293B", "Pacific Midnight"),
            ("#1A2E22", "Forest Emerald"),
            ("#3B1E24", "Crimson Wine"),
            ("#2E1E3B", "Imperial Violet"),
            ("#F4F4F5", "Apple Frosted White"),
        ]

        for hex_col, tooltip in apple_presets:
            s_btn = QPushButton()
            s_btn.setFixedSize(26, 26)
            s_btn.setToolTip(tooltip)
            s_btn.setCursor(Qt.PointingHandCursor)
            border_col = "rgba(0, 0, 0, 0.4)" if hex_col == "#F4F4F5" else "rgba(255, 255, 255, 0.25)"
            s_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {hex_col};
                    border: 1.5px solid {border_col};
                    border-radius: 8px;
                }}
                QPushButton:hover {{
                    border: 1.5px solid #FFFFFF;
                }}
                QPushButton:pressed {{
                    border: 2px solid #FFFFFF;
                }}
            """)
            s_btn.clicked.connect(lambda checked=False, col=hex_col: self.set_color_hex(col))
            swatch_row.addWidget(s_btn)

        swatch_row.addStretch()
        lay.addLayout(swatch_row)

    def _on_spectrum_changed(self, h: float, s: float):
        self.cur_h = h
        self.cur_s = s
        self._update_display()

    def _on_depth_slider_changed(self, val: int):
        self.cur_v = val / 100.0
        self.spectrum.value = self.cur_v
        self.spectrum._cached_image = None
        self.spectrum.update()
        self._update_display()

    def _set_depth_value(self, val: float):
        self.depth_slider.setValue(int(val * 100))

    def _update_display(self, emit: bool = True):
        # Calculate resulting color
        col = QColor.fromHsvF(self.cur_h, self.cur_s, self.cur_v)
        self.current_hex = col.name()

        self.preview_pill.setStyleSheet(f"""
            background-color: {self.current_hex};
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 9px;
        """)
        self.hex_lbl.setText(self.current_hex.upper())

        if emit:
            self.color_selected.emit(self.current_hex)

    def set_color_hex(self, hex_code: str):
        col = QColor(hex_code)
        if not col.isValid():
            return
        self.cur_h = col.hueF() if col.hueF() >= 0 else 0.0
        self.cur_s = col.saturationF()
        self.cur_v = max(0.08, col.valueF())

        self.depth_slider.blockSignals(True)
        self.depth_slider.setValue(int(self.cur_v * 100))
        self.depth_slider.blockSignals(False)

        self.spectrum.set_hsv(self.cur_h, self.cur_s, self.cur_v)
        self.spectrum._cached_image = None
        self.spectrum.update()

        self._update_display(emit=True)

    def set_color(self, hex_code: str):
        self.set_color_hex(hex_code)

