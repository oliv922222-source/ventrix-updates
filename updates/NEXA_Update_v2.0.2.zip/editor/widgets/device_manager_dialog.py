"""
TouchDeck - Device Management & Pairing Dialog
Author: NEXA
"""

import time
from typing import List

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QFrame,
    QMessageBox
)
from PySide6.QtCore import Qt, Signal

from shared.models import DeviceModel
from shared.config_store import ConfigStore
from editor.networking.server import TouchDeckServer
from shared.constants import (
    COLOR_BG, COLOR_CARD, COLOR_BORDER, COLOR_PRIMARY_BLUE,
    COLOR_BRIGHT_BLUE, COLOR_SUCCESS, COLOR_ERROR, COLOR_TEXT_MUTED
)


class DeviceManagerDialog(QDialog):
    def __init__(self, config_store: ConfigStore, server: TouchDeckServer, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Surface Device Manager")
        self.setFixedSize(620, 480)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)

        self.config_store = config_store
        self.server = server

        self._init_ui()
        self._refresh_devices_table()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        # Pairing Code Card
        code_card = QFrame()
        code_card.setStyleSheet(f"""
            QFrame {{
                background-color: #11141C;
                border: 1px solid {COLOR_PRIMARY_BLUE};
                border-radius: 10px;
                padding: 14px;
            }}
        """)
        code_layout = QVBoxLayout(code_card)
        code_layout.setSpacing(6)

        code_title = QLabel("SURFACE PAIRING CODE")
        code_title.setStyleSheet("font-size: 11px; font-weight: 700; color: #8B95A7; letter-spacing: 1px;")
        code_layout.addWidget(code_title)

        code_row = QHBoxLayout()
        self.pin_label = QLabel(self.server.active_pairing_code)
        self.pin_label.setStyleSheet(f"font-size: 28px; font-weight: 800; color: {COLOR_BRIGHT_BLUE}; letter-spacing: 6px;")
        code_row.addWidget(self.pin_label)

        code_row.addStretch()

        regen_btn = QPushButton("New Code")
        regen_btn.clicked.connect(self._regenerate_code)
        code_row.addWidget(regen_btn)

        code_layout.addLayout(code_row)

        desc = QLabel("Enter this 6-digit code on your Microsoft Surface to complete pairing.")
        desc.setStyleSheet("color: #8B95A7; font-size: 11px;")
        code_layout.addWidget(desc)

        layout.addWidget(code_card)

        # Paired Devices List Header
        dev_header = QLabel("PAIRED TOUCHDECK DEVICES")
        dev_header.setStyleSheet("font-size: 12px; font-weight: 700; color: #8B95A7;")
        layout.addWidget(dev_header)

        # Table
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Device Name", "IP Address", "Status", "Actions"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        layout.addWidget(self.table)

        # Bottom Bar
        bottom_bar = QHBoxLayout()
        bottom_bar.addStretch()
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        bottom_bar.addWidget(close_btn)
        layout.addLayout(bottom_bar)

    def _regenerate_code(self):
        new_code = self.server.generate_new_pairing_code()
        self.pin_label.setText(new_code)

    def _refresh_devices_table(self):
        devices = self.config_store.devices
        self.table.setRowCount(len(devices))

        for row, dev in enumerate(devices):
            self.table.setItem(row, 0, QTableWidgetItem(dev.name))
            self.table.setItem(row, 1, QTableWidgetItem(dev.last_ip or "Unknown"))

            # Check if active in server connections
            is_active = any(info.get("device_id") == dev.device_id for info in self.server.active_connections.values())
            status_text = "● Connected" if is_active else "○ Offline"
            status_item = QTableWidgetItem(status_text)
            status_item.setForeground(QColor(COLOR_SUCCESS if is_active else COLOR_TEXT_MUTED))
            self.table.setItem(row, 2, status_item)

            # Action button
            forget_btn = QPushButton("Forget")
            forget_btn.setObjectName("dangerBtn")
            forget_btn.clicked.connect(lambda ch=False, d_id=dev.device_id: self._forget_device(d_id))
            self.table.setCellWidget(row, 3, forget_btn)

    def _forget_device(self, device_id: str):
        reply = QMessageBox.question(
            self,
            "Forget Device",
            "Are you sure you want to forget and unpair this device?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self.config_store.devices = [d for d in self.config_store.devices if d.device_id != device_id]
            self.config_store.save_devices()
            self._refresh_devices_table()
