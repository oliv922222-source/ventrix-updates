"""
TouchDeck Editor Widgets Package
Author: NEXA
"""

from editor.widgets.live_surface_preview import LiveSurfacePreview
from editor.widgets.button_inspector import ButtonInspector
from editor.widgets.icon_picker_dialog import IconPickerDialog
from editor.widgets.macro_editor_dialog import MacroEditorDialog
from editor.widgets.device_manager_dialog import DeviceManagerDialog
from editor.widgets.usb_deployment_dialog import UsbDeploymentDialog
from editor.widgets.settings_dialog import SettingsDialog

__all__ = [
    "LiveSurfacePreview",
    "ButtonInspector",
    "IconPickerDialog",
    "MacroEditorDialog",
    "DeviceManagerDialog",
    "UsbDeploymentDialog",
    "SettingsDialog"
]
