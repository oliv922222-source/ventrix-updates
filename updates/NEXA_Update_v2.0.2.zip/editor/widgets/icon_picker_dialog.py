"""
TouchDeck - Icon Picker Dialog
Allows selecting built-in icons or custom image files (PNG, SVG, ICO, JPG).
Author: NEXA
"""

import os
from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QLineEdit, QFileDialog, QScrollArea, QWidget,
    QFrame
)
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtCore import Qt, QSize, Signal

from shared.constants import (
    COLOR_BG, COLOR_CARD, COLOR_CARD_HOVER, COLOR_BORDER,
    COLOR_PRIMARY_BLUE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED
)


class IconTile(QPushButton):
    def __init__(self, icon_name: str, icon_path: Path, parent=None):
        super().__init__(parent)
        self.icon_name = icon_name
        self.icon_path = icon_path

        self.setFixedSize(68, 68)
        self.setCursor(Qt.PointingHandCursor)
        self.setIcon(QIcon(str(icon_path)))
        self.setIconSize(QSize(36, 36))
        self.setToolTip(icon_name)

        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLOR_CARD};
                border: 1px solid {COLOR_BORDER};
                border-radius: 8px;
            }}
            QPushButton:hover {{
                background-color: {COLOR_CARD_HOVER};
                border: 1px solid {COLOR_PRIMARY_BLUE};
            }}
        """)


class IconPickerDialog(QDialog):
    icon_selected = Signal(str)  # Emits icon name or custom file path

    def __init__(self, current_icon: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Select Button Icon")
        self.setFixedSize(540, 480)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)

        self.selected_icon_value = current_icon
        self.assets_icons_dir = Path(__file__).parent.parent.parent / "assets" / "icons"
        self.tiles = []

        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(14)

        # Header and search
        top_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search built-in icons...")
        self.search_input.textChanged.connect(self._filter_icons)
        top_row.addWidget(self.search_input)

        browse_file_btn = QPushButton("Browse Custom File...")
        browse_file_btn.clicked.connect(self._browse_custom_file)
        top_row.addWidget(browse_file_btn)
        layout.addLayout(top_row)

        # Icon Grid Scroll Area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet(f"background-color: {COLOR_BG}; border: 1px solid {COLOR_BORDER}; border-radius: 8px;")

        self.grid_container = QWidget()
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setSpacing(10)
        self.grid_layout.setContentsMargins(12, 12, 12, 12)

        self._populate_icons()
        scroll.setWidget(self.grid_container)
        layout.addWidget(scroll)

        # Bottom Buttons
        bottom_row = QHBoxLayout()
        clear_btn = QPushButton("No Icon")
        clear_btn.clicked.connect(self._clear_icon)
        bottom_row.addWidget(clear_btn)

        bottom_row.addStretch()

        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        bottom_row.addWidget(cancel_btn)

        layout.addLayout(bottom_row)

    def _populate_icons(self):
        # Clear existing
        for t in self.tiles:
            self.grid_layout.removeWidget(t)
            t.deleteLater()
        self.tiles.clear()

        if not self.assets_icons_dir.exists():
            return

        icon_files = sorted(list(self.assets_icons_dir.glob("*.png")))
        cols = 6
        for idx, icon_file in enumerate(icon_files):
            name = icon_file.stem
            tile = IconTile(name, icon_file)
            tile.clicked.connect(lambda checked=False, n=name: self._on_icon_tile_clicked(n))
            self.tiles.append(tile)
            r = idx // cols
            c = idx % cols
            self.grid_layout.addWidget(tile, r, c)

    def _filter_icons(self, query: str):
        query = query.lower().strip()
        visible_idx = 0
        cols = 6
        for tile in self.tiles:
            if not query or query in tile.icon_name.lower():
                tile.show()
                self.grid_layout.removeWidget(tile)
                self.grid_layout.addWidget(tile, visible_idx // cols, visible_idx % cols)
                visible_idx += 1
            else:
                tile.hide()

    def _on_icon_tile_clicked(self, icon_name: str):
        self.selected_icon_value = icon_name
        self.icon_selected.emit(icon_name)
        self.accept()

    def _browse_custom_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Custom Icon Image",
            "",
            "Image Files (*.png *.ico *.svg *.jpg *.jpeg)"
        )
        if file_path:
            self.selected_icon_value = file_path
            self.icon_selected.emit(file_path)
            self.accept()

    def _clear_icon(self):
        self.selected_icon_value = ""
        self.icon_selected.emit("")
        self.accept()

    def get_selected_icon(self) -> str:
        return self.selected_icon_value

