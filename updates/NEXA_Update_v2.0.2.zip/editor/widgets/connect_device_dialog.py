"""
NEXA - Connect Device Dialog (Phone & iPad Pairing)
Ultra-Premium Apple Obsidian Glass Standalone Modal.
Frameless, floating frosted obsidian glass card with pure monochrome Apple aesthetic.
Zero Windows titlebar borders, pure Apple VisionOS / macOS glass styling.
"""

import io
import time
from typing import List, Optional
from pathlib import Path

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QWidget, QScrollArea, QApplication, QGraphicsDropShadowEffect
)
from PySide6.QtGui import (
    QPixmap, QImage, QColor, QFont, QPainter, QRadialGradient,
    QLinearGradient, QBrush, QPen, QPainterPath, QCursor
)
from PySide6.QtCore import Qt, Signal, QPoint, QRectF

from shared.models import DeviceModel
from shared.config_store import ConfigStore
from editor.networking.server import TouchDeckServer
from shared.i18n import t, I18nManager


class GlassCard(QFrame):
    """Deep obsidian Apple frosted glass card with ambient rim lighting."""
    def __init__(self, parent=None, radius: int = 24):
        super().__init__(parent)
        self.radius = radius

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect()
        path = QPainterPath()
        path.addRoundedRect(rect.adjusted(1, 1, -1, -1), self.radius, self.radius)

        # Base obsidian frosted fill
        painter.fillPath(path, QColor(14, 16, 22, 248))

        # Soft top ambient glass halo (Apple lighting)
        halo_grad = QRadialGradient(rect.center().x(), rect.top() + 25, rect.width() * 0.65)
        halo_grad.setColorAt(0.0, QColor(255, 255, 255, 22))
        halo_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.setPen(Qt.NoPen)
        painter.setBrush(halo_grad)
        painter.drawRoundedRect(rect.adjusted(2, 2, -2, int(rect.height() * 0.40)), self.radius, self.radius)

        # Subtle white rim border
        border_pen = QPen(QColor(255, 255, 255, 28), 1.2)
        painter.setPen(border_pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(path)


class ConnectDeviceDialog(QDialog):
    """
    Ultra-Premium Apple Frameless Obsidian Glass dialog.
    Pure monochrome black & white aesthetic with no standard Windows titlebars.
    """

    def __init__(self, config_store: ConfigStore, server: TouchDeckServer, parent=None):
        super().__init__(parent)
        self.config_store = config_store
        self.server = server

        self.setWindowTitle(t("pair_modal_title"))
        self.setFixedSize(700, 560)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self._drag_pos = QPoint()
        self._init_ui()
        self._generate_qr_code()
        self._refresh_device_list()

        # Connect to server updates
        self.server.on_client_connected = self._on_device_updated
        self.server.on_client_disconnected = self._on_device_updated

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and not self._drag_pos.isNull():
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(12, 12, 12, 12)

        self.card = GlassCard(self, radius=26)
        card_lay = QVBoxLayout(self.card)
        card_lay.setContentsMargins(28, 22, 28, 24)
        card_lay.setSpacing(16)

        # Header Row
        header_lay = QHBoxLayout()
        header_lay.setContentsMargins(0, 0, 0, 0)

        # Device Icon Badge
        badge = QLabel()
        badge.setFixedSize(40, 40)
        badge.setAlignment(Qt.AlignCenter)
        pix = QPixmap(40, 40)
        pix.fill(Qt.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.Antialiasing)
        b_path = QPainterPath()
        b_path.addRoundedRect(1, 1, 38, 38, 12, 12)
        p.fillPath(b_path, QColor(255, 255, 255, 18))
        p.setPen(QPen(QColor(255, 255, 255, 45), 1.0))
        p.drawPath(b_path)
        p.setPen(QColor("#FFFFFF"))
        p.setFont(QFont("-apple-system", 16, QFont.Bold))
        p.drawText(pix.rect(), Qt.AlignCenter, "📱")
        p.end()
        badge.setPixmap(pix)
        header_lay.addWidget(badge)

        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        title_box.setContentsMargins(6, 0, 0, 0)

        self.title_lbl = QLabel(t("pair_modal_title"))
        self.title_lbl.setStyleSheet("""
            font-size: 19px;
            font-weight: 800;
            color: #FFFFFF;
            letter-spacing: -0.4px;
            font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", sans-serif;
        """)
        title_box.addWidget(self.title_lbl)

        self.subtitle_lbl = QLabel(t("pair_modal_subtitle"))
        self.subtitle_lbl.setStyleSheet("""
            font-size: 12px;
            color: #8E8E93;
            font-weight: 400;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        """)
        title_box.addWidget(self.subtitle_lbl)
        header_lay.addLayout(title_box)

        header_lay.addStretch()

        # Minimalist Apple Close Button (Circular frosted button)
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(30, 30)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #8E8E93;
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 15px;
                font-size: 13px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.20);
                color: #FFFFFF;
                border-color: rgba(255, 255, 255, 0.30);
            }
        """)
        close_btn.clicked.connect(self.accept)
        header_lay.addWidget(close_btn)
        card_lay.addLayout(header_lay)

        # Main Pairing Card (Apple Obsidian Container)
        inner_card = QFrame()
        inner_card.setStyleSheet("""
            QFrame {
                background: rgba(255, 255, 255, 0.03);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 18px;
            }
        """)
        inner_lay = QHBoxLayout(inner_card)
        inner_lay.setContentsMargins(20, 20, 20, 20)
        inner_lay.setSpacing(24)

        # Left Column: QR Code + Clean Step 2 Label
        qr_box = QVBoxLayout()
        qr_box.setAlignment(Qt.AlignCenter)
        qr_box.setSpacing(10)

        # Pure white rounded card for high-contrast QR scanning
        self.qr_frame = QFrame()
        self.qr_frame.setFixedSize(160, 160)
        self.qr_frame.setStyleSheet("""
            QFrame {
                background: #FFFFFF;
                border-radius: 16px;
                border: 1px solid rgba(255, 255, 255, 0.3);
            }
        """)
        qr_inner_lay = QVBoxLayout(self.qr_frame)
        qr_inner_lay.setContentsMargins(8, 8, 8, 8)
        qr_inner_lay.setAlignment(Qt.AlignCenter)

        self.qr_label = QLabel()
        self.qr_label.setFixedSize(144, 144)
        self.qr_label.setAlignment(Qt.AlignCenter)
        self.qr_label.setStyleSheet("background: transparent; border: none;")
        qr_inner_lay.addWidget(self.qr_label)
        qr_box.addWidget(self.qr_frame, alignment=Qt.AlignCenter)

        qr_hint = QLabel("2. " + t("pair_step2"))
        qr_hint.setWordWrap(True)
        qr_hint.setFixedWidth(160)
        qr_hint.setStyleSheet("""
            font-size: 11px;
            color: #A1A1AA;
            line-height: 1.3;
            text-align: center;
        """)
        qr_hint.setAlignment(Qt.AlignCenter)
        qr_box.addWidget(qr_hint, alignment=Qt.AlignCenter)

        inner_lay.addLayout(qr_box)

        # Right Column: Instructions, PIN, and Link
        info_box = QVBoxLayout()
        info_box.setSpacing(10)
        info_box.setAlignment(Qt.AlignVCenter)

        step1 = QLabel(t("pair_step1"))
        step1.setStyleSheet("font-size: 13px; color: #E4E4E7; font-weight: 500;")
        step1.setWordWrap(True)
        info_box.addWidget(step1)

        step3 = QLabel(t("pair_step3"))
        step3.setStyleSheet("font-size: 13px; color: #E4E4E7; font-weight: 500;")
        step3.setWordWrap(True)
        info_box.addWidget(step3)

        # PIN Capsule Row (Apple Obsidian Glass Pill)
        pin_row = QHBoxLayout()
        pin_row.setSpacing(12)

        self.pin_label = QLabel()
        self.pin_label.setStyleSheet("""
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.25);
            border-radius: 12px;
            padding: 8px 20px;
            font-size: 26px;
            font-weight: 800;
            color: #FFFFFF;
            letter-spacing: 7px;
            font-family: "SF Mono", "Consolas", "Courier New", monospace;
        """)
        self._update_pin_text()
        pin_row.addWidget(self.pin_label)

        new_code_btn = QPushButton(t("pair_new_code"))
        new_code_btn.setCursor(Qt.PointingHandCursor)
        new_code_btn.setFixedHeight(44)
        new_code_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.16);
                border-radius: 12px;
                padding: 0 16px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.16);
                border-color: rgba(255, 255, 255, 0.35);
            }
            QPushButton:pressed {
                background: rgba(255, 255, 255, 0.22);
            }
        """)
        new_code_btn.clicked.connect(self._regenerate_code)
        pin_row.addWidget(new_code_btn)
        pin_row.addStretch()

        info_box.addLayout(pin_row)

        # Direct LAN Link Row
        link_row = QHBoxLayout()
        link_row.setSpacing(10)

        local_ip = self.server.get_local_ip()
        self.direct_url = f"http://{local_ip}:18888"

        self.url_label = QLabel(self.direct_url)
        self.url_label.setStyleSheet("""
            font-size: 13px;
            color: #D4D4D8;
            font-family: "SF Mono", "Consolas", monospace;
            padding: 6px 12px;
            background: rgba(255, 255, 255, 0.04);
            border-radius: 8px;
            border: 1px solid rgba(255, 255, 255, 0.08);
        """)
        link_row.addWidget(self.url_label)

        self.copy_btn = QPushButton(t("pair_copy_link"))
        self.copy_btn.setCursor(Qt.PointingHandCursor)
        self.copy_btn.setFixedHeight(34)
        self.copy_btn.setStyleSheet("""
            QPushButton {
                background: #FFFFFF;
                color: #000000;
                border: none;
                border-radius: 9px;
                padding: 0 16px;
                font-size: 12px;
                font-weight: 700;
            }
            QPushButton:hover {
                background: #E5E5EA;
            }
            QPushButton:pressed {
                background: #D1D1D6;
            }
        """)
        self.copy_btn.clicked.connect(self._copy_link)
        link_row.addWidget(self.copy_btn)
        link_row.addStretch()

        info_box.addLayout(link_row)
        inner_lay.addLayout(info_box)
        card_lay.addWidget(inner_card)

        # Connected Devices Section
        dev_row = QHBoxLayout()
        dev_title = QLabel(t("pair_connected_devices").upper())
        dev_title.setStyleSheet("""
            font-size: 11px;
            font-weight: 700;
            color: #71717A;
            letter-spacing: 0.8px;
        """)
        dev_row.addWidget(dev_title)
        dev_row.addStretch()
        card_lay.addLayout(dev_row)

        self.dev_scroll = QScrollArea()
        self.dev_scroll.setWidgetResizable(True)
        self.dev_scroll.setFixedHeight(105)
        self.dev_scroll.setStyleSheet("""
            QScrollArea {
                background: rgba(255, 255, 255, 0.02);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 14px;
            }
            QScrollArea > QWidget > QWidget {
                background: transparent;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 6px;
                margin: 0;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 0.15);
                border-radius: 3px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background: rgba(255, 255, 255, 0.30);
            }
        """)

        self.dev_container = QWidget()
        self.dev_container.setStyleSheet("background: transparent;")
        self.dev_container_lay = QVBoxLayout(self.dev_container)
        self.dev_container_lay.setContentsMargins(12, 10, 12, 10)
        self.dev_container_lay.setSpacing(6)
        self.dev_scroll.setWidget(self.dev_container)
        card_lay.addWidget(self.dev_scroll)

        root_lay.addWidget(self.card)

    def _update_pin_text(self):
        code = self.server.active_pairing_code
        if len(code) == 6:
            formatted = f"{code[:3]} {code[3:]}"
        else:
            formatted = code
        self.pin_label.setText(formatted)

    def _generate_qr_code(self):
        try:
            import qrcode
            local_ip = self.server.get_local_ip()
            url = f"http://{local_ip}:18888"

            qr = qrcode.QRCode(box_size=6, border=1)
            qr.add_data(url)
            qr.make(fit=True)
            img = qr.make_image(fill_color="#000000", back_color="#FFFFFF")

            buf = io.BytesIO()
            img.save(buf, format="PNG")
            qimg = QImage.fromData(buf.getvalue())
            pix = QPixmap.fromImage(qimg).scaled(144, 144, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.qr_label.setPixmap(pix)
        except Exception as e:
            self.qr_label.setText(f"QR Fejl: {e}")

    def _regenerate_code(self):
        self.server.generate_new_pairing_code()
        self._update_pin_text()

    def _copy_link(self):
        QApplication.clipboard().setText(self.direct_url)
        self.copy_btn.setText(t("pair_copied"))
        from PySide6.QtCore import QTimer
        QTimer.singleShot(2000, lambda: self.copy_btn.setText(t("pair_copy_link")))

    def _on_device_updated(self, *args):
        # Safely invoke refresh on UI thread
        self._refresh_device_list()

    def _refresh_device_list(self):
        # Clear existing items
        while self.dev_container_lay.count():
            item = self.dev_container_lay.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

        devices = self.config_store.devices
        paired_devs = [d for d in devices if d.paired]

        if not paired_devs:
            empty_lbl = QLabel(t("pair_no_devices"))
            empty_lbl.setStyleSheet("color: #71717A; font-size: 12px; font-style: italic; padding: 4px;")
            self.dev_container_lay.addWidget(empty_lbl)
            self.dev_container_lay.addStretch()
            return

        for dev in paired_devs:
            row = QFrame()
            row.setStyleSheet("""
                QFrame {
                    background: rgba(255, 255, 255, 0.05);
                    border: 1px solid rgba(255, 255, 255, 0.08);
                    border-radius: 10px;
                    padding: 4px 10px;
                }
                QFrame:hover {
                    background: rgba(255, 255, 255, 0.08);
                    border-color: rgba(255, 255, 255, 0.16);
                }
            """)
            row_lay = QHBoxLayout(row)
            row_lay.setContentsMargins(8, 4, 8, 4)

            # Glowing status dot (Apple Emerald)
            dot = QLabel("●")
            dot.setStyleSheet("color: #34D399; font-size: 14px; margin-right: 4px;")
            row_lay.addWidget(dot)

            name = QLabel(dev.name or "Telefon / Tablet")
            name.setStyleSheet("font-size: 13px; font-weight: 600; color: #FFFFFF;")
            row_lay.addWidget(name)

            ip = QLabel(f"({dev.last_ip or 'Wi-Fi'})")
            ip.setStyleSheet("font-size: 11px; color: #A1A1AA;")
            row_lay.addWidget(ip)

            row_lay.addStretch()

            unpair_btn = QPushButton(t("pair_disconnect"))
            unpair_btn.setCursor(Qt.PointingHandCursor)
            unpair_btn.setStyleSheet("""
                QPushButton {
                    background: transparent;
                    color: #F87171;
                    border: 1px solid rgba(248, 113, 113, 0.35);
                    border-radius: 8px;
                    padding: 4px 12px;
                    font-size: 11px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background: rgba(239, 68, 68, 0.18);
                    border-color: #EF4444;
                    color: #FFFFFF;
                }
            """)
            unpair_btn.clicked.connect(lambda _, d=dev: self._disconnect_device(d))
            row_lay.addWidget(unpair_btn)

            self.dev_container_lay.addWidget(row)

        self.dev_container_lay.addStretch()

    def _disconnect_device(self, dev: DeviceModel):
        dev.paired = False
        dev.auth_token = ""
        self.config_store.save_devices()
        self._refresh_device_list()
