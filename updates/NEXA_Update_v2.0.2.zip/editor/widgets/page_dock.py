"""
TouchDeck - Floating Glass Page Dock
Inspired by macOS / iOS floating dock. Replaces the old vertical left sidebar.
Strict Monochromatic Black, White & Real Translucent Glass.
Author: NEXA
"""

from typing import List, Optional
from PySide6.QtWidgets import (
    QWidget, QFrame, QHBoxLayout, QPushButton, QLabel, QMenu,
    QScrollArea
)
from PySide6.QtGui import (
    QPainter, QColor, QFont, QPen, QLinearGradient, QPainterPath
)
from PySide6.QtCore import Qt, Signal, QRectF, QPoint

from shared.models import PageModel
from editor.widgets.apple_dialogs import AppleGlassInputDialog, AppleGlassConfirmDialog


class DockPageItem(QPushButton):
    """Sleek translucent pill item inside the bottom dock."""

    def __init__(self, page: PageModel, index: int, is_active: bool = False, parent=None):
        super().__init__(page.name, parent)
        self.page = page
        self.page_index = index
        self.is_active = is_active
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(32)
        self.setMinimumWidth(75)
        self.setMaximumWidth(150)
        self.setObjectName("dockPillActive" if is_active else "dockPill")

    def set_active(self, active: bool):
        self.is_active = active
        self.setObjectName("dockPillActive" if active else "dockPill")
        self.setStyleSheet("")  # re-evaluate QSS
        self.update()


class DockNavButton(QPushButton):
    """Frosted Apple glass arrow button for previous/next page navigation at the bottom."""
    def __init__(self, direction: str = "prev", parent=None):
        super().__init__(parent)
        self.direction = direction
        self.setFixedSize(28, 28)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Forrige side (←)" if direction == "prev" else "Næste side (→)")

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        if self.isDown():
            bg_color = QColor(255, 255, 255, 45)
        elif self.underMouse():
            bg_color = QColor(255, 255, 255, 28)
        else:
            bg_color = QColor(255, 255, 255, 14)

        border_color = QColor(255, 255, 255, 26)
        painter.setBrush(bg_color)
        painter.setPen(QPen(border_color, 1.0))
        painter.drawEllipse(1, 1, 26, 26)

        # Draw Chevron Arrow
        arrow_pen = QPen(QColor(255, 255, 255, 230), 2.0, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
        painter.setPen(arrow_pen)
        if self.direction == "prev":
            # Points left: (16, 9) -> (11, 14) -> (16, 19)
            painter.drawLine(16, 9, 11, 14)
            painter.drawLine(11, 14, 16, 19)
        else:
            # Points right: (12, 9) -> (17, 14) -> (12, 19)
            painter.drawLine(12, 9, 17, 14)
            painter.drawLine(17, 14, 12, 19)


class DockAddButton(QPushButton):
    """Frosted Apple glass circular button with a thick, crisp, perfectly centered '+' plus icon."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(28, 28)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Opret ny side (Ctrl+N)")

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        if self.isDown():
            bg_color = QColor(255, 255, 255, 50)
        elif self.underMouse():
            bg_color = QColor(255, 255, 255, 32)
        else:
            bg_color = QColor(255, 255, 255, 16)

        border_color = QColor(255, 255, 255, 30)
        painter.setBrush(bg_color)
        painter.setPen(QPen(border_color, 1.0))
        painter.drawEllipse(1, 1, 26, 26)

        # Draw crisp, clean '+' plus icon: horizontal and vertical lines of equal length
        plus_pen = QPen(QColor(255, 255, 255, 240), 2.2, Qt.SolidLine, Qt.RoundCap)
        painter.setPen(plus_pen)
        # Center is (14, 14)
        painter.drawLine(14, 8, 14, 20)   # Vertical bar
        painter.drawLine(8, 14, 20, 14)   # Horizontal bar


class PageDock(QFrame):
    """
    Floating Frosted Glass Bottom Dock for Page Navigation.
    Provides [ ‹ ] [ Page Pills ] [ › ] [ + ] with zero clutter at the top.
    """
    page_selected = Signal(int)
    page_created = Signal()
    page_renamed = Signal(int, str)
    page_duplicated = Signal(int)
    page_deleted = Signal(int)
    page_moved = Signal(int, int)  # from_idx, to_idx
    prev_requested = Signal()
    next_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("floatingDock")
        self.setFixedHeight(50)
        self.pages: List[PageModel] = []
        self.active_index: int = 0
        self.items: List[DockPageItem] = []

        self._init_ui()

    def _init_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(10, 5, 10, 5)
        main_layout.setSpacing(8)

        # Prev Button (‹)
        self.prev_btn = DockNavButton(direction="prev")
        self.prev_btn.clicked.connect(self.prev_requested.emit)
        main_layout.addWidget(self.prev_btn)

        # Scrollable items container
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setStyleSheet("background: transparent; border: none;")

        self.pill_container = QWidget()
        self.pill_layout = QHBoxLayout(self.pill_container)
        self.pill_layout.setContentsMargins(0, 0, 0, 0)
        self.pill_layout.setSpacing(6)
        self.pill_layout.setAlignment(Qt.AlignCenter)

        self.scroll.setWidget(self.pill_container)
        main_layout.addWidget(self.scroll, stretch=1)

        # Next Button (›)
        self.next_btn = DockNavButton(direction="next")
        self.next_btn.clicked.connect(self.next_requested.emit)
        main_layout.addWidget(self.next_btn)

        # + New Page button with custom painted plus sign
        self.add_btn = DockAddButton()
        self.add_btn.clicked.connect(self.page_created.emit)
        main_layout.addWidget(self.add_btn)

    def set_pages(self, pages: List[PageModel], active_index: int = 0):
        self.pages = pages
        self.active_index = active_index
        self._rebuild_items()

    def set_active_index(self, index: int):
        self.active_index = index
        for i, item in enumerate(self.items):
            item.set_active(i == index)

    def _rebuild_items(self):
        # Clear existing
        while self.pill_layout.count():
            child = self.pill_layout.takeAt(0)
            widget = child.widget()
            if widget:
                widget.deleteLater()
        self.items.clear()

        for i, page in enumerate(self.pages):
            is_act = (i == self.active_index)
            btn = DockPageItem(page, i, is_active=is_act, parent=self.pill_container)
            btn.clicked.connect(lambda checked=False, idx=i: self._on_item_clicked(idx))
            btn.setContextMenuPolicy(Qt.CustomContextMenu)
            btn.customContextMenuRequested.connect(lambda pos, idx=i: self._show_context_menu(pos, idx))
            self.pill_layout.addWidget(btn)
            self.items.append(btn)

    def _on_item_clicked(self, index: int):
        self.set_active_index(index)
        self.page_selected.emit(index)

    def _show_context_menu(self, pos: QPoint, index: int):
        if index < 0 or index >= len(self.pages):
            return

        page = self.pages[index]
        menu = QMenu(self)

        rename_act = menu.addAction(f"Omdøb '{page.name}'")
        dup_act = menu.addAction("Dupliker Side")
        menu.addSeparator()

        move_left_act = None
        if index > 0:
            move_left_act = menu.addAction("Flyt til Venstre ←")

        move_right_act = None
        if index < len(self.pages) - 1:
            move_right_act = menu.addAction("Flyt til Højre →")

        menu.addSeparator()
        del_act = menu.addAction("Slet Side")
        if len(self.pages) <= 1:
            del_act.setEnabled(False)

        global_pos = self.items[index].mapToGlobal(pos)
        selected = menu.exec(global_pos)

        if not selected:
            return

        if selected == rename_act:
            new_name, ok = AppleGlassInputDialog.get_text(
                self.window(), "Omdøb Side", "Nyt navn til siden:", text=page.name
            )
            if ok and new_name.strip():
                self.page_renamed.emit(index, new_name.strip())
        elif selected == dup_act:
            self.page_duplicated.emit(index)
        elif selected == move_left_act:
            self.page_moved.emit(index, index - 1)
        elif selected == move_right_act:
            self.page_moved.emit(index, index + 1)
        elif selected == del_act:
            confirm = AppleGlassConfirmDialog.ask(
                self.window(), "Slet Side",
                f"Er du sikker på, at du vil slette siden '{page.name}'?",
                confirm_text="Slet", is_danger=True
            )
            if confirm:
                self.page_deleted.emit(index)
