"""
TouchDeck - Authentic Stream Deck Physical Hardware Preview Canvas
Strict Apple-Grade Physicality, Translucent Glass Buttons & Alpha Logo Rendering.
Author: NEXA
"""

import os
from pathlib import Path
from typing import Optional, Dict

from PySide6.QtWidgets import (
    QWidget, QGridLayout, QVBoxLayout, QHBoxLayout, QLabel,
    QFrame, QMenu, QMessageBox
)
from PySide6.QtGui import (
    QPainter, QColor, QFont, QPen, QBrush, QIcon, QPixmap,
    QDrag, QMouseEvent, QPaintEvent, QLinearGradient, QPainterPath
)
from PySide6.QtCore import Qt, QSize, QPoint, QRect, QRectF, Signal, QMimeData

from shared.models import ButtonModel, PageModel
from shared.constants import (
    COLOR_BG, COLOR_BG_SECONDARY, COLOR_CARD, COLOR_BORDER,
    COLOR_TEXT_MAIN
)
from editor.utils.icon_storage import resolve_icon_path


class PreviewButtonTile(QFrame):
    """
    Tactile Physical Glass Button Tile on the Stream Deck chassis.
    Pure Apple design: dark translucent surface, hairline rim reflection, no neon.
    Preserves transparent PNG alpha with zero white bounding artifacts.
    """
    clicked = Signal(str)                  # button_id
    right_clicked = Signal(str, QPoint)    # button_id, global_pos
    dropped_on = Signal(str, str)          # source_id, target_slot_or_btn_id

    def __init__(self, button: Optional[ButtonModel], row: int, col: int, is_selected: bool = False, parent=None):
        super().__init__(parent)
        self.button = button
        self.row = row
        self.col = col
        self.is_selected = is_selected
        self.is_hovered = False
        self.is_pressed = False

        self.setAcceptDrops(True)
        self.setMouseTracking(True)
        self.setCursor(Qt.PointingHandCursor)

    def enterEvent(self, event):
        self.is_hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.is_hovered = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self.is_pressed = True
            self.update()
            if self.button:
                self.clicked.emit(self.button.id)
            else:
                self.clicked.emit(f"empty_{self.row}_{self.col}")
            self.drag_start_pos = event.pos()
        elif event.button() == Qt.RightButton:
            if self.button:
                self.right_clicked.emit(self.button.id, event.globalPosition().toPoint())

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self.is_pressed = False
            self.update()
        super().mouseReleaseEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent):
        if not (event.buttons() & Qt.LeftButton) or not self.button:
            return
        if (event.pos() - getattr(self, "drag_start_pos", QPoint())).manhattanLength() < 12:
            return

        drag = QDrag(self)
        mime = QMimeData()
        mime.setText(f"touchdeck_btn:{self.button.id}")
        drag.setMimeData(mime)

        pixmap = QPixmap(self.size())
        self.render(pixmap)
        drag.setPixmap(pixmap)
        drag.setHotSpot(event.pos())
        drag.exec(Qt.MoveAction)

    def dragEnterEvent(self, event):
        if event.mimeData().hasText() and event.mimeData().text().startswith("touchdeck_btn:"):
            event.acceptProposedAction()
            self.is_hovered = True
            self.update()

    def dragLeaveEvent(self, event):
        self.is_hovered = False
        self.update()

    def dropEvent(self, event):
        if event.mimeData().hasText():
            source_id = event.mimeData().text().replace("touchdeck_btn:", "")
            target_id = self.button.id if self.button else f"empty_{self.row}_{self.col}"
            self.dropped_on.emit(source_id, target_id)
            event.acceptProposedAction()
            self.is_hovered = False
            self.update()

    def paintEvent(self, event: QPaintEvent):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)

        rect = self.rect().adjusted(2, 2, -2, -2)
        if self.is_pressed:
            rect = rect.adjusted(1, 1, -1, -1)

        # ----------------------------------------------------
        # 1. Empty Slot Placeholder
        # ----------------------------------------------------
        if not self.button:
            border_col = QColor(255, 255, 255, 40) if self.is_hovered else QColor(255, 255, 255, 15)
            pen = QPen(border_col, 1.0, Qt.DashLine)
            painter.setPen(pen)
            bg_col = QColor(255, 255, 255, 6) if self.is_hovered else QColor(16, 16, 18, 120)
            painter.setBrush(QBrush(bg_col))
            painter.drawRoundedRect(rect, 12, 12)

            painter.setPen(QColor(255, 255, 255, 90 if self.is_hovered else 40))
            painter.setFont(QFont("Segoe UI Variable Text", 16, QFont.Normal))
            painter.drawText(rect, Qt.AlignCenter, "+")
            return

        # ----------------------------------------------------
        # 2. Configured Physical Tactile Button Tile
        # ----------------------------------------------------
        r = float(self.button.border_radius or 14)
        path = QPainterPath()
        path.addRoundedRect(QRectF(rect), r, r)

        # Base Surface Tone (Almost black with subtle translucent glass tint)
        raw_bg = QColor(self.button.bg_color or "#141416")
        if self.is_hovered:
            raw_bg = raw_bg.lighter(108)

        # Subtle Vertical Glass Depth
        fill = QLinearGradient(0, rect.top(), 0, rect.bottom())
        fill.setColorAt(0.0, QColor(raw_bg.red(), raw_bg.green(), raw_bg.blue(), 235))
        fill.setColorAt(1.0, QColor(max(0, raw_bg.red() - 8), max(0, raw_bg.green() - 8), max(0, raw_bg.blue() - 8), 245))
        painter.fillPath(path, fill)

        # Hairline Top Light Reflection (Apple Specular Highlight)
        sheen_height = min(26, rect.height() // 3)
        sheen_rect = QRectF(rect.left(), rect.top(), rect.width(), sheen_height)
        sheen_path = QPainterPath()
        sheen_path.addRoundedRect(sheen_rect, r, r)
        sheen_grad = QLinearGradient(0, rect.top(), 0, rect.top() + sheen_height)
        sheen_grad.setColorAt(0.0, QColor(255, 255, 255, 22 if self.is_hovered else 12))
        sheen_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.fillPath(sheen_path, sheen_grad)

        # Hairline Rim Highlight (Border)
        if self.is_selected:
            # Clean Apple White Selection Ring
            border_pen = QPen(QColor(255, 255, 255, 220), 1.5)
        elif self.is_hovered:
            border_pen = QPen(QColor(255, 255, 255, 75), 1.0)
        else:
            border_grad = QLinearGradient(0, rect.top(), 0, rect.bottom())
            border_grad.setColorAt(0.0, QColor(255, 255, 255, 35))
            border_grad.setColorAt(0.5, QColor(255, 255, 255, 14))
            border_grad.setColorAt(1.0, QColor(255, 255, 255, 6))
            border_pen = QPen()
            border_pen.setWidthF(1.0)
            border_pen.setBrush(border_grad)

        painter.strokePath(path, border_pen)

        # ----------------------------------------------------
        # 3. Custom Logo / Image Rendering (100% Reliable & Transparent)
        # ----------------------------------------------------
        icon_drawn = False
        resolved_icon_path = resolve_icon_path(self.button.icon)

        if resolved_icon_path and resolved_icon_path.exists():
            pix = QPixmap(str(resolved_icon_path))
            if not pix.isNull():
                max_icon_size = min(int(rect.height() * 0.44), int(rect.width() * 0.48), 52)
                scaled_pix = pix.scaled(max_icon_size, max_icon_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                ix = rect.center().x() - scaled_pix.width() // 2
                iy = rect.top() + int(rect.height() * 0.32) - scaled_pix.height() // 2
                painter.drawPixmap(ix, iy, scaled_pix)
                icon_drawn = True

        # ----------------------------------------------------
        # 4. Button Label Typography (Clean White Text)
        # ----------------------------------------------------
        painter.setPen(QColor(self.button.text_color or "#FFFFFF"))
        font_size = self.button.font_size or 11
        painter.setFont(QFont("Segoe UI Variable Text", font_size, QFont.DemiBold))

        if icon_drawn:
            text_rect = QRect(
                rect.left() + 6,
                rect.top() + int(rect.height() * 0.58),
                rect.width() - 12,
                int(rect.height() * 0.38)
            )
        else:
            text_rect = rect.adjusted(8, 8, -8, -8)

        painter.drawText(text_rect, Qt.AlignCenter | Qt.TextWordWrap, self.button.title or "Button")


class LiveSurfacePreview(QFrame):
    """
    Center Stage Authentic Stream Deck Hardware Housing.
    Encased in a precision matte dark chassis bezel with clean button grid.
    """
    button_selected = Signal(object)        # ButtonModel or None
    button_test_requested = Signal(object)  # ButtonModel
    layout_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("hardwareChassis")
        self.current_page: Optional[PageModel] = None
        self.selected_button_id: Optional[str] = None
        self.tiles_dict: Dict[str, PreviewButtonTile] = {}

        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 16, 20, 20)
        main_layout.setSpacing(12)

        # Clean Hardware Header Bezel
        header_row = QHBoxLayout()
        header_row.setContentsMargins(6, 0, 6, 0)

        title = QLabel("STREAM DECK HARDWARE PREVIEW")
        title.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 600; letter-spacing: 1.2px;")
        header_row.addWidget(title)
        header_row.addStretch()

        aspect_badge = QLabel("12-Key Studio")
        aspect_badge.setStyleSheet("""
            color: #8E8E93;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 6px;
            padding: 2px 8px;
            font-size: 10px;
            font-weight: 500;
        """)
        header_row.addWidget(aspect_badge)

        main_layout.addLayout(header_row)

        # Stream Deck Precision Grid Container
        self.grid_container = QWidget()
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setContentsMargins(0, 0, 0, 0)
        self.grid_layout.setSpacing(14)
        main_layout.addWidget(self.grid_container, stretch=1)

    def set_page(self, page: Optional[PageModel], selected_button_id: Optional[str] = None):
        self.current_page = page
        self.selected_button_id = selected_button_id
        self.rebuild_grid()

    def set_selected_button(self, button_id: Optional[str]):
        self.selected_button_id = button_id
        for bid, tile in self.tiles_dict.items():
            tile.is_selected = (bid == button_id)
            tile.update()

    def rebuild_grid(self):
        # Clear existing tiles
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self.tiles_dict.clear()

        if not self.current_page:
            empty_lbl = QLabel("Ingen side valgt")
            empty_lbl.setAlignment(Qt.AlignCenter)
            empty_lbl.setStyleSheet("color: #8E8E93; font-size: 13px;")
            self.grid_layout.addWidget(empty_lbl, 0, 0)
            return

        rows = max(1, getattr(self.current_page, "rows", 3) or 3)
        cols = max(1, getattr(self.current_page, "cols", 4) or 4)

        # Map button positions
        button_map = {}
        for btn in self.current_page.buttons:
            button_map[(btn.row, btn.col)] = btn

        for r in range(rows):
            self.grid_layout.setRowStretch(r, 1)
            for c in range(cols):
                if r == 0:
                    self.grid_layout.setColumnStretch(c, 1)

                btn = button_map.get((r, c))
                is_sel = bool(btn and btn.id == self.selected_button_id)
                tile = PreviewButtonTile(btn, r, c, is_selected=is_sel, parent=self.grid_container)

                if btn:
                    self.tiles_dict[btn.id] = tile

                tile.clicked.connect(self._on_tile_clicked)
                tile.right_clicked.connect(self._on_tile_right_clicked)
                tile.dropped_on.connect(self._on_tile_dropped_on)

                self.grid_layout.addWidget(tile, r, c)

    def _on_tile_clicked(self, tile_key: str):
        if tile_key.startswith("empty_"):
            parts = tile_key.split("_")
            row, col = int(parts[1]), int(parts[2])
            new_btn = self._create_button_at(row, col)
            self.button_selected.emit(new_btn)
        else:
            self.selected_button_id = tile_key
            self.set_selected_button(tile_key)
            for btn in self.current_page.buttons:
                if btn.id == tile_key:
                    self.button_selected.emit(btn)
                    return
            self.button_selected.emit(None)

    def _create_button_at(self, row: int, col: int) -> ButtonModel:
        if not self.current_page:
            return None
        import uuid
        new_btn = ButtonModel(
            id=str(uuid.uuid4())[:8],
            row=row,
            col=col,
            title=f"Knap {len(self.current_page.buttons) + 1}",
            bg_color="#141416",
            text_color="#FFFFFF",
            font_size=11,
            border_radius=14
        )
        self.current_page.buttons.append(new_btn)
        self.rebuild_grid()
        self.set_selected_button(new_btn.id)
        self.layout_changed.emit()
        return new_btn

    def _on_tile_right_clicked(self, button_id: str, global_pos: QPoint):
        menu = QMenu(self)
        test_act = menu.addAction("▶ Test Knap på PC")
        menu.addSeparator()
        clear_act = menu.addAction("Ryd Ikon")
        del_act = menu.addAction("Slet Knap")

        selected_action = menu.exec(global_pos)
        if not selected_action or not self.current_page:
            return

        target_btn = next((b for b in self.current_page.buttons if b.id == button_id), None)
        if not target_btn:
            return

        if selected_action == test_act:
            self.button_test_requested.emit(target_btn)
        elif selected_action == clear_act:
            target_btn.icon = ""
            self.rebuild_grid()
            self.layout_changed.emit()
        elif selected_action == del_act:
            self.current_page.buttons.remove(target_btn)
            if self.selected_button_id == button_id:
                self.selected_button_id = None
                self.button_selected.emit(None)
            self.rebuild_grid()
            self.layout_changed.emit()

    def _on_tile_dropped_on(self, source_id: str, target_id_or_empty: str):
        if not self.current_page:
            return
        source_btn = next((b for b in self.current_page.buttons if b.id == source_id), None)
        if not source_btn:
            return

        if target_id_or_empty.startswith("empty_"):
            parts = target_id_or_empty.split("_")
            source_btn.row = int(parts[1])
            source_btn.col = int(parts[2])
        else:
            target_btn = next((b for b in self.current_page.buttons if b.id == target_id_or_empty), None)
            if target_btn and target_btn != source_btn:
                # Swap positions
                source_btn.row, target_btn.row = target_btn.row, source_btn.row
                source_btn.col, target_btn.col = target_btn.col, source_btn.col

        self.rebuild_grid()
        self.set_selected_button(source_btn.id)
        self.layout_changed.emit()

    def refresh_grid(self):
        self.rebuild_grid()

    def _delete_button(self, button: ButtonModel):
        if self.current_page and button in self.current_page.buttons:
            self.current_page.buttons.remove(button)
            if self.selected_button_id == button.id:
                self.selected_button_id = None
                self.button_selected.emit(None)
            self.rebuild_grid()
            self.layout_changed.emit()
