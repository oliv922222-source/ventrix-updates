"""
NEXA - Web & Google Favicon Logo Fetcher
Downloads official high-resolution website favicons/logos using Google Favicon API
and DuckDuckGo icon service, with threaded background downloading and caching.
Author: NEXA
"""

import re
import urllib.request
from urllib.parse import urlparse
from pathlib import Path
from typing import Optional
from io import BytesIO
from PIL import Image

from PySide6.QtCore import QThread, Signal
from editor.utils.icon_storage import save_custom_image


# Popular brand mappings for instant resolution
BRAND_DOMAINS = {
    "dr": "dr.dk",
    "tv2": "tv2.dk",
    "eb": "ekstrabladet.dk",
    "ekstrabladet": "ekstrabladet.dk",
    "bt": "bt.dk",
    "twitch": "twitch.tv",
    "youtube": "youtube.com",
    "yt": "youtube.com",
    "netflix": "netflix.com",
    "disney": "disneyplus.com",
    "disney+": "disneyplus.com",
    "disneyplus": "disneyplus.com",
    "chatgpt": "chatgpt.com",
    "openai": "openai.com",
    "spotify": "spotify.com",
    "discord": "discord.com",
    "steam": "store.steampowered.com",
    "reddit": "reddit.com",
    "github": "github.com",
    "google": "google.com",
    "gmail": "mail.google.com",
    "amazon": "amazon.com",
    "prime": "primevideo.com",
    "wikipedia": "wikipedia.org",
    "wiki": "wikipedia.org",
    "facebook": "facebook.com",
    "fb": "facebook.com",
    "instagram": "instagram.com",
    "insta": "instagram.com",
    "tiktok": "tiktok.com",
    "twitter": "x.com",
    "x": "x.com",
}


def sanitize_domain_or_url(input_text: str) -> str:
    """Extract clean domain from URL, brand name, or domain string."""
    text = input_text.strip().lower()
    if not text:
        return ""

    # Check direct brand mapping first
    if text in BRAND_DOMAINS:
        return BRAND_DOMAINS[text]

    # If it doesn't have http:// or https://, add https://
    if not text.startswith("http://") and not text.startswith("https://"):
        if "." not in text:
            text = f"{text}.com"
        text = f"https://{text}"

    try:
        parsed = urlparse(text)
        netloc = parsed.netloc or parsed.path
        # Strip port and www.
        netloc = re.sub(r":\d+$", "", netloc)
        if netloc.startswith("www."):
            netloc = netloc[4:]
        # Remove trailing slashes or paths if caught in netloc
        netloc = netloc.split("/")[0]
        return netloc
    except Exception:
        return text.replace("https://", "").replace("http://", "").split("/")[0]


def fetch_website_logo_bytes(domain_or_url: str) -> Optional[bytes]:
    """
    Fetch favicon bytes using Google Favicon Service V2, Google S2, DuckDuckGo and Unavatar.
    Returns PNG/ICO image bytes or None if failed.
    """
    domain = sanitize_domain_or_url(domain_or_url)
    if not domain:
        return None

    # URL endpoints in order of quality
    urls = [
        f"https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://{domain}&size=128",
        f"https://www.google.com/s2/favicons?domain={domain}&sz=128",
        f"https://icons.duckduckgo.com/ip3/{domain}.ico",
        f"https://unavatar.io/{domain}",
    ]

    for url in urls:
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status == 200:
                    data = resp.read()
                    if data and len(data) > 200:
                        # Verify it's a valid image with PIL
                        try:
                            im = Image.open(BytesIO(data))
                            if im.width >= 16 and im.height >= 16:
                                return data
                        except Exception:
                            continue
        except Exception:
            continue

    return None


def download_and_save_web_logo(domain_or_url: str) -> Optional[str]:
    """
    Synchronously fetch and save web logo to custom icons store.
    Returns stored filename (e.g. 'custom_netflix.png') or None.
    """
    data = fetch_website_logo_bytes(domain_or_url)
    if not data:
        return None

    try:
        domain = sanitize_domain_or_url(domain_or_url)
        clean_name = re.sub(r"[^\w\-]", "_", domain)
        im = Image.open(BytesIO(data)).convert("RGBA")

        # Save to temp and use save_custom_image
        temp_dir = Path(__file__).parent.parent.parent / "assets" / "icons" / "extracted"
        temp_dir.mkdir(parents=True, exist_ok=True)
        temp_path = temp_dir / f"web_{clean_name}.png"
        im.save(temp_path, "PNG")

        return save_custom_image(temp_path)
    except Exception:
        return None


class WebLogoFetchWorker(QThread):
    """Background worker to download logos without blocking Qt UI."""
    success = Signal(str, str)  # (stored_filename, domain)
    failure = Signal(str)       # (error_message)

    def __init__(self, query: str, parent=None):
        super().__init__(parent)
        self.query = query

    def run(self):
        try:
            domain = sanitize_domain_or_url(self.query)
            if not domain:
                self.failure.emit("Ugyldig hjemmeside eller domæne")
                return

            filename = download_and_save_web_logo(self.query)
            if filename:
                self.success.emit(filename, domain)
            else:
                self.failure.emit(f"Kunne ikke finde logo for {domain}")
        except Exception as e:
            self.failure.emit(str(e))
