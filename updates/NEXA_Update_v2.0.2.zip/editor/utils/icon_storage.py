"""
TouchDeck - Persistent Icon & Custom Logo Storage Manager
Ensures user-selected logos and custom images NEVER disappear across app restarts.
Author: NEXA
"""

import os
import shutil
import hashlib
from pathlib import Path
from typing import Optional
from PySide6.QtGui import QPixmap, QImage

# Persistent storage inside user's AppData (survives app updates and restarts)
USER_ICONS_DIR = Path(os.environ.get("APPDATA", str(Path.home()))) / "TouchDeck" / "user_icons"
USER_ICONS_DIR.mkdir(parents=True, exist_ok=True)

# Project assets directory fallback
PROJECT_ASSETS_DIR = Path(__file__).parent.parent.parent / "assets" / "icons"


def get_user_icons_dir() -> Path:
    """Returns the persistent user icons directory."""
    USER_ICONS_DIR.mkdir(parents=True, exist_ok=True)
    return USER_ICONS_DIR


def save_custom_image(source_path: str) -> Optional[str]:
    """
    Saves a user-uploaded image/logo into persistent storage.
    Preserves exact transparency (alpha channel) for PNG/WEBP/SVG.
    Returns the permanent absolute path as a string.
    """
    if not source_path or not os.path.exists(source_path):
        return None

    try:
        src = Path(source_path)
        ext = src.suffix.lower()
        if not ext:
            ext = ".png"

        # Generate a unique stable filename using stem + md5 hash of file content
        with open(src, "rb") as f:
            file_hash = hashlib.md5(f.read()).hexdigest()[:8]

        clean_stem = "".join(c for c in src.stem if c.isalnum() or c in ("-", "_")).lower()
        if not clean_stem:
            clean_stem = "custom_logo"

        dest_filename = f"{clean_stem}_{file_hash}{ext}"
        dest_path = USER_ICONS_DIR / dest_filename

        # Copy directly to preserve exact format and full alpha channel
        shutil.copy2(str(src), str(dest_path))
        return str(dest_path)
    except Exception as e:
        print(f"[IconStorage] Failed to save custom image {source_path}: {e}")
        return source_path


def resolve_icon_path(icon_ref: Optional[str]) -> Optional[Path]:
    """
    Resolves an icon identifier or path into an existing Path object.
    Checks:
    1. Direct file path if it exists
    2. Persistent user icons directory
    3. Project built-in icons
    4. Project extracted icons
    5. Fallback scan in Pictures/Downloads for orphaned files
    """
    if not icon_ref:
        return None

    # 1. Direct path check
    p = Path(icon_ref)
    if p.exists() and p.is_file():
        return p

    # 2. Check by filename in user_icons
    user_cand = USER_ICONS_DIR / p.name
    if user_cand.exists() and user_cand.is_file():
        return user_cand

    # 3. Check by stem with .png in user_icons
    user_cand_png = USER_ICONS_DIR / f"{p.stem}.png"
    if user_cand_png.exists() and user_cand_png.is_file():
        return user_cand_png

    # 4. Check project assets
    for candidate in [
        PROJECT_ASSETS_DIR / f"{icon_ref}.png",
        PROJECT_ASSETS_DIR / icon_ref,
        PROJECT_ASSETS_DIR / "extracted" / f"{icon_ref}.png",
        PROJECT_ASSETS_DIR / "extracted" / icon_ref,
        PROJECT_ASSETS_DIR / "extracted" / f"{p.name}",
    ]:
        if candidate.exists() and candidate.is_file():
            return candidate

    # 5. Check user Pictures / Downloads directory for recovery
    pictures_dir = Path.home() / "Pictures"
    if pictures_dir.exists():
        for candidate in [
            pictures_dir / p.name,
            pictures_dir / f"{p.stem}.png",
            pictures_dir / f"{p.stem}.jpg",
        ]:
            if candidate.exists() and candidate.is_file():
                # Auto-copy to persistent storage so it stays permanently
                saved = save_custom_image(str(candidate))
                return Path(saved) if saved else candidate

    return None


def migrate_broken_icon_paths(profiles: list) -> bool:
    """
    Scans profile buttons for dead paths (such as old temporary _MEI... folders)
    and automatically re-anchors them to persistent user storage.
    """
    changed = False
    pictures_dir = Path.home() / "Pictures"

    for profile in profiles:
        for page in getattr(profile, "pages", []):
            for btn in getattr(page, "buttons", []):
                icon_str = getattr(btn, "icon", "")
                if not icon_str:
                    continue

                p = Path(icon_str)
                if not p.exists():
                    resolved = resolve_icon_path(icon_str)
                    if resolved and resolved.exists():
                        btn.icon = str(resolved)
                        changed = True
                    else:
                        recovered = False
                        target_stem = p.stem.lower()

                        # 1. Search Pictures
                        if pictures_dir.exists():
                            for pic_file in pictures_dir.glob("*"):
                                if pic_file.is_file():
                                    p_stem = pic_file.stem.lower()
                                    if p_stem == target_stem or p_stem in target_stem or target_stem in p_stem:
                                        saved = save_custom_image(str(pic_file))
                                        if saved:
                                            btn.icon = saved
                                            changed = True
                                            recovered = True
                                            break

                        # 2. Search Desktop Shortcuts
                        if not recovered:
                            desktop_dir = Path.home() / "Desktop"
                            if desktop_dir.exists():
                                btn_title_clean = btn.title.lower().replace(" ", "")
                                for lnk in desktop_dir.glob("*.lnk"):
                                    lnk_clean = lnk.stem.lower().replace(" ", "")
                                    if (target_stem in lnk_clean or lnk_clean in target_stem
                                            or btn_title_clean in lnk_clean or lnk_clean in btn_title_clean):
                                        try:
                                            from editor.utils.icon_extractor import extract_app_icon
                                            extracted = extract_app_icon(str(lnk))
                                            if extracted:
                                                saved = save_custom_image(extracted)
                                                if saved:
                                                    btn.icon = saved
                                                    changed = True
                                                    recovered = True
                                                    break
                                        except Exception:
                                            pass
    return changed
