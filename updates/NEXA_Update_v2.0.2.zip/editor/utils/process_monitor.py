"""
TouchDeck - Process Monitor
Tracks running processes for each Application-type button.
Polls Windows task list every 3 seconds to determine if apps are open,
and computes how long they have been running.
Author: NEXA
"""

import subprocess
import threading
import time
import logging
import os
from pathlib import Path
from typing import Dict, Optional, Set, Tuple

from shared.models import ProfileModel
from shared.constants import ACTION_TYPE_APPLICATION

logger = logging.getLogger("TouchDeck.ProcessMonitor")

# Interval between polls (seconds) — shorter for more responsive status
POLL_INTERVAL = 3.0

# Apps where the process name differs from the exe filename.
# Map lowercased exe stem → actual process name in tasklist
KNOWN_ALIASES: Dict[str, str] = {
    "discord":        "discord.exe",
    "spotify":        "spotify.exe",
    "chrome":         "chrome.exe",
    "msedge":         "msedge.exe",
    "edge":           "msedge.exe",
    "firefox":        "firefox.exe",
    "steam":          "steam.exe",
    "obs64":          "obs64.exe",
    "obs":            "obs64.exe",
    "code":           "code.exe",
    "slack":          "slack.exe",
    "zoom":           "zoom.exe",
    "teams":          "teams.exe",
    "notepad":        "notepad.exe",
    "explorer":       "explorer.exe",
    "vlc":            "vlc.exe",
    "blender":        "blender.exe",
    "pythonw":        "pythonw.exe",
    "python":         "python.exe",
}


def _resolve_exe_candidates(target: str) -> Set[str]:
    """
    Return a set of candidate exe names (lowercased) to match against tasklist.
    Handles:
    - Direct .exe paths  → {"discord.exe"}
    - .lnk shortcuts     → resolves via PowerShell, falls back to stem.exe
    - No extension       → adds .exe suffix
    Multiple candidates are tried so partial matches work.
    """
    if not target:
        return set()

    t = target.strip().strip('"').strip("'").replace("/", "\\")
    candidates: Set[str] = set()

    # ── Resolve .lnk shortcut ──────────────────────────────────────────────
    if t.lower().endswith(".lnk"):
        # Fallback candidate: e.g. "Discord.lnk" → try "discord.exe"
        stem = Path(t).stem.lower()
        candidates.add(stem + ".exe")
        if stem in KNOWN_ALIASES:
            candidates.add(KNOWN_ALIASES[stem])

        if os.path.exists(t):
            try:
                result = subprocess.run(
                    ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                     f"(New-Object -ComObject WScript.Shell).CreateShortcut([System.IO.Path]::GetFullPath('{t}')).TargetPath"],
                    capture_output=True, text=True,
                    creationflags=0x08000000, timeout=4
                )
                resolved = result.stdout.strip()
                if resolved and not resolved.lower().endswith(".lnk"):
                    t = resolved  # fall through to exe handling below
                    # Don't return yet — let exe path handling add more candidates
            except Exception:
                pass

    # ── Direct exe / resolved path ─────────────────────────────────────────
    p = Path(t)
    name = p.name.lower()

    if name.endswith(".exe"):
        candidates.add(name)
    else:
        # No extension — try adding .exe
        candidates.add(name + ".exe")

    # Also try known aliases by stem
    stem = p.stem.lower()
    if stem in KNOWN_ALIASES:
        candidates.add(KNOWN_ALIASES[stem])

    return candidates


class ProcessMonitor:
    """
    Background service that polls Windows task list every POLL_INTERVAL seconds.
    Maps button IDs → {running: bool, uptime_sec: int}.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # {exe_name_lower: (first_seen_time, pid)}  — tracks uptime per process
        self._first_seen: Dict[str, Tuple[float, int]] = {}

        # {button_id: {"running": bool, "uptime_sec": int}}
        self._statuses: Dict[str, dict] = {}

        # {button_id: set of candidate exe names} — cached so we don't
        # call PowerShell on every poll cycle
        self._button_candidates: Dict[str, Set[str]] = {}

        # Current profile snapshot (set externally)
        self._profile: Optional[ProfileModel] = None
        self._profile_dirty = True   # Rebuild candidate cache on next poll

    def set_profile(self, profile: Optional[ProfileModel]):
        with self._lock:
            self._profile = profile
            self._profile_dirty = True

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._thread.start()
        logger.info("ProcessMonitor started")

    def stop(self):
        self._running = False

    def get_all_statuses(self) -> Dict[str, dict]:
        """Returns a snapshot of {button_id: {running, uptime_sec}}."""
        with self._lock:
            return dict(self._statuses)

    # ── Internal ───────────────────────────────────────────────────────────────

    def _poll_loop(self):
        while self._running:
            try:
                self._do_poll()
            except Exception as e:
                logger.debug(f"ProcessMonitor poll error: {e}")
            time.sleep(POLL_INTERVAL)

    def _rebuild_candidates(self, profile: ProfileModel):
        """Rebuild the button→exe-candidates cache from the profile."""
        cache: Dict[str, Set[str]] = {}
        for page in profile.pages:
            for btn in page.buttons:
                if not btn.action or btn.action.action_type != ACTION_TYPE_APPLICATION:
                    continue
                candidates = _resolve_exe_candidates(btn.action.target)
                if candidates:
                    cache[btn.id] = candidates
                    logger.debug(f"Button '{btn.title}' → candidates: {candidates}")
        self._button_candidates = cache
        self._profile_dirty = False

    def _do_poll(self):
        # 1. Rebuild candidate cache if profile changed
        with self._lock:
            profile = self._profile
            dirty = self._profile_dirty

        if dirty and profile:
            self._rebuild_candidates(profile)

        # 2. Get snapshot of currently running processes from Windows
        running_procs = self._get_tasklist()   # {exe_name_lower: [pid, ...]}
        now = time.time()

        # 3. Update first_seen tracking
        # Remove processes that are no longer running
        dead = [name for name in list(self._first_seen) if name not in running_procs]
        for name in dead:
            del self._first_seen[name]

        # Add newly seen / PID-changed processes
        for name, pids in running_procs.items():
            pid = pids[0] if pids else 0
            existing = self._first_seen.get(name)
            if existing is None:
                self._first_seen[name] = (now, pid)
            elif existing[1] != pid:
                # PID changed = process restarted → reset timer
                self._first_seen[name] = (now, pid)

        # 4. Build statuses for all tracked buttons
        with self._lock:
            candidates_map = dict(self._button_candidates)

        new_statuses: Dict[str, dict] = {}
        for btn_id, candidates in candidates_map.items():
            # Check if ANY candidate exe is running
            matched_name: Optional[str] = None
            for cand in candidates:
                if cand in running_procs:
                    matched_name = cand
                    break

            running = matched_name is not None
            uptime_sec = 0
            if running and matched_name and matched_name in self._first_seen:
                uptime_sec = int(now - self._first_seen[matched_name][0])

            new_statuses[btn_id] = {
                "running": running,
                "uptime_sec": uptime_sec,
            }

        with self._lock:
            self._statuses = new_statuses

    def _get_tasklist(self) -> Dict[str, list]:
        """
        Runs 'tasklist /FO CSV /NH' and returns {exe_name_lower: [pid, ...]}.
        Falls back to empty dict on error.
        """
        try:
            result = subprocess.run(
                ["tasklist", "/FO", "CSV", "/NH"],
                capture_output=True, text=True,
                creationflags=0x08000000,   # CREATE_NO_WINDOW
                timeout=8
            )
            procs: Dict[str, list] = {}
            for line in result.stdout.strip().splitlines():
                # CSV: "Image Name","PID","Session Name","Session#","Mem Usage"
                parts = [p.strip('"') for p in line.split('","')]
                if len(parts) >= 2:
                    name = parts[0].lower()
                    try:
                        pid = int(parts[1])
                    except ValueError:
                        pid = 0
                    procs.setdefault(name, []).append(pid)
            return procs
        except Exception as e:
            logger.debug(f"tasklist error: {e}")
            return {}
