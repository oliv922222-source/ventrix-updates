"""
TouchDeck - Windows Application Icon Extractor
Extracts native high-resolution icons from .exe and .lnk files on Windows WITHOUT shortcut arrow overlay.
Special resolution for Squirrel apps (Discord, Spotify, Slack, etc.).
Author: NEXA
"""

import os
import sys
import glob
import ctypes
from pathlib import Path
from typing import Optional
from PySide6.QtWidgets import QApplication, QFileIconProvider
from PySide6.QtCore import QFileInfo
from PySide6.QtGui import QIcon, QPixmap

ICONS_CACHE_DIR = Path(__file__).parent.parent.parent / "assets" / "icons" / "extracted"


def resolve_lnk_target(file_path: str) -> str:
    """Resolves a Windows shortcut or Squirrel updater to the authentic main executable."""
    if not file_path:
        return file_path

    # 1. Check for Discord special case (AppData\Local\Discord\app-*\Discord.exe)
    if "discord" in file_path.lower():
        matches = glob.glob(os.path.expandvars(r"%LOCALAPPDATA%\Discord\app-*\Discord.exe"))
        if matches and os.path.exists(matches[-1]):
            return matches[-1]

    # 2. Check for Spotify special case
    if "spotify" in file_path.lower():
        spotify_path = os.path.expandvars(r"%APPDATA%\Spotify\Spotify.exe")
        if os.path.exists(spotify_path):
            return spotify_path

    # 3. Check for Steam special case
    if "steam" in file_path.lower():
        steam_paths = [r"C:\Program Files (x86)\Steam\steam.exe", r"C:\Program Files\Steam\steam.exe"]
        for sp in steam_paths:
            if os.path.exists(sp):
                return sp

    if not file_path.lower().endswith(".lnk"):
        return file_path

    # 4. Resolve generic .lnk via PowerShell WScript.Shell
    try:
        import subprocess
        safe_path = file_path.replace("'", "''").replace('"', '`"')
        cmd = f'(New-Object -COM WScript.Shell).CreateShortcut("{safe_path}").TargetPath'
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
            text=True,
            timeout=3,
            creationflags=0x08000000  # CREATE_NO_WINDOW
        ).strip()
        if out and os.path.exists(out):
            # If target is a Squirrel Update.exe, search for subfolder app-*\<App>.exe
            if "update.exe" in out.lower():
                parent_dir = Path(out).parent
                sub_exes = list(parent_dir.glob("app-*/*.exe"))
                main_exes = [e for e in sub_exes if not e.name.lower().startswith("update")]
                if main_exes:
                    return str(main_exes[-1])
            return out
    except Exception:
        pass

    return file_path


def extract_app_icon(file_path: str) -> Optional[str]:
    """
    Extracts the pure application icon from an executable or resolved shortcut and saves it as a PNG.
    Guarantees NO shortcut arrow overlay on the resulting image.
    """
    if not file_path or not os.path.exists(file_path):
        return None

    # Ensure Qt Application instance exists for pixmap processing
    _app = QApplication.instance() or QApplication(sys.argv)

    # Resolve .lnk to target .exe so there is NO shortcut arrow badge
    real_target = resolve_lnk_target(file_path)
    lookup_file = real_target if os.path.exists(real_target) else file_path

    ICONS_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    base_name = Path(real_target if real_target else file_path).stem.lower().replace(" ", "_")
    output_png = ICONS_CACHE_DIR / f"{base_name}.png"

    # Method: PySide6 QFileIconProvider on the resolved .exe target (NO arrow because target is genuine .exe)
    try:
        provider = QFileIconProvider()
        icon = provider.icon(QFileInfo(lookup_file))
        if not icon.isNull():
            for size in (256, 128, 96, 64, 48):
                pixmap = icon.pixmap(size, size)
                if not pixmap.isNull() and pixmap.width() > 0:
                    pixmap.save(str(output_png), "PNG")
                    return str(output_png)
    except Exception:
        pass

    return str(output_png) if output_png.exists() else None
