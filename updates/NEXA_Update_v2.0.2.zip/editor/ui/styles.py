"""
TouchDeck - Apple / visionOS Glassmorphism Stylesheet
Strict Monochromatic Black, White & Real Translucent Glass.
Minimalist, calm, refined desktop software aesthetic.
Author: NEXA
"""

import sys
from pathlib import Path

def _get_chevron_path() -> str:
    if hasattr(sys, "_MEIPASS"):
        p = Path(sys._MEIPASS) / "assets" / "icons" / "chevron_down.png"
        if p.exists():
            return p.as_posix()
    p = Path(__file__).parent.parent.parent / "assets" / "icons" / "chevron_down.png"
    return p.resolve().as_posix()

_CHEVRON_PATH = _get_chevron_path()

DARK_THEME_QSS = """
/* =========================================================================
   1. GLOBAL ROOT & SYSTEM FONTS
   ========================================================================= */
QMainWindow, QWidget#centralWidget {
    background-color: #0A0A0C;
    color: #FFFFFF;
    font-family: 'Segoe UI Variable Text', 'Segoe UI', -apple-system, BlinkMacSystemFont, 'SF Pro Text', sans-serif;
    font-size: 13px;
}

QDialog {
    background-color: #121214;
    color: #FFFFFF;
    font-family: 'Segoe UI Variable Text', 'Segoe UI', -apple-system, BlinkMacSystemFont, 'SF Pro Text', sans-serif;
    font-size: 13px;
}

/* Base transparent containers */
QScrollArea, QAbstractScrollArea, QStackedWidget {
    background: transparent !important;
    background-color: transparent !important;
    border: none !important;
}

QScrollArea > QWidget > QWidget {
    background: transparent !important;
    background-color: transparent !important;
}

/* =========================================================================
   2. FLOATING GLASS TOPBAR & DOCKS (Apple macOS / visionOS)
   ========================================================================= */
QFrame#floatingTopBar {
    background: rgba(20, 20, 22, 0.78);
    border-top: 1px solid rgba(255, 255, 255, 0.14);
    border-bottom: 1px solid rgba(255, 255, 255, 0.04);
    border-left: 1px solid rgba(255, 255, 255, 0.08);
    border-right: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 14px;
}

QFrame#floatingDock {
    background: rgba(22, 22, 24, 0.82);
    border-top: 1px solid rgba(255, 255, 255, 0.16);
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    border-left: 1px solid rgba(255, 255, 255, 0.09);
    border-right: 1px solid rgba(255, 255, 255, 0.09);
    border-radius: 20px;
}

QFrame#cardFrame, QWidget#cardFrame {
    background: rgba(22, 22, 25, 0.65);
    border: 1px solid rgba(255, 255, 255, 0.07);
    border-top: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 12px;
}

/* =========================================================================
   3. HARDWARE CHASSIS (Stream Deck Physical Housing)
   ========================================================================= */
QFrame#hardwareChassis {
    background: #0D0D0F;
    border: 1.5px solid #1E1E22;
    border-top: 1.5px solid #28282E;
    border-radius: 22px;
}

/* =========================================================================
   4. APPLE-STYLE BUTTONS & CONTROLS
   ========================================================================= */
QPushButton {
    background: rgba(255, 255, 255, 0.06);
    color: #F5F5F5;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-top: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 8px;
    padding: 6px 13px;
    font-size: 12px;
    font-weight: 500;
}

QPushButton:hover {
    background: rgba(255, 255, 255, 0.12);
    border-color: rgba(255, 255, 255, 0.18);
    color: #FFFFFF;
}

QPushButton:pressed {
    background: rgba(255, 255, 255, 0.18);
    border-color: rgba(255, 255, 255, 0.22);
}

QPushButton:disabled {
    background: rgba(255, 255, 255, 0.02);
    color: #555558;
    border: 1px solid rgba(255, 255, 255, 0.03);
}

/* Primary Action: Send to Surface (Monochrome Apple Solid Pill) */
QPushButton#pushBtn {
    background: #FFFFFF;
    color: #000000;
    font-size: 12px;
    font-weight: 600;
    padding: 6px 15px;
    border: 1px solid #FFFFFF;
    border-radius: 8px;
}

QPushButton#pushBtn:hover {
    background: #EBEBEB;
    color: #000000;
    border-color: #EBEBEB;
}

QPushButton#pushBtn:pressed {
    background: #CCCCCC;
    color: #000000;
}

/* Danger Button (Subtle Muted Red) */
QPushButton#dangerBtn {
    background: rgba(255, 69, 58, 0.10);
    color: #FF6961;
    border: 1px solid rgba(255, 69, 58, 0.22);
    border-radius: 8px;
    font-weight: 500;
}

QPushButton#dangerBtn:hover {
}

/* Destructive / Danger Button */
QPushButton#deleteBtn, QPushButton#dangerBtn {
    background-color: rgba(239, 68, 68, 0.12);
    color: #F87171;
    border: 1px solid rgba(239, 68, 68, 0.30);
    border-radius: 8px;
    padding: 6px 14px;
    font-size: 12px;
    font-weight: 600;
}

QPushButton#deleteBtn:hover, QPushButton#dangerBtn:hover {
    background-color: rgba(239, 68, 68, 0.25);
    border-color: #EF4444;
    color: #FFFFFF;
}

/* =========================================================================
   4. APPLE SEGMENTED CONTROLS (Pills)
   ========================================================================= */
QFrame#segmentedControl {
    background-color: rgba(255, 255, 255, 0.06);
    border-radius: 12px;
    padding: 3px;
}

QPushButton#segmentBtn {
    background: transparent;
    color: #8E8E93;
    border: none;
    border-radius: 9px;
    padding: 6px 14px;
    font-size: 12px;
    font-weight: 600;
}

QPushButton#segmentBtn:hover {
    color: #FFFFFF;
    background: rgba(255, 255, 255, 0.05);
}

QPushButton#segmentBtn:checked {
    background-color: rgba(255, 255, 255, 0.18);
    color: #FFFFFF;
    border: 0.5px solid rgba(255, 255, 255, 0.20);
}

/* Status pill indicator */
QFrame#statusPill {
    background-color: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.10);
    border-radius: 12px;
    padding: 6px 14px;
    font-size: 12px;
    font-weight: 600;
}

/* =========================================================================
   5. INPUT FIELDS & COMBOBOXES (Crisp Apple Glass Design)
   ========================================================================= */
QLineEdit, QTextEdit {
    background-color: rgba(255, 255, 255, 0.08);
    color: #FFFFFF;
    border: 1px solid rgba(255, 255, 255, 0.22);
    border-radius: 9px;
    padding: 8px 12px;
    font-size: 13px;
    font-weight: 500;
    min-height: 20px;
    selection-background-color: #2563EB;
    selection-color: #FFFFFF;
}

QLineEdit:hover, QTextEdit:hover {
    border: 1px solid rgba(255, 255, 255, 0.38);
    background-color: rgba(255, 255, 255, 0.12);
}

QLineEdit:focus, QTextEdit:focus {
    border: 1.5px solid #FFFFFF;
    background-color: rgba(255, 255, 255, 0.16);
}

QComboBox {
    background-color: rgba(255, 255, 255, 0.08);
    color: #FFFFFF;
    border: 1px solid rgba(255, 255, 255, 0.22);
    border-radius: 9px;
    padding: 7px 12px;
    min-height: 20px;
    font-size: 13px;
    font-weight: 500;
}

QComboBox:hover {
    background-color: rgba(255, 255, 255, 0.12);
    border: 1px solid rgba(255, 255, 255, 0.38);
}

QComboBox:focus, QComboBox:on {
    border: 1.5px solid #FFFFFF;
    background-color: rgba(255, 255, 255, 0.16);
}

QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 28px;
    border: none;
    background: transparent;
}

QComboBox::down-arrow {
    image: url("__CHEVRON_PATH__");
    width: 12px;
    height: 12px;
    margin-right: 8px;
}");
    width: 12px;
    height: 12px;
    margin-right: 8px;
    color: #FFFFFF;
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 8px;
    padding: 7px 12px;
    font-size: 13px;
}

/* =========================================================================
   CHECKBOXES & RADIOS (Clean White Typography)
   ========================================================================= */
QCheckBox, QRadioButton {
    color: #FFFFFF;
    font-size: 13px;
    font-weight: 500;
    spacing: 10px;
    background: transparent;
}

QCheckBox:hover, QRadioButton:hover {
    color: #FFFFFF;
}

QCheckBox:disabled, QRadioButton:disabled {
    color: #636366;
}

QCheckBox::indicator {
    width: 18px;
    height: 18px;
    border-radius: 5px;
    border: 1.5px solid rgba(255, 255, 255, 0.28);
    background: rgba(255, 255, 255, 0.05);
}

QCheckBox::indicator:hover {
    border-color: rgba(255, 255, 255, 0.50);
    background: rgba(255, 255, 255, 0.10);
}

QCheckBox::indicator:checked {
    background: #FFFFFF;
    border-color: #FFFFFF;
}

/* =========================================================================
   6. SLIDERS (Apple Minimalist)
   ========================================================================= */
QSlider::groove:horizontal {
    height: 4px;
    background: rgba(255, 255, 255, 0.12);
    border-radius: 2px;
}

QSlider::sub-page:horizontal {
    background: #FFFFFF;
    border-radius: 2px;
}

QSlider::handle:horizontal {
    background: #FFFFFF;
    border: 1px solid rgba(0, 0, 0, 0.2);
    width: 14px;
    height: 14px;
    margin: -5px 0;
    border-radius: 7px;
}

QSlider::handle:horizontal:hover {
    background: #F0F0F0;
}

/* =========================================================================
   7. LABELS & TYPOGRAPHY
   ========================================================================= */
QLabel {
    color: #EBEBF5;
    font-size: 12px;
}

QLabel#brandTitle {
    color: #FFFFFF;
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 0.5px;
}

QLabel#sectionHeader {
    color: #8E8E93;
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.8px;
}

QLabel#subText {
    color: #8E8E93;
    font-size: 11px;
}

/* =========================================================================
   8. CLEAN NATIVE SCROLLBARS
   ========================================================================= */
QScrollBar:vertical {
    background: transparent;
    width: 6px;
    margin: 0px;
}

QScrollBar::handle:vertical {
    background: rgba(255, 255, 255, 0.15);
    min-height: 24px;
    border-radius: 3px;
}

QScrollBar::handle:vertical:hover {
    background: rgba(255, 255, 255, 0.28);
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
    background: transparent;
}

/* =========================================================================
   9. MENUS & TOOLTIPS
   ========================================================================= */
QMenu {
    background-color: #1A1A1D;
    color: #FFFFFF;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 10px;
    padding: 6px;
}

QMenu::item {
    padding: 6px 20px 6px 12px;
    border-radius: 6px;
}

QMenu::item:selected {
    background-color: rgba(255, 255, 255, 0.12);
    color: #FFFFFF;
}

QMenu::separator {
    height: 1px;
    background: rgba(255, 255, 255, 0.08);
    margin: 4px 6px;
}

QToolTip {
    background-color: #1E1E22;
    color: #FFFFFF;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 6px;
    padding: 5px 8px;
    font-size: 11px;
}
""".replace("__CHEVRON_PATH__", _CHEVRON_PATH)
