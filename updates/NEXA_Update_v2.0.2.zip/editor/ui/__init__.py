"""
TouchDeck Editor UI Package
Author: NEXA
"""

from editor.ui.styles import DARK_THEME_QSS

__all__ = ["DARK_THEME_QSS"]
