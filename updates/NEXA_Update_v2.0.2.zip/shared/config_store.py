"""
TouchDeck - Configuration and Profile Store
Author: NEXA
"""

import os
import json
import shutil
import time
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Any

from shared.models import (
    ProfileModel, PageModel, ButtonModel, ActionModel,
    MacroStepModel, DeviceModel, AppSettingsModel
)
from shared.constants import (
    COLOR_CARD, COLOR_PRIMARY_BLUE, COLOR_ERROR, COLOR_SUCCESS,
    COLOR_WARNING, COLOR_BORDER, COLOR_TEXT_MAIN,
    ACTION_TYPE_APPLICATION, ACTION_TYPE_HOTKEY, ACTION_TYPE_MEDIA,
    ACTION_TYPE_SYSTEM, ACTION_TYPE_SCRIPT, ACTION_TYPE_MACRO,
    MEDIA_PLAY_PAUSE, MEDIA_NEXT, MEDIA_PREV, MEDIA_VOLUME_UP,
    MEDIA_VOLUME_DOWN, MEDIA_VOLUME_MUTE, SYSTEM_LOCK, SYSTEM_TASK_MANAGER,
    SYSTEM_OPEN_SETTINGS
)


class ConfigStore:
    """Handles thread-safe, atomic configuration persistence, profile management, and automatic backups."""

    def __init__(self, config_dir: Optional[Path] = None):
        if config_dir is None:
            # Default to AppData or local workspace config
            base_dir = Path(os.environ.get("APPDATA", str(Path.home()))) / "TouchDeck"
            self.config_dir = base_dir
        else:
            self.config_dir = config_dir

        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.backups_dir = self.config_dir / "backups"
        self.backups_dir.mkdir(parents=True, exist_ok=True)

        self.config_file = self.config_dir / "touchdeck_config.json"
        self.devices_file = self.config_dir / "touchdeck_devices.json"
        self.settings_file = self.config_dir / "touchdeck_settings.json"

        self.settings = AppSettingsModel()
        self.profiles: List[ProfileModel] = []
        self.devices: List[DeviceModel] = []

        self.load_all()

    def create_default_profiles(self) -> List[ProfileModel]:
        """Creates a single empty profile with one blank page so users start with a clean slate."""
        empty_page = PageModel(name="Page 1", rows=3, cols=4, buttons=[])

        default_profile = ProfileModel(
            name="Default Profile",
            pages=[empty_page],
            active_page_index=0
        )

        return [default_profile]

    def load_all(self):
        """Loads settings, profiles, and devices from disk."""
        # 1. Load Settings
        if self.settings_file.exists():
            try:
                with open(self.settings_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.settings = AppSettingsModel.from_dict(data)
            except Exception as e:
                print(f"[ConfigStore] Error loading settings: {e}")
                self.settings = AppSettingsModel()
        else:
            self.settings = AppSettingsModel()
            self.save_settings()

        # 2. Load Profiles
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    profiles_raw = data.get("profiles", [])
                    self.profiles = [ProfileModel.from_dict(p) for p in profiles_raw]
            except Exception as e:
                print(f"[ConfigStore] Error loading profiles: {e}")
                self.profiles = self.create_default_profiles()
                self.save_profiles()
        else:
            self.profiles = self.create_default_profiles()
            self.save_profiles()

        if not self.profiles:
            self.profiles = self.create_default_profiles()
            self.save_profiles()

        # Migrate broken icon paths if any exist
        try:
            from editor.utils.icon_storage import migrate_broken_icon_paths
            if migrate_broken_icon_paths(self.profiles):
                self.save_profiles(create_backup=False)
        except Exception as e:
            print(f"[ConfigStore] Icon migration note: {e}")

        if not self.settings.active_profile_id or not self.get_active_profile():
            self.settings.active_profile_id = self.profiles[0].id
            self.save_settings()

        # 3. Load Devices
        if self.devices_file.exists():
            try:
                with open(self.devices_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.devices = [DeviceModel.from_dict(d) for d in data.get("devices", [])]
            except Exception as e:
                print(f"[ConfigStore] Error loading devices: {e}")
                self.devices = []

    def get_active_profile(self) -> Optional[ProfileModel]:
        for p in self.profiles:
            if p.id == self.settings.active_profile_id:
                return p
        return self.profiles[0] if self.profiles else None

    def get_version_hash(self) -> str:
        """Calculates MD5 hash of active profile layout for version synchronization."""
        active = self.get_active_profile()
        if not active:
            return ""
        data_str = json.dumps(active.to_dict(), sort_keys=True)
        return hashlib.md5(data_str.encode("utf-8")).hexdigest()

    def _atomic_write_json(self, target_path: Path, data: Dict[str, Any]):
        """Writes JSON atomically via temporary file to prevent corruption."""
        temp_file = target_path.with_suffix(".tmp")
        with open(temp_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        shutil.move(str(temp_file), str(target_path))

    def save_settings(self):
        try:
            self._atomic_write_json(self.settings_file, self.settings.to_dict())
        except Exception as e:
            print(f"[ConfigStore] Error saving settings: {e}")

    def save_all(self):
        """Saves settings, profiles, and devices atomically."""
        self.save_settings()
        self.save_profiles(create_backup=False)
        self.save_devices()

    def save_profiles(self, create_backup: bool = True):
        try:
            data = {
                "version": "1.0.0",
                "updated_at": time.time(),
                "profiles": [p.to_dict() for p in self.profiles]
            }
            self._atomic_write_json(self.config_file, data)

            if create_backup:
                timestamp = time.strftime("%Y%m%d_%H%M%S")
                backup_path = self.backups_dir / f"config_{timestamp}.json"
                try:
                    shutil.copy2(str(self.config_file), str(backup_path))
                    # Keep maximum 20 backups
                    backups = sorted(list(self.backups_dir.glob("config_*.json")))
                    if len(backups) > 20:
                        for old in backups[:-20]:
                            old.unlink(missing_ok=True)
                except Exception:
                    pass
        except Exception as e:
            print(f"[ConfigStore] Error saving profiles: {e}")

    def save_devices(self):
        try:
            data = {"devices": [d.to_dict() for d in self.devices]}
            self._atomic_write_json(self.devices_file, data)
        except Exception as e:
            print(f"[ConfigStore] Error saving devices: {e}")

    def add_or_update_device(self, device: DeviceModel):
        found = False
        for i, d in enumerate(self.devices):
            if d.device_id == device.device_id:
                self.devices[i] = device
                found = True
                break
        if not found:
            self.devices.append(device)
        self.save_devices()

    def get_device(self, device_id: str) -> Optional[DeviceModel]:
        for d in self.devices:
            if d.device_id == device_id:
                return d
        return None

    def export_profile_json(self, profile_id: str, file_path: Path) -> bool:
        for p in self.profiles:
            if p.id == profile_id:
                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(p.to_dict(), f, indent=2)
                return True
        return False

    def import_profile_json(self, file_path: Path) -> Optional[ProfileModel]:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                profile = ProfileModel.from_dict(data)
                self.profiles.append(profile)
                self.save_profiles()
                return profile
        except Exception as e:
            print(f"[ConfigStore] Import failed: {e}")
            return None
