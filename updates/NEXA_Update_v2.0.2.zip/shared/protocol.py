"""
TouchDeck - Network Protocol and Message Schemas
Author: NEXA
"""

import json
import time
from typing import Dict, Any, Optional

# Message Types
MSG_HELLO = "HELLO"
MSG_DISCOVER_ANNOUNCE = "DISCOVER_ANNOUNCE"
MSG_PAIR_REQUEST = "PAIR_REQUEST"
MSG_PAIR_CHALLENGE = "PAIR_CHALLENGE"
MSG_PAIR_CONFIRM = "PAIR_CONFIRM"
MSG_PAIR_RESULT = "PAIR_RESULT"

MSG_AUTH_REQUEST = "AUTH_REQUEST"
MSG_AUTH_RESULT = "AUTH_RESULT"

MSG_SYNC_LAYOUT = "SYNC_LAYOUT"
MSG_LAYOUT_VERSION_CHECK = "LAYOUT_VERSION_CHECK"

MSG_BUTTON_PRESS = "BUTTON_PRESS"
MSG_BUTTON_RELEASE = "BUTTON_RELEASE"
MSG_BUTTON_LONG_PRESS = "BUTTON_LONG_PRESS"
MSG_BUTTON_FEEDBACK = "BUTTON_FEEDBACK"

MSG_HEARTBEAT_PING = "HEARTBEAT_PING"
MSG_HEARTBEAT_PONG = "HEARTBEAT_PONG"

MSG_DEVICE_STATUS = "DEVICE_STATUS"
MSG_SET_ACTIVE_PAGE = "SET_ACTIVE_PAGE"
MSG_ACTION_RESULT = "ACTION_RESULT"


class TouchDeckProtocol:
    """Helper for encoding and decoding TouchDeck network protocol messages."""

    @staticmethod
    def create_message(msg_type: str, payload: Optional[Dict[str, Any]] = None) -> str:
        data = {
            "type": msg_type,
            "timestamp": time.time(),
            "payload": payload or {}
        }
        return json.dumps(data)

    @staticmethod
    def parse_message(raw_json: str) -> Optional[Dict[str, Any]]:
        try:
            data = json.loads(raw_json)
            if isinstance(data, dict) and "type" in data:
                return data
        except Exception:
            pass
        return None

    # Helper message builders
    @staticmethod
    def msg_hello(device_name: str, device_id: str, app_version: str) -> str:
        return TouchDeckProtocol.create_message(MSG_HELLO, {
            "device_name": device_name,
            "device_id": device_id,
            "app_version": app_version
        })

    @staticmethod
    def msg_pair_request(device_name: str, device_id: str) -> str:
        return TouchDeckProtocol.create_message(MSG_PAIR_REQUEST, {
            "device_name": device_name,
            "device_id": device_id
        })

    @staticmethod
    def msg_pair_confirm(device_id: str, pin_code: str) -> str:
        return TouchDeckProtocol.create_message(MSG_PAIR_CONFIRM, {
            "device_id": device_id,
            "pin_code": pin_code
        })

    @staticmethod
    def msg_pair_result(success: bool, auth_token: str = "", message: str = "") -> str:
        return TouchDeckProtocol.create_message(MSG_PAIR_RESULT, {
            "success": success,
            "auth_token": auth_token,
            "message": message
        })

    @staticmethod
    def msg_auth_request(device_id: str, auth_token: str) -> str:
        return TouchDeckProtocol.create_message(MSG_AUTH_REQUEST, {
            "device_id": device_id,
            "auth_token": auth_token
        })

    @staticmethod
    def msg_auth_result(success: bool, message: str = "") -> str:
        return TouchDeckProtocol.create_message(MSG_AUTH_RESULT, {
            "success": success,
            "message": message
        })

    @staticmethod
    def msg_sync_layout(profile_data: Dict[str, Any], version_hash: str) -> str:
        return TouchDeckProtocol.create_message(MSG_SYNC_LAYOUT, {
            "profile": profile_data,
            "version_hash": version_hash
        })

    @staticmethod
    def msg_button_press(button_id: str, page_id: str) -> str:
        return TouchDeckProtocol.create_message(MSG_BUTTON_PRESS, {
            "button_id": button_id,
            "page_id": page_id
        })

    @staticmethod
    def msg_button_long_press(button_id: str, page_id: str) -> str:
        return TouchDeckProtocol.create_message(MSG_BUTTON_LONG_PRESS, {
            "button_id": button_id,
            "page_id": page_id
        })

    @staticmethod
    def msg_button_feedback(button_id: str, status: str = "success", message: str = "") -> str:
        return TouchDeckProtocol.create_message(MSG_BUTTON_FEEDBACK, {
            "button_id": button_id,
            "status": status,
            "message": message
        })

    @staticmethod
    def msg_ping() -> str:
        return TouchDeckProtocol.create_message(MSG_HEARTBEAT_PING)

    @staticmethod
    def msg_pong() -> str:
        return TouchDeckProtocol.create_message(MSG_HEARTBEAT_PONG)

    @staticmethod
    def msg_set_active_page(page_index: int) -> str:
        return TouchDeckProtocol.create_message(MSG_SET_ACTIVE_PAGE, {
            "page_index": page_index
        })
