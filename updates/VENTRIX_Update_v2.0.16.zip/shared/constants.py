"""
TouchDeck - Shared Constants and Design System Tokens
Author: VENTRIX
"""

import sys
from pathlib import Path

# Application Metadata
APP_NAME = "VENTRIX"
APP_VERSION = "2.0.16"
APP_AUTHOR = "VENTRIX"
APP_DESCRIPTION = "VENTRIX — Stream Deck Studio"

# Online Update System — change this URL to where you host update_manifest.json
# Example: GitHub raw, your own server, or any public URL
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/oliv922222-source/ventrix-updates/main/update_manifest.json"

# Network Defaults
DEFAULT_WS_PORT = 18880
DEFAULT_DISCOVERY_PORT = 18881
DEFAULT_DISCOVERY_INTERVAL = 2.0  # seconds
HEARTBEAT_INTERVAL = 5.0  # seconds
HEARTBEAT_TIMEOUT = 12.0  # seconds

# Design System Color Palette (Inspired by professional dark control dashboard)
COLOR_BG = "#0D0F14"
COLOR_BG_SECONDARY = "#11141C"
COLOR_CARD = "#181C26"
COLOR_CARD_HOVER = "#222736"
COLOR_CARD_ACTIVE = "#2C3345"
COLOR_BORDER = "#292F3A"
COLOR_BORDER_FOCUS = "#3B82F6"

COLOR_PRIMARY_BLUE = "#2563EB"
COLOR_BRIGHT_BLUE = "#3B82F6"
COLOR_ACCENT_BLUE_BG = "#1E293B"

COLOR_TEXT_MAIN = "#F5F7FA"
COLOR_TEXT_MUTED = "#8B95A7"
COLOR_TEXT_FAINT = "#556075"

COLOR_WARNING = "#F59E0B"
COLOR_ERROR = "#EF4444"
COLOR_SUCCESS = "#22C55E"
COLOR_INFO = "#38BDF8"

# Grid Defaults
DEFAULT_GRID_ROWS = 3
DEFAULT_GRID_COLS = 4
DEFAULT_BUTTON_SPACING = 14
DEFAULT_BUTTON_RADIUS = 28
DEFAULT_FONT_FAMILY = "Segoe UI"

# Action Types
ACTION_TYPE_APPLICATION = "application"
ACTION_TYPE_HOTKEY = "hotkey"
ACTION_TYPE_MEDIA = "media"
ACTION_TYPE_MOUSE = "mouse"
ACTION_TYPE_SYSTEM = "system"
ACTION_TYPE_FILE_FOLDER_URL = "file_folder_url"
ACTION_TYPE_SCRIPT = "script"
ACTION_TYPE_MACRO = "macro"
ACTION_TYPE_NAVIGATION = "navigation"

# Media Sub-actions
MEDIA_PLAY_PAUSE = "play_pause"
MEDIA_NEXT = "next"
MEDIA_PREV = "prev"
MEDIA_VOLUME_UP = "volume_up"
MEDIA_VOLUME_DOWN = "volume_down"
MEDIA_VOLUME_MUTE = "volume_mute"

# System Sub-actions
SYSTEM_LOCK = "lock"
SYSTEM_SLEEP = "sleep"
SYSTEM_SHUTDOWN = "shutdown"
SYSTEM_RESTART = "restart"
SYSTEM_OPEN_SETTINGS = "open_settings"
SYSTEM_TASK_MANAGER = "task_manager"

# Mouse Sub-actions
MOUSE_LEFT_CLICK = "left_click"
MOUSE_RIGHT_CLICK = "right_click"
MOUSE_DOUBLE_CLICK = "double_click"

# Emergency Escape Sequence on Surface Runtime
EMERGENCY_ESCAPE_COMBO = "Ctrl+Alt+Shift+F12"
SECRET_TAP_CORNER_HOLD_MS = 4000  # 4 second hold on top-left
