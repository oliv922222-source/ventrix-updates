"""
TouchDeck - Stream Deck Editor v2.0.0
Apple-Grade Desktop Interface: Pure Black, White, Real Translucent Glass.
Author: VENTRIX
"""

import os
from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QSplitter, QFrame,
    QSystemTrayIcon, QMenu, QApplication, QStackedWidget
)
from PySide6.QtGui import QIcon, QPixmap, QCloseEvent, QKeySequence, QShortcut
from PySide6.QtCore import Qt, QSize, Signal, QTimer, QPoint

from shared.models import ProfileModel, PageModel, ButtonModel, DeviceModel, ActionModel
from shared.config_store import ConfigStore
from shared.constants import (
    APP_NAME, APP_VERSION, APP_AUTHOR, COLOR_BG, COLOR_TEXT_MAIN, ACTION_TYPE_MEDAL
)
from editor.services.medal_sync import auto_sync_medal_button
from editor.ui.styles import DARK_THEME_QSS
from editor.actions.action_engine import ActionEngine
from editor.networking.server import TouchDeckServer
from editor.utils.process_monitor import ProcessMonitor
from editor.auth.google_auth import GoogleAuthManager
from editor.widgets.glass_widgets import (
    GlassCard, GlassButton, GlassStatusPill, GlassAvatar, GlassToast, AppleSettingsButton
)
from editor.widgets.apple_dialogs import (
    AppleGlassInputDialog, AppleGlassConfirmDialog
)
from editor.widgets.page_switcher_bar import PageSwitcherBar
from editor.widgets.page_dock import PageDock
from editor.widgets.live_surface_preview import LiveSurfacePreview
from editor.widgets.button_inspector import ButtonInspector
from editor.widgets.deck_inspector import DeckInspector
from editor.widgets.device_manager_dialog import DeviceManagerDialog
from editor.widgets.connect_device_dialog import ConnectDeviceDialog
from editor.widgets.usb_deployment_dialog import UsbDeploymentDialog
from editor.widgets.settings_dialog import SettingsDialog, SettingsView
from editor.widgets.welcome_screen import WelcomeScreen
from editor.widgets.license_dialog import LicenseActivationDialog
from editor.widgets.discord_inspector import DiscordInspector
from editor.widgets.medal_inspector import MedalInspector
from shared.license_manager import is_licensed, get_license_info
from shared.i18n import t, set_language, get_current_language, I18nManager



class MainWindow(QMainWindow):
    """
    Main TouchDeck Studio Window.
    Monochromatic Apple glass aesthetic: sleek top bar, Stream Deck hardware preview,
    floating bottom dock, and floating settings inspector.
    """

    def __init__(self, config_store: ConfigStore, action_engine: ActionEngine, server: TouchDeckServer):
        super().__init__()
        self.config_store = config_store
        self.action_engine = action_engine
        self.server = server
        self.auth_mgr = GoogleAuthManager.get_instance()

        self.setWindowTitle(f"{APP_NAME} — Stream Deck Studio")
        self.resize(1380, 880)
        self.setMinimumSize(1080, 700)

        # Window Icon & Branding
        self.icon_path = Path(__file__).parent.parent.parent / "assets" / "ventrix.ico"
        if not self.icon_path.exists():
            self.icon_path = Path(__file__).parent.parent.parent / "assets" / "touchdeck.ico"
        self.logo_png_path = Path(__file__).parent.parent.parent / "assets" / "ventrix.png"

        if self.icon_path.exists():
            self.app_icon = QIcon(str(self.icon_path))
            self.setWindowIcon(self.app_icon)
        elif self.logo_png_path.exists():
            self.app_icon = QIcon(str(self.logo_png_path))
            self.setWindowIcon(self.app_icon)
        else:
            self.app_icon = QIcon()

        self.setStyleSheet(DARK_THEME_QSS)

        # Initialize i18n
        saved_lang = getattr(self.config_store.settings, "language", "da") or "da"
        set_language(saved_lang)
        I18nManager.get_instance().language_changed.connect(self._on_language_changed)

        # Process monitor for button status
        self.process_monitor = ProcessMonitor()
        self.process_monitor.start()
        self.server.process_monitor = self.process_monitor

        self._active_toasts = []

        self._init_ui()
        self._init_shortcuts()
        self._init_networking_signals()
        self._init_auth_signals()
        self._init_system_tray()
        self._load_active_profile()

        # Auto-sync Medal.tv hotkeys on startup so all clip lengths (15s, 30s, 1m, 2m, 5m) work immediately
        try:
            auto_sync_medal_button()
        except Exception:
            pass

        # Welcome screen state: show every time if always_show_welcome is True (default True)
        if getattr(self.config_store.settings, "always_show_welcome", True):
            self.main_stack.setCurrentIndex(0)
            self.welcome_screen.fade_in()
        else:
            self.main_stack.setCurrentIndex(1)

    def _init_ui(self):
        self.central = QWidget()
        self.setCentralWidget(self.central)
        root_lay = QVBoxLayout(self.central)
        root_lay.setContentsMargins(14, 12, 14, 14)
        root_lay.setSpacing(10)

        self.main_stack = QStackedWidget()

        # ----------------------------------------------------
        # STACK 0: Welcome / Onboarding Screen
        # ----------------------------------------------------
        user_name = getattr(self.config_store.settings, "user_name", "") or ""
        always_show = getattr(self.config_store.settings, "always_show_welcome", True)
        cur_lang = getattr(self.config_store.settings, "language", "da") or "da"
        self.welcome_screen = WelcomeScreen(
            user_name=user_name,
            language=cur_lang,
            always_show=always_show
        )
        self.welcome_screen.continue_clicked.connect(self._on_welcome_continued)
        self.main_stack.addWidget(self.welcome_screen)

        # ----------------------------------------------------
        # STACK 1: Studio Workspace
        # ----------------------------------------------------
        studio_widget = QWidget()
        studio_lay = QVBoxLayout(studio_widget)
        studio_lay.setContentsMargins(0, 0, 0, 0)
        studio_lay.setSpacing(10)

        # 1. FLOATING GLASS TOP NAVIGATION BAR
        top_bar = QFrame()
        top_bar.setObjectName("floatingTopBar")
        top_bar.setFixedHeight(56)
        top_lay = QHBoxLayout(top_bar)
        top_lay.setContentsMargins(16, 0, 16, 0)
        top_lay.setSpacing(0)
        top_lay.setAlignment(Qt.AlignVCenter)

        # ── LEFT: Branding + License ──────────────────────────────────────────
        left_box = QHBoxLayout()
        left_box.setSpacing(8)
        left_box.setAlignment(Qt.AlignVCenter)
        left_box.setContentsMargins(0, 0, 0, 0)

        brand_icon = QLabel()
        brand_icon.setFixedSize(22, 22)
        brand_icon.setAlignment(Qt.AlignCenter)
        brand_icon.setStyleSheet("background: transparent; border: none;")
        if self.logo_png_path.exists():
            brand_icon.setPixmap(QPixmap(str(self.logo_png_path)).scaled(22, 22, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        elif self.icon_path.exists():
            brand_icon.setPixmap(QPixmap(str(self.icon_path)).scaled(22, 22, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        left_box.addWidget(brand_icon, alignment=Qt.AlignVCenter)

        brand_lbl = QLabel(APP_NAME)
        brand_lbl.setObjectName("brandTitle")
        brand_lbl.setFixedHeight(24)
        brand_lbl.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)
        brand_lbl.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 700; letter-spacing: 0.6px; background: transparent; border: none;")
        left_box.addWidget(brand_lbl, alignment=Qt.AlignVCenter)

        left_box.addSpacing(2)

        # Version badge
        ver_badge = GlassButton(f"v{APP_VERSION}", is_primary=False, corner_radius=8)
        ver_badge.setFixedHeight(24)
        ver_badge.setFixedWidth(56)
        ver_badge.setCursor(Qt.ArrowCursor)
        left_box.addWidget(ver_badge, alignment=Qt.AlignVCenter)

        # License status pill (Pro ✓ / Aktiver)
        self.license_badge = GlassButton("Aktiver", is_primary=False, corner_radius=8)
        self.license_badge.setFixedHeight(24)
        self.license_badge.clicked.connect(self._open_license_dialog)
        self._update_license_badge()
        left_box.addWidget(self.license_badge, alignment=Qt.AlignVCenter)

        # Discrete vertical separator between branding and status
        brand_sep = QFrame()
        brand_sep.setFrameShape(QFrame.VLine)
        brand_sep.setFixedWidth(1)
        brand_sep.setFixedHeight(18)
        brand_sep.setStyleSheet("background: rgba(255, 255, 255, 0.12); border: none; margin: 0 4px;")
        left_box.addWidget(brand_sep, alignment=Qt.AlignVCenter)

        # Status area: [🟢 Forbundet] [1 Enhed]
        self.status_pill = GlassStatusPill()
        self.status_pill.setFixedHeight(26)
        left_box.addWidget(self.status_pill, alignment=Qt.AlignVCenter)

        self.device_count_lbl = QLabel("0 Enheder")
        self.device_count_lbl.setStyleSheet("color: #8E8E93; font-size: 11px; font-weight: 500; background: transparent; border: none; padding-left: 2px;")
        left_box.addWidget(self.device_count_lbl, alignment=Qt.AlignVCenter)

        top_lay.addLayout(left_box)

        # ── FLEXIBLE SPACING (Balances left and right naturally) ─────────────
        top_lay.addStretch(1)

        # ── RIGHT: Actions Dock (Spacious, beautifully structured) ────────────
        right_box = QHBoxLayout()
        right_box.setSpacing(10)
        right_box.setAlignment(Qt.AlignVCenter)
        right_box.setContentsMargins(0, 0, 0, 0)

        # Primary Action: Send til Surface (Crisp White Highlight Pill)
        self.push_btn = QPushButton(t("topbar_push_surface"))
        self.push_btn.setObjectName("dockPushBtn")
        self.push_btn.setFixedHeight(34)
        self.push_btn.setToolTip(t("topbar_push_surface_tooltip"))
        self.push_btn.clicked.connect(self._on_push_to_surface)
        right_box.addWidget(self.push_btn, alignment=Qt.AlignVCenter)

        # Forbind Enhed
        self.devices_btn = QPushButton(t("topbar_connect_device"))
        self.devices_btn.setObjectName("dockBtn")
        self.devices_btn.setFixedHeight(34)
        self.devices_btn.setToolTip(t("topbar_connect_device"))
        self.devices_btn.clicked.connect(self._open_connect_device_dialog)
        right_box.addWidget(self.devices_btn, alignment=Qt.AlignVCenter)

        # USB
        self.usb_btn = QPushButton(t("topbar_usb"))
        self.usb_btn.setObjectName("dockBtn")
        self.usb_btn.setFixedHeight(34)
        self.usb_btn.setToolTip(t("topbar_usb"))
        self.usb_btn.clicked.connect(self._open_usb_dialog)
        right_box.addWidget(self.usb_btn, alignment=Qt.AlignVCenter)

        # Group Separator Spacing
        right_box.addSpacing(8)

        # Discord Button (Subtle purple/blue accent)
        self.discord_btn = QPushButton(" Discord")
        self.discord_btn.setObjectName("dockDiscordBtn")
        self.discord_btn.setFixedHeight(34)
        self.discord_btn.setToolTip("Discord Kontrol (Mute, Deafen, PTT, Stream)")
        discord_icon = Path(__file__).resolve().parent.parent.parent / "assets" / "icons" / "discord.png"
        if discord_icon.exists():
            self.discord_btn.setIcon(QIcon(str(discord_icon)))
            self.discord_btn.setIconSize(QSize(15, 15))
        self.discord_btn.clicked.connect(self._toggle_discord_inspector)
        right_box.addWidget(self.discord_btn, alignment=Qt.AlignVCenter)

        # Medal Button (Subtle gold/yellow accent)
        self.medal_btn = QPushButton(" Medal")
        self.medal_btn.setObjectName("dockMedalBtn")
        self.medal_btn.setFixedHeight(34)
        self.medal_btn.setToolTip("Medal.tv Kontrol (Klip 15s/30s/1m/2m/5m, Optagelse, Bogmærke)")
        medal_icon = Path(__file__).resolve().parent.parent.parent / "assets" / "icons" / "medal.png"
        if medal_icon.exists():
            self.medal_btn.setIcon(QIcon(str(medal_icon)))
            self.medal_btn.setIconSize(QSize(15, 15))
        self.medal_btn.clicked.connect(self._toggle_medal_inspector)
        right_box.addWidget(self.medal_btn, alignment=Qt.AlignVCenter)

        # Group Separator Spacing
        right_box.addSpacing(8)

        # In-App Update Button
        self.update_btn = QPushButton(t("topbar_update"))
        self.update_btn.setObjectName("dockBtn")
        self.update_btn.setFixedHeight(34)
        self.update_btn.setToolTip(t("topbar_update"))
        self.update_btn.clicked.connect(self._open_update_dialog)
        right_box.addWidget(self.update_btn, alignment=Qt.AlignVCenter)

        # Subtle Vertical Divider before Settings
        settings_sep = QFrame()
        settings_sep.setFrameShape(QFrame.VLine)
        settings_sep.setFixedWidth(1)
        settings_sep.setFixedHeight(18)
        settings_sep.setStyleSheet("background: rgba(255, 255, 255, 0.12); border: none; margin: 0 4px;")
        right_box.addWidget(settings_sep, alignment=Qt.AlignVCenter)

        # Settings Button (Apple SF Symbols style gear)
        self.settings_btn = AppleSettingsButton()
        self.settings_btn.setFixedSize(34, 34)
        self.settings_btn.setToolTip(t("topbar_settings_tooltip"))
        self.settings_btn.clicked.connect(self._open_settings_dialog)
        right_box.addWidget(self.settings_btn, alignment=Qt.AlignVCenter)

        top_lay.addLayout(right_box)


        studio_lay.addWidget(top_bar)

        # 2. CENTER SPLITTER WORKSPACE (Canvas + Inspector)
        workspace = QSplitter(Qt.Horizontal)
        workspace.setHandleWidth(1)
        workspace.setStyleSheet("QSplitter::handle { background-color: rgba(255, 255, 255, 0.05); }")

        # Center Column: Switcher + Surface Preview + Bottom Dock
        center_col = QWidget()
        center_lay = QVBoxLayout(center_col)
        center_lay.setContentsMargins(0, 0, 0, 0)
        center_lay.setSpacing(10)

        # Live Hardware Preview (Center Stage)
        self.preview = LiveSurfacePreview()
        self.preview.button_selected.connect(self._on_button_selected_in_preview)
        self.preview.background_dropped.connect(self._on_background_dropped)
        self.preview.layout_changed.connect(self._on_layout_changed)
        self.preview.button_test_requested.connect(self._on_button_test_requested)
        center_lay.addWidget(self.preview, stretch=1)

        # Floating Bottom Page Dock (Navigation and + New Page at bottom)
        self.dock = PageDock()
        self.dock.page_selected.connect(self._on_dock_page_selected)
        self.dock.prev_requested.connect(self._prev_page)
        self.dock.next_requested.connect(self._next_page)
        self.dock.page_created.connect(self._create_new_page)
        self.dock.page_renamed.connect(self._on_page_renamed)
        self.dock.page_duplicated.connect(self._duplicate_page)
        self.dock.page_deleted.connect(self._delete_page)
        self.dock.page_moved.connect(self._move_page)
        self.dock.button_dropped_on_page.connect(self._on_button_moved_to_page)
        center_lay.addWidget(self.dock)

        workspace.addWidget(center_col)

        # Right Panel: Floating Translucent Inspector Stack
        self.right_stack = QStackedWidget()
        self.right_stack.setMinimumWidth(380)
        self.right_stack.setMaximumWidth(460)

        # Page 0: Deck Customizer (Background drag/drop, button gap, corner radius, padding)
        self.deck_inspector = DeckInspector(self)
        self.deck_inspector.page_style_changed.connect(self._on_deck_style_changed)
        self.right_stack.addWidget(self.deck_inspector)

        # Page 1: Single Button Inspector
        self.inspector = ButtonInspector(self)
        self.inspector.button_updated.connect(self._on_button_updated_in_inspector)
        self.inspector.button_deleted.connect(self._on_button_deleted_in_inspector)
        self.inspector.button_test_requested.connect(self._on_button_test_requested)
        self.inspector.push_requested.connect(self._on_push_to_surface)
        self.right_stack.addWidget(self.inspector)

        # Page 2: Discord Inspector
        self.discord_inspector = DiscordInspector(self)
        self.discord_inspector.close_requested.connect(lambda: self.right_stack.setCurrentIndex(0))
        self.discord_inspector.button_creation_requested.connect(self._on_external_button_created)
        self.right_stack.addWidget(self.discord_inspector)

        # Page 3: Medal Inspector
        self.medal_inspector = MedalInspector(self)
        self.medal_inspector.close_requested.connect(lambda: self.right_stack.setCurrentIndex(0))
        self.medal_inspector.button_creation_requested.connect(self._on_external_button_created)
        self.right_stack.addWidget(self.medal_inspector)

        workspace.addWidget(self.right_stack)

        workspace.setSizes([860, 420])
        studio_lay.addWidget(workspace, stretch=1)

        self.main_stack.addWidget(studio_widget)

        # ----------------------------------------------------
        # STACK 2: In-Window Settings Workspace
        # ----------------------------------------------------
        self.settings_view = SettingsView(self.config_store, self.server, self)
        self.settings_view.back_to_studio_requested.connect(lambda: self.main_stack.setCurrentIndex(1))
        self.settings_view.replay_welcome_requested.connect(lambda: self.main_stack.setCurrentIndex(0))
        self.main_stack.addWidget(self.settings_view)

        root_lay.addWidget(self.main_stack)

    def _init_shortcuts(self):
        """Bind keyboard shortcuts for fluent navigation."""
        QShortcut(QKeySequence(Qt.Key_Left), self, self._prev_page)
        QShortcut(QKeySequence(Qt.Key_Right), self, self._next_page)
        QShortcut(QKeySequence("Ctrl+N"), self, self._create_new_page)
        QShortcut(QKeySequence("Ctrl+S"), self, self._on_push_to_surface)

    def _init_networking_signals(self):
        self.server.on_client_connected = lambda d: QTimer.singleShot(0, lambda: self._handle_client_connected(d))
        self.server.on_client_disconnected = lambda did: QTimer.singleShot(0, lambda: self._handle_client_disconnected(did))
        self.server.on_button_pressed = lambda bid, t: QTimer.singleShot(0, lambda: self._handle_button_pressed(bid, t))

        # Periodic live check of connected devices on GUI thread
        self.connection_poll_timer = QTimer(self)
        self.connection_poll_timer.timeout.connect(self._refresh_connection_status)
        self.connection_poll_timer.start(1500)
        self._refresh_connection_status()

    def _refresh_connection_status(self):
        count = self.server.get_connected_devices_count() if self.server else 0
        is_conn = (count > 0)
        if self.status_pill.is_connected != is_conn:
            self.status_pill.set_connected(is_conn)
        self.device_count_lbl.setText(f"{count} Enhed{'er' if count != 1 else ''}")

    def _init_auth_signals(self):
        if hasattr(self, "topbar_avatar"):
            self.auth_mgr.auth_success.connect(self._update_auth_avatar)
            self.auth_mgr.auth_logged_out.connect(self._update_auth_avatar)
            self._update_auth_avatar()

    def _update_auth_avatar(self, *args):
        if not hasattr(self, "topbar_avatar"):
            return
        if self.auth_mgr.is_logged_in():
            u = self.auth_mgr.current_user or {}
            av_path = u.get("avatar_path")
            if av_path and os.path.exists(av_path):
                self.topbar_avatar.set_image(av_path)
            else:
                self.topbar_avatar.set_initials(u.get("name", "TD"))
            self.topbar_avatar.setToolTip(f"Logget ind som: {u.get('name', 'Google Bruger')} ({u.get('email', '')})")
        else:
            self.topbar_avatar.set_image(None)
            self.topbar_avatar.set_initials("TD")
            self.topbar_avatar.setToolTip("Google Sign-In & Profil")

    def _open_account_menu(self):
        if not hasattr(self, "topbar_avatar"):
            return
        menu = QMenu(self)
        if self.auth_mgr.is_logged_in():
            u = self.auth_mgr.current_user or {}
            name_act = menu.addAction(u.get('name', 'Google Bruger'))
            name_act.setEnabled(False)
            email_act = menu.addAction(u.get('email', ''))
            email_act.setEnabled(False)
            menu.addSeparator()
            pref_act = menu.addAction("Indstillinger...")
            signout_act = menu.addAction("Log Ud")
            chosen = menu.exec(self.topbar_avatar.mapToGlobal(QPoint(0, 36)))
            if chosen == signout_act:
                self.auth_mgr.sign_out()
                self.show_toast("Logget ud af Google")
            elif chosen == pref_act:
                self._open_settings_dialog(page_index=1)
        else:
            login_act = menu.addAction("Continue with Google...")
            pref_act = menu.addAction("Konfigurer OAuth...")
            chosen = menu.exec(self.topbar_avatar.mapToGlobal(QPoint(0, 36)))
            if chosen == login_act:
                cid, _ = self.auth_mgr.get_credentials()
                if not cid:
                    self._open_settings_dialog(page_index=1)
                else:
                    self.auth_mgr.start_desktop_oauth_flow()
            elif chosen == pref_act:
                self._open_settings_dialog(page_index=1)

    def _update_license_badge(self):
        info = get_license_info()
        if info.get("licensed", False):
            self.license_badge.setText("Pro ✓")
            self.license_badge.setToolTip(f"VENTRIX Pro Aktiveret ({info.get('key', '')})")
        else:
            self.license_badge.setText("Få Licens")
            self.license_badge.setToolTip("Klik for at indtaste eller hente din gratis licensnøgle")

    def _open_license_dialog(self):
        dlg = LicenseActivationDialog(parent=self)
        dlg.activated.connect(lambda k: self._update_license_badge())
        dlg.exec()

    def _on_welcome_continued(self, user_name: str, language: str, always_show: bool):
        self.config_store.settings.user_name = user_name
        self.config_store.settings.language = language
        self.config_store.settings.always_show_welcome = always_show
        self.config_store.settings.has_seen_welcome = True
        self.config_store.save_settings()
        set_language(language)
        self._update_license_badge()
        self.main_stack.setCurrentIndex(1)
        if not is_licensed():
            from PySide6.QtCore import QTimer
            QTimer.singleShot(400, self._open_license_dialog)

    def _on_language_changed(self, lang: str):
        self.prof_lbl.setText(t("topbar_profile"))
        self.push_btn.setText(t("topbar_push_surface"))
        self.push_btn.setToolTip(t("topbar_push_surface_tooltip"))
        self.devices_btn.setText(t("topbar_devices"))
        self.devices_btn.setToolTip(t("topbar_devices"))
        self.usb_btn.setText(t("topbar_usb"))
        self.usb_btn.setToolTip(t("topbar_usb"))
        self.settings_btn.setToolTip(t("topbar_settings_tooltip"))

        count = self.server.get_connected_devices_count() if self.server else 0
        self.device_count_lbl.setText(t("topbar_devices_count", count=count))

    def show_toast(self, message: str):
        """Displays floating translucent glass toast pill."""
        toast = GlassToast(message, self)
        toast.adjustSize()
        x = (self.width() - toast.width()) // 2
        y = 65 + len(self._active_toasts) * 42
        toast.move(x, y)
        toast.show()
        self._active_toasts.append(toast)
        QTimer.singleShot(2500, lambda: self._active_toasts.remove(toast) if toast in self._active_toasts else None)

    def _handle_client_connected(self, device: DeviceModel):
        count = self.server.get_connected_devices_count()
        self.status_pill.set_connected(True)
        self.device_count_lbl.setText(f"{count} Enhed{'er' if count != 1 else ''}")
        self.show_toast(f"Surface forbundet: {device.name}")

    def _handle_client_disconnected(self, device_id: str):
        count = self.server.get_connected_devices_count()
        if count == 0:
            self.status_pill.set_connected(False)
            self.device_count_lbl.setText("0 Enheder")
            self.show_toast("Surface afbrudt")
        else:
            self.device_count_lbl.setText(f"{count} Enhed{'er' if count != 1 else ''}")

    def _handle_button_pressed(self, button_id: str, title: str):
        pass

    def _load_active_profile(self):
        self._refresh_pages()
        self.process_monitor.set_profile(self.config_store.get_active_profile())

    def _refresh_pages(self):
        active = self.config_store.get_active_profile()
        if not active or not active.pages:
            return

        cur_idx = min(active.active_page_index, len(active.pages) - 1)
        cur_page = active.pages[cur_idx]

        # Update preview & inspectors
        self.preview.set_page(cur_page)
        self.deck_inspector.set_page(cur_page)
        self.inspector.set_button(None)
        self.right_stack.setCurrentIndex(0)

        # Update floating dock
        self.dock.set_pages(active.pages, active_index=cur_idx)

    def _on_profile_combo_changed(self, index: int):
        if index < 0 or index >= len(self.config_store.profiles):
            return
        prof = self.config_store.profiles[index]
        self.config_store.settings.active_profile_id = prof.id
        self.config_store.save_settings()
        self._refresh_pages()
        self.server.broadcast_layout_update()
        self.show_toast(f"Profil aktiveret: {prof.name}")

    def _create_new_profile(self):
        name, ok = AppleGlassInputDialog.get_text(self, "Ny Profil", "Navn på den nye profil:")
        if ok and name.strip():
            new_prof = ProfileModel(
                name=name.strip(),
                pages=[PageModel(name="Home", rows=3, cols=4, buttons=[])]
            )
            self.config_store.profiles.append(new_prof)
            self.config_store.settings.active_profile_id = new_prof.id
            self.config_store.save_profiles()
            self.config_store.save_settings()
            self._load_active_profile()
            self.server.broadcast_layout_update()
            self.show_toast(f"Profil oprettet: {new_prof.name}")

    def _delete_active_profile(self):
        if len(self.config_store.profiles) <= 1:
            AppleGlassConfirmDialog.alert(self, "Kan Ikke Slettes", "Du skal have mindst én profil.")
            return

        reply = AppleGlassConfirmDialog.ask(
            self, "Slet Profil", "Er du sikker på, at du vil slette den aktive profil?",
            confirm_text="Slet", is_danger=True
        )
        if reply:
            active = self.config_store.get_active_profile()
            self.config_store.profiles = [p for p in self.config_store.profiles if p.id != active.id]
            self.config_store.settings.active_profile_id = self.config_store.profiles[0].id
            self.config_store.save_profiles()
            self.config_store.save_settings()
            self._load_active_profile()
            self.server.broadcast_layout_update()
            self.show_toast("Profil slettet")

    # ----------------------------------------------------
    # Page Navigation (Horizontal & Dock)
    # ----------------------------------------------------
    def _switch_to_page(self, index: int):
        active = self.config_store.get_active_profile()
        if not active or index < 0 or index >= len(active.pages):
            return

        active.active_page_index = index
        self.config_store.save_profiles(create_backup=False)

        cur_page = active.pages[index]
        self.preview.set_page(cur_page)
        self.deck_inspector.set_page(cur_page)
        self.inspector.set_button(None)
        self.right_stack.setCurrentIndex(0)
        self.dock.set_active_index(index)
        self.server.broadcast_layout_update()

    def _prev_page(self):
        active = self.config_store.get_active_profile()
        if not active or not active.pages:
            return
        idx = (active.active_page_index - 1) % len(active.pages)
        self._switch_to_page(idx)

    def _next_page(self):
        active = self.config_store.get_active_profile()
        if not active or not active.pages:
            return
        idx = (active.active_page_index + 1) % len(active.pages)
        self._switch_to_page(idx)

    def _on_dock_page_selected(self, index: int):
        self._switch_to_page(index)

    def _create_new_page(self):
        active = self.config_store.get_active_profile()
        if not active:
            return

        name, ok = AppleGlassInputDialog.get_text(self, "Ny Side", "Navn på den nye side:")
        if ok and name.strip():
            new_page = PageModel(name=name.strip(), rows=3, cols=4, buttons=[])
            active.pages.append(new_page)
            self.config_store.save_profiles()
            self._refresh_pages()
            self._switch_to_page(len(active.pages) - 1)
            self.show_toast(f"Side '{new_page.name}' oprettet")

    def _on_page_renamed(self, index: int, new_name: str):
        active = self.config_store.get_active_profile()
        if active and 0 <= index < len(active.pages):
            active.pages[index].name = new_name
            self.config_store.save_profiles(create_backup=False)
            self._refresh_pages()
            self.server.broadcast_layout_update()
            self.show_toast("Side omdøbt")

    def _duplicate_page(self, index: int):
        active = self.config_store.get_active_profile()
        if not active or index < 0 or index >= len(active.pages):
            return

        source = active.pages[index]
        d = source.to_dict()
        d["id"] = ""
        d["name"] = f"{source.name} (Kopi)"
        dup = PageModel.from_dict(d)

        active.pages.insert(index + 1, dup)
        self.config_store.save_profiles()
        self._refresh_pages()
        self._switch_to_page(index + 1)
        self.show_toast("Side duplikeret")

    def _delete_page(self, index: int):
        active = self.config_store.get_active_profile()
        if not active or index < 0 or index >= len(active.pages):
            return

        if len(active.pages) <= 1:
            AppleGlassConfirmDialog.alert(self, "Kan Ikke Slettes", "En profil skal have mindst én side.")
            return

        del_name = active.pages[index].name
        reply = AppleGlassConfirmDialog.ask(
            self, "Slet Side", f"Er du sikker på, at du vil slette siden '{del_name}'?",
            confirm_text="Slet", is_danger=True
        )
        if reply:
            del active.pages[index]
            active.active_page_index = max(0, min(active.active_page_index, len(active.pages) - 1))
            self.config_store.save_profiles()
            self._refresh_pages()
            self._switch_to_page(active.active_page_index)
            self.show_toast("Side slettet")

    def _move_page(self, from_idx: int, to_idx: int):
        active = self.config_store.get_active_profile()
        if not active:
            return
        if 0 <= from_idx < len(active.pages) and 0 <= to_idx < len(active.pages):
            item = active.pages.pop(from_idx)
            active.pages.insert(to_idx, item)
            self.config_store.save_profiles(create_backup=False)
            self._refresh_pages()
            self._switch_to_page(to_idx)

    def _on_button_moved_to_page(self, button_id: str, target_page_index: int):
        active = self.config_store.get_active_profile()
        if not active or not active.pages:
            return
        cur_idx = min(active.active_page_index, len(active.pages) - 1)
        if cur_idx == target_page_index:
            return

        cur_page = active.pages[cur_idx]
        if target_page_index < 0 or target_page_index >= len(active.pages):
            return
        target_page = active.pages[target_page_index]

        btn = next((b for b in cur_page.buttons if b.id == button_id), None)
        if not btn:
            return

        occupied = {(b.row, b.col) for b in target_page.buttons}
        target_slot = None
        for r in range(target_page.rows):
            for c in range(target_page.cols):
                if (r, c) not in occupied:
                    target_slot = (r, c)
                    break
            if target_slot:
                break

        if not target_slot:
            self.show_toast(f"Siden '{target_page.name}' er fuld!")
            return

        cur_page.buttons.remove(btn)
        btn.row = target_slot[0]
        btn.col = target_slot[1]
        target_page.buttons.append(btn)

        self.config_store.save_profiles(create_backup=False)
        self._switch_to_page(target_page_index)
        self.preview.set_selected_button(btn.id)
        self.server.broadcast_layout_update()
        self.show_toast(f"Flyttet til {target_page.name}")

    # ----------------------------------------------------
    # Button & Inspector Handlers
    # ----------------------------------------------------
    def _on_button_selected_in_preview(self, button: Optional[ButtonModel]):
        if button:
            self.inspector.set_button(button)
            self.right_stack.setCurrentIndex(1)
        else:
            active = self.config_store.get_active_profile()
            if active and active.pages:
                cur_idx = min(active.active_page_index, len(active.pages) - 1)
                self.deck_inspector.set_page(active.pages[cur_idx])
            self.right_stack.setCurrentIndex(0)

    def _on_deck_style_changed(self):
        self.preview.rebuild_grid()
        self.preview.update()
        self.config_store.save_profiles(create_backup=False)
        self.server.broadcast_layout_update()

    def _on_background_dropped(self, image_path: str):
        if self.preview.current_page:
            self.deck_inspector.set_page(self.preview.current_page)
        self.preview.update()
        self.config_store.save_profiles(create_backup=False)
        self.server.broadcast_layout_update()
        self.show_toast("Baggrund opdateret via Drag & Drop")

    def _on_button_updated_in_inspector(self, button: ButtonModel):
        self.preview.refresh_grid()
        self.config_store.save_profiles(create_backup=False)
        self.server.broadcast_layout_update()

    def _on_button_deleted_in_inspector(self, button_id: str):
        # Find and remove button
        active = self.config_store.get_active_profile()
        if active and active.pages:
            cur_page = active.pages[active.active_page_index]
            tgt = next((b for b in cur_page.buttons if b.id == button_id), None)
            if tgt:
                self.preview._delete_button(tgt)
        self.inspector.set_button(None)
        if self.preview.current_page:
            self.deck_inspector.set_page(self.preview.current_page)
        self.right_stack.setCurrentIndex(0)
        self.show_toast("Knap slettet")

    def _on_layout_changed(self):
        self.config_store.save_profiles(create_backup=False)
        self.server.broadcast_layout_update()

    def _on_button_test_requested(self, button: ButtonModel):
        if button and button.action:
            self.action_engine.execute_action_async(button.action, button_id=button.id)
            self.show_toast(f"Test udført: {button.title}")

    def _toggle_discord_inspector(self):
        """Toggle Discord Inspector side panel in right_stack."""
        if self.right_stack.currentIndex() == 2:
            self.right_stack.setCurrentIndex(0)
        else:
            self.right_stack.setCurrentIndex(2)

    def _toggle_medal_inspector(self):
        """Toggle Medal.tv Inspector side panel in right_stack."""
        if self.right_stack.currentIndex() == 3:
            self.right_stack.setCurrentIndex(0)
        else:
            self.right_stack.setCurrentIndex(3)

    def _on_external_button_created(self, spec: dict):
        """Creates or assigns a preset button (Discord/Medal) onto the active page."""
        import uuid
        active = self.config_store.get_active_profile()
        if not active or not active.pages:
            self.show_toast("Ingen aktiv side fundet")
            return
        cur_idx = min(active.active_page_index, len(active.pages) - 1)
        cur_page = active.pages[cur_idx]

        # 1. Determine target slot:
        # If an empty slot was explicitly selected (e.g. empty_r_c), use it.
        # Otherwise, find the next free slot on the page.
        occupied = {(b.row, b.col) for b in cur_page.buttons}
        target_slot = None

        sel_id = getattr(self.preview, "selected_button_id", None)
        if sel_id and sel_id.startswith("empty_"):
            parts = sel_id.split("_")
            try:
                cand = (int(parts[1]), int(parts[2]))
                if cand not in occupied:
                    target_slot = cand
            except Exception:
                target_slot = None

        if not target_slot:
            for r in range(cur_page.rows):
                for c in range(cur_page.cols):
                    if (r, c) not in occupied:
                        target_slot = (r, c)
                        break
                if target_slot:
                    break

        action_data = ActionModel(
            action_type=spec.get("action_type", ""),
            sub_action=spec.get("sub_action", ""),
            target=spec.get("target", ""),
            args=spec.get("args", "")
        )

        icon_val = spec.get("icon", spec.get("icon_name", ""))
        title_val = spec.get("title", "Knap")
        bg_col = spec.get("bg_color", "#1E1F2A")

        # Automatically configure user's Medal shortcuts if this is a Medal button
        if spec.get("action_type") == ACTION_TYPE_MEDAL:
            sub = spec.get("sub_action", "")
            key = spec.get("target", "") or spec.get("args", "")
            auto_sync_medal_button(sub, key)

        if not target_slot:
            # If the page is full and a button is currently selected, replace that button
            if sel_id and not sel_id.startswith("empty_"):
                target_btn = next((b for b in cur_page.buttons if b.id == sel_id), None)
                if target_btn:
                    target_btn.title = title_val
                    target_btn.icon = icon_val
                    target_btn.action = action_data
                    target_btn.bg_color = bg_col
                    target_btn.text_color = "#FFFFFF"
                    self.config_store.save_profiles(create_backup=False)
                    self.preview.rebuild_grid()
                    self.preview.set_selected_button(target_btn.id)
                    self.inspector.set_button(target_btn)
                    self.server.broadcast_layout_update()
                    if spec.get("action_type") == ACTION_TYPE_MEDAL:
                        self.show_toast(f"✓ Medal knap opdateret & synkroniseret ({spec.get('target', '')})")
                    else:
                        self.show_toast(f"Knap opdateret: {title_val}")
                    return
            self.show_toast("Siden er fuld!")
            return

        new_btn = ButtonModel(
            id=str(uuid.uuid4())[:8],
            row=target_slot[0],
            col=target_slot[1],
            title=title_val,
            icon=icon_val,
            bg_color=bg_col,
            text_color="#FFFFFF",
            action=action_data
        )
        cur_page.buttons.append(new_btn)

        self.config_store.save_profiles(create_backup=False)
        self.preview.rebuild_grid()
        self.preview.set_selected_button(new_btn.id)
        self.inspector.set_button(new_btn)
        self.server.broadcast_layout_update()
        if spec.get("action_type") == ACTION_TYPE_MEDAL:
            self.show_toast(f"✓ Medal {title_val} ({spec.get('target', '')}) synkroniseret & oprettet på Deck")
        else:
            self.show_toast(f"Oprettet på Deck: {title_val}")

    # ----------------------------------------------------
    # Push to Surface Primary Action (Apple Feedback Flow)
    # ----------------------------------------------------
    def _on_push_to_surface(self):
        """
        Saves all configurations and broadcasts instant layout sync.
        Transitions: Preparing... -> Sending... -> Done ✓
        """
        self.config_store.save_all()
        self.server.broadcast_layout_sync()
        self.preview.refresh_grid()

        self.push_btn.setText("Preparing...")
        self.push_btn.setEnabled(False)

        def step_sending():
            self.push_btn.setText("Sending...")
            QTimer.singleShot(250, step_done)

        def step_done():
            self.push_btn.setText("Done ✓")
            self.show_toast("Done ✓")

            QTimer.singleShot(1500, step_restore)

        def step_restore():
            self.push_btn.setText("↗ Send til Surface")
            self.push_btn.setEnabled(True)

        QTimer.singleShot(150, step_sending)

    # ----------------------------------------------------
    # In-Window View Navigation (Zero External Popups)
    # ----------------------------------------------------
    def _open_connect_device_dialog(self):
        dlg = ConnectDeviceDialog(self.config_store, self.server, self)
        dlg.exec()
        self._refresh_connection_status()

    def _open_update_dialog(self):
        from editor.widgets.update_dialog import UpdateDialog
        dlg = UpdateDialog(self)
        dlg.exec()

    def _open_devices_dialog(self):
        self.settings_view.category_list.setCurrentRow(2)
        self.main_stack.setCurrentIndex(2)

    def _open_usb_dialog(self):
        self.settings_view.category_list.setCurrentRow(3)
        self.main_stack.setCurrentIndex(2)

    def _open_settings_dialog(self, page_index: int = 0):
        self.settings_view.category_list.setCurrentRow(page_index)
        self.main_stack.setCurrentIndex(2)

    def _init_system_tray(self):
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray = QSystemTrayIcon(self.app_icon, self)
        menu = QMenu()
        open_act = menu.addAction(f"Open {APP_NAME}")
        open_act.triggered.connect(self.showNormal)
        menu.addSeparator()
        quit_act = menu.addAction("Quit")
        quit_act.triggered.connect(QApplication.instance().quit)
        self.tray.setContextMenu(menu)
        self.tray.show()

    def closeEvent(self, event: QCloseEvent):
        if self.config_store.settings.minimize_to_tray:
            event.ignore()
            self.hide()
            if hasattr(self, "tray"):
                self.tray.showMessage(APP_NAME, f"{APP_NAME} kører i baggrunden.", QSystemTrayIcon.Information, 1500)
        else:
            event.accept()

    def showEvent(self, event):
        super().showEvent(event)
        self._apply_windows_dark_titlebar()

    def _apply_windows_dark_titlebar(self):
        """Forces Windows 10/11 OS titlebar to pitch dark mode (#0A0A0C) with white text, eliminating the white bar."""
        import sys
        if sys.platform != "win32":
            return
        try:
            import ctypes
            from ctypes import c_int, byref, sizeof
            hwnd = int(self.winId())
            if hwnd:
                dark_val = c_int(1)
                # DWMWA_USE_IMMERSIVE_DARK_MODE (20 on Win11/Win10 2004+, 19 on older Win10)
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 20, byref(dark_val), sizeof(dark_val))
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 19, byref(dark_val), sizeof(dark_val))

                # DWMWA_CAPTION_COLOR = 35 (Win11) -> 0x000C0A0A (#0A0A0C)
                caption_col = c_int(0x000C0A0A)
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 35, byref(caption_col), sizeof(caption_col))

                # DWMWA_TEXT_COLOR = 36 (Win11) -> 0x00FFFFFF (#FFFFFF)
                text_col = c_int(0x00FFFFFF)
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 36, byref(text_col), sizeof(text_col))
        except Exception:
            pass
