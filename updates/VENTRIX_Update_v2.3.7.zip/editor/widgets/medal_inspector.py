"""
TouchDeck / VENTRIX - Medal.tv Integration Inspector
Apple visionOS Glass aesthetic panel for configuring and quick-adding
Medal.tv controls to TouchDeck:
- Clip durations (15s, 30s, 1 min, 2 min, 5 min)
- Start / Stop Full Screen Session Recording
- Gameplay Bookmarks / Markers
- Keybind customization & triggers
Author: VENTRIX
"""

import os
from pathlib import Path
from typing import Optional, Dict, Any

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFrame, QScrollArea, QGridLayout
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QIcon, QPixmap

from shared.constants import (
    ACTION_TYPE_MEDAL,
    MEDAL_CLIP_15S, MEDAL_CLIP_30S, MEDAL_CLIP_1M, MEDAL_CLIP_2M, MEDAL_CLIP_5M,
    MEDAL_RECORD_TOGGLE, MEDAL_BOOKMARK
)
from shared.models import ButtonModel, ActionModel
from editor.actions.action_engine import Win32KeyboardMouse
from editor.services.medal_sync import sync_hotkeys_to_medal


class AppleDivider(QFrame):
    """Subtle 1px hairline divider."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.HLine)
        self.setFrameShadow(QFrame.Plain)
        self.setFixedHeight(1)
        self.setStyleSheet("background: rgba(255, 255, 255, 0.08); border: none;")


class MedalClipPresetChip(QFrame):
    """A sleek glass pill chip for clip duration preset."""
    create_requested = Signal(dict)

    def __init__(self, duration_label: str, sub_action: str, default_key: str = "F8", parent=None):
        super().__init__(parent)
        self.duration_label = duration_label
        self.sub_action = sub_action
        self.default_key = default_key

        self.setStyleSheet("""
            QFrame {
                background: rgba(255, 255, 255, 0.035);
                border: 1px solid rgba(255, 255, 255, 0.09);
                border-radius: 12px;
                padding: 4px;
            }
            QFrame:hover {
                background: rgba(255, 255, 255, 0.06);
                border-color: rgba(234, 179, 8, 0.35);
            }
        """)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(8)

        # Time label
        time_lbl = QLabel(duration_label)
        time_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        lay.addWidget(time_lbl, stretch=1)

        # Key badge
        key_badge = QLabel(default_key)
        key_badge.setStyleSheet("""
            color: rgba(255, 255, 255, 0.65);
            background: rgba(255, 255, 255, 0.07);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            padding: 2px 7px;
        """)
        lay.addWidget(key_badge)

        # Quick Add button
        add_btn = QPushButton("+ Opret")
        add_btn.setCursor(Qt.PointingHandCursor)
        add_btn.setFixedHeight(24)
        add_btn.setStyleSheet("""
            QPushButton {
                background: rgba(234, 179, 8, 0.20);
                border: 1px solid rgba(234, 179, 8, 0.40);
                border-radius: 8px;
                color: #FDE047;
                font-size: 11px;
                font-weight: 600;
                padding: 0 10px;
            }
            QPushButton:hover {
                background: rgba(234, 179, 8, 0.35);
                border-color: #EAB308;
                color: #FFFFFF;
            }
        """)
        add_btn.clicked.connect(self._create_on_deck)
        lay.addWidget(add_btn)

    def _create_on_deck(self):
        spec = {
            "title": f"Klip {self.duration_label}",
            "action_type": ACTION_TYPE_MEDAL,
            "sub_action": self.sub_action,
            "target": self.default_key,
            "args": self.default_key,
            "icon_name": "medal",
            "bg_color": "#261E14"
        }
        self.create_requested.emit(spec)


class MedalActionCard(QFrame):
    """Glass card for Medal recording toggle or bookmark."""
    create_requested = Signal(dict)

    def __init__(self, title: str, subtitle: str, sub_action: str, default_key: str, icon_name: str, parent=None):
        super().__init__(parent)
        self.title_text = title
        self.sub_action = sub_action
        self.default_key = default_key
        self.icon_name = icon_name

        self.setObjectName("medalCard")
        self.setStyleSheet("""
            QFrame#medalCard {
                background: rgba(255, 255, 255, 0.035);
                border: 1px solid rgba(255, 255, 255, 0.09);
                border-radius: 14px;
                padding: 10px;
            }
            QFrame#medalCard:hover {
                background: rgba(255, 255, 255, 0.055);
                border-color: rgba(255, 255, 255, 0.16);
            }
        """)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        # Header row
        header_row = QHBoxLayout()
        header_row.setSpacing(10)

        # Icon badge
        icon_lbl = QLabel()
        icon_lbl.setFixedSize(30, 30)
        icon_lbl.setAlignment(Qt.AlignCenter)
        icon_lbl.setStyleSheet("background: rgba(234, 179, 8, 0.18); border: 1px solid rgba(234, 179, 8, 0.35); border-radius: 8px;")
        
        icon_path = Path(__file__).resolve().parent.parent.parent / "assets" / "icons" / f"{icon_name}.png"
        if icon_path.exists():
            pix = QPixmap(str(icon_path)).scaled(18, 18, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            icon_lbl.setPixmap(pix)
        else:
            icon_lbl.setText("")
        header_row.addWidget(icon_lbl)

        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        t_lbl = QLabel(title)
        t_lbl.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 600;")
        title_col.addWidget(t_lbl)

        s_lbl = QLabel(subtitle)
        s_lbl.setStyleSheet("color: #8E8E93; font-size: 11px;")
        s_lbl.setWordWrap(True)
        title_col.addWidget(s_lbl)
        header_row.addLayout(title_col, stretch=1)

        lay.addLayout(header_row)

        # Buttons row
        btn_row = QHBoxLayout()
        btn_row.setSpacing(6)

        test_btn = QPushButton("Test")
        test_btn.setCursor(Qt.PointingHandCursor)
        test_btn.setFixedHeight(28)
        test_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 9px;
                color: #A1A1AA;
                font-size: 11px;
                font-weight: 600;
                padding: 0 12px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.12);
                color: #FFFFFF;
                border-color: rgba(255, 255, 255, 0.22);
            }
        """)
        test_btn.clicked.connect(self._test_action)
        btn_row.addWidget(test_btn)

        create_btn = QPushButton("+ Opret på Deck")
        create_btn.setCursor(Qt.PointingHandCursor)
        create_btn.setFixedHeight(28)
        create_btn.setStyleSheet("""
            QPushButton {
                background: rgba(234, 179, 8, 0.25);
                border: 1px solid rgba(234, 179, 8, 0.45);
                border-radius: 9px;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 600;
                padding: 0 14px;
            }
            QPushButton:hover {
                background: rgba(234, 179, 8, 0.45);
                border-color: #EAB308;
            }
            QPushButton:pressed {
                background: rgba(234, 179, 8, 0.60);
            }
        """)
        create_btn.clicked.connect(self._create_on_deck)
        btn_row.addWidget(create_btn, stretch=1)

        lay.addLayout(btn_row)

    def _test_action(self):
        Win32KeyboardMouse.send_hotkey_combo(self.default_key)

    def _create_on_deck(self):
        spec = {
            "title": self.title_text,
            "action_type": ACTION_TYPE_MEDAL,
            "sub_action": self.sub_action,
            "target": self.default_key,
            "args": self.default_key,
            "icon_name": self.icon_name,
            "bg_color": "#261E14"
        }
        self.create_requested.emit(spec)


class MedalInspector(QWidget):
    """
    Dedicated Medal.tv configuration and quick-add inspector panel in the right stack.
    """
    close_requested = Signal()
    button_creation_requested = Signal(dict)

    def __init__(self, main_win=None, parent=None):
        super().__init__(parent)
        self.main_win = main_win
        self._init_ui()

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(0, 0, 0, 0)
        root_lay.setSpacing(0)

        # Scroll Area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("background: transparent; border: none;")

        container = QWidget()
        container.setObjectName("medalInspectorContainer")
        container.setStyleSheet("background: transparent;")
        lay = QVBoxLayout(container)
        lay.setContentsMargins(18, 16, 18, 20)
        lay.setSpacing(14)

        # Top Header Row: Badge, Title & Close Button
        header_row = QHBoxLayout()
        header_row.setSpacing(10)

        # Medal Logo
        logo_lbl = QLabel()
        logo_lbl.setFixedSize(28, 28)
        logo_lbl.setAlignment(Qt.AlignCenter)
        medal_icon_path = Path(__file__).resolve().parent.parent.parent / "assets" / "icons" / "medal.png"
        if medal_icon_path.exists():
            pix = QPixmap(str(medal_icon_path)).scaled(24, 24, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            logo_lbl.setPixmap(pix)
        else:
            logo_lbl.setText("")
        header_row.addWidget(logo_lbl)

        header_title_col = QVBoxLayout()
        header_title_col.setSpacing(1)
        h_title = QLabel("Medal.tv Kontrol")
        h_title.setStyleSheet("color: #FFFFFF; font-size: 15px; font-weight: 700; letter-spacing: -0.2px;")
        header_title_col.addWidget(h_title)

        h_sub = QLabel("Klip & optag gameplay i realtid")
        h_sub.setStyleSheet("color: #8E8E93; font-size: 11px;")
        header_title_col.addWidget(h_sub)
        header_row.addLayout(header_title_col, stretch=1)

        # Close Button
        close_btn = QPushButton("✕")
        close_btn.setObjectName("inspectorCloseBtn")
        close_btn.setToolTip("Luk Medal panel")
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.clicked.connect(self.close_requested.emit)
        header_row.addWidget(close_btn)

        lay.addLayout(header_row)
        lay.addWidget(AppleDivider())

        # Section 1: Klip Gameplay (Varighed)
        sec_title = QLabel("KLIP GAMEPLAY (VARIGHED)")
        sec_title.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 700; letter-spacing: 0.8px;")
        lay.addWidget(sec_title)

        presets = [
            ("15 sekunder", MEDAL_CLIP_15S, "Ctrl+F8"),
            ("30 sekunder", MEDAL_CLIP_30S, "F8"),
            ("1 minut", MEDAL_CLIP_1M, "Ctrl+F9"),
            ("2 minutter", MEDAL_CLIP_2M, "Ctrl+F10"),
            ("5 minutter", MEDAL_CLIP_5M, "Ctrl+F11"),
        ]

        for lbl, sub_act, dkey in presets:
            chip = MedalClipPresetChip(duration_label=lbl, sub_action=sub_act, default_key=dkey, parent=self)
            chip.create_requested.connect(self._on_item_create)
            lay.addWidget(chip)

        lay.addSpacing(6)
        lay.addWidget(AppleDivider())
        lay.addSpacing(4)

        # Section 2: Fuld Skærm Optagelse & Bogmærke
        sec2_title = QLabel("OPTAGELSE & BOGMÆRKER")
        sec2_title.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 700; letter-spacing: 0.8px;")
        lay.addWidget(sec2_title)

        # Record Toggle Card
        card_record = MedalActionCard(
            title="Start/Stop Fuld Optagelse",
            subtitle="Optag hele spilsessionen (Medal default: Alt+F7)",
            sub_action=MEDAL_RECORD_TOGGLE,
            default_key="Alt+F7",
            icon_name="record_start",
            parent=self
        )
        card_record.create_requested.connect(self._on_item_create)
        lay.addWidget(card_record)

        # Bookmark Card
        card_bm = MedalActionCard(
            title="Tilføj Bogmærke",
            subtitle="Sæt et tidslinje-mærke i Medal (Default: F10)",
            sub_action=MEDAL_BOOKMARK,
            default_key="F10",
            icon_name="game",
            parent=self
        )
        card_bm.create_requested.connect(self._on_item_create)
        lay.addWidget(card_bm)

        lay.addSpacing(6)
        lay.addWidget(AppleDivider())
        lay.addSpacing(4)

        # Section 3: Auto-Synkronisering med Medal
        sec3_title = QLabel("MEDAL BYPASS & SYNKRONISERING")
        sec3_title.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 700; letter-spacing: 0.8px;")
        lay.addWidget(sec3_title)

        sync_btn = QPushButton("Synkroniser genveje til Medal.tv")
        sync_btn.setCursor(Qt.PointingHandCursor)
        sync_btn.setFixedHeight(36)
        sync_btn.setStyleSheet("""
            QPushButton {
                background: rgba(234, 179, 8, 0.22);
                border: 1px solid rgba(234, 179, 8, 0.45);
                border-radius: 10px;
                color: #FEF08A;
                font-size: 12px;
                font-weight: 600;
                padding: 0 14px;
            }
            QPushButton:hover {
                background: rgba(234, 179, 8, 0.38);
                border-color: #EAB308;
                color: #FFFFFF;
            }
            QPushButton:pressed {
                background: rgba(234, 179, 8, 0.55);
            }
        """)
        sync_btn.clicked.connect(self._on_sync_medal)
        lay.addWidget(sync_btn)

        self.sync_status_lbl = QLabel("")
        self.sync_status_lbl.setStyleSheet("font-size: 11px; padding: 2px 4px;")
        self.sync_status_lbl.setWordWrap(True)
        self.sync_status_lbl.setVisible(False)
        lay.addWidget(self.sync_status_lbl)

        lay.addSpacing(4)

        # Info Box
        info_box = QFrame()
        info_box.setStyleSheet("background: rgba(234, 179, 8, 0.08); border: 1px solid rgba(234, 179, 8, 0.20); border-radius: 10px; padding: 10px;")
        info_lay = QVBoxLayout(info_box)
        info_lay.setContentsMargins(10, 10, 10, 10)
        info_lay.setSpacing(6)
        
        info_h = QLabel("Bypass Medal dropdown-tid:")
        info_h.setStyleSheet("color: #FEF08A; font-size: 12px; font-weight: 700;")
        info_lay.addWidget(info_h)

        info_txt = QLabel(
            "For at optage f.eks. 15 sekunder uden at ændre Medals globale tidsvælger, "
            "har hver klip-knap sin egen direkte genvej (f.eks. <b>Ctrl+F8</b> for 15s og <b>F8</b> for 30s).<br><br>"
            "Tryk på knappen ovenfor for automatisk at oprette disse genveje i Medal, eller tilføj dem manuelt under "
            "<b>Manage Hotkeys</b> i Medal."
        )
        info_txt.setWordWrap(True)
        info_txt.setStyleSheet("color: #E4E4E7; font-size: 11px; line-height: 1.45;")
        info_lay.addWidget(info_txt)
        lay.addWidget(info_box)

        lay.addStretch(1)

        scroll.setWidget(container)
        root_lay.addWidget(scroll)

    def _on_sync_medal(self):
        success, msg = sync_hotkeys_to_medal()
        self.sync_status_lbl.setVisible(True)
        if success:
            self.sync_status_lbl.setStyleSheet("color: #4ADE80; font-size: 11px;")
            self.sync_status_lbl.setText("Genveje synkroniseret! Genstart Medal for at aktivere de nye taster.")
        else:
            self.sync_status_lbl.setStyleSheet("color: #F87171; font-size: 11px;")
            self.sync_status_lbl.setText(msg)

    def _on_item_create(self, spec: dict):
        self.button_creation_requested.emit(spec)
