"""
NEXA - Warm Apple Welcome & Setup Surface
Features:
- Prominent 110x110 squircle logo with soft ambient glass halo
- Personalized greeting ("Velkommen tilbage, User" / "Welcome back, User")
- Live bilingual language switcher [ Dansk ]  [ English ]
- Name personalization input
- Smooth fade-in animation
Author: NEXA
"""

from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QCheckBox, QFrame, QGraphicsOpacityEffect, QStackedWidget
)
from PySide6.QtGui import (
    QFont, QPixmap, QPainter, QRadialGradient, QColor, QBrush, QPen
)
from PySide6.QtCore import Qt, Signal, QPropertyAnimation, QEasingCurve, QSize

from shared.i18n import t, get_current_language, set_language, I18nManager


class LanguageSegmentedButton(QFrame):
    """Sleek Apple glass segmented language toggle [ Dansk | English ]."""
    language_changed = Signal(str)

    def __init__(self, current_lang: str = "da", parent=None):
        super().__init__(parent)
        self.current_lang = "en" if current_lang.lower().startswith("en") else "da"
        self.setFixedHeight(34)
        self.setFixedWidth(190)
        self.setStyleSheet("""
            QFrame {
                background: rgba(255, 255, 255, 0.06);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 17px;
            }
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(3, 3, 3, 3)
        layout.setSpacing(2)

        self.da_btn = QPushButton("Dansk")
        self.da_btn.setCursor(Qt.PointingHandCursor)
        self.da_btn.setFixedHeight(28)

        self.en_btn = QPushButton("English")
        self.en_btn.setCursor(Qt.PointingHandCursor)
        self.en_btn.setFixedHeight(28)

        self.da_btn.clicked.connect(lambda: self._select_language("da"))
        self.en_btn.clicked.connect(lambda: self._select_language("en"))

        layout.addWidget(self.da_btn)
        layout.addWidget(self.en_btn)

        self._update_styles()

    def _select_language(self, lang: str):
        if self.current_lang != lang:
            self.current_lang = lang
            self._update_styles()
            self.language_changed.emit(lang)

    def _update_styles(self):
        active_style = """
            QPushButton {
                background: rgba(255, 255, 255, 0.22);
                border: 1px solid rgba(255, 255, 255, 0.45);
                border-radius: 14px;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 600;
            }
        """
        inactive_style = """
            QPushButton {
                background: transparent;
                border: 1px solid transparent;
                border-radius: 14px;
                color: #8E8E93;
                font-size: 11px;
                font-weight: 500;
            }
            QPushButton:hover {
                color: #FFFFFF;
                background: rgba(255, 255, 255, 0.08);
            }
        """
        if self.current_lang == "da":
            self.da_btn.setStyleSheet(active_style)
            self.en_btn.setStyleSheet(inactive_style)
        else:
            self.da_btn.setStyleSheet(inactive_style)
            self.en_btn.setStyleSheet(active_style)


class WarmGlassCard(QFrame):
    """Apple frosted glass card with soft ambient backlight."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = self.rect().adjusted(1, 1, -1, -1)

        # Soft warm-charcoal glass background
        painter.setPen(QPen(QColor(255, 255, 255, 30), 1.2))
        painter.setBrush(QBrush(QColor(18, 18, 22, 235)))
        painter.drawRoundedRect(rect, 24, 24)

        # Subtle top specular highlight
        halo_rect = rect.adjusted(4, 4, -4, int(-rect.height() * 0.55))
        halo_grad = QRadialGradient(rect.center().x(), rect.top() + 40, rect.width() * 0.6)
        halo_grad.setColorAt(0.0, QColor(255, 255, 255, 20))
        halo_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.setPen(Qt.NoPen)
        painter.setBrush(halo_grad)
        painter.drawRoundedRect(halo_rect, 20, 20)


class WelcomeScreen(QFrame):
    """
    Warm, hospitable Apple introductory surface.
    Displays prominent logo, personal greeting with user's name, and live language switcher.
    """
    continue_clicked = Signal(str, str, bool)  # (user_name, language, always_show)

    def __init__(self, user_name: str = "", language: str = "da", always_show: bool = True, parent=None):
        super().__init__(parent)
        self.user_name = user_name
        self.current_lang = language or "da"
        self.always_show = always_show
        self.is_editing_name = False

        self._init_ui()

        # Listen to i18n language updates
        I18nManager.get_instance().language_changed.connect(self._on_language_changed)

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(20, 20, 20, 20)
        root_lay.setAlignment(Qt.AlignCenter)

        self.card = WarmGlassCard()
        self.card.setFixedSize(520, 560)
        card_lay = QVBoxLayout(self.card)
        card_lay.setContentsMargins(44, 38, 44, 34)
        card_lay.setSpacing(12)
        card_lay.setAlignment(Qt.AlignCenter)

        # 1. Top Bar inside card: Language Switcher Pill
        top_row = QHBoxLayout()
        top_row.setContentsMargins(0, 0, 0, 0)
        top_row.addStretch()

        self.lang_toggle = LanguageSegmentedButton(current_lang=self.current_lang)
        self.lang_toggle.language_changed.connect(self._on_lang_toggled)
        top_row.addWidget(self.lang_toggle)
        top_row.addStretch()
        card_lay.addLayout(top_row)

        card_lay.addSpacing(4)

        # 2. Prominent High-Res Logo (110x110)
        self.logo_lbl = QLabel()
        self.logo_lbl.setAlignment(Qt.AlignCenter)
        self.logo_lbl.setFixedHeight(110)
        logo_path = Path(__file__).parent.parent.parent / "assets" / "nexa.png"
        if logo_path.exists():
            pix = QPixmap(str(logo_path)).scaled(110, 110, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.logo_lbl.setPixmap(pix)
        card_lay.addWidget(self.logo_lbl, alignment=Qt.AlignCenter)

        # 3. Wordmark
        self.brand_lbl = QLabel("NEXA")
        self.brand_lbl.setAlignment(Qt.AlignCenter)
        self.brand_lbl.setStyleSheet("""
            background: transparent;
            border: none;
            color: rgba(255, 255, 255, 0.70);
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 3px;
        """)
        card_lay.addWidget(self.brand_lbl)

        # 4. Welcome Headline & Tagline
        self.title_lbl = QLabel()
        self.title_lbl.setAlignment(Qt.AlignCenter)
        self.title_lbl.setStyleSheet("""
            background: transparent;
            border: none;
            color: #FFFFFF;
            font-size: 28px;
            font-weight: 600;
            letter-spacing: -0.6px;
        """)
        card_lay.addWidget(self.title_lbl)

        self.tagline_lbl = QLabel()
        self.tagline_lbl.setAlignment(Qt.AlignCenter)
        self.tagline_lbl.setWordWrap(True)
        self.tagline_lbl.setStyleSheet("""
            background: transparent;
            border: none;
            color: #8E8E93;
            font-size: 13px;
            font-weight: 400;
            line-height: 1.4;
        """)
        card_lay.addWidget(self.tagline_lbl)

        card_lay.addSpacing(6)

        # 5. Name Personalization Section
        self.name_stack = QStackedWidget()
        self.name_stack.setFixedHeight(58)
        self.name_stack.setStyleSheet("background: transparent; border: none;")

        # Page 0: Name Input Field
        input_widget = QWidget()
        input_widget.setStyleSheet("background: transparent; border: none;")
        input_lay = QVBoxLayout(input_widget)
        input_lay.setContentsMargins(0, 0, 0, 0)
        input_lay.setSpacing(4)
        input_lay.setAlignment(Qt.AlignCenter)

        self.name_prompt_lbl = QLabel()
        self.name_prompt_lbl.setAlignment(Qt.AlignCenter)
        self.name_prompt_lbl.setStyleSheet("background: transparent; border: none; color: #FFFFFF; font-size: 11px; font-weight: 500;")
        input_lay.addWidget(self.name_prompt_lbl)

        self.name_input = QLineEdit()
        self.name_input.setText(self.user_name)
        self.name_input.setFixedWidth(280)
        self.name_input.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.18);
                border-radius: 9px;
                color: #FFFFFF;
                padding: 7px 12px;
                font-size: 13px;
                text-align: center;
            }
            QLineEdit:focus {
                background: rgba(255, 255, 255, 0.14);
                border-color: #FFFFFF;
            }
        """)
        self.name_input.returnPressed.connect(self._on_continue_clicked)
        input_lay.addWidget(self.name_input, alignment=Qt.AlignCenter)
        self.name_stack.addWidget(input_widget)

        # Page 1: Greeting display with Edit option
        greeting_widget = QWidget()
        greeting_widget.setStyleSheet("background: transparent; border: none;")
        greet_lay = QHBoxLayout(greeting_widget)
        greet_lay.setContentsMargins(0, 0, 0, 0)
        greet_lay.setSpacing(8)
        greet_lay.setAlignment(Qt.AlignCenter)

        self.logged_in_lbl = QLabel()
        self.logged_in_lbl.setStyleSheet("background: transparent; border: none; color: rgba(255, 255, 255, 0.85); font-size: 13px; font-weight: 500;")
        greet_lay.addWidget(self.logged_in_lbl)

        self.edit_name_btn = QPushButton()
        self.edit_name_btn.setCursor(Qt.PointingHandCursor)
        self.edit_name_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.16);
                border-radius: 12px;
                color: #A1A1AA;
                font-size: 11px;
                padding: 4px 12px;
            }
            QPushButton:hover {
                color: #FFFFFF;
                background: rgba(255, 255, 255, 0.16);
                border-color: rgba(255, 255, 255, 0.30);
            }
        """)
        self.edit_name_btn.clicked.connect(self._enable_name_edit)
        greet_lay.addWidget(self.edit_name_btn)
        self.name_stack.addWidget(greeting_widget)

        card_lay.addWidget(self.name_stack)

        card_lay.addSpacing(6)

        # 6. Continue / Open Studio Button (Apple Solid White Pill)
        self.continue_btn = QPushButton()
        self.continue_btn.setFixedSize(200, 42)
        self.continue_btn.setCursor(Qt.PointingHandCursor)
        self.continue_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFFFFF;
                color: #000000;
                border: 1px solid #FFFFFF;
                border-radius: 21px;
                font-size: 13px;
                font-weight: 700;
                letter-spacing: 0.2px;
            }
            QPushButton:hover {
                background-color: #E5E5EA;
                border-color: #E5E5EA;
            }
            QPushButton:pressed {
                background-color: #D1D1D6;
                border-color: #D1D1D6;
            }
        """)
        self.continue_btn.clicked.connect(self._on_continue_clicked)
        card_lay.addWidget(self.continue_btn, alignment=Qt.AlignCenter)

        # 7. Checkbox: Always show on startup
        self.always_show_cb = QCheckBox()
        self.always_show_cb.setChecked(self.always_show)
        self.always_show_cb.setStyleSheet("""
            QCheckBox {
                color: #8E8E93;
                font-size: 11px;
                spacing: 8px;
                background: transparent;
                border: none;
            }
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
                border-radius: 5px;
                border: 1.5px solid rgba(255, 255, 255, 0.28);
                background: rgba(255, 255, 255, 0.06);
            }
            QCheckBox::indicator:hover {
                border-color: rgba(255, 255, 255, 0.50);
            }
            QCheckBox::indicator:checked {
                background: #FFFFFF;
                border-color: #FFFFFF;
            }
        """)
        card_lay.addWidget(self.always_show_cb, alignment=Qt.AlignCenter)

        root_lay.addWidget(self.card)

        self._refresh_texts()

    def set_user_data(self, user_name: str, language: str = "da", always_show: bool = True):
        self.user_name = user_name.strip()
        self.current_lang = language or "da"
        self.always_show = always_show
        self.name_input.setText(self.user_name)
        self.always_show_cb.setChecked(self.always_show)
        self.lang_toggle._select_language(self.current_lang)
        self._refresh_texts()

    def _refresh_texts(self):
        """Update all text based on current language and user name state."""
        has_name = bool(self.user_name and self.user_name.strip())

        if has_name and not self.is_editing_name:
            self.title_lbl.setText(t("welcome_title_return", name=self.user_name))
            self.tagline_lbl.setText(t("welcome_tagline_return"))
            self.logged_in_lbl.setText(f"{t('welcome_logged_in_as')} {self.user_name}")
            self.edit_name_btn.setText(t("welcome_change_name"))
            self.name_stack.setCurrentIndex(1)
        else:
            self.title_lbl.setText(t("welcome_title_first"))
            self.tagline_lbl.setText(t("welcome_tagline_first"))
            self.name_prompt_lbl.setText(t("welcome_name_label"))
            self.name_input.setPlaceholderText(t("welcome_name_placeholder"))
            self.name_stack.setCurrentIndex(0)

        self.continue_btn.setText(t("welcome_open_studio"))
        self.always_show_cb.setText(t("welcome_always_show"))

    def _enable_name_edit(self):
        self.is_editing_name = True
        self.name_stack.setCurrentIndex(0)
        self.name_input.selectAll()
        self.name_input.setFocus()

    def _on_lang_toggled(self, lang: str):
        set_language(lang)
        self.current_lang = lang

    def _on_language_changed(self, lang: str):
        self.current_lang = lang
        self._refresh_texts()

    def _on_continue_clicked(self):
        entered_name = self.name_input.text().strip()
        if entered_name:
            self.user_name = entered_name
        self.always_show = self.always_show_cb.isChecked()
        self.continue_clicked.emit(self.user_name, self.current_lang, self.always_show)

    def fade_in(self):
        effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(effect)
        anim = QPropertyAnimation(effect, b"opacity")
        anim.setDuration(350)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.start()
        self._fade_anim = anim
