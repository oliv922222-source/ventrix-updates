"""
TouchDeck / NEXA - Apple macOS Segmented Button Inspector
Clean, calm, uncrowded architecture:
- Segmented Apple Tabs: [ Indhold | Handling | Design ]
- Zero visual clutter: Only 2-4 focused controls visible at a time
- Zero emojis: Clean typography and subtle glass geometry
- Full bilingual Danish & English support via shared.i18n
Author: NEXA
"""

import os
from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QComboBox, QSlider, QFrame, QFileDialog,
    QScrollArea, QStackedWidget
)
from PySide6.QtCore import Qt, Signal, QSize, QRect, QRectF, QTimer
from PySide6.QtGui import (
    QIcon, QColor, QFont, QPixmap, QPainter, QLinearGradient,
    QPainterPath, QPen, QBrush
)

from editor.widgets.apple_color_picker import AppleGlassColorPicker
from editor.widgets.apple_icon_picker import AppleGlassIconPicker
from editor.widgets.macro_editor_dialog import MacroEditorDialog

from shared.constants import (
    ACTION_TYPE_APPLICATION, ACTION_TYPE_HOTKEY, ACTION_TYPE_MEDIA,
    ACTION_TYPE_MOUSE, ACTION_TYPE_SYSTEM, ACTION_TYPE_FILE_FOLDER_URL,
    ACTION_TYPE_SCRIPT, ACTION_TYPE_MACRO
)
from shared.models import ButtonModel, ActionModel
from editor.utils.icon_storage import save_custom_image, resolve_icon_path
from shared.i18n import t, I18nManager


class AppleDivider(QFrame):
    """Subtle 1px hairline divider."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.HLine)
        self.setFrameShadow(QFrame.Plain)
        self.setFixedHeight(1)
        self.setStyleSheet("background: rgba(255, 255, 255, 0.08); border: none;")


class MiniButtonPreview(QFrame):
    """Clean visionOS-inspired mini live button preview."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.button: Optional[ButtonModel] = None
        self.setFixedHeight(110)
        self.setCursor(Qt.ArrowCursor)

    def set_button(self, button: Optional[ButtonModel]):
        self.button = button
        self.update()

    def paintEvent(self, event):
        if not self.button:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)

        rect = self.rect().adjusted(14, 10, -14, -10)
        radius = self.button.border_radius or 14

        # Background Fill
        bg_col = QColor(self.button.bg_color or "#141416")
        path = QPainterPath()
        path.addRoundedRect(QRectF(rect), radius, radius)
        painter.fillPath(path, QBrush(bg_col))

        # Soft top sheen
        sheen_path = QPainterPath()
        sheen_rect = QRectF(rect.x(), rect.y(), rect.width(), rect.height() * 0.45)
        sheen_path.addRoundedRect(sheen_rect, radius, radius)
        sheen_grad = QLinearGradient(0, rect.top(), 0, rect.top() + rect.height() * 0.45)
        sheen_grad.setColorAt(0.0, QColor(255, 255, 255, 28))
        sheen_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.fillPath(sheen_path, sheen_grad)

        # Hairline Rim
        border_pen = QPen(QColor(255, 255, 255, 25), 1.0)
        painter.strokePath(path, border_pen)

        # Custom Logo / Icon
        icon_drawn = False
        resolved_icon_path = resolve_icon_path(self.button.icon)

        if resolved_icon_path and resolved_icon_path.exists():
            pix = QPixmap(str(resolved_icon_path))
            if not pix.isNull():
                max_icon_size = min(int(rect.height() * 0.44), 44)
                scaled_pix = pix.scaled(max_icon_size, max_icon_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                ix = rect.center().x() - scaled_pix.width() // 2
                iy = rect.top() + int(rect.height() * 0.32) - scaled_pix.height() // 2
                painter.drawPixmap(ix, iy, scaled_pix)
                icon_drawn = True

        # Typography
        painter.setPen(QColor(self.button.text_color or "#FFFFFF"))
        font_size = self.button.font_size or 11
        painter.setFont(QFont("Segoe UI Variable Text", font_size, QFont.DemiBold))

        if icon_drawn:
            text_rect = QRect(
                rect.left() + 6,
                rect.top() + int(rect.height() * 0.58),
                rect.width() - 12,
                int(rect.height() * 0.38)
            )
        else:
            text_rect = rect.adjusted(6, 6, -6, -6)

        painter.drawText(text_rect, Qt.AlignCenter | Qt.TextWordWrap, self.button.title or "Button")


class SegmentedTabControl(QFrame):
    """Apple macOS Segmented capsule tab bar."""
    tab_changed = Signal(int)

    def __init__(self, tabs: list, current_index: int = 0, parent=None):
        super().__init__(parent)
        self.tabs = tabs
        self.current_index = current_index
        self.buttons = []

        self.setFixedHeight(34)
        self.setStyleSheet("""
            QFrame {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 9px;
            }
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(3, 3, 3, 3)
        layout.setSpacing(2)

        for i, text in enumerate(tabs):
            btn = QPushButton(text)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFixedHeight(28)
            btn.clicked.connect(lambda checked=False, idx=i: self._select_tab(idx))
            layout.addWidget(btn)
            self.buttons.append(btn)

        self._update_styles()

    def _select_tab(self, idx: int):
        if self.current_index != idx:
            self.current_index = idx
            self._update_styles()
            self.tab_changed.emit(idx)

    def set_tab_texts(self, texts: list):
        self.tabs = texts
        for i, text in enumerate(texts):
            if i < len(self.buttons):
                self.buttons[i].setText(text)

    def _update_styles(self):
        for i, btn in enumerate(self.buttons):
            if i == self.current_index:
                btn.setStyleSheet("""
                    QPushButton {
                        background: rgba(255, 255, 255, 0.20);
                        border: 1px solid rgba(255, 255, 255, 0.40);
                        border-radius: 7px;
                        color: #FFFFFF;
                        font-size: 11px;
                        font-weight: 600;
                    }
                """)
            else:
                btn.setStyleSheet("""
                    QPushButton {
                        background: transparent;
                        border: none;
                        border-radius: 7px;
                        color: #8E8E93;
                        font-size: 11px;
                        font-weight: 500;
                    }
                    QPushButton:hover {
                        color: #FFFFFF;
                        background: rgba(255, 255, 255, 0.08);
                    }
                """)


class ButtonInspector(QFrame):
    """
    Calm, elegant Apple Settings panel for button editing.
    Segmented into 3 tranquil tabs: [ Indhold | Handling | Design ].
    Zero visual noise, zero emojis, pure macOS glass.
    """
    button_updated = Signal(object)        # ButtonModel
    button_deleted = Signal(str)           # button_id
    button_test_requested = Signal(object) # ButtonModel
    push_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("cardFrame")
        self.button: Optional[ButtonModel] = None

        # Auto-fetch timer for website URLs (700ms debounce)
        self.url_fetch_timer = QTimer(self)
        self.url_fetch_timer.setSingleShot(True)
        self.url_fetch_timer.setInterval(700)
        self.url_fetch_timer.timeout.connect(self._auto_fetch_url_logo)

        self._init_ui()

        # Listen to language changes
        I18nManager.get_instance().language_changed.connect(self._on_language_changed)

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(16, 14, 16, 14)
        root_lay.setSpacing(12)

        # ----------------------------------------------------
        # Top Header: Title & Delete Action
        # ----------------------------------------------------
        header_row = QHBoxLayout()
        header_row.setContentsMargins(0, 0, 0, 0)

        self.title_lbl = QLabel(t("inspector_title"))
        self.title_lbl.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 600; letter-spacing: 1px;")
        header_row.addWidget(self.title_lbl)
        header_row.addStretch()

        self.delete_btn = QPushButton(t("inspector_delete"))
        self.delete_btn.setObjectName("dangerBtn")
        self.delete_btn.setFixedHeight(28)
        self.delete_btn.setCursor(Qt.PointingHandCursor)
        self.delete_btn.clicked.connect(self._on_delete_clicked)
        header_row.addWidget(self.delete_btn)
        root_lay.addLayout(header_row)

        # ----------------------------------------------------
        # Apple Segmented Tabs: [ Indhold | Handling | Design ]
        # ----------------------------------------------------
        tab_names = [t("inspector_tab_content"), t("inspector_tab_action"), t("inspector_tab_design")]
        self.segmented_tabs = SegmentedTabControl(tab_names, current_index=0)
        self.segmented_tabs.tab_changed.connect(self._on_tab_changed)
        root_lay.addWidget(self.segmented_tabs)

        # ----------------------------------------------------
        # Stacked Pages: Content | Action | Design
        # ----------------------------------------------------
        self.stack = QStackedWidget()
        self.stack.addWidget(self._build_content_tab())
        self.stack.addWidget(self._build_action_tab())
        self.stack.addWidget(self._build_design_tab())
        root_lay.addWidget(self.stack, stretch=1)

    # =========================================================================
    # TAB 1: INDHOLD (CONTENT)
    # =========================================================================
    def _build_content_tab(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")

        container = QWidget()
        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 4, 0, 4)
        lay.setSpacing(12)

        # 1. Mini Live Physical Button Preview
        self.mini_preview = MiniButtonPreview()
        lay.addWidget(self.mini_preview)

        lay.addWidget(AppleDivider())

        # 2. Button Title
        self.title_input_lbl = QLabel(t("inspector_title_label"))
        self.title_input_lbl.setStyleSheet("color: #A1A1AA; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;")
        lay.addWidget(self.title_input_lbl)

        self.title_input = QLineEdit()
        self.title_input.setFixedHeight(38)
        self.title_input.setPlaceholderText(t("inspector_title_placeholder"))
        self.title_input.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                border: 1.5px solid rgba(255, 255, 255, 0.25);
                border-radius: 9px;
                padding: 0 12px;
                font-size: 13px;
                font-weight: 600;
            }
            QLineEdit:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: rgba(255, 255, 255, 0.40);
            }
            QLineEdit:focus {
                background-color: rgba(255, 255, 255, 0.16);
                border-color: #FFFFFF;
            }
        """)
        self.title_input.textChanged.connect(self._on_title_changed)
        lay.addWidget(self.title_input)

        lay.addWidget(AppleDivider())

        # 3. Compact Current Icon Card (With clean toggle)
        self.icon_sec_lbl = QLabel(t("inspector_icon_section"))
        self.icon_sec_lbl.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 600; letter-spacing: 0.8px;")
        lay.addWidget(self.icon_sec_lbl)

        icon_card = QFrame()
        icon_card.setStyleSheet("""
            QFrame {
                background: rgba(255, 255, 255, 0.04);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
            }
        """)
        icon_card_lay = QHBoxLayout(icon_card)
        icon_card_lay.setContentsMargins(10, 10, 10, 10)
        icon_card_lay.setSpacing(10)

        # Active icon preview squircle
        self.icon_thumb_lbl = QLabel()
        self.icon_thumb_lbl.setFixedSize(40, 40)
        self.icon_thumb_lbl.setAlignment(Qt.AlignCenter)
        self.icon_thumb_lbl.setStyleSheet("""
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.14);
            border-radius: 8px;
        """)
        icon_card_lay.addWidget(self.icon_thumb_lbl)

        # Active icon label info
        self.icon_name_lbl = QLabel(t("inspector_no_icon"))
        self.icon_name_lbl.setStyleSheet("color: #FFFFFF; font-size: 11px; font-weight: 500;")
        icon_card_lay.addWidget(self.icon_name_lbl, stretch=1)

        # Toggle icon picker button
        self.toggle_picker_btn = QPushButton(t("inspector_choose_icon"))
        self.toggle_picker_btn.setCursor(Qt.PointingHandCursor)
        self.toggle_picker_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.10);
                border: 1px solid rgba(255, 255, 255, 0.18);
                border-radius: 7px;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 600;
                padding: 6px 10px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.20);
            }
        """)
        self.toggle_picker_btn.clicked.connect(self._toggle_icon_picker)
        icon_card_lay.addWidget(self.toggle_picker_btn)

        # Remove icon button
        self.remove_icon_btn = QPushButton(t("inspector_remove_icon"))
        self.remove_icon_btn.setCursor(Qt.PointingHandCursor)
        self.remove_icon_btn.setStyleSheet("""
            QPushButton {
                background: rgba(239, 68, 68, 0.10);
                border: 1px solid rgba(239, 68, 68, 0.22);
                border-radius: 7px;
                color: #EF4444;
                font-size: 11px;
                font-weight: 500;
                padding: 6px 8px;
            }
            QPushButton:hover {
                background: rgba(239, 68, 68, 0.20);
            }
        """)
        self.remove_icon_btn.clicked.connect(self._clear_icon)
        icon_card_lay.addWidget(self.remove_icon_btn)

        lay.addWidget(icon_card)

        # Collapsible Icon Picker (Only shown when requested!)
        self.icon_picker = AppleGlassIconPicker(parent=self)
        self.icon_picker.icon_selected.connect(self._on_icon_selected)
        self.icon_picker.hide()
        lay.addWidget(self.icon_picker)

        lay.addStretch()
        scroll.setWidget(container)
        return scroll

    # =========================================================================
    # TAB 2: HANDLING (ACTION)
    # =========================================================================
    def _build_action_tab(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")

        container = QWidget()
        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 4, 0, 4)
        lay.setSpacing(14)

        self.act_type_lbl = QLabel(t("inspector_action_type"))
        self.act_type_lbl.setStyleSheet("color: #A1A1AA; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;")
        lay.addWidget(self.act_type_lbl)

        self.action_type_combo = QComboBox()
        self.action_type_combo.setFixedHeight(38)
        self._populate_action_types()
        self.action_type_combo.currentIndexChanged.connect(self._on_action_type_changed)
        lay.addWidget(self.action_type_combo)

        # Action Parameters Stack
        self.action_stack = QStackedWidget()

        # Page 0: Application
        app_widget = QWidget()
        app_lay = QVBoxLayout(app_widget)
        app_lay.setContentsMargins(0, 0, 0, 0)
        app_lay.setSpacing(8)
        app_lbl = QLabel("Program (.exe) eller genvej:")
        app_lbl.setStyleSheet("color: #A1A1AA; font-size: 11px; font-weight: 600;")
        app_lay.addWidget(app_lbl)
        self.pick_exe_btn = QPushButton(t("inspector_browse_exe"))
        self.pick_exe_btn.setFixedHeight(36)
        self.pick_exe_btn.setCursor(Qt.PointingHandCursor)
        self.pick_exe_btn.clicked.connect(self._browse_application)
        app_lay.addWidget(self.pick_exe_btn)
        self.app_path_input = QLineEdit()
        self.app_path_input.setFixedHeight(38)
        self.app_path_input.setPlaceholderText(t("inspector_app_placeholder"))
        self.app_path_input.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                border: 1.5px solid rgba(255, 255, 255, 0.25);
                border-radius: 9px;
                padding: 0 12px;
                font-size: 13px;
                font-weight: 500;
            }
            QLineEdit:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: rgba(255, 255, 255, 0.40);
            }
            QLineEdit:focus {
                background-color: rgba(255, 255, 255, 0.16);
                border-color: #FFFFFF;
            }
        """)
        self.app_path_input.textChanged.connect(self._on_action_params_changed)
        app_lay.addWidget(self.app_path_input)
        self.action_stack.addWidget(app_widget)

        # Page 1: Hotkey
        hotkey_widget = QWidget()
        hotkey_lay = QVBoxLayout(hotkey_widget)
        hotkey_lay.setContentsMargins(0, 0, 0, 0)
        hotkey_lay.setSpacing(8)
        hotkey_lbl = QLabel("Tastatur-kombination:")
        hotkey_lbl.setStyleSheet("color: #E4E4E7; font-size: 12px; font-weight: 600;")
        hotkey_lay.addWidget(hotkey_lbl)

        self.hotkey_input = QLineEdit()
        self.hotkey_input.setFixedHeight(42)
        self.hotkey_input.setPlaceholderText(t("inspector_hotkey_placeholder"))
        self.hotkey_input.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                border: 1.5px solid rgba(255, 255, 255, 0.30);
                border-radius: 10px;
                padding: 0 14px;
                font-size: 14px;
                font-weight: 700;
                font-family: "SF Mono", "Consolas", monospace;
                letter-spacing: 0.5px;
            }
            QLineEdit:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: rgba(255, 255, 255, 0.50);
            }
            QLineEdit:focus {
                background-color: rgba(255, 255, 255, 0.16);
                border-color: #FFFFFF;
            }
        """)
        self.hotkey_input.textChanged.connect(self._on_action_params_changed)
        hotkey_lay.addWidget(self.hotkey_input)

        hint_lbl = QLabel("F.eks. Ctrl+Shift+M, Alt+F4, Media_Play eller F13")
        hint_lbl.setStyleSheet("color: #71717A; font-size: 11px; font-style: italic;")
        hotkey_lay.addWidget(hint_lbl)
        hotkey_lay.addStretch()
        self.action_stack.addWidget(hotkey_widget)

        # Page 2: Media
        media_widget = QWidget()
        media_lay = QVBoxLayout(media_widget)
        media_lay.setContentsMargins(0, 0, 0, 0)
        media_lay.setSpacing(8)
        media_lbl = QLabel("Mediehandling:")
        media_lbl.setStyleSheet("color: #A1A1AA; font-size: 11px; font-weight: 600;")
        media_lay.addWidget(media_lbl)
        self.media_combo = QComboBox()
        self.media_combo.setFixedHeight(38)
        self.media_combo.addItems(["play_pause", "next_track", "prev_track", "volume_up", "volume_down", "volume_mute"])
        self.media_combo.currentIndexChanged.connect(self._on_action_params_changed)
        media_lay.addWidget(self.media_combo)
        self.action_stack.addWidget(media_widget)

        # Page 3: URL
        url_widget = QWidget()
        url_lay = QVBoxLayout(url_widget)
        url_lay.setContentsMargins(0, 0, 0, 0)
        url_lay.setSpacing(8)
        url_lbl = QLabel("Webadresse / URL:")
        url_lbl.setStyleSheet("color: #A1A1AA; font-size: 11px; font-weight: 600;")
        url_lay.addWidget(url_lbl)
        self.url_input = QLineEdit()
        self.url_input.setFixedHeight(38)
        self.url_input.setPlaceholderText(t("inspector_url_placeholder"))
        self.url_input.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                border: 1.5px solid rgba(255, 255, 255, 0.25);
                border-radius: 9px;
                padding: 0 12px;
                font-size: 13px;
                font-weight: 500;
            }
            QLineEdit:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: rgba(255, 255, 255, 0.40);
            }
            QLineEdit:focus {
                background-color: rgba(255, 255, 255, 0.16);
                border-color: #FFFFFF;
            }
        """)
        self.url_input.textChanged.connect(self._on_action_params_changed)
        url_lay.addWidget(self.url_input)

        self.fetch_url_logo_btn = QPushButton(t("inspector_fetch_logo"))
        self.fetch_url_logo_btn.setFixedHeight(34)
        self.fetch_url_logo_btn.setCursor(Qt.PointingHandCursor)
        self.fetch_url_logo_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.18);
                border-radius: 8px;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 600;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.16);
            }
        """)
        self.fetch_url_logo_btn.clicked.connect(self._fetch_logo_for_current_url)
        url_lay.addWidget(self.fetch_url_logo_btn)
        self.action_stack.addWidget(url_widget)

        # Page 4: System
        sys_widget = QWidget()
        sys_lay = QVBoxLayout(sys_widget)
        sys_lay.setContentsMargins(0, 0, 0, 0)
        sys_lay.setSpacing(8)
        sys_lbl = QLabel("Systemhandling:")
        sys_lbl.setStyleSheet("color: #A1A1AA; font-size: 11px; font-weight: 600;")
        sys_lay.addWidget(sys_lbl)
        self.sys_combo = QComboBox()
        self.sys_combo.setFixedHeight(38)
        self.sys_combo.addItems(["lock_workstation", "sleep", "screenshot", "task_manager"])
        self.sys_combo.currentIndexChanged.connect(self._on_action_params_changed)
        sys_lay.addWidget(self.sys_combo)
        self.action_stack.addWidget(sys_widget)

        # Page 5: Macro
        macro_widget = QWidget()
        macro_lay = QVBoxLayout(macro_widget)
        macro_lay.setContentsMargins(0, 0, 0, 0)
        macro_lay.setSpacing(8)
        self.macro_btn = QPushButton(t("inspector_edit_macro"))
        self.macro_btn.setFixedHeight(38)
        self.macro_btn.clicked.connect(self._open_macro_editor)
        macro_lay.addWidget(self.macro_btn)
        self.action_stack.addWidget(macro_widget)

        lay.addWidget(self.action_stack)

        lay.addWidget(AppleDivider())

        # Test Button
        self.test_btn = QPushButton(t("inspector_test_button"))
        self.test_btn.setCursor(Qt.PointingHandCursor)
        self.test_btn.setFixedHeight(38)
        self.test_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.10);
                border: 1px solid rgba(255, 255, 255, 0.20);
                border-radius: 8px;
                color: #FFFFFF;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.20);
            }
        """)
        self.test_btn.clicked.connect(self._on_test_clicked)
        lay.addWidget(self.test_btn)

        lay.addStretch()
        scroll.setWidget(container)
        return scroll

    # =========================================================================
    # TAB 3: DESIGN (APPEARANCE)
    # =========================================================================
    def _build_design_tab(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")

        container = QWidget()
        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 4, 0, 4)
        lay.setSpacing(14)

        # Color & Depth Picker
        self.color_sec_lbl = QLabel(t("inspector_color_section"))
        self.color_sec_lbl.setStyleSheet("color: #FFFFFF; font-size: 11px; font-weight: 500;")
        lay.addWidget(self.color_sec_lbl)

        self.color_picker = AppleGlassColorPicker(current_color="#141416", parent=self)
        self.color_picker.color_selected.connect(self._set_button_color)
        lay.addWidget(self.color_picker)

        lay.addWidget(AppleDivider())

        # Corner Radius Slider
        rad_row = QHBoxLayout()
        self.rad_lbl = QLabel(t("inspector_radius_label"))
        self.rad_lbl.setStyleSheet("color: #8E8E93; font-size: 11px;")
        rad_row.addWidget(self.rad_lbl)
        self.radius_slider = QSlider(Qt.Horizontal)
        self.radius_slider.setRange(4, 28)
        self.radius_slider.setValue(14)
        self.radius_slider.valueChanged.connect(self._on_radius_changed)
        rad_row.addWidget(self.radius_slider)
        lay.addLayout(rad_row)

        # Font Size Slider
        font_row = QHBoxLayout()
        self.font_lbl = QLabel(t("inspector_font_size_label"))
        self.font_lbl.setStyleSheet("color: #8E8E93; font-size: 11px;")
        font_row.addWidget(self.font_lbl)
        self.font_slider = QSlider(Qt.Horizontal)
        self.font_slider.setRange(8, 18)
        self.font_slider.setValue(11)
        self.font_slider.valueChanged.connect(self._on_font_size_changed)
        font_row.addWidget(self.font_slider)
        lay.addLayout(font_row)

        lay.addStretch()
        scroll.setWidget(container)
        return scroll

    def _populate_action_types(self):
        self.action_type_combo.blockSignals(True)
        self.action_type_combo.clear()
        self.action_type_combo.addItem(t("action_application"), ACTION_TYPE_APPLICATION)
        self.action_type_combo.addItem(t("action_hotkey"), ACTION_TYPE_HOTKEY)
        self.action_type_combo.addItem(t("action_media"), ACTION_TYPE_MEDIA)
        self.action_type_combo.addItem(t("action_url"), ACTION_TYPE_FILE_FOLDER_URL)
        self.action_type_combo.addItem(t("action_system"), ACTION_TYPE_SYSTEM)
        self.action_type_combo.addItem(t("action_macro"), ACTION_TYPE_MACRO)
        self.action_type_combo.blockSignals(False)

    def _on_tab_changed(self, idx: int):
        self.stack.setCurrentIndex(idx)

    def _toggle_icon_picker(self):
        if self.icon_picker.isVisible():
            self.icon_picker.hide()
            self.toggle_picker_btn.setText(t("inspector_choose_icon"))
        else:
            self.icon_picker.show()
            self.toggle_picker_btn.setText(t("inspector_close_icon_picker"))

    def _update_icon_thumb(self):
        if not self.button or not self.button.icon:
            self.icon_thumb_lbl.setPixmap(QPixmap())
            self.icon_thumb_lbl.setText("-")
            self.icon_thumb_lbl.setStyleSheet("color: #8E8E93; font-size: 14px; background: rgba(255, 255, 255, 0.04); border: 1px dashed rgba(255, 255, 255, 0.15); border-radius: 8px;")
            self.icon_name_lbl.setText(t("inspector_no_icon"))
            return

        resolved = resolve_icon_path(self.button.icon)
        if resolved and resolved.exists():
            pix = QPixmap(str(resolved)).scaled(32, 32, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.icon_thumb_lbl.setText("")
            self.icon_thumb_lbl.setPixmap(pix)
            self.icon_thumb_lbl.setStyleSheet("background: rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.20); border-radius: 8px;")
            self.icon_name_lbl.setText(Path(self.button.icon).stem.replace("_", " ").title())
        else:
            self.icon_thumb_lbl.setPixmap(QPixmap())
            self.icon_thumb_lbl.setText("?")
            self.icon_name_lbl.setText(self.button.icon)

    def set_button(self, button: Optional[ButtonModel]):
        self.button = button
        self.mini_preview.set_button(button)

        if not button:
            self.setEnabled(False)
            self.title_input.clear()
            self._update_icon_thumb()
            return

        self.setEnabled(True)
        self.title_input.blockSignals(True)
        self.title_input.setText(button.title or "")
        self.title_input.blockSignals(False)

        # Update Icon
        self._update_icon_thumb()
        self.icon_picker.set_current_icon(button.icon or "")

        # Update Color & Sliders
        self.color_picker.set_color(button.bg_color or "#141416")

        self.radius_slider.blockSignals(True)
        self.radius_slider.setValue(button.border_radius or 14)
        self.radius_slider.blockSignals(False)

        self.font_slider.blockSignals(True)
        self.font_slider.setValue(button.font_size or 11)
        self.font_slider.blockSignals(False)

        # Update Action
        self.action_type_combo.blockSignals(True)
        if button.action:
            act_type = button.action.action_type
            idx = self.action_type_combo.findData(act_type)
            if idx >= 0:
                self.action_type_combo.setCurrentIndex(idx)
                self.action_stack.setCurrentIndex(idx)
            else:
                self.action_type_combo.setCurrentIndex(0)
                self.action_stack.setCurrentIndex(0)

            # Fill inputs
            target = button.action.target or ""
            sub_act = button.action.sub_action or ""

            self.app_path_input.blockSignals(True)
            self.app_path_input.setText(target if act_type == ACTION_TYPE_APPLICATION else "")
            self.app_path_input.blockSignals(False)

            self.hotkey_input.blockSignals(True)
            self.hotkey_input.setText(target if act_type == ACTION_TYPE_HOTKEY else "")
            self.hotkey_input.blockSignals(False)

            self.url_input.blockSignals(True)
            self.url_input.setText(target if act_type == ACTION_TYPE_FILE_FOLDER_URL else "")
            self.url_input.blockSignals(False)

            if act_type == ACTION_TYPE_MEDIA:
                m_idx = self.media_combo.findText(sub_act)
                if m_idx >= 0:
                    self.media_combo.setCurrentIndex(m_idx)

            if act_type == ACTION_TYPE_SYSTEM:
                s_idx = self.sys_combo.findText(sub_act)
                if s_idx >= 0:
                    self.sys_combo.setCurrentIndex(s_idx)
        else:
            self.action_type_combo.setCurrentIndex(0)
            self.action_stack.setCurrentIndex(0)

        self.action_type_combo.blockSignals(False)

    def _on_title_changed(self, text: str):
        if self.button:
            self.button.title = text
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_icon_selected(self, icon_val: str):
        if not self.button:
            return
        self.button.icon = icon_val
        self._update_icon_thumb()
        self.mini_preview.update()
        self.button_updated.emit(self.button)

    def _clear_icon(self):
        if not self.button:
            return
        self.button.icon = ""
        self._update_icon_thumb()
        self.icon_picker.set_current_icon("")
        self.mini_preview.update()
        self.button_updated.emit(self.button)

    def _set_button_color(self, hex_color: str):
        if self.button:
            self.button.bg_color = hex_color
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_radius_changed(self, val: int):
        if self.button:
            self.button.border_radius = val
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_font_size_changed(self, val: int):
        if self.button:
            self.button.font_size = val
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_action_type_changed(self, index: int):
        if not self.button:
            return
        act_type = self.action_type_combo.currentData()
        self.action_stack.setCurrentIndex(index)
        if not self.button.action:
            self.button.action = ActionModel(action_type=act_type)
        else:
            self.button.action.action_type = act_type
        self._on_action_params_changed()

    def _on_action_params_changed(self):
        if not self.button:
            return
        act_type = self.action_type_combo.currentData()
        target = ""
        sub_action = ""

        if act_type == ACTION_TYPE_APPLICATION:
            target = self.app_path_input.text().strip()
        elif act_type == ACTION_TYPE_HOTKEY:
            target = self.hotkey_input.text().strip()
        elif act_type == ACTION_TYPE_MEDIA:
            sub_action = self.media_combo.currentText()
        elif act_type == ACTION_TYPE_FILE_FOLDER_URL:
            target = self.url_input.text().strip()
        elif act_type == ACTION_TYPE_SYSTEM:
            sub_action = self.sys_combo.currentText()

        if not self.button.action:
            self.button.action = ActionModel(action_type=act_type, target=target, sub_action=sub_action)
        else:
            self.button.action.action_type = act_type
            self.button.action.target = target
            self.button.action.sub_action = sub_action

        # Auto-fetch web logo if URL has at least 3 characters and button doesn't have a logo yet
        if act_type == ACTION_TYPE_FILE_FOLDER_URL and len(target) >= 3:
            if not self.button.icon:
                self.url_fetch_timer.start()

        self.mini_preview.update()
        self.button_updated.emit(self.button)

    def _auto_fetch_url_logo(self):
        if not self.button or self.button.icon:
            return
        url = self.url_input.text().strip()
        if len(url) < 3:
            return
        self.fetch_url_logo_btn.setText(t("inspector_fetching_logo"))
        from editor.utils.web_icon_fetcher import WebLogoFetchWorker
        self._url_worker = WebLogoFetchWorker(url, parent=self)
        self._url_worker.success.connect(self._on_url_logo_success)
        self._url_worker.failure.connect(self._on_url_logo_failure)
        self._url_worker.start()

    def _fetch_logo_for_current_url(self):
        url = self.url_input.text().strip()
        if not url:
            return
        self.fetch_url_logo_btn.setEnabled(False)
        self.fetch_url_logo_btn.setText(t("inspector_fetching_logo"))

        from editor.utils.web_icon_fetcher import WebLogoFetchWorker
        self._url_worker = WebLogoFetchWorker(url, parent=self)
        self._url_worker.success.connect(self._on_url_logo_success)
        self._url_worker.failure.connect(self._on_url_logo_failure)
        self._url_worker.start()

    def _on_url_logo_success(self, filename: str, domain: str):
        self.fetch_url_logo_btn.setEnabled(True)
        self.fetch_url_logo_btn.setText(t("inspector_fetch_logo"))
        if not self.button:
            return
        self.button.icon = filename
        self._update_icon_thumb()
        self.icon_picker.set_current_icon(filename)
        # If title is empty or default, suggest domain name formatted
        if not self.button.title or self.button.title.startswith("Knap ") or self.button.title.startswith("Button "):
            clean_title = domain.split(".")[0].title()
            self.title_input.setText(clean_title)
            self.button.title = clean_title
        self.mini_preview.update()
        self.button_updated.emit(self.button)

    def _on_url_logo_failure(self, error: str):
        self.fetch_url_logo_btn.setEnabled(True)
        self.fetch_url_logo_btn.setText(t("inspector_fetch_logo"))

    def _browse_application(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Vælg Program", "", "Programmer (*.exe);;Alle Filer (*.*)"
        )
        if file_path:
            self.app_path_input.setText(file_path)

    def _open_macro_editor(self):
        if not self.button:
            return
        dialog = MacroEditorDialog(self.button.action, self)
        if dialog.exec():
            self.button.action = dialog.get_action()
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_test_clicked(self):
        if self.button:
            self.button_test_requested.emit(self.button)

    def _on_delete_clicked(self):
        if self.button:
            self.button_deleted.emit(self.button.id)

    def _on_language_changed(self, lang: str):
        self.title_lbl.setText(t("inspector_title"))
        self.delete_btn.setText(t("inspector_delete"))
        self.segmented_tabs.set_tab_texts([
            t("inspector_tab_content"),
            t("inspector_tab_action"),
            t("inspector_tab_design")
        ])
        self.title_input_lbl.setText(t("inspector_title_label"))
        self.title_input.setPlaceholderText(t("inspector_title_placeholder"))
        self.icon_sec_lbl.setText(t("inspector_icon_section"))
        if self.icon_picker.isVisible():
            self.toggle_picker_btn.setText(t("inspector_close_icon_picker"))
        else:
            self.toggle_picker_btn.setText(t("inspector_choose_icon"))
        self.remove_icon_btn.setText(t("inspector_remove_icon"))
        self._update_icon_thumb()

        self.act_type_lbl.setText(t("inspector_action_type"))
        cur_act_data = self.action_type_combo.currentData()
        self._populate_action_types()
        act_idx = self.action_type_combo.findData(cur_act_data)
        if act_idx >= 0:
            self.action_type_combo.setCurrentIndex(act_idx)

        self.pick_exe_btn.setText(t("inspector_browse_exe"))
        self.app_path_input.setPlaceholderText(t("inspector_app_placeholder"))
        self.hotkey_input.setPlaceholderText(t("inspector_hotkey_placeholder"))
        self.url_input.setPlaceholderText(t("inspector_url_placeholder"))
        self.fetch_url_logo_btn.setText(t("inspector_fetch_logo"))
        self.macro_btn.setText(t("inspector_edit_macro"))
        self.test_btn.setText(t("inspector_test_button"))

        self.color_sec_lbl.setText(t("inspector_color_section"))
        self.rad_lbl.setText(t("inspector_radius_label"))
        self.font_lbl.setText(t("inspector_font_size_label"))
