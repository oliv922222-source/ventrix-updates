# NEXA Studio — Changelog

Alle ændringer til NEXA Studio dokumenteres her. Versionen følger [Semantic Versioning](https://semver.org/).

---

## v2.0.2 — 2026-09-07

### Forbedringer & Redesign
- 📱 **Apple Glass "Forbind Telefon eller iPad" modal** — Fuldstændig redesignet uden standard Windows-titelbar, fremstillet som svævende obsidian frosted glass card med hvid/sort æstetik, centreret QR-kode uden overlappende tekst og lysende PIN-kapsel.
- 🎯 **Tastatur-genvej inputfelt** — Genskabt med synlig, krystalklar Apple Glass styling og hjælpetekst.
- 🎨 **Apple Glass Farve-Presets** — Opgraderet til elegante 26x26 squircles med dybe obsidian- og glas-nuancer.
- 🧹 **Topbar oprydning** — Fjernet overflødige tomme profilknapper ved siden af profilvælgeren.
- 🔽 **Minimalistiske Apple chevrons** — Erstattet firkantede pile med rene SVG/PNG chevrons på alle dropdowns.
- 🚀 **NEXA_Setup.exe rettelse** — Fjernet utilsigtet selv-terminering og inkluderet den komplette standalone `NEXA.exe` direkte i installationspakken.

---

## v2.0.1 — 2026-09-07

### Fejlrettelser
- **PIN-kode parring fikset** — Manglende `uuid` modul tilføjet, som forhindrede parring i at virke selvom koden var korrekt
- **Tom standard-profil** — Appen starter nu med en helt tom profil (ingen forudindlæste apps) så brugere kan tilpasse fra starten
- **Enhedsforbindelses-fejl rettet** — Forkerte feltnavne (`device_name` → `name`, `ip_address` → `last_ip`) i device model er rettet
- **PIN auto-submit timing** — 100ms delay tilføjet før auto-submit for at forhindre race condition på mobil-browsere
- **Bedre fejlhåndtering** — Mere præcise fejlmeddelelser ved forkert PIN-kode

---

## v2.0.0 — 2026-09-06

### Nyheder
- 🎨 **Nyt Apple Glass design** — Premium sort/hvid glasmorfisk brugerflade
- 🔗 **Web-parring** — Forbind telefon/tablet via QR-kode og 6-cifret PIN
- 🖥️ **Ren installation** — Ingen CMD-vinduer, ingen personlige data eksponeret
- 📦 **Installer wizard** — Professionel setup med system-notice dialog
- 🔄 **In-app opdatering** — 1-klik opdatering direkte fra appen
- 🛡️ **Publisher trust** — NEXA Studio registreret som betroet udgiver
