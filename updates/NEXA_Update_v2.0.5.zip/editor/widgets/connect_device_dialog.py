"""
NEXA - Connect Device Dialog (Phone & iPad Pairing)
Premium Apple glass system panel — clean, compact, no emojis.
Author: NEXA
"""

import io
from pathlib import Path

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QWidget, QScrollArea, QApplication
)
from PySide6.QtGui import (
    QPixmap, QImage, QColor, QFont, QPainter,
    QLinearGradient, QBrush, QPen, QPainterPath, QRadialGradient
)
from PySide6.QtCore import Qt, QPoint, QRectF, QPointF, QTimer

from shared.models import DeviceModel
from shared.config_store import ConfigStore
from editor.networking.server import TouchDeckServer
from shared.i18n import t, I18nManager


# ─────────────────────────────────────────────────────────────────────────────
# Close Button  (painted X — no emoji, no text character)
# ─────────────────────────────────────────────────────────────────────────────

class _CloseButton(QPushButton):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(28, 28)
        self.setCursor(Qt.PointingHandCursor)
        self._hovered = False
        self.setStyleSheet("QPushButton { border: none; background: transparent; }")

    def enterEvent(self, e):
        self._hovered = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hovered = False
        self.update()
        super().leaveEvent(e)

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        path = QPainterPath()
        path.addEllipse(r)

        if self._hovered:
            p.fillPath(path, QColor(255, 255, 255, 20))
            p.strokePath(path, QPen(QColor(255, 255, 255, 35), 1.0))
        else:
            p.fillPath(path, QColor(255, 255, 255, 8))
            p.strokePath(path, QPen(QColor(255, 255, 255, 18), 1.0))

        cx = r.center().x()
        cy = r.center().y()
        d = 4.8
        alpha = 155 if self._hovered else 100
        pen = QPen(QColor(255, 255, 255, alpha), 1.5, Qt.SolidLine, Qt.RoundCap)
        p.setPen(pen)
        p.drawLine(QPointF(cx - d, cy - d), QPointF(cx + d, cy + d))
        p.drawLine(QPointF(cx + d, cy - d), QPointF(cx - d, cy + d))


# ─────────────────────────────────────────────────────────────────────────────
# Glass Card Surface
# ─────────────────────────────────────────────────────────────────────────────

class _GlassCard(QFrame):
    """Deep obsidian frosted glass surface with hairline border."""

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        r = self.rect()
        path = QPainterPath()
        path.addRoundedRect(QRectF(r).adjusted(1, 1, -1, -1), 22, 22)

        # Base fill
        p.fillPath(path, QColor(13, 14, 18, 252))

        # Top ambient halo
        halo = QRadialGradient(r.center().x(), r.top() + 20, r.width() * 0.6)
        halo.setColorAt(0.0, QColor(255, 255, 255, 18))
        halo.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.setPen(Qt.NoPen)
        p.setBrush(halo)
        p.drawRoundedRect(QRectF(r).adjusted(2, 2, -2, int(r.height() * 0.42)), 22, 22)

        # Border
        p.setPen(QPen(QColor(255, 255, 255, 24), 1.2))
        p.setBrush(Qt.NoBrush)
        p.drawPath(path)


# ─────────────────────────────────────────────────────────────────────────────
# Thin divider
# ─────────────────────────────────────────────────────────────────────────────

class _Divider(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(1)
        self.setStyleSheet("background: rgba(255,255,255,0.07); border: none;")


# ─────────────────────────────────────────────────────────────────────────────
# Step Row widget
# ─────────────────────────────────────────────────────────────────────────────

def _make_step(number_str: str, text: str) -> QWidget:
    import re
    clean_text = re.sub(r'^\d+[\.:\s]*', '', text).strip()
    w = QWidget()
    w.setStyleSheet("background: transparent; border: none;")
    row = QHBoxLayout(w)
    row.setContentsMargins(0, 0, 0, 0)
    row.setSpacing(12)
    row.setAlignment(Qt.AlignVCenter)

    num = QLabel(number_str)
    num.setFixedWidth(26)
    num.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    num.setStyleSheet(
        "background:transparent; border:none; "
        "color:rgba(255,255,255,0.22); font-size:10px; font-weight:700; "
        "font-family:'Consolas','Courier New',monospace; letter-spacing:0.5px;"
    )
    row.addWidget(num)

    lbl = QLabel(clean_text)
    lbl.setWordWrap(True)
    lbl.setStyleSheet(
        "background:transparent; border:none; "
        "color:rgba(255,255,255,0.75); font-size:12px; font-weight:400;"
    )
    row.addWidget(lbl, stretch=1)
    return w


# ─────────────────────────────────────────────────────────────────────────────
# Main Dialog
# ─────────────────────────────────────────────────────────────────────────────

class ConnectDeviceDialog(QDialog):
    """
    Professional Apple glass pairing panel.
    Zero emojis. All original functionality preserved.
    """

    def __init__(self, config_store: ConfigStore, server: TouchDeckServer, parent=None):
        super().__init__(parent)
        self.config_store = config_store
        self.server = server

        self.setWindowTitle(t("pair_modal_title"))
        self.setFixedSize(660, 590)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self._drag_pos = QPoint()
        self._digit_labels = []          # 6 individual digit labels
        self.direct_url = ""

        self._init_ui()
        self._generate_qr_code()
        self._refresh_device_list()

        # Wire server callbacks
        self.server.on_client_connected = self._on_device_updated
        self.server.on_client_disconnected = self._on_device_updated

    # ── drag-to-move (frameless) ──────────────────────────────────────────────
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and not self._drag_pos.isNull():
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    # ── UI construction ───────────────────────────────────────────────────────
    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(10, 10, 10, 10)

        self.card = _GlassCard(self)
        card_lay = QVBoxLayout(self.card)
        card_lay.setContentsMargins(26, 20, 26, 22)
        card_lay.setSpacing(14)

        # ── HEADER ────────────────────────────────────────────────────────────
        header = QHBoxLayout()
        header.setSpacing(0)

        title_col = QVBoxLayout()
        title_col.setSpacing(3)
        title_col.setAlignment(Qt.AlignVCenter)

        self.title_lbl = QLabel(t("pair_modal_title"))
        self.title_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color:#FFFFFF; font-size:17px; font-weight:700; letter-spacing:-0.3px;"
        )
        title_col.addWidget(self.title_lbl)

        self.subtitle_lbl = QLabel(t("pair_modal_subtitle"))
        self.subtitle_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color:rgba(255,255,255,0.42); font-size:11px; font-weight:400;"
        )
        title_col.addWidget(self.subtitle_lbl)

        header.addLayout(title_col)
        header.addStretch()

        close_btn = _CloseButton()
        close_btn.clicked.connect(self.accept)
        header.addWidget(close_btn)

        card_lay.addLayout(header)
        card_lay.addWidget(_Divider())

        # ── BODY (two columns) ────────────────────────────────────────────────
        body = QHBoxLayout()
        body.setSpacing(28)
        body.setContentsMargins(0, 4, 0, 0)

        # LEFT: QR code column
        left_col = QVBoxLayout()
        left_col.setSpacing(10)
        left_col.setAlignment(Qt.AlignTop | Qt.AlignHCenter)

        # QR white container
        self.qr_frame = QFrame()
        self.qr_frame.setFixedSize(186, 186)
        self.qr_frame.setStyleSheet("""
            QFrame {
                background: #FFFFFF;
                border-radius: 14px;
                border: none;
            }
        """)
        qr_inner = QVBoxLayout(self.qr_frame)
        qr_inner.setContentsMargins(10, 10, 10, 10)
        qr_inner.setAlignment(Qt.AlignCenter)

        self.qr_label = QLabel()
        self.qr_label.setFixedSize(166, 166)
        self.qr_label.setAlignment(Qt.AlignCenter)
        self.qr_label.setStyleSheet("background: transparent; border: none;")
        qr_inner.addWidget(self.qr_label)

        left_col.addWidget(self.qr_frame, alignment=Qt.AlignHCenter)

        # Scan hint below QR
        scan_hint = QLabel("Scan med kamera for direkte adgang")
        scan_hint.setWordWrap(True)
        scan_hint.setFixedWidth(186)
        scan_hint.setAlignment(Qt.AlignCenter)
        scan_hint.setStyleSheet(
            "background:transparent; border:none; "
            "color:rgba(255,255,255,0.35); font-size:10px; font-weight:400;"
        )
        left_col.addWidget(scan_hint, alignment=Qt.AlignHCenter)

        body.addLayout(left_col)

        # RIGHT: Instructions, code, link
        right_col = QVBoxLayout()
        right_col.setSpacing(14)
        right_col.setAlignment(Qt.AlignTop)

        # Steps 01 / 02 / 03
        right_col.addWidget(_make_step("01", t("pair_step1")))
        right_col.addWidget(_make_step("02", t("pair_step2")))
        right_col.addWidget(_make_step("03", t("pair_step3")))

        right_col.addSpacing(6)
        right_col.addWidget(_Divider())
        right_col.addSpacing(6)

        # Code label
        code_lbl = QLabel("Kode")
        code_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color:rgba(255,255,255,0.38); font-size:10px; font-weight:600; letter-spacing:0.8px;"
        )
        right_col.addWidget(code_lbl)

        # 6 digit cells + "Ny kode" button
        code_row = QHBoxLayout()
        code_row.setSpacing(0)
        code_row.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

        digits_row = QHBoxLayout()
        digits_row.setSpacing(5)

        self._digit_labels = []
        for i in range(6):
            if i == 3:
                gap = QLabel()
                gap.setFixedWidth(10)
                gap.setStyleSheet("background: transparent; border: none;")
                digits_row.addWidget(gap)

            cell = QFrame()
            cell.setFixedSize(38, 48)
            cell.setStyleSheet("""
                QFrame {
                    background: rgba(255, 255, 255, 0.06);
                    border: 1px solid rgba(255, 255, 255, 0.13);
                    border-radius: 8px;
                }
            """)
            cell_lay = QVBoxLayout(cell)
            cell_lay.setContentsMargins(0, 0, 0, 0)

            d_lbl = QLabel("·")
            d_lbl.setAlignment(Qt.AlignCenter)
            d_lbl.setStyleSheet(
                "background:transparent; border:none; "
                "color:#FFFFFF; font-size:20px; font-weight:700; "
                "font-family:'Consolas','Courier New',monospace;"
            )
            cell_lay.addWidget(d_lbl, alignment=Qt.AlignCenter)

            self._digit_labels.append(d_lbl)
            digits_row.addWidget(cell)

        code_row.addLayout(digits_row)
        code_row.addSpacing(12)

        # "Ny kode" secondary button
        new_code_btn = QPushButton(t("pair_new_code"))
        new_code_btn.setCursor(Qt.PointingHandCursor)
        new_code_btn.setFixedHeight(36)
        new_code_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.07);
                color: rgba(255, 255, 255, 0.70);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 9px;
                padding: 0 14px;
                font-size: 11px;
                font-weight: 600;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.13);
                color: #FFFFFF;
                border-color: rgba(255, 255, 255, 0.24);
            }
            QPushButton:pressed {
                background: rgba(255, 255, 255, 0.18);
            }
        """)
        new_code_btn.clicked.connect(self._regenerate_code)
        code_row.addWidget(new_code_btn, alignment=Qt.AlignVCenter)
        code_row.addStretch()

        right_col.addLayout(code_row)

        # Link row
        link_lbl = QLabel("Adresse")
        link_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color:rgba(255,255,255,0.38); font-size:10px; font-weight:600; letter-spacing:0.8px;"
        )
        right_col.addWidget(link_lbl)

        local_ip = self.server.get_local_ip()
        self.direct_url = f"http://{local_ip}:18888"

        link_row = QHBoxLayout()
        link_row.setSpacing(8)

        self.url_label = QLabel(self.direct_url)
        self.url_label.setStyleSheet("""
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 8px;
            color: rgba(255, 255, 255, 0.60);
            font-size: 11px;
            font-weight: 400;
            font-family: 'Consolas', 'Courier New', monospace;
            padding: 5px 10px;
        """)
        link_row.addWidget(self.url_label, stretch=1)

        self.copy_btn = QPushButton(t("pair_copy_link"))
        self.copy_btn.setCursor(Qt.PointingHandCursor)
        self.copy_btn.setFixedHeight(30)
        self.copy_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.10);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.16);
                border-radius: 8px;
                padding: 0 14px;
                font-size: 11px;
                font-weight: 600;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.18);
                border-color: rgba(255, 255, 255, 0.28);
            }
            QPushButton:pressed {
                background: rgba(255, 255, 255, 0.24);
            }
        """)
        self.copy_btn.clicked.connect(self._copy_link)
        link_row.addWidget(self.copy_btn)

        right_col.addLayout(link_row)
        right_col.addStretch()

        body.addLayout(right_col, stretch=1)
        card_lay.addLayout(body)

        # ── CONNECTED DEVICES ─────────────────────────────────────────────────
        card_lay.addWidget(_Divider())

        dev_header = QHBoxLayout()
        dev_title = QLabel(t("pair_connected_devices").upper())
        dev_title.setStyleSheet(
            "background:transparent; border:none; "
            "color:rgba(255,255,255,0.32); font-size:9px; font-weight:700; letter-spacing:1px;"
        )
        dev_header.addWidget(dev_title)
        dev_header.addStretch()
        card_lay.addLayout(dev_header)

        # Compact device list area
        self.dev_scroll = QScrollArea()
        self.dev_scroll.setWidgetResizable(True)
        self.dev_scroll.setFixedHeight(90)
        self.dev_scroll.setStyleSheet("""
            QScrollArea {
                background: rgba(255, 255, 255, 0.02);
                border: 1px solid rgba(255, 255, 255, 0.06);
                border-radius: 12px;
            }
            QScrollArea > QWidget > QWidget { background: transparent; }
            QScrollBar:vertical {
                background: transparent; width: 5px; margin: 0;
            }
            QScrollBar::handle:vertical {
                background: rgba(255,255,255,0.14); border-radius: 2px; min-height: 16px;
            }
            QScrollBar::handle:vertical:hover { background: rgba(255,255,255,0.26); }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0; width: 0; border: none; background: transparent;
            }
        """)

        self.dev_container = QWidget()
        self.dev_container.setStyleSheet("background: transparent; border: none;")
        self.dev_container_lay = QVBoxLayout(self.dev_container)
        self.dev_container_lay.setContentsMargins(10, 8, 10, 8)
        self.dev_container_lay.setSpacing(5)
        self.dev_scroll.setWidget(self.dev_container)

        card_lay.addWidget(self.dev_scroll)

        root_lay.addWidget(self.card)

        # Populate initial pin after labels are created
        self._update_pin_text()

    # ── Pairing code ──────────────────────────────────────────────────────────

    def _update_pin_text(self):
        code = self.server.active_pairing_code
        for i, lbl in enumerate(self._digit_labels):
            lbl.setText(code[i] if i < len(code) else "·")

    # ── QR code ───────────────────────────────────────────────────────────────

    def _generate_qr_code(self):
        try:
            import qrcode
            local_ip = self.server.get_local_ip()
            url = f"http://{local_ip}:18888"

            qr = qrcode.QRCode(box_size=6, border=1)
            qr.add_data(url)
            qr.make(fit=True)
            img = qr.make_image(fill_color="#000000", back_color="#FFFFFF")

            buf = __import__("io").BytesIO()
            img.save(buf, format="PNG")
            qimg = QImage.fromData(buf.getvalue())
            pix = QPixmap.fromImage(qimg).scaled(
                166, 166, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.qr_label.setPixmap(pix)
        except Exception as e:
            self.qr_label.setText(f"QR: {e}")
            self.qr_label.setStyleSheet(
                "background:transparent; border:none; "
                "color:#555; font-size:10px;")

    # ── Regenerate code ───────────────────────────────────────────────────────

    def _regenerate_code(self):
        self.server.generate_new_pairing_code()
        self._update_pin_text()

    # ── Copy link ─────────────────────────────────────────────────────────────

    def _copy_link(self):
        QApplication.clipboard().setText(self.direct_url)
        self.copy_btn.setText(t("pair_copied"))
        QTimer.singleShot(2000, lambda: self.copy_btn.setText(t("pair_copy_link")))

    # ── Device list ───────────────────────────────────────────────────────────

    def _on_device_updated(self, *_args):
        self._refresh_device_list()

    def _refresh_device_list(self):
        while self.dev_container_lay.count():
            item = self.dev_container_lay.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

        devices = self.config_store.devices
        paired = [d for d in devices if d.paired]

        if not paired:
            empty = QLabel(t("pair_no_devices"))
            empty.setStyleSheet(
                "background:transparent; border:none; "
                "color:rgba(255,255,255,0.28); font-size:11px; font-style:italic;"
            )
            self.dev_container_lay.addWidget(empty, alignment=Qt.AlignCenter)
            self.dev_container_lay.addStretch()
            return

        for dev in paired:
            row = QFrame()
            row.setStyleSheet("""
                QFrame {
                    background: rgba(255, 255, 255, 0.04);
                    border: 1px solid rgba(255, 255, 255, 0.07);
                    border-radius: 8px;
                }
                QFrame:hover {
                    background: rgba(255, 255, 255, 0.07);
                }
            """)
            row_lay = QHBoxLayout(row)
            row_lay.setContentsMargins(10, 4, 10, 4)
            row_lay.setSpacing(8)

            # Status dot (painted as small ellipse via stylesheet hack-free label)
            dot = QLabel()
            dot.setFixedSize(7, 7)
            dot.setStyleSheet(
                "background: #34D399; border-radius: 3px; border: none;"
            )
            row_lay.addWidget(dot, alignment=Qt.AlignVCenter)

            name_lbl = QLabel(dev.name or "Telefon / Tablet")
            name_lbl.setStyleSheet(
                "background:transparent; border:none; "
                "color:#FFFFFF; font-size:12px; font-weight:600;"
            )
            row_lay.addWidget(name_lbl)

            ip_lbl = QLabel(dev.last_ip or "Wi-Fi")
            ip_lbl.setStyleSheet(
                "background:transparent; border:none; "
                "color:rgba(255,255,255,0.38); font-size:11px;"
            )
            row_lay.addWidget(ip_lbl)
            row_lay.addStretch()

            unpair_btn = QPushButton(t("pair_disconnect"))
            unpair_btn.setCursor(Qt.PointingHandCursor)
            unpair_btn.setStyleSheet("""
                QPushButton {
                    background: transparent;
                    color: rgba(248, 113, 113, 0.80);
                    border: 1px solid rgba(248, 113, 113, 0.28);
                    border-radius: 6px;
                    padding: 3px 10px;
                    font-size: 10px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background: rgba(239, 68, 68, 0.16);
                    color: #FFFFFF;
                    border-color: rgba(239, 68, 68, 0.55);
                }
            """)
            unpair_btn.clicked.connect(lambda _, d=dev: self._disconnect_device(d))
            row_lay.addWidget(unpair_btn)

            self.dev_container_lay.addWidget(row)

        self.dev_container_lay.addStretch()

    def _disconnect_device(self, dev: DeviceModel):
        dev.paired = False
        dev.auth_token = ""
        self.config_store.save_devices()
        self._refresh_device_list()
