"""
TouchDeck - Surface Fullscreen Touch Window
Author: VENTRIX
"""

import sys
import os
import json
import threading
import urllib.request
from pathlib import Path
from typing import Optional, Dict

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QGridLayout, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QFrame, QStackedWidget,
    QMessageBox
)
from PySide6.QtGui import (
    QKeyEvent, QMouseEvent, QTouchEvent, QColor, QFont, QPen,
    QBrush, QPainter
)
from PySide6.QtCore import Qt, QTimer, QPoint, QSize, Signal, QObject, Slot

from shared.models import ProfileModel, PageModel, ButtonModel
from shared.constants import (
    APP_NAME, APP_VERSION, COLOR_BG, COLOR_BG_SECONDARY, COLOR_CARD,
    COLOR_BORDER, COLOR_PRIMARY_BLUE, COLOR_BRIGHT_BLUE,
    COLOR_SUCCESS, COLOR_ERROR, COLOR_WARNING, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED
)
from surface.networking.client import SurfaceNetworkClient, SurfaceClientState
from surface.widgets.touch_button import TouchButton
from surface.widgets.recovery_dialog import RecoveryDialog


class _UIBridge(QObject):
    """
    Bridge object that lives on the main (GUI) thread.
    Network callbacks emit these signals to safely update the Qt UI
    from the asyncio background thread.
    """
    state_changed = Signal(str, str)          # state, message
    layout_updated = Signal(object)            # ProfileModel
    button_feedback = Signal(str, str, str)    # button_id, status, message
    pairing_needed = Signal()


class TouchWindow(QMainWindow):
    def __init__(self, client: SurfaceNetworkClient):
        super().__init__()
        self.client = client
        self.current_profile: Optional[ProfileModel] = self.client.cached_profile
        self.current_page_index = 0

        self.setWindowTitle(f"{APP_NAME} Surface Appliance")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setStyleSheet(f"background-color: {COLOR_BG}; color: {COLOR_TEXT_MAIN};")

        self.button_widgets: Dict[str, TouchButton] = {}

        # Touch swipe tracking
        self.drag_start_pos: Optional[QPoint] = None

        # Secret top-left corner hold timer (4 seconds)
        self.corner_timer = QTimer(self)
        self.corner_timer.setSingleShot(True)
        self.corner_timer.setInterval(4000)
        self.corner_timer.timeout.connect(self._open_recovery_menu)

        # ── Thread-safe UI bridge ─────────────────────────────────────────────
        self._bridge = _UIBridge(self)
        self._bridge.state_changed.connect(self._on_client_state_changed)
        self._bridge.layout_updated.connect(self._on_layout_updated)
        self._bridge.button_feedback.connect(self._on_button_feedback)
        self._bridge.pairing_needed.connect(self._on_pairing_needed)
        # ─────────────────────────────────────────────────────────────────────

        # App-status polling (every 5s from PC server HTTP /api/status)
        self._process_statuses: Dict[str, dict] = {}
        self._status_enabled = False
        self._status_poll_timer = QTimer(self)
        self._status_poll_timer.setInterval(5000)
        self._status_poll_timer.timeout.connect(self._poll_status_async)
        self._status_poll_timer.start()
        # Also poll immediately when the layout is rendered
        QTimer.singleShot(1500, self._poll_status_async)

        self._init_ui()
        self._bind_client_signals()

        # Render initial cached profile if available
        if self.current_profile:
            self._render_current_page()

    def _init_ui(self):
        self.central = QWidget()
        self.setCentralWidget(self.central)
        self.main_layout = QVBoxLayout(self.central)
        self.main_layout.setContentsMargins(16, 12, 16, 12)
        self.main_layout.setSpacing(8)

        # 1. TOP STATUS BAR (Slim, unobtrusive)
        top_bar = QHBoxLayout()
        top_bar.setContentsMargins(8, 0, 8, 0)

        self.page_title_lbl = QLabel("HOME")
        self.page_title_lbl.setStyleSheet("font-size: 14px; font-weight: 700; color: #8B95A7; letter-spacing: 1px;")
        top_bar.addWidget(self.page_title_lbl)

        top_bar.addStretch()

        self.status_pill = QLabel("Connecting...")
        self.status_pill.setStyleSheet(f"""
            background-color: rgba(245, 158, 11, 0.15);
            color: {COLOR_WARNING};
            border: 1px solid rgba(245, 158, 11, 0.35);
            border-radius: 10px;
            padding: 4px 12px;
            font-weight: 600;
            font-size: 11px;
        """)
        top_bar.addWidget(self.status_pill)

        self.main_layout.addLayout(top_bar)

        # 2. CENTER BUTTON GRID CONTAINER
        self.grid_container = QWidget()
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setSpacing(14)
        self.grid_layout.setContentsMargins(4, 4, 4, 4)

        self.main_layout.addWidget(self.grid_container, stretch=1)

        # 3. BOTTOM PAGE NAVIGATION BAR
        self.bottom_bar = QHBoxLayout()
        self.bottom_bar.setContentsMargins(8, 4, 8, 4)

        self.prev_btn = QPushButton("◀ Prev")
        self.prev_btn.setFixedSize(90, 42)
        self.prev_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLOR_CARD};
                color: {COLOR_TEXT_MAIN};
                border: 1px solid {COLOR_BORDER};
                border-radius: 8px;
                font-weight: 600;
            }}
            QPushButton:hover {{ border-color: {COLOR_PRIMARY_BLUE}; }}
        """)
        self.prev_btn.clicked.connect(self._prev_page)
        self.bottom_bar.addWidget(self.prev_btn)

        self.page_indicator = QLabel("1 / 1")
        self.page_indicator.setAlignment(Qt.AlignCenter)
        self.page_indicator.setStyleSheet("color: #8B95A7; font-weight: 700; font-size: 13px;")
        self.bottom_bar.addWidget(self.page_indicator, stretch=1)

        self.next_btn = QPushButton("Next ▶")
        self.next_btn.setFixedSize(90, 42)
        self.next_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLOR_CARD};
                color: {COLOR_TEXT_MAIN};
                border: 1px solid {COLOR_BORDER};
                border-radius: 8px;
                font-weight: 600;
            }}
            QPushButton:hover {{ border-color: {COLOR_PRIMARY_BLUE}; }}
        """)
        self.next_btn.clicked.connect(self._next_page)
        self.bottom_bar.addWidget(self.next_btn)

        self.main_layout.addLayout(self.bottom_bar)

    def _bind_client_signals(self):
        """Route all client callbacks through the thread-safe _UIBridge."""
        # These lambdas are called from the asyncio background thread —
        # they ONLY emit Qt signals (which are thread-safe), never touch Qt widgets.
        self.client.on_state_changed = lambda s, m: self._bridge.state_changed.emit(s, m)
        self.client.on_layout_updated = lambda p: self._bridge.layout_updated.emit(p)
        self.client.on_button_feedback = lambda bid, st, msg: self._bridge.button_feedback.emit(bid, st, msg)
        self.client.on_pairing_needed = lambda: self._bridge.pairing_needed.emit()

    # ── Slots (always on main thread via signal/slot) ──────────────────────────

    @Slot(str, str)
    def _on_client_state_changed(self, state: str, message: str):
        if state == SurfaceClientState.CONNECTED:
            self.status_pill.setText("Connected ●")
            self.status_pill.setStyleSheet(f"""
                background-color: rgba(34, 197, 94, 0.15);
                color: {COLOR_SUCCESS};
                border: 1px solid rgba(34, 197, 94, 0.35);
                border-radius: 10px;
                padding: 4px 12px;
                font-weight: 600;
                font-size: 11px;
            """)
        elif state == SurfaceClientState.OFFLINE_CACHED:
            self.status_pill.setText("PC Offline (Cached Layout)")
            self.status_pill.setStyleSheet(f"""
                background-color: rgba(245, 158, 11, 0.15);
                color: {COLOR_WARNING};
                border: 1px solid rgba(245, 158, 11, 0.35);
                border-radius: 10px;
                padding: 4px 12px;
                font-weight: 600;
                font-size: 11px;
            """)
        elif state == SurfaceClientState.PAIRING_REQUIRED:
            self.status_pill.setText("Pairing Required")
            self.status_pill.setStyleSheet(f"""
                background-color: rgba(59, 130, 246, 0.15);
                color: {COLOR_BRIGHT_BLUE};
                border: 1px solid rgba(59, 130, 246, 0.35);
                border-radius: 10px;
                padding: 4px 12px;
                font-weight: 600;
                font-size: 11px;
            """)
        else:
            self.status_pill.setText(message or "Connecting...")
            self.status_pill.setStyleSheet(f"""
                background-color: rgba(239, 68, 68, 0.15);
                color: {COLOR_ERROR};
                border: 1px solid rgba(239, 68, 68, 0.35);
                border-radius: 10px;
                padding: 4px 12px;
                font-weight: 600;
                font-size: 11px;
            """)

    @Slot(object)
    def _on_layout_updated(self, profile: ProfileModel):
        """Called on main thread when server sends a layout update."""
        self.current_profile = profile
        if self.current_page_index >= len(profile.pages):
            self.current_page_index = 0
        self._render_current_page()

    @Slot(str, str, str)
    def _on_button_feedback(self, button_id: str, status: str, message: str):
        if button_id in self.button_widgets:
            self.button_widgets[button_id].trigger_feedback_flash(status)

    @Slot()
    def _on_pairing_needed(self):
        QTimer.singleShot(100, self._show_pairing_dialog)

    def _show_pairing_dialog(self):
        dlg = QFrame(self)
        dlg.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog | Qt.WindowStaysOnTopHint)
        dlg.setFixedSize(480, 260)
        dlg.setStyleSheet(f"""
            QFrame {{
                background-color: {COLOR_CARD};
                border: 2px solid {COLOR_PRIMARY_BLUE};
                border-radius: 12px;
                color: {COLOR_TEXT_MAIN};
            }}
        """)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(20, 20, 20, 20)
        lay.setSpacing(14)

        t = QLabel("PAIR WITH VENTRIX STUDIO PC")
        t.setStyleSheet("font-size: 14px; font-weight: 800; color: #3B82F6;")
        lay.addWidget(t)

        msg = QLabel("Enter the 6-digit pairing code displayed in VENTRIX Studio on your main PC:")
        msg.setStyleSheet("color: #8B95A7; font-size: 12px;")
        msg.setWordWrap(True)
        lay.addWidget(msg)

        pin_input = QLineEdit()
        pin_input.setMaxLength(6)
        pin_input.setAlignment(Qt.AlignCenter)
        pin_input.setStyleSheet(f"""
            font-size: 24px;
            font-weight: 800;
            letter-spacing: 6px;
            background-color: {COLOR_BG_SECONDARY};
            color: #FFFFFF;
            border: 1px solid {COLOR_BORDER};
            border-radius: 8px;
            padding: 8px;
        """)
        lay.addWidget(pin_input)

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(dlg.close)
        btn_row.addWidget(cancel_btn)

        pair_btn = QPushButton("Pair Now")
        pair_btn.setStyleSheet(f"background-color: {COLOR_PRIMARY_BLUE}; color: white; border-radius: 6px; padding: 8px;")
        pair_btn.clicked.connect(lambda: self._submit_pin(dlg, pin_input.text()))
        btn_row.addWidget(pair_btn)
        lay.addLayout(btn_row)

        dlg.move(self.rect().center() - dlg.rect().center())
        dlg.show()

    def _submit_pin(self, dialog: QFrame, pin: str):
        if len(pin.strip()) == 6:
            self.client.submit_pairing_pin(pin.strip())
            dialog.close()

    def _render_current_page(self):
        # Clear existing buttons
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.button_widgets.clear()

        if not self.current_profile or not self.current_profile.pages:
            self.page_title_lbl.setText("NO PAGES CONFIGURED")
            self.page_indicator.setText("0 / 0")
            return

        page = self.current_profile.pages[self.current_page_index]
        self.page_title_lbl.setText(page.name.upper())
        self.page_indicator.setText(f"Page {self.current_page_index + 1} of {len(self.current_profile.pages)}")

        # Configure grid stretches
        for r in range(page.rows):
            self.grid_layout.setRowStretch(r, 1)
        for c in range(page.cols):
            self.grid_layout.setColumnStretch(c, 1)

        for btn in page.buttons:
            if not btn.enabled:
                continue
            widget = TouchButton(btn, page.id)
            widget.pressed_signal.connect(self._on_touch_button_pressed)
            self.button_widgets[btn.id] = widget
            self.grid_layout.addWidget(widget, btn.row, btn.col, btn.row_span, btn.col_span)

        # Apply any already-known process statuses immediately
        self._apply_statuses_to_buttons()

    def _poll_status_async(self):
        """Kick off a background thread to fetch /api/status without blocking the UI."""
        server_ip = getattr(self.client, "server_ip", None) or "127.0.0.1"
        server_ip = server_ip if server_ip and server_ip != "auto" else "127.0.0.1"
        url = f"http://{server_ip}:18888/api/status"

        def _fetch():
            try:
                with urllib.request.urlopen(url, timeout=4) as resp:
                    raw = resp.read().decode("utf-8")
                data = json.loads(raw)
                # Dispatch back to main thread via QTimer
                QTimer.singleShot(0, lambda: self._on_status_received(data))
            except Exception:
                pass  # Silently ignore when PC is unreachable

        threading.Thread(target=_fetch, daemon=True).start()

    def _on_status_received(self, data: dict):
        """Called on main thread with the parsed /api/status response."""
        self._status_enabled = bool(data.get("enabled", False))
        self._process_statuses = data.get("statuses", {})
        self._apply_statuses_to_buttons()

    def _apply_statuses_to_buttons(self):
        """Push current process statuses into all visible TouchButton widgets."""
        for btn_id, widget in self.button_widgets.items():
            if btn_id in self._process_statuses:
                s = self._process_statuses[btn_id]
                widget.set_process_status(
                    running=bool(s.get("running", False)),
                    uptime_sec=int(s.get("uptime_sec", 0)),
                    enabled=self._status_enabled
                )
            else:
                # Button has no process info (not an Application type) — hide status
                widget.set_process_status(running=False, uptime_sec=0, enabled=False)

    def _on_touch_button_pressed(self, button_id: str, page_id: str, is_long_press: bool):
        self.client.send_button_press(button_id, page_id, is_long_press)

    def _prev_page(self):
        if self.current_profile and len(self.current_profile.pages) > 1:
            self.current_page_index = (self.current_page_index - 1) % len(self.current_profile.pages)
            self._render_current_page()

    def _next_page(self):
        if self.current_profile and len(self.current_profile.pages) > 1:
            self.current_page_index = (self.current_page_index + 1) % len(self.current_profile.pages)
            self._render_current_page()

    # Touch & Swipe Recognition
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self.drag_start_pos = event.pos()
            # Top-left secret corner check (within 60x60 px)
            if event.pos().x() < 60 and event.pos().y() < 60:
                self.corner_timer.start()

    def mouseReleaseEvent(self, event: QMouseEvent):
        self.corner_timer.stop()
        if event.button() == Qt.LeftButton and self.drag_start_pos:
            delta_x = event.pos().x() - self.drag_start_pos.x()
            delta_y = event.pos().y() - self.drag_start_pos.y()
            if abs(delta_x) > 120 and abs(delta_x) > abs(delta_y) * 2:
                if delta_x < 0:
                    self._next_page()
                else:
                    self._prev_page()
        self.drag_start_pos = None

    def keyPressEvent(self, event: QKeyEvent):
        # Emergency Exit Combo: Ctrl + Shift + Alt + F12
        if (event.key() == Qt.Key_F12 and
            event.modifiers() == (Qt.ControlModifier | Qt.ShiftModifier | Qt.AltModifier)):
            self._open_recovery_menu()
        elif event.key() == Qt.Key_Escape:
            # Normal escape also allows recovery for developer ease
            self._open_recovery_menu()

    def _open_recovery_menu(self):
        dlg = RecoveryDialog(self.client, self)
        dlg.exit_to_desktop_requested.connect(self.close)
        dlg.restart_runtime_requested.connect(self._restart_app)
        dlg.exec()

    def _restart_app(self):
        os.execv(sys.executable, [sys.executable] + sys.argv)
