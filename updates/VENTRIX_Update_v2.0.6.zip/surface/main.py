"""
TouchDeck - Surface Touchscreen Runtime Entry Point
Author: VENTRIX
"""

import sys
import os
from pathlib import Path
import logging

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon

from shared.constants import APP_NAME, APP_VERSION
from surface.networking.client import SurfaceNetworkClient
from surface.ui.touch_window import TouchWindow

# Setup logging
log_dir = PROJECT_ROOT / "logs"
log_dir.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] [Surface]: %(message)s",
    handlers=[
        logging.FileHandler(log_dir / "surface.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("TouchDeck.SurfaceMain")


def main():
    logger.info(f"Starting {APP_NAME} Surface Appliance v{APP_VERSION}...")

    app = QApplication(sys.argv)
    app.setApplicationName(f"{APP_NAME} Surface")
    app.setApplicationVersion(APP_VERSION)

    # Set icon
    icon_path = PROJECT_ROOT / "assets" / "touchdeck.ico"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    # Initialize Surface Client
    client = SurfaceNetworkClient()
    client.start()

    # Launch Fullscreen Touch Window
    window = TouchWindow(client)
    window.showFullScreen()

    exit_code = app.exec()

    logger.info("Stopping TouchDeck Surface client...")
    client.stop()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
