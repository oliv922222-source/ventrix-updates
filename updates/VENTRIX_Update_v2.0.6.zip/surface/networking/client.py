"""
TouchDeck - Surface Client Networking
Handles UDP discovery listener, WebSocket connection, auto-reconnect, pairing, and local layout caching.
Author: VENTRIX
"""

import asyncio
import json
import socket
import threading
import time
import uuid
import logging
from pathlib import Path
from typing import Dict, Any, Optional, Callable

import websockets

from shared.constants import (
    DEFAULT_WS_PORT, DEFAULT_DISCOVERY_PORT, HEARTBEAT_INTERVAL
)
from shared.protocol import (
    TouchDeckProtocol, MSG_HELLO, MSG_PAIR_REQUEST, MSG_PAIR_RESULT,
    MSG_AUTH_REQUEST, MSG_AUTH_RESULT, MSG_SYNC_LAYOUT,
    MSG_BUTTON_FEEDBACK, MSG_HEARTBEAT_PING, MSG_HEARTBEAT_PONG
)
from shared.models import ProfileModel

logger = logging.getLogger("TouchDeck.SurfaceClient")


class SurfaceClientState:
    DISCONNECTED = "DISCONNECTED"
    DISCOVERING = "DISCOVERING"
    CONNECTING = "CONNECTING"
    PAIRING_REQUIRED = "PAIRING_REQUIRED"
    AUTHENTICATING = "AUTHENTICATING"
    CONNECTED = "CONNECTED"
    OFFLINE_CACHED = "OFFLINE_CACHED"


class SurfaceNetworkClient:
    """Lightweight, resilient network client for TouchDeck on Microsoft Surface."""

    def __init__(self, cache_dir: Optional[Path] = None):
        if cache_dir is None:
            base = Path.home() / ".touchdeck_surface"
            self.cache_dir = base
        else:
            self.cache_dir = cache_dir

        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.device_info_file = self.cache_dir / "device_info.json"
        self.layout_cache_file = self.cache_dir / "cached_layout.json"

        self._load_device_info()

        self.state = SurfaceClientState.DISCONNECTED
        self.server_ip = self.device_info.get("last_server_ip", "127.0.0.1")
        self.server_port = self.device_info.get("last_server_port", DEFAULT_WS_PORT)

        self.running = False
        self.websocket = None
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.client_thread: Optional[threading.Thread] = None

        self.cached_profile: Optional[ProfileModel] = self._load_cached_layout()

        # Callbacks for UI
        self.on_state_changed: Optional[Callable[[str, str], None]] = None
        self.on_layout_updated: Optional[Callable[[ProfileModel], None]] = None
        self.on_button_feedback: Optional[Callable[[str, str, str], None]] = None
        self.on_pairing_needed: Optional[Callable[[], None]] = None

    def _load_device_info(self):
        if self.device_info_file.exists():
            try:
                with open(self.device_info_file, "r", encoding="utf-8") as f:
                    self.device_info = json.load(f)
            except Exception:
                self.device_info = {}
        else:
            self.device_info = {}

        if "device_id" not in self.device_info:
            self.device_info["device_id"] = f"surface_{uuid.uuid4().hex[:8]}"
        if "device_name" not in self.device_info:
            self.device_info["device_name"] = "VENTRIX Surface"
        if "auth_token" not in self.device_info:
            self.device_info["auth_token"] = ""
        self._save_device_info()

    def _save_device_info(self):
        try:
            with open(self.device_info_file, "w", encoding="utf-8") as f:
                json.dump(self.device_info, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving device info: {e}")

    def _load_cached_layout(self) -> Optional[ProfileModel]:
        if self.layout_cache_file.exists():
            try:
                with open(self.layout_cache_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return ProfileModel.from_dict(data)
            except Exception as e:
                logger.error(f"Error loading cached layout: {e}")
        return None

    def _save_cached_layout(self, profile: ProfileModel):
        try:
            with open(self.layout_cache_file, "w", encoding="utf-8") as f:
                json.dump(profile.to_dict(), f, indent=2)
            self.cached_profile = profile
        except Exception as e:
            logger.error(f"Error saving layout cache: {e}")

    def _set_state(self, new_state: str, message: str = ""):
        self.state = new_state
        logger.info(f"Client state -> {new_state} ({message})")
        if self.on_state_changed:
            self.on_state_changed(new_state, message)

    def start(self):
        if self.running:
            return
        self.running = True
        self.client_thread = threading.Thread(target=self._run_network_worker, daemon=True)
        self.client_thread.start()

    def stop(self):
        self.running = False
        if self.loop and self.loop.is_running():
            try:
                for task in asyncio.all_tasks(self.loop):
                    self.loop.call_soon_threadsafe(task.cancel)
                self.loop.call_soon_threadsafe(self.loop.stop)
            except Exception:
                pass

    def _run_network_worker(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        try:
            self.loop.run_until_complete(self._main_connection_loop())
        except Exception as e:
            logger.error(f"Network worker loop error: {e}")
        finally:
            self.loop.close()

    async def _main_connection_loop(self):
        backoff = 0.5
        while self.running:
            # Check if server IP needs discovery
            if not self.server_ip or self.server_ip == "auto":
                self._set_state(SurfaceClientState.DISCOVERING, "Scanning for PC on network...")
                discovered = await self._discover_server_udp(timeout=2.0)
                if discovered:
                    self.server_ip, self.server_port = discovered
                    self.device_info["last_server_ip"] = self.server_ip
                    self.device_info["last_server_port"] = self.server_port
                    self._save_device_info()
                else:
                    await asyncio.sleep(1.0)
                    continue

            uri = f"ws://{self.server_ip}:{self.server_port}"
            self._set_state(SurfaceClientState.CONNECTING, f"Connecting to {self.server_ip}...")

            try:
                async with websockets.connect(uri, ping_interval=None) as ws:
                    self.websocket = ws
                    backoff = 0.5

                    # Step 1: Send HELLO
                    dev_id = self.device_info["device_id"]
                    dev_name = self.device_info["device_name"]
                    await ws.send(TouchDeckProtocol.msg_hello(dev_name, dev_id, "1.0.0"))

                    # Step 2: Authenticate or Request Pairing
                    auth_token = self.device_info.get("auth_token", "")
                    if auth_token:
                        self._set_state(SurfaceClientState.AUTHENTICATING, "Authenticating session...")
                        await ws.send(TouchDeckProtocol.msg_auth_request(dev_id, auth_token))
                    else:
                        self._set_state(SurfaceClientState.PAIRING_REQUIRED, "Pairing required")
                        if self.on_pairing_needed:
                            self.on_pairing_needed()

                    # Message and Heartbeat tasks
                    rx_task = asyncio.create_task(self._receive_messages(ws))
                    hb_task = asyncio.create_task(self._heartbeat_loop(ws))

                    done, pending = await asyncio.wait(
                        [rx_task, hb_task],
                        return_when=asyncio.FIRST_COMPLETED
                    )
                    for t in pending:
                        t.cancel()

            except Exception as e:
                logger.debug(f"Connection failed: {e}")
                self._set_state(
                    SurfaceClientState.OFFLINE_CACHED if self.cached_profile else SurfaceClientState.DISCONNECTED,
                    f"PC Offline. Reconnecting in {int(backoff)}s..."
                )

            self.websocket = None
            await asyncio.sleep(backoff)
            backoff = min(backoff * 1.5, 6.0)

    async def _discover_server_udp(self, timeout: float = 2.0) -> Optional[tuple]:
        """Listens for UDP broadcast from TouchDeck Server."""
        try:
            loop = asyncio.get_running_loop()
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("", DEFAULT_DISCOVERY_PORT))
            sock.setblocking(False)

            start = time.time()
            while time.time() - start < timeout and self.running:
                try:
                    data, addr = await loop.sock_recvfrom(sock, 2048)
                    payload = json.loads(data.decode("utf-8"))
                    if payload.get("type") == "TOUCHDECK_SERVER_ANNOUNCE":
                        port = payload.get("ws_port", DEFAULT_WS_PORT)
                        sock.close()
                        return (addr[0], port)
                except BlockingIOError:
                    await asyncio.sleep(0.1)
                except Exception:
                    break
            sock.close()
        except Exception as e:
            logger.debug(f"UDP Discovery listener exception: {e}")
        return None

    async def _receive_messages(self, ws: Any):
        async for raw in ws:
            msg = TouchDeckProtocol.parse_message(raw)
            if not msg:
                continue

            mtype = msg.get("type")
            payload = msg.get("payload", {})

            if mtype == MSG_AUTH_RESULT:
                if payload.get("success", False):
                    self._set_state(SurfaceClientState.CONNECTED, "Connected to PC")
                else:
                    self.device_info["auth_token"] = ""
                    self._save_device_info()
                    self._set_state(SurfaceClientState.PAIRING_REQUIRED, "Pairing required")
                    if self.on_pairing_needed:
                        self.on_pairing_needed()

            elif mtype == MSG_PAIR_RESULT:
                if payload.get("success", False):
                    token = payload.get("auth_token", "")
                    if token:
                        self.device_info["auth_token"] = token
                        self._save_device_info()
                    self._set_state(SurfaceClientState.CONNECTED, "Paired and Connected")
                else:
                    self._set_state(SurfaceClientState.PAIRING_REQUIRED, payload.get("message", "Pairing failed"))

            elif mtype == MSG_SYNC_LAYOUT:
                prof_data = payload.get("profile", {})
                if prof_data:
                    profile = ProfileModel.from_dict(prof_data)
                    self._save_cached_layout(profile)
                    if self.on_layout_updated:
                        self.on_layout_updated(profile)

            elif mtype == MSG_BUTTON_FEEDBACK:
                b_id = payload.get("button_id", "")
                status = payload.get("status", "success")
                message = payload.get("message", "")
                if self.on_button_feedback:
                    self.on_button_feedback(b_id, status, message)

    async def _heartbeat_loop(self, ws: Any):
        while self.running:
            await asyncio.sleep(HEARTBEAT_INTERVAL)
            try:
                await ws.send(TouchDeckProtocol.msg_ping())
            except Exception:
                break

    def submit_pairing_pin(self, pin: str):
        if not self.websocket or not self.loop:
            return
        dev_id = self.device_info["device_id"]
        msg = TouchDeckProtocol.msg_pair_confirm(dev_id, pin)
        asyncio.run_coroutine_threadsafe(self.websocket.send(msg), self.loop)

    def send_button_press(self, button_id: str, page_id: str, is_long_press: bool = False):
        if not self.websocket or not self.loop or self.state != SurfaceClientState.CONNECTED:
            return
        msg = TouchDeckProtocol.msg_button_long_press(button_id, page_id) if is_long_press else TouchDeckProtocol.msg_button_press(button_id, page_id)
        asyncio.run_coroutine_threadsafe(self.websocket.send(msg), self.loop)

    def set_manual_server_ip(self, ip: str, port: int = DEFAULT_WS_PORT):
        self.server_ip = ip.strip()
        self.server_port = port
        self.device_info["last_server_ip"] = self.server_ip
        self.device_info["last_server_port"] = self.server_port
        self._save_device_info()
