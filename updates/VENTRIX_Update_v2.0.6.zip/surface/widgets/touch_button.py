"""
TouchDeck - Surface Touch-Optimized Button
Features touch feedback animations, custom sizing, icons, long-press detection,
and optional app-status display ("Lukket" / "Åben: X timer").
Author: VENTRIX
"""

import os
from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import QWidget
from PySide6.QtGui import QPainter, QColor, QFont, QPen, QBrush, QPixmap, QMouseEvent
from PySide6.QtCore import Qt, QSize, QPoint, QRect, QTimer, Signal

from shared.models import ButtonModel
from shared.constants import (
    COLOR_CARD, COLOR_CARD_ACTIVE, COLOR_BORDER, COLOR_PRIMARY_BLUE,
    COLOR_BRIGHT_BLUE, COLOR_TEXT_MAIN, COLOR_SUCCESS, COLOR_ERROR
)


def _format_uptime(seconds: int) -> str:
    """Format uptime seconds as a compact Danish string, e.g. '2t 15m' or '45s'."""
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    mins = minutes % 60
    if mins == 0:
        return f"{hours}t"
    return f"{hours}t {mins}m"


class TouchButton(QWidget):
    pressed_signal = Signal(str, str, bool)  # button_id, page_id, is_long_press

    def __init__(self, button: ButtonModel, page_id: str, parent=None):
        super().__init__(parent)
        self.button = button
        self.page_id = page_id

        self.is_pressed = False
        self.is_feedback_flashing = False
        self.feedback_color = QColor(COLOR_SUCCESS)

        # App-status display (set externally via set_process_status)
        self._status_enabled = False
        self._status_running = False
        self._status_uptime_sec = 0

        self.assets_icons_dir = Path(__file__).parent.parent.parent / "assets" / "icons"

        # Long-press timer (600ms)
        self.long_press_timer = QTimer(self)
        self.long_press_timer.setSingleShot(True)
        self.long_press_timer.setInterval(600)
        self.long_press_timer.timeout.connect(self._on_long_press_timeout)
        self.long_press_triggered = False

        # Feedback flash timer
        self.flash_timer = QTimer(self)
        self.flash_timer.setSingleShot(True)
        self.flash_timer.setInterval(200)
        self.flash_timer.timeout.connect(self._end_feedback_flash)

        self.setCursor(Qt.PointingHandCursor)
        self.setAttribute(Qt.WA_AcceptTouchEvents, True)

    def set_process_status(self, running: bool, uptime_sec: int, enabled: bool):
        """Update app-status badge. Call this whenever status polling returns new data."""
        changed = (
            self._status_enabled != enabled or
            self._status_running != running or
            self._status_uptime_sec != uptime_sec
        )
        self._status_enabled = enabled
        self._status_running = running
        self._status_uptime_sec = uptime_sec
        if changed:
            self.update()

    def trigger_feedback_flash(self, status: str = "success"):
        self.feedback_color = QColor(COLOR_SUCCESS if status == "success" else COLOR_ERROR)
        self.is_feedback_flashing = True
        self.update()
        self.flash_timer.start()

    def _end_feedback_flash(self):
        self.is_feedback_flashing = False
        self.update()

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self.is_pressed = True
            self.long_press_triggered = False
            self.long_press_timer.start()
            self.update()

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self.long_press_timer.stop()
            if self.is_pressed and not self.long_press_triggered:
                self.pressed_signal.emit(self.button.id, self.page_id, False)
                self.trigger_feedback_flash("success")
            self.is_pressed = False
            self.update()

    def _on_long_press_timeout(self):
        if self.is_pressed:
            self.long_press_triggered = True
            self.pressed_signal.emit(self.button.id, self.page_id, True)
            self.trigger_feedback_flash("success")

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Scale down slightly when pressed for tactile effect
        rect = self.rect().adjusted(4, 4, -4, -4)
        if self.is_pressed:
            rect = rect.adjusted(3, 3, -3, -3)

        bg_col = QColor(self.button.bg_color or COLOR_CARD)
        if self.is_pressed:
            bg_col = bg_col.lighter(130)

        # Border
        if self.is_feedback_flashing:
            border_pen = QPen(self.feedback_color, 3)
        elif self.is_pressed:
            border_pen = QPen(QColor(COLOR_BRIGHT_BLUE), 2.5)
        else:
            border_pen = QPen(QColor(self.button.border_color or COLOR_BORDER), 1.5)

        painter.setPen(border_pen)
        painter.setBrush(QBrush(bg_col))
        r = self.button.border_radius or 28
        if r <= 16:
            r = 28
        painter.drawRoundedRect(rect, r, r)

        # ── Decide whether to show status bar ────────────────────────────────
        show_status = self._status_enabled
        # Reserve space at bottom for status label when enabled
        status_bar_height = int(rect.height() * 0.22) if show_status else 0

        # Draw Icon
        icon_drawn = False
        content_rect = QRect(rect.left(), rect.top(), rect.width(),
                             rect.height() - status_bar_height)

        if self.button.icon:
            icon_path = None
            try:
                from editor.utils.icon_storage import resolve_icon_path
                icon_path = resolve_icon_path(self.button.icon)
            except Exception:
                pass

            if not icon_path or not icon_path.exists():
                if os.path.exists(self.button.icon):
                    icon_path = Path(self.button.icon)
                else:
                    cand = self.assets_icons_dir / f"{self.button.icon}.png"
                    if cand.exists():
                        icon_path = cand

            if icon_path and icon_path.exists():
                pix = QPixmap(str(icon_path))
                if not pix.isNull():
                    isize = min(content_rect.height() // 2,
                                max(28, int(content_rect.height() * 0.38)))
                    ix = content_rect.center().x() - isize // 2
                    iy = content_rect.top() + (content_rect.height() // 3) - isize // 2
                    painter.drawPixmap(ix, iy, isize, isize, pix)
                    icon_drawn = True

        # Draw Title
        painter.setPen(QColor(self.button.text_color or COLOR_TEXT_MAIN))
        font_size = max(11, int(content_rect.height() * 0.085))
        font = QFont(self.button.font_family or "Segoe UI", font_size, QFont.Bold)
        painter.setFont(font)

        if icon_drawn:
            text_rect = QRect(content_rect.left() + 6,
                              content_rect.center().y() + 4,
                              content_rect.width() - 12,
                              content_rect.height() // 2 - 8)
        else:
            text_rect = content_rect.adjusted(10, 10, -10, -10)

        painter.drawText(text_rect, Qt.AlignCenter | Qt.TextWordWrap,
                         self.button.title or "Button")

        # ── Status badge at the bottom of the button ─────────────────────────
        if show_status and status_bar_height > 0:
            status_rect = QRect(
                rect.left() + 6,
                rect.bottom() - status_bar_height,
                rect.width() - 12,
                status_bar_height - 4
            )

            if self._status_running:
                # Green pill: "Åben: 2t 15m"
                uptime_str = _format_uptime(self._status_uptime_sec)
                status_text = f"● Åben: {uptime_str}"
                status_color = QColor("#22C55E")   # success green
                pill_bg = QColor(34, 197, 94, 35)  # subtle green bg
            else:
                # Red pill: "Lukket"
                status_text = "● Lukket"
                status_color = QColor("#EF4444")   # error red
                pill_bg = QColor(239, 68, 68, 35)  # subtle red bg

            # Draw pill background
            painter.setPen(Qt.NoPen)
            painter.setBrush(QBrush(pill_bg))
            pill_radius = status_rect.height() // 2
            painter.drawRoundedRect(status_rect, pill_radius, pill_radius)

            # Draw status text
            painter.setPen(status_color)
            status_font_size = max(8, int(status_rect.height() * 0.55))
            status_font = QFont("Segoe UI", status_font_size, QFont.Bold)
            painter.setFont(status_font)
            painter.drawText(status_rect, Qt.AlignCenter, status_text)
