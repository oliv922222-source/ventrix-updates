"""
TouchDeck - Surface Recovery & Emergency Escape Menu
Author: VENTRIX
"""

import sys
import os
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QMessageBox, QFrame
)
from PySide6.QtCore import Qt, Signal

from surface.networking.client import SurfaceNetworkClient
from shared.constants import (
    COLOR_BG, COLOR_CARD, COLOR_BORDER, COLOR_PRIMARY_BLUE,
    COLOR_ERROR, COLOR_WARNING, COLOR_SUCCESS, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED
)


class RecoveryDialog(QDialog):
    exit_to_desktop_requested = Signal()
    restart_runtime_requested = Signal()

    def __init__(self, client: SurfaceNetworkClient, parent=None):
        super().__init__(parent)
        self.setWindowTitle("TouchDeck Recovery")
        self.setFixedSize(540, 420)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog | Qt.WindowStaysOnTopHint)

        self.client = client
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {COLOR_BG};
                border: 2px solid {COLOR_WARNING};
                border-radius: 12px;
            }}
            QPushButton {{
                background-color: {COLOR_CARD};
                color: {COLOR_TEXT_MAIN};
                border: 1px solid {COLOR_BORDER};
                border-radius: 8px;
                padding: 10px;
                font-size: 13px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                border-color: {COLOR_PRIMARY_BLUE};
            }}
        """)

        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(14)

        title = QLabel("TOUCHDECK RECOVERY & DIAGNOSTICS")
        title.setStyleSheet("font-size: 15px; font-weight: 800; color: #F59E0B; letter-spacing: 0.5px;")
        layout.addWidget(title)

        status_box = QFrame()
        status_box.setStyleSheet(f"background-color: #11141C; border: 1px solid {COLOR_BORDER}; border-radius: 8px; padding: 10px;")
        status_lay = QVBoxLayout(status_box)
        
        state_lbl = QLabel(f"Network State: {self.client.state}")
        state_lbl.setStyleSheet("font-size: 12px; color: #F5F7FA;")
        status_lay.addWidget(state_lbl)

        ip_lbl = QLabel(f"Target PC IP: {self.client.server_ip}:{self.client.server_port}")
        ip_lbl.setStyleSheet("font-size: 12px; color: #8B95A7;")
        status_lay.addWidget(ip_lbl)

        layout.addWidget(status_box)

        # Manual IP input
        ip_row = QHBoxLayout()
        self.manual_ip_input = QLineEdit(self.client.server_ip)
        self.manual_ip_input.setPlaceholderText("Enter PC IP manually (e.g. 192.168.1.100)")
        ip_row.addWidget(self.manual_ip_input)

        set_ip_btn = QPushButton("Set PC IP")
        set_ip_btn.clicked.connect(self._set_manual_ip)
        ip_row.addWidget(set_ip_btn)
        layout.addLayout(ip_row)

        # Buttons
        restart_btn = QPushButton("Restart TouchDeck Runtime")
        restart_btn.clicked.connect(self._restart_runtime)
        layout.addWidget(restart_btn)

        clear_pair_btn = QPushButton("Clear Pairing & Re-Pair")
        clear_pair_btn.clicked.connect(self._clear_pairing)
        layout.addWidget(clear_pair_btn)

        exit_btn = QPushButton("Exit to Windows Desktop")
        exit_btn.setStyleSheet(f"background-color: rgba(239, 68, 68, 0.2); border-color: {COLOR_ERROR}; color: #FCA5A5;")
        exit_btn.clicked.connect(self._exit_to_desktop)
        layout.addWidget(exit_btn)

        # Resume
        bottom_row = QHBoxLayout()
        bottom_row.addStretch()
        resume_btn = QPushButton("Resume TouchDeck")
        resume_btn.setStyleSheet(f"background-color: {COLOR_PRIMARY_BLUE}; color: white; border-color: #3B82F6;")
        resume_btn.clicked.connect(self.accept)
        bottom_row.addWidget(resume_btn)
        layout.addLayout(bottom_row)

    def _set_manual_ip(self):
        ip = self.manual_ip_input.text().strip()
        if ip:
            self.client.set_manual_server_ip(ip)
            QMessageBox.information(self, "IP Set", f"Server IP updated to {ip}. Reconnecting...")
            self.accept()

    def _clear_pairing(self):
        self.client.device_info["auth_token"] = ""
        self.client._save_device_info()
        QMessageBox.information(self, "Pairing Reset", "Pairing token cleared. Reconnecting to request new pairing...")
        self.accept()

    def _restart_runtime(self):
        self.restart_runtime_requested.emit()
        self.accept()

    def _exit_to_desktop(self):
        self.exit_to_desktop_requested.emit()
        self.accept()
