"""
VENTRIX - Internationalization (i18n) Engine
Supports Danish (da) and English (en) with live language switching.
Author: VENTRIX
"""

from typing import Dict, Callable, List
from PySide6.QtCore import QObject, Signal


TRANSLATIONS: Dict[str, Dict[str, str]] = {
    # ----------------------------------------------------
    # Welcome / Onboarding Screen
    # ----------------------------------------------------
    "welcome_title_first": {
        "da": "Velkommen.",
        "en": "Welcome.",
    },
    "welcome_title_return": {
        "da": "Velkommen tilbage, {name}.",
        "en": "Welcome back, {name}.",
    },
    "welcome_tagline_first": {
        "da": "Gør din Stream Deck personlig og lynhurtig.",
        "en": "Make your Stream Deck personal and blazing fast.",
    },
    "welcome_tagline_return": {
        "da": "Klar til at styre dit workflow.",
        "en": "Ready to take control of your workflow.",
    },
    "welcome_name_label": {
        "da": "Hvad vil du have vi kalder dig?",
        "en": "What should we call you?",
    },
    "welcome_name_placeholder": {
        "da": "Indtast dit navn...",
        "en": "Enter your name...",
    },
    "topbar_connect_device": {
        "da": "Forbind Enhed",
        "en": "Connect Device",
    },
    "pair_modal_title": {
        "da": "Forbind Telefon eller iPad",
        "en": "Connect Phone or iPad",
    },
    "pair_modal_subtitle": {
        "da": "Styr din PC direkte fra touchskærmen på din telefon eller tablet over Wi-Fi.",
        "en": "Control your PC directly from your phone or tablet touchscreen over Wi-Fi.",
    },
    "pair_step1": {
        "da": "1. Sørg for at din telefon/iPad er på samme Wi-Fi netværk som din PC.",
        "en": "1. Make sure your phone/iPad is connected to the same Wi-Fi as your PC.",
    },
    "pair_step2": {
        "da": "2. Scan QR-koden med kameraet eller åbn linket nedenfor i browseren.",
        "en": "2. Scan the QR code with your camera or open the link below in your browser.",
    },
    "pair_step3": {
        "da": "3. Indtast denne 6-cifrede kode på din enhed for at godkende forbindelsen:",
        "en": "3. Enter this 6-digit code on your device to approve the connection:",
    },
    "pair_new_code": {
        "da": "Ny kode",
        "en": "New code",
    },
    "pair_copy_link": {
        "da": "Kopier Link",
        "en": "Copy Link",
    },
    "pair_copied": {
        "da": "Kopieret!",
        "en": "Copied!",
    },
    "pair_connected_devices": {
        "da": "Forbundne Enheder",
        "en": "Connected Devices",
    },
    "pair_no_devices": {
        "da": "Ingen eksterne enheder forbundet lige nu.",
        "en": "No external devices currently connected.",
    },
    "pair_disconnect": {
        "da": "Afbryd",
        "en": "Disconnect",
    },
    "welcome_language_label": {
        "da": "Vælg sprog:",
        "en": "Choose language:",
    },
    "welcome_open_studio": {
        "da": "Åbn Studio →",
        "en": "Open Studio →",
    },
    "welcome_always_show": {
        "da": "Vis altid denne velkomst ved opstart",
        "en": "Always show this welcome on startup",
    },
    "welcome_logged_in_as": {
        "da": "Logget ind som",
        "en": "Logged in as",
    },
    "welcome_change_name": {
        "da": "Skift navn",
        "en": "Change name",
    },

    # ----------------------------------------------------
    # Top Navigation Bar
    # ----------------------------------------------------
    "topbar_profile": {
        "da": "Profil:",
        "en": "Profile:",
    },
    "topbar_new_profile_tooltip": {
        "da": "Opret Ny Profil",
        "en": "Create New Profile",
    },
    "topbar_del_profile_tooltip": {
        "da": "Slet Aktiv Profil",
        "en": "Delete Active Profile",
    },
    "topbar_push_surface": {
        "da": "Send til Surface",
        "en": "Push to Surface",
    },
    "topbar_push_surface_tooltip": {
        "da": "Gemmer og opdaterer dine knapper direkte på din Surface (Ctrl+S)",
        "en": "Saves and updates buttons directly on your Surface (Ctrl+S)",
    },
    "topbar_devices": {
        "da": "Enheder",
        "en": "Devices",
    },
    "topbar_usb": {
        "da": "USB",
        "en": "USB",
    },
    "topbar_settings_tooltip": {
        "da": "Indstillinger",
        "en": "Settings",
    },
    "topbar_connected": {
        "da": "Forbundet",
        "en": "Connected",
    },
    "topbar_disconnected": {
        "da": "Afbrudt",
        "en": "Disconnected",
    },
    "topbar_devices_count": {
        "da": "{count} Enheder",
        "en": "{count} Devices",
    },

    # ----------------------------------------------------
    # Bottom Page Dock
    # ----------------------------------------------------
    "dock_new_page": {
        "da": "Ny Side",
        "en": "New Page",
    },
    "dock_prev_page": {
        "da": "Forrige side",
        "en": "Previous page",
    },
    "dock_next_page": {
        "da": "Næste side",
        "en": "Next page",
    },

    # ----------------------------------------------------
    # Button Inspector
    # ----------------------------------------------------
    "inspector_title": {
        "da": "INSPEKTØR",
        "en": "INSPECTOR",
    },
    "inspector_tab_content": {
        "da": "Indhold",
        "en": "Content",
    },
    "inspector_tab_action": {
        "da": "Handling",
        "en": "Action",
    },
    "inspector_tab_design": {
        "da": "Design",
        "en": "Design",
    },
    "inspector_delete": {
        "da": "Slet Knap",
        "en": "Delete Button",
    },
    "inspector_title_label": {
        "da": "Navn på knap",
        "en": "Button Title",
    },
    "inspector_title_placeholder": {
        "da": "f.eks. Discord, OBS, Spotify...",
        "en": "e.g. Discord, OBS, Spotify...",
    },
    "inspector_icon_section": {
        "da": "Ikon & Grafik",
        "en": "Icon & Graphics",
    },
    "inspector_choose_icon": {
        "da": "Vælg / Skift Ikon...",
        "en": "Choose / Change Icon...",
    },
    "inspector_close_icon_picker": {
        "da": "Luk Ikonvælger",
        "en": "Close Icon Picker",
    },
    "inspector_remove_icon": {
        "da": "Fjern",
        "en": "Remove",
    },
    "inspector_no_icon": {
        "da": "Intet ikon valgt",
        "en": "No icon selected",
    },
    "inspector_action_type": {
        "da": "Handlingstype",
        "en": "Action Type",
    },
    "action_application": {
        "da": "Åbn Program (.exe)",
        "en": "Launch Application (.exe)",
    },
    "action_hotkey": {
        "da": "Tastatur-genvej",
        "en": "Keyboard Shortcut",
    },
    "action_media": {
        "da": "Medie-kontrol",
        "en": "Media Control",
    },
    "action_url": {
        "da": "Web-adresse / URL",
        "en": "Website / URL",
    },
    "action_system": {
        "da": "System-handling",
        "en": "System Action",
    },
    "action_macro": {
        "da": "Makro",
        "en": "Macro",
    },
    "inspector_browse_exe": {
        "da": "Gennemse .exe fra din PC...",
        "en": "Browse .exe from your PC...",
    },
    "inspector_app_placeholder": {
        "da": "Sti til program (.exe)...",
        "en": "Path to program (.exe)...",
    },
    "inspector_hotkey_placeholder": {
        "da": "f.eks. Ctrl+Shift+M eller F13",
        "en": "e.g. Ctrl+Shift+M or F13",
    },
    "inspector_url_placeholder": {
        "da": "https://youtube.com, netflix.com...",
        "en": "https://youtube.com, netflix.com...",
    },
    "inspector_fetch_logo": {
        "da": "Hent Logo automatisk fra Google",
        "en": "Fetch Logo automatically from Google",
    },
    "inspector_fetching_logo": {
        "da": "Henter logo fra Google...",
        "en": "Fetching logo from Google...",
    },
    "inspector_edit_macro": {
        "da": "Rediger Makro...",
        "en": "Edit Macro...",
    },
    "inspector_test_button": {
        "da": "Test Knap på PC",
        "en": "Test Button on PC",
    },
    "inspector_color_section": {
        "da": "Baggrundsfarve",
        "en": "Background Color",
    },
    "inspector_radius_label": {
        "da": "Hjørne-radius",
        "en": "Corner Radius",
    },
    "inspector_font_size_label": {
        "da": "Tekst-størrelse",
        "en": "Font Size",
    },

    # ----------------------------------------------------
    # Settings Dialog / View
    # ----------------------------------------------------
    "settings_title": {
        "da": "VENTRIX Indstillinger",
        "en": "VENTRIX Settings",
    },
    "settings_back": {
        "da": "Tilbage til Studio",
        "en": "Back to Studio",
    },
    "settings_save": {
        "da": "Gem Indstillinger",
        "en": "Save Settings",
    },
    "settings_cat_general": {
        "da": "Generelt",
        "en": "General",
    },
    "settings_cat_account": {
        "da": "Google Konto",
        "en": "Google Account",
    },
    "settings_cat_devices": {
        "da": "Enheder & Parring",
        "en": "Devices & Pairing",
    },
    "settings_cat_usb": {
        "da": "USB Surface Creator",
        "en": "USB Surface Creator",
    },
    "settings_cat_appearance": {
        "da": "Udseende & Glass",
        "en": "Appearance & Glass",
    },
    "settings_cat_shortcuts": {
        "da": "Tastaturgenveje",
        "en": "Keyboard Shortcuts",
    },
    "settings_cat_network": {
        "da": "Netværk & Server",
        "en": "Network & Server",
    },
    "settings_cat_about": {
        "da": "Om VENTRIX",
        "en": "About VENTRIX",
    },
    "settings_language": {
        "da": "Sprog (Language)",
        "en": "Language (Sprog)",
    },
    "settings_user_name": {
        "da": "Dit Navn (Personalisering)",
        "en": "Your Name (Personalization)",
    },
    "settings_start_with_windows": {
        "da": "Start automatisk med Windows",
        "en": "Start automatically with Windows",
    },
    "settings_minimize_to_tray": {
        "da": "Minimer til systembakken (Tray)",
        "en": "Minimize to system tray",
    },
    "settings_always_show_welcome": {
        "da": "Vis altid startskærm ved opstart",
        "en": "Always show welcome screen on startup",
    },

    # ----------------------------------------------------
    # Icon Picker
    # ----------------------------------------------------
    "picker_search_placeholder": {
        "da": "Søg ikoner (frem, pause, lyd, discord...)",
        "en": "Search icons (next, pause, volume, discord...)",
    },
    "picker_google_placeholder": {
        "da": "Hent fra Google (fx netflix, twitch, dr.dk)...",
        "en": "Fetch from Google (e.g. netflix, twitch, youtube)...",
    },
    "picker_google_fetch_btn": {
        "da": "Hent",
        "en": "Fetch",
    },
    "picker_google_fetch_action": {
        "da": "Hent '{query}' logo fra Google",
        "en": "Fetch '{query}' logo from Google",
    },
    "picker_browse_file": {
        "da": "Gennemse fil fra PC...",
        "en": "Browse file from PC...",
    },
    "picker_clear": {
        "da": "Fjern",
        "en": "Clear",
    },
    "picker_cat_all": {
        "da": "Alle",
        "en": "All",
    },
    "picker_cat_media": {
        "da": "Medier",
        "en": "Media",
    },
    "picker_cat_system": {
        "da": "System",
        "en": "System",
    },
    "picker_cat_navigation": {
        "da": "Navigation",
        "en": "Navigation",
    },
    "picker_cat_apps": {
        "da": "Apps",
        "en": "Apps",
    },
    # ----------------------------------------------------
    # In-App Update System
    # ----------------------------------------------------
    "topbar_update": {
        "da": "Opdatering",
        "en": "Update",
    },
    "update_dialog_title": {
        "da": "VENTRIX Studio Opdatering",
        "en": "VENTRIX Studio Update",
    },
    "update_dialog_current_version": {
        "da": "Nuværende version: v{version}",
        "en": "Current version: v{version}",
    },
    "update_dialog_checking": {
        "da": "Søger efter opdateringer...",
        "en": "Checking for updates...",
    },
    "update_dialog_up_to_date": {
        "da": "VENTRIX Studio er fuldt opdateret",
        "en": "VENTRIX Studio is up to date",
    },
    "update_dialog_up_to_date_sub": {
        "da": "Du kører den nyeste version (v{version}). Ingen opdatering nødvendig.",
        "en": "You are running the latest version (v{version}). No update needed.",
    },
    "update_dialog_available": {
        "da": "Ny opdatering fundet: v{version}",
        "en": "New update available: v{version}",
    },
    "update_dialog_available_sub": {
        "da": "Opdateringen installeres lynhurtigt og direkte i appen uden at geninstallere.",
        "en": "The update installs instantly in-app without needing to reinstall.",
    },
    "update_dialog_install_btn": {
        "da": "Hent og opdater nu",
        "en": "Download & Update Now",
    },
    "update_dialog_restart_btn": {
        "da": "Genstart for at anvende",
        "en": "Restart to Apply",
    },
    "update_dialog_downloading": {
        "da": "Installerer opdatering... ({pct}%)",
        "en": "Installing update... ({pct}%)",
    },
    "update_dialog_success": {
        "da": "✓ Opdatering gennemført! Genstart for at tage den i brug.",
        "en": "✓ Update completed! Restart to apply changes.",
    },
    "update_dialog_changelog_title": {
        "da": "Hvad er nyt:",
        "en": "What's new:",
    },
    "update_check_again": {
        "da": "Søg igen",
        "en": "Check again",
    },
}


class I18nManager(QObject):
    """Singleton managing application-wide language and updates."""
    _instance = None
    language_changed = Signal(str)

    def __init__(self):
        super().__init__()
        self._current_lang = "da"

    @classmethod
    def get_instance(cls) -> "I18nManager":
        if cls._instance is None:
            cls._instance = I18nManager()
        return cls._instance

    @property
    def language(self) -> str:
        return self._current_lang

    def set_language(self, lang: str):
        clean_lang = "en" if lang.lower().startswith("en") else "da"
        if self._current_lang != clean_lang:
            self._current_lang = clean_lang
            self.language_changed.emit(self._current_lang)

    def t(self, key: str, **kwargs) -> str:
        """Lookup localized string with formatting."""
        item = TRANSLATIONS.get(key)
        if not item:
            return key
        text = item.get(self._current_lang, item.get("da", key))
        if kwargs:
            try:
                return text.format(**kwargs)
            except Exception:
                return text
        return text


# Global convenient functions
def t(key: str, **kwargs) -> str:
    return I18nManager.get_instance().t(key, **kwargs)


def get_current_language() -> str:
    return I18nManager.get_instance().language


def set_language(lang: str):
    I18nManager.get_instance().set_language(lang)
