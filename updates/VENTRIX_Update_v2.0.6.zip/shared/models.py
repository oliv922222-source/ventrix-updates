"""
TouchDeck - Data Models
Author: VENTRIX
"""

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
import uuid
import json

from shared.constants import (
    COLOR_CARD, COLOR_TEXT_MAIN, COLOR_BORDER, COLOR_PRIMARY_BLUE,
    DEFAULT_BUTTON_RADIUS, DEFAULT_FONT_FAMILY, ACTION_TYPE_HOTKEY,
    DEFAULT_GRID_ROWS, DEFAULT_GRID_COLS
)


@dataclass
class MacroStepModel:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    step_type: str = "hotkey"  # application, hotkey, media, script, delay
    target: str = ""           # cmd, key combo, app path, media command
    args: str = ""             # command line arguments or options
    delay_ms: int = 250        # wait after execution in ms

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MacroStepModel":
        return cls(
            id=data.get("id", str(uuid.uuid4())[:8]),
            step_type=data.get("step_type", "hotkey"),
            target=data.get("target", ""),
            args=data.get("args", ""),
            delay_ms=int(data.get("delay_ms", 250)),
        )


@dataclass
class ActionModel:
    action_type: str = ACTION_TYPE_HOTKEY
    target: str = ""                       # App path, Hotkey combo, URL, etc.
    args: str = ""                         # Optional args
    working_dir: str = ""
    sub_action: str = ""                   # For media/system/mouse
    macro_steps: List[MacroStepModel] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_type": self.action_type,
            "target": self.target,
            "args": self.args,
            "working_dir": self.working_dir,
            "sub_action": self.sub_action,
            "macro_steps": [s.to_dict() for s in self.macro_steps],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ActionModel":
        steps_raw = data.get("macro_steps", [])
        steps = [MacroStepModel.from_dict(s) for s in steps_raw] if isinstance(steps_raw, list) else []
        return cls(
            action_type=data.get("action_type", ACTION_TYPE_HOTKEY),
            target=data.get("target", ""),
            args=data.get("args", ""),
            working_dir=data.get("working_dir", ""),
            sub_action=data.get("sub_action", ""),
            macro_steps=steps,
        )


@dataclass
class ButtonModel:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = "New Button"
    icon: str = ""                         # Name of built-in icon or custom image filename/path
    row: int = 0
    col: int = 0
    row_span: int = 1                      # 1 or 2
    col_span: int = 1                      # 1 or 2
    bg_color: str = COLOR_CARD
    text_color: str = COLOR_TEXT_MAIN
    border_color: str = COLOR_BORDER
    border_radius: int = DEFAULT_BUTTON_RADIUS
    font_family: str = DEFAULT_FONT_FAMILY
    font_size: int = 12
    icon_size: int = 36
    action: ActionModel = field(default_factory=ActionModel)
    long_press_action: Optional[ActionModel] = None
    enabled: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "icon": self.icon,
            "row": self.row,
            "col": self.col,
            "row_span": self.row_span,
            "col_span": self.col_span,
            "bg_color": self.bg_color,
            "text_color": self.text_color,
            "border_color": self.border_color,
            "border_radius": self.border_radius,
            "font_family": self.font_family,
            "font_size": self.font_size,
            "icon_size": self.icon_size,
            "action": self.action.to_dict() if self.action else None,
            "long_press_action": self.long_press_action.to_dict() if self.long_press_action else None,
            "enabled": self.enabled,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ButtonModel":
        action_data = data.get("action")
        action = ActionModel.from_dict(action_data) if action_data else ActionModel()
        
        lp_data = data.get("long_press_action")
        lp_action = ActionModel.from_dict(lp_data) if lp_data else None

        return cls(
            id=data.get("id", str(uuid.uuid4())),
            title=data.get("title", "Button"),
            icon=data.get("icon", ""),
            row=int(data.get("row", 0)),
            col=int(data.get("col", 0)),
            row_span=int(data.get("row_span", 1)),
            col_span=int(data.get("col_span", 1)),
            bg_color=data.get("bg_color", COLOR_CARD),
            text_color=data.get("text_color", COLOR_TEXT_MAIN),
            border_color=data.get("border_color", COLOR_BORDER),
            border_radius=int(data.get("border_radius", DEFAULT_BUTTON_RADIUS)) if int(data.get("border_radius", DEFAULT_BUTTON_RADIUS)) > 16 else DEFAULT_BUTTON_RADIUS,
            font_family=data.get("font_family", DEFAULT_FONT_FAMILY),
            font_size=int(data.get("font_size", 12)),
            icon_size=int(data.get("icon_size", 36)),
            action=action,
            long_press_action=lp_action,
            enabled=data.get("enabled", True),
        )


@dataclass
class PageModel:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = "Home"
    rows: int = DEFAULT_GRID_ROWS
    cols: int = DEFAULT_GRID_COLS
    buttons: List[ButtonModel] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "rows": self.rows,
            "cols": self.cols,
            "buttons": [b.to_dict() for b in self.buttons],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PageModel":
        buttons_raw = data.get("buttons", [])
        buttons = [ButtonModel.from_dict(b) for b in buttons_raw] if isinstance(buttons_raw, list) else []
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            name=data.get("name", "Page"),
            rows=int(data.get("rows", DEFAULT_GRID_ROWS)),
            cols=int(data.get("cols", DEFAULT_GRID_COLS)),
            buttons=buttons,
        )

    def get_button_at(self, row: int, col: int) -> Optional[ButtonModel]:
        for btn in self.buttons:
            if btn.row == row and btn.col == col:
                return btn
        return None


@dataclass
class ProfileModel:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = "Default"
    pages: List[PageModel] = field(default_factory=list)
    active_page_index: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "pages": [p.to_dict() for p in self.pages],
            "active_page_index": self.active_page_index,
        }

    def get_button(self, button_id: str) -> Optional[ButtonModel]:
        for page in self.pages:
            for btn in page.buttons:
                if btn.id == button_id:
                    return btn
        return None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProfileModel":
        pages_raw = data.get("pages", [])
        pages = [PageModel.from_dict(p) for p in pages_raw] if isinstance(pages_raw, list) else []
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            name=data.get("name", "Default"),
            pages=pages,
            active_page_index=int(data.get("active_page_index", 0)),
        )


@dataclass
class DeviceModel:
    device_id: str = ""
    name: str = "Microsoft Surface"
    paired: bool = False
    auth_token: str = ""
    last_ip: str = ""
    last_seen: float = 0.0
    screen_width: int = 2736
    screen_height: int = 1824
    assigned_profile_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DeviceModel":
        return cls(
            device_id=data.get("device_id", ""),
            name=data.get("name", "Microsoft Surface"),
            paired=data.get("paired", False),
            auth_token=data.get("auth_token", ""),
            last_ip=data.get("last_ip", ""),
            last_seen=float(data.get("last_seen", 0.0)),
            screen_width=int(data.get("screen_width", 2736)),
            screen_height=int(data.get("screen_height", 1824)),
            assigned_profile_id=data.get("assigned_profile_id", ""),
        )


@dataclass
class AppSettingsModel:
    host_ip: str = "0.0.0.0"
    ws_port: int = 18880
    discovery_port: int = 18881
    auto_discovery: bool = True
    start_with_windows: bool = False
    minimize_to_tray: bool = True
    active_profile_id: str = ""
    theme: str = "dark_pro"
    haptic_feedback: bool = True
    pairing_code: str = ""  # Currently active 6-digit challenge
    show_app_status: bool = False  # Show "Lukket" / "Åben: X" under button labels on Surface
    has_seen_welcome: bool = False  # Welcome / onboarding guide state
    user_name: str = ""             # User's display name for personalization
    language: str = "da"            # "da" (Danish) or "en" (English)
    always_show_welcome: bool = True # Always show welcome screen on launch

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AppSettingsModel":
        return cls(
            host_ip=data.get("host_ip", "0.0.0.0"),
            ws_port=int(data.get("ws_port", 18880)),
            discovery_port=int(data.get("discovery_port", 18881)),
            auto_discovery=data.get("auto_discovery", True),
            start_with_windows=data.get("start_with_windows", False),
            minimize_to_tray=data.get("minimize_to_tray", True),
            active_profile_id=data.get("active_profile_id", ""),
            theme=data.get("theme", "dark_pro"),
            haptic_feedback=data.get("haptic_feedback", True),
            pairing_code=data.get("pairing_code", ""),
            show_app_status=bool(data.get("show_app_status", False)),
            has_seen_welcome=bool(data.get("has_seen_welcome", False)),
            user_name=str(data.get("user_name", "")),
            language=str(data.get("language", "da")),
            always_show_welcome=bool(data.get("always_show_welcome", True)),
        )

