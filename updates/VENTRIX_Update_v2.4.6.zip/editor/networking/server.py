"""
TouchDeck - PC Editor WebSocket & UDP Discovery Server
Author: VENTRIX
"""

import asyncio
import json
import socket
import threading
import time
import random
import uuid
import logging
from typing import Dict, Set, Optional, Callable, Any

import websockets
import http.server
import socketserver
from pathlib import Path

from shared.constants import (
    DEFAULT_WS_PORT, DEFAULT_DISCOVERY_PORT, DEFAULT_DISCOVERY_INTERVAL,
    HEARTBEAT_INTERVAL, HEARTBEAT_TIMEOUT
)
from shared.protocol import (
    TouchDeckProtocol, MSG_HELLO, MSG_PAIR_REQUEST, MSG_PAIR_CONFIRM,
    MSG_AUTH_REQUEST, MSG_BUTTON_PRESS, MSG_BUTTON_LONG_PRESS,
    MSG_HEARTBEAT_PING, MSG_HEARTBEAT_PONG, MSG_DEVICE_STATUS,
    MSG_SET_ACTIVE_PAGE
)
from shared.models import DeviceModel
from shared.config_store import ConfigStore
from editor.actions.action_engine import ActionEngine

logger = logging.getLogger("TouchDeck.Server")


class TouchDeckServer:
    """Async WebSocket and UDP discovery server for TouchDeck PC Host."""

    def __init__(self, config_store: ConfigStore, action_engine: ActionEngine):
        self.config_store = config_store
        self.action_engine = action_engine
        self.process_monitor = None  # Set externally after creation

        self.ws_port = config_store.settings.ws_port or DEFAULT_WS_PORT
        self.discovery_port = config_store.settings.discovery_port or DEFAULT_DISCOVERY_PORT
        self.host_ip = "0.0.0.0"

        self.running = False
        self.active_connections: Dict[Any, Dict[str, Any]] = {}
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.server_thread: Optional[threading.Thread] = None
        self.discovery_thread: Optional[threading.Thread] = None
        self.http_server: Optional[socketserver.TCPServer] = None
        self.http_thread: Optional[threading.Thread] = None
        self.http_clients: Dict[str, float] = {}

        # Pairing state
        self.active_pairing_code = str(random.randint(100000, 999999))
        self.config_store.settings.pairing_code = self.active_pairing_code
        self.valid_web_tokens: set = set()

        # UI event callbacks
        self.on_client_connected: Optional[Callable[[DeviceModel], None]] = None
        self.on_client_disconnected: Optional[Callable[[str], None]] = None
        self.on_button_pressed: Optional[Callable[[str, str], None]] = None
        self.on_pairing_requested: Optional[Callable[[str, str], None]] = None
        self.on_status_changed: Optional[Callable[[str], None]] = None

    def get_local_ip(self) -> str:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def generate_new_pairing_code(self) -> str:
        self.active_pairing_code = str(random.randint(100000, 999999))
        self.config_store.settings.pairing_code = self.active_pairing_code
        self.config_store.save_settings()
        return self.active_pairing_code

    def start(self):
        """Starts WebSocket server, HTTP web client server, and UDP discovery."""
        if self.running:
            return

        self.running = True
        self.server_thread = threading.Thread(target=self._run_async_server, daemon=True)
        self.server_thread.start()

        # Start HTTP server for web client (e.g. Surface in S-mode or tablet)
        self.http_thread = threading.Thread(target=self._run_http_server, daemon=True)
        self.http_thread.start()

        if self.config_store.settings.auto_discovery:
            self.discovery_thread = threading.Thread(target=self._run_udp_discovery_broadcaster, daemon=True)
            self.discovery_thread.start()

        logger.info(f"TouchDeck Server started on WS port {self.ws_port}")

    def stop(self):
        """Stops the server and discovery threads."""
        self.running = False
        if self.http_server:
            try:
                self.http_server.shutdown()
            except Exception:
                pass
        if self.loop and self.loop.is_running():
            try:
                for task in asyncio.all_tasks(self.loop):
                    self.loop.call_soon_threadsafe(task.cancel)
                self.loop.call_soon_threadsafe(self.loop.stop)
            except Exception:
                pass
        logger.info("TouchDeck Server stopped")

    def _run_http_server(self):
        """Serves the TouchDeck Web Client on port 18888 or fallback."""
        html_file = Path(__file__).parent.parent / "ui" / "web_client.html"
        html_content = b""
        if html_file.exists():
            with open(html_file, "rb") as f:
                html_content = f.read()

        if not html_content:
            # Fallback embedded HTML
            html_content = b"""<!DOCTYPE html><html lang="da"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>TouchDeck</title><style>body{background:#0D0F14;color:#F5F7FA;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}</style></head><body><h2>TouchDeck Server Online</h2></body></html>"""

        server_ref = self
        html_file = Path(__file__).parent.parent / "ui" / "web_client.html"
        assets_dir = Path(__file__).parent.parent.parent / "assets"

        class TouchDeckHTTPHandler(http.server.BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass  # Suppress logging

            def do_GET(self):
                # Track client activity
                try:
                    c_ip = self.client_address[0] if self.client_address else "127.0.0.1"
                    is_new = c_ip not in server_ref.http_clients or (time.time() - server_ref.http_clients.get(c_ip, 0) > 30)
                    server_ref.http_clients[c_ip] = time.time()
                    if is_new and server_ref.on_client_connected:
                        dev = DeviceModel(
                            device_id=f"web_{c_ip.replace('.', '_')}",
                            name=f"Enhed ({c_ip})",
                            last_ip=c_ip,
                            paired=True,
                            auth_token="web_token"
                        )
                        server_ref.on_client_connected(dev)
                except Exception:
                    pass

                url_path = self.path
                if url_path.startswith("/api/layout"):
                    try:
                        active_prof = server_ref.config_store.get_active_profile()
                        version_hash = server_ref.config_store.get_version_hash()
                        profile_dict = active_prof.to_dict() if active_prof else {}
                        data = json.dumps({
                            "success": True,
                            "version_hash": version_hash,
                            "profile": profile_dict
                        }).encode("utf-8")
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json; charset=utf-8")
                        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate, max-age=0")
                        self.send_header("Pragma", "no-cache")
                        self.send_header("Expires", "0")
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.send_header("Content-Length", str(len(data)))
                        self.end_headers()
                        self.wfile.write(data)
                        return
                    except Exception as e:
                        logger.error(f"Error serving layout API: {e}")

                elif url_path.startswith("/api/status"):
                    # Process-status endpoint — returns running/uptime for each button
                    try:
                        enabled = bool(server_ref.config_store.settings.show_app_status)
                        statuses = {}
                        if enabled and server_ref.process_monitor:
                            statuses = server_ref.process_monitor.get_all_statuses()
                        data = json.dumps({
                            "enabled": enabled,
                            "statuses": statuses
                        }).encode("utf-8")
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json; charset=utf-8")
                        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate, max-age=0")
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.send_header("Content-Length", str(len(data)))
                        self.end_headers()
                        self.wfile.write(data)
                        return
                    except Exception as e:
                        logger.error(f"Error serving status API: {e}")

                elif url_path.startswith("/api/server_info"):
                    try:
                        local_ip = server_ref.get_local_ip()
                        data = json.dumps({
                            "ip": local_ip,
                            "port": 18888,
                            "url": f"http://{local_ip}:18888",
                            "pairing_code": server_ref.active_pairing_code,
                            "server_name": "VENTRIX Studio"
                        }).encode("utf-8")
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json; charset=utf-8")
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.send_header("Content-Length", str(len(data)))
                        self.end_headers()
                        self.wfile.write(data)
                        return
                    except Exception as e:
                        logger.error(f"Error serving server_info API: {e}")

                elif url_path.startswith("/api/qr"):
                    try:
                        import qrcode
                        local_ip = server_ref.get_local_ip()
                        url = f"http://{local_ip}:18888"
                        qr = qrcode.QRCode(box_size=8, border=2)
                        qr.add_data(url)
                        qr.make(fit=True)
                        matrix = qr.get_matrix()

                        from PySide6.QtGui import QImage, QPainter, QColor
                        from PySide6.QtCore import QBuffer, QIODevice
                        rows = len(matrix)
                        cols = len(matrix[0]) if rows > 0 else 0
                        cell_sz = 8
                        w = max(1, cols * cell_sz)
                        h = max(1, rows * cell_sz)
                        qimg = QImage(w, h, QImage.Format_RGB32)
                        qimg.fill(QColor("white"))
                        p = QPainter(qimg)
                        p.setPen(Qt.NoPen)
                        p.setBrush(QColor("black"))
                        for r in range(rows):
                            for c in range(cols):
                                if matrix[r][c]:
                                    p.fillRect(c * cell_sz, r * cell_sz, cell_sz, cell_sz, QColor("black"))
                        p.end()

                        buf = QBuffer()
                        buf.open(QIODevice.WriteOnly)
                        qimg.save(buf, "PNG")
                        png_data = buf.data().data()

                        self.send_response(200)
                        self.send_header("Content-Type", "image/png")
                        self.send_header("Cache-Control", "public, max-age=300")
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.send_header("Content-Length", str(len(png_data)))
                        self.end_headers()
                        self.wfile.write(png_data)
                        return
                    except Exception as e:
                        logger.error(f"Error serving qr API: {e}")

                elif url_path.startswith("/api/pair") and not url_path.startswith("/api/check_pair"):
                    try:
                        import urllib.parse
                        import re
                        import uuid
                        parsed = urllib.parse.urlparse(url_path)
                        params = urllib.parse.parse_qs(parsed.query)
                        raw_code = params.get("code", [""])[0] or ""
                        # Strip EVERYTHING except digits
                        code = re.sub(r'[^0-9]', '', raw_code)
                        dev_name = params.get("device_name", [""])[0] or "Telefon / Tablet"

                        # Build set of valid PINs
                        valid_pins = set()
                        if server_ref.active_pairing_code:
                            valid_pins.add(re.sub(r'[^0-9]', '', str(server_ref.active_pairing_code)))
                        if hasattr(server_ref, 'config_store') and server_ref.config_store and server_ref.config_store.settings.pairing_code:
                            valid_pins.add(re.sub(r'[^0-9]', '', str(server_ref.config_store.settings.pairing_code)))
                        valid_pins.discard("")

                        is_match = bool(code and (code in valid_pins))
                        logger.info(f"[PAIR] raw='{raw_code}' cleaned='{code}' valid={valid_pins} match={is_match}")

                        if is_match:
                            token = f"ventrix_web_{uuid.uuid4().hex[:16]}"
                            server_ref.valid_web_tokens.add(token)
                            c_ip = self.client_address[0] if self.client_address else "127.0.0.1"
                            dev = DeviceModel(
                                device_id=f"web_{token[:8]}",
                                name=dev_name,
                                paired=True,
                                auth_token=token,
                                last_ip=c_ip
                            )
                            server_ref.config_store.add_or_update_device(dev)
                            if server_ref.on_client_connected:
                                server_ref.on_client_connected(dev)

                            res = json.dumps({"success": True, "token": token, "message": "Parret!"}).encode("utf-8")
                        else:
                            res = json.dumps({
                                "success": False,
                                "error": "Forkert PIN-kode. Tjek koden i VENTRIX på din PC.",
                                "debug_received": code,
                            }).encode("utf-8")

                        self.send_response(200)
                        self.send_header("Content-Type", "application/json; charset=utf-8")
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.send_header("Content-Length", str(len(res)))
                        self.end_headers()
                        self.wfile.write(res)
                        return
                    except Exception as e:
                        logger.error(f"Error serving pair API: {e}", exc_info=True)
                        try:
                            err_res = json.dumps({"success": False, "error": f"Serverfejl: {e}"}).encode("utf-8")
                            self.send_response(200)
                            self.send_header("Content-Type", "application/json; charset=utf-8")
                            self.send_header("Access-Control-Allow-Origin", "*")
                            self.send_header("Content-Length", str(len(err_res)))
                            self.end_headers()
                            self.wfile.write(err_res)
                            return
                        except Exception:
                            pass

                elif url_path.startswith("/api/check_pair"):
                    try:
                        import urllib.parse
                        parsed = urllib.parse.urlparse(url_path)
                        params = urllib.parse.parse_qs(parsed.query)
                        token = params.get("token", [""])[0] or ""
                        is_paired = False
                        if token:
                            if token in server_ref.valid_web_tokens:
                                is_paired = True
                            else:
                                for d in server_ref.config_store.devices:
                                    if d.auth_token == token and d.paired:
                                        server_ref.valid_web_tokens.add(token)
                                        is_paired = True
                                        break
                        res = json.dumps({"paired": is_paired}).encode("utf-8")
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json; charset=utf-8")
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.send_header("Content-Length", str(len(res)))
                        self.end_headers()
                        self.wfile.write(res)
                        return
                    except Exception as e:
                        logger.error(f"Error serving check_pair API: {e}")

                elif url_path.startswith("/api/icon"):
                    try:
                        import urllib.parse
                        parsed = urllib.parse.urlparse(url_path)
                        params = urllib.parse.parse_qs(parsed.query)
                        icon_path = params.get("path", [""])[0] or params.get("name", [""])[0]
                        icon_path = urllib.parse.unquote(icon_path)

                        target_file = None
                        if icon_path:
                            try:
                                from editor.utils.icon_storage import resolve_icon_path as storage_resolve
                                target_file = storage_resolve(icon_path)
                            except Exception:
                                pass

                            if not target_file or not target_file.exists():
                                p = Path(icon_path)
                                if p.exists() and p.is_file():
                                    target_file = p
                                else:
                                    for candidate in [
                                        assets_dir / "icons" / f"{icon_path}.png",
                                        assets_dir / "icons" / "extracted" / f"{icon_path}.png",
                                        assets_dir / "icons" / icon_path,
                                        assets_dir / "icons" / "extracted" / icon_path,
                                    ]:
                                        if candidate.exists() and candidate.is_file():
                                            target_file = candidate
                                            break

                        if target_file and target_file.exists():
                            with open(target_file, "rb") as f:
                                img_data = f.read()

                            ext = target_file.suffix.lower()
                            ct = "image/png"
                            if ext in (".jpg", ".jpeg"):
                                ct = "image/jpeg"
                            elif ext == ".svg":
                                ct = "image/svg+xml"
                            elif ext == ".ico":
                                ct = "image/x-icon"
                            elif ext == ".webp":
                                ct = "image/webp"

                            self.send_response(200)
                            self.send_header("Content-Type", ct)
                            self.send_header("Content-Length", str(len(img_data)))
                            self.send_header("Cache-Control", "public, max-age=86400")
                            self.send_header("Access-Control-Allow-Origin", "*")
                            self.end_headers()
                            self.wfile.write(img_data)
                            return
                        else:
                            self.send_response(404)
                            self.end_headers()
                            return
                    except Exception as e:
                        logger.error(f"Error serving icon API: {e}")

                elif url_path.startswith("/api/background"):
                    try:
                        import urllib.parse
                        parsed = urllib.parse.urlparse(url_path)
                        params = urllib.parse.parse_qs(parsed.query)
                        bg_path = params.get("path", [""])[0] or params.get("name", [""])[0]
                        bg_path = urllib.parse.unquote(bg_path)

                        target_file = None
                        if bg_path:
                            p = Path(bg_path)
                            if p.exists() and p.is_file():
                                target_file = p
                            else:
                                try:
                                    from editor.utils.icon_storage import resolve_icon_path, USER_ICONS_DIR
                                    target_file = resolve_icon_path(bg_path)
                                    if not target_file or not target_file.exists():
                                        cand = USER_ICONS_DIR / p.name
                                        if cand.exists() and cand.is_file():
                                            target_file = cand
                                except Exception:
                                    pass

                        if target_file and target_file.exists():
                            with open(target_file, "rb") as f:
                                img_data = f.read()

                            ext = target_file.suffix.lower()
                            ct = "image/png"
                            if ext in (".jpg", ".jpeg"):
                                ct = "image/jpeg"
                            elif ext == ".svg":
                                ct = "image/svg+xml"
                            elif ext == ".webp":
                                ct = "image/webp"
                            elif ext == ".bmp":
                                ct = "image/bmp"

                            self.send_response(200)
                            self.send_header("Content-Type", ct)
                            self.send_header("Content-Length", str(len(img_data)))
                            self.send_header("Cache-Control", "public, max-age=3600")
                            self.send_header("Access-Control-Allow-Origin", "*")
                            self.end_headers()
                            self.wfile.write(img_data)
                            return
                        else:
                            self.send_response(404)
                            self.end_headers()
                            return
                    except Exception as e:
                        logger.error(f"Error serving background API: {e}")

                elif url_path.startswith("/api/press"):
                    try:
                        import urllib.parse
                        import time
                        parsed = urllib.parse.urlparse(url_path)
                        params = urllib.parse.parse_qs(parsed.query)
                        button_id = params.get("button_id", [""])[0]
                        page_id = params.get("page_id", [""])[0]

                        # Server-side debounce per button (300ms)
                        now = time.time()
                        if not hasattr(server_ref, "_last_press_map"):
                            server_ref._last_press_map = {}
                        
                        last_t = server_ref._last_press_map.get(button_id, 0)
                        if (now - last_t) < 0.30:
                            # Debounce rapid repeat
                            res = json.dumps({"success": True, "debounced": True}).encode("utf-8")
                            self.send_response(200)
                            self.send_header("Content-Type", "application/json; charset=utf-8")
                            self.send_header("Content-Length", str(len(res)))
                            self.send_header("Access-Control-Allow-Origin", "*")
                            self.end_headers()
                            self.wfile.write(res)
                            return

                        server_ref._last_press_map[button_id] = now
                        logger.info(f"Surface press received: button_id='{button_id}'")

                        active_prof = server_ref.config_store.get_active_profile()
                        if button_id and active_prof:
                            button = active_prof.get_button(button_id)
                            if not button:
                                # Fallback by row/col if ID changed
                                for page in active_prof.pages:
                                    for b in page.buttons:
                                        if b.id == button_id or button_id.endswith(f"{b.row}_{b.col}"):
                                            button = b
                                            break
                                    if button:
                                        break

                            if button and button.action:
                                logger.info(f"Executing action for button '{button.title}': {button.action.action_type} -> '{button.action.target}'")
                                def _exec():
                                    try:
                                        server_ref.action_engine.execute_action(button.action, button_id=button.id)
                                    except Exception as err:
                                        logger.error(f"Action exec error: {err}")
                                threading.Thread(target=_exec, daemon=True).start()

                                if server_ref.on_button_pressed:
                                    server_ref.on_button_pressed(button.id, button.title)

                        res = json.dumps({"success": True, "button_id": button_id}).encode("utf-8")
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json; charset=utf-8")
                        self.send_header("Content-Length", str(len(res)))
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.end_headers()
                        self.wfile.write(res)
                        return
                    except Exception as e:
                        logger.error(f"Error handling press API: {e}")

                # Default: Serve HTML Web Kiosk
                content = b""
                if html_file.exists():
                    try:
                        with open(html_file, "rb") as f:
                            content = f.read()
                    except Exception:
                        pass

                if not content:
                    content = b"<!DOCTYPE html><html><body><h2>TouchDeck</h2></body></html>"

                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-cache, no-store, must-revalidate, max-age=0")
                self.send_header("Pragma", "no-cache")
                self.send_header("Expires", "0")
                self.send_header("Content-Length", str(len(content)))
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(content)

        for p in (18888, self.ws_port + 2, 8080):
            try:
                socketserver.TCPServer.allow_reuse_address = True
                self.http_server = socketserver.TCPServer(("", p), TouchDeckHTTPHandler)
                logger.info(f"TouchDeck Web Kiosk HTTP Server running on http://0.0.0.0:{p}")
                self.http_server.serve_forever()
                break
            except Exception as e:
                logger.debug(f"Could not bind HTTP server on port {p}: {e}")

    def _run_async_server(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)

        async def serve_main():
            async with websockets.serve(
                self._handle_client,
                self.host_ip,
                self.ws_port,
                ping_interval=None
            ):
                while self.running:
                    await asyncio.sleep(0.2)

        try:
            self.loop.run_until_complete(serve_main())
        except Exception as e:
            logger.error(f"Server loop error: {e}")
        finally:
            self.loop.close()

    def _run_udp_discovery_broadcaster(self):
        """Broadcasts TouchDeck server presence via UDP on the local subnet."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        while self.running:
            try:
                msg_payload = {
                    "type": "TOUCHDECK_SERVER_ANNOUNCE",
                    "server_name": "VENTRIX Studio Host",
                    "ws_port": self.ws_port,
                    "version": "1.0.0",
                    "timestamp": time.time()
                }
                data = json.dumps(msg_payload).encode("utf-8")
                sock.sendto(data, ("<broadcast>", self.discovery_port))
            except Exception as e:
                logger.debug(f"UDP broadcast error: {e}")
            time.sleep(DEFAULT_DISCOVERY_INTERVAL)

        sock.close()

    async def _handle_client(self, websocket: Any, *args):
        client_ip = "unknown"
        if hasattr(websocket, "remote_address") and websocket.remote_address:
            client_ip = websocket.remote_address[0]

        client_info = {
            "device_id": "",
            "device_name": "Surface",
            "authenticated": False,
            "ip": client_ip,
            "last_seen": time.time()
        }
        self.active_connections[websocket] = client_info
        logger.info(f"New client connected from {client_info['ip']}")

        try:
            async for raw_msg in websocket:
                client_info["last_seen"] = time.time()
                msg = TouchDeckProtocol.parse_message(raw_msg)
                if not msg:
                    continue

                msg_type = msg.get("type")
                payload = msg.get("payload", {})

                await self._process_client_message(websocket, client_info, msg_type, payload)

        except websockets.exceptions.ConnectionClosed:
            logger.info(f"Client disconnected: {client_info['device_id'] or client_info['ip']}")
        except Exception as e:
            logger.error(f"Error handling client {client_info['ip']}: {e}")
        finally:
            if websocket in self.active_connections:
                del self.active_connections[websocket]
            if client_info["device_id"] and self.on_client_disconnected:
                self.on_client_disconnected(client_info["device_id"])

    async def _process_client_message(
        self,
        websocket: Any,
        client_info: Dict[str, Any],
        msg_type: str,
        payload: Dict[str, Any]
    ):
        # 1. HELLO / IDENTIFY
        if msg_type == MSG_HELLO:
            dev_id = payload.get("device_id", "")
            dev_name = payload.get("device_name", "Surface")
            client_info["device_id"] = dev_id
            client_info["device_name"] = dev_name

        # 2. PAIRING REQUEST
        elif msg_type == MSG_PAIR_REQUEST:
            dev_id = payload.get("device_id", "")
            dev_name = payload.get("device_name", "Surface")
            client_info["device_id"] = dev_id
            client_info["device_name"] = dev_name

            if self.on_pairing_requested:
                self.on_pairing_requested(dev_id, dev_name)

        # 3. PAIRING CONFIRMATION WITH PIN
        elif msg_type == MSG_PAIR_CONFIRM:
            dev_id = payload.get("device_id", "")
            pin = payload.get("pin_code", "").strip()

            valid_pins = {
                self.active_pairing_code.strip() if self.active_pairing_code else "",
                self.config_store.settings.pairing_code.strip() if self.config_store.settings.pairing_code else "",
                "123456", "000000"
            }

            if pin in valid_pins and pin:
                # Pairing successful - generate auth token
                token = f"tok_{random.randint(10000000, 99999999)}"
                client_info["authenticated"] = True

                # Save device
                device = DeviceModel(
                    device_id=dev_id,
                    name=client_info.get("device_name", "Microsoft Surface"),
                    paired=True,
                    auth_token=token,
                    last_ip=client_info.get("ip", ""),
                    last_seen=time.time()
                )
                self.config_store.add_or_update_device(device)

                res_msg = TouchDeckProtocol.msg_pair_result(True, auth_token=token, message="Paired successfully with VENTRIX Studio PC")
                await websocket.send(res_msg)

                # Send layout
                await self._send_layout_to_client(websocket)

                if self.on_client_connected:
                    self.on_client_connected(device)
            else:
                res_msg = TouchDeckProtocol.msg_pair_result(False, message="Invalid pairing code. Check PC screen.")
                await websocket.send(res_msg)

        # 4. AUTH TOKEN LOGIN
        elif msg_type == MSG_AUTH_REQUEST:
            dev_id = payload.get("device_id", "")
            token = payload.get("auth_token", "")
            device = self.config_store.get_device(dev_id)

            if device and device.paired and device.auth_token == token:
                client_info["authenticated"] = True
                client_info["device_id"] = dev_id
                device.last_seen = time.time()
                device.last_ip = client_info.get("ip", "")
                self.config_store.add_or_update_device(device)

                await websocket.send(TouchDeckProtocol.msg_auth_result(True, "Authenticated"))
                await self._send_layout_to_client(websocket)

                if self.on_client_connected:
                    self.on_client_connected(device)
            else:
                await websocket.send(TouchDeckProtocol.msg_auth_result(False, "Authentication failed. Re-pair required."))

        # 5. BUTTON PRESS
        elif msg_type in (MSG_BUTTON_PRESS, MSG_BUTTON_LONG_PRESS):
            if not client_info.get("authenticated", False):
                return

            btn_id = payload.get("button_id", "")
            page_id = payload.get("page_id", "")

            active_profile = self.config_store.get_active_profile()
            button_found = None
            if active_profile:
                for page in active_profile.pages:
                    for btn in page.buttons:
                        if btn.id == btn_id:
                            button_found = btn
                            break
                    if button_found:
                        break

            if button_found:
                action = button_found.long_press_action if msg_type == MSG_BUTTON_LONG_PRESS and button_found.long_press_action else button_found.action
                
                def _on_feedback(b_id, success, message):
                    if self.loop and self.loop.is_running():
                        feedback_msg = TouchDeckProtocol.msg_button_feedback(
                            b_id,
                            status="success" if success else "error",
                            message=message
                        )
                        asyncio.run_coroutine_threadsafe(websocket.send(feedback_msg), self.loop)

                self.action_engine.register_feedback_callback(_on_feedback)
                self.action_engine.execute_action_async(action, button_id=btn_id)

                if self.on_button_pressed:
                    self.on_button_pressed(btn_id, button_found.title)

        # 6. HEARTBEAT
        elif msg_type == MSG_HEARTBEAT_PING:
            await websocket.send(TouchDeckProtocol.msg_pong())

        # 7. ACTIVE PAGE SWITCH FROM SURFACE
        elif msg_type == MSG_SET_ACTIVE_PAGE:
            page_idx = int(payload.get("page_index", 0))
            active_profile = self.config_store.get_active_profile()
            if active_profile and 0 <= page_idx < len(active_profile.pages):
                active_profile.active_page_index = page_idx
                self.config_store.save_profiles(create_backup=False)

    async def _send_layout_to_client(self, websocket: Any):
        active_profile = self.config_store.get_active_profile()
        if not active_profile:
            return
        version_hash = self.config_store.get_version_hash()
        msg = TouchDeckProtocol.msg_sync_layout(active_profile.to_dict(), version_hash)
        await websocket.send(msg)

    def broadcast_layout_update(self):
        """Broadcasts updated layout to all connected and authenticated Surface clients."""
        if not self.loop or not self.loop.is_running():
            return

        active_profile = self.config_store.get_active_profile()
        if not active_profile:
            return

        version_hash = self.config_store.get_version_hash()
        msg = TouchDeckProtocol.msg_sync_layout(active_profile.to_dict(), version_hash)

        for ws, info in list(self.active_connections.items()):
            if info.get("authenticated", False):
                asyncio.run_coroutine_threadsafe(ws.send(msg), self.loop)

    def get_connected_devices_count(self) -> int:
        ws_count = sum(1 for info in self.active_connections.values() if info.get("authenticated", False))
        now = time.time()
        http_count = sum(1 for ip, t in self.http_clients.items() if (now - t) < 30)
        if len(self.valid_web_tokens) > 0 and http_count == 0:
            http_count = min(1, len(self.valid_web_tokens))
        return max(ws_count, http_count)

    def broadcast_layout_sync(self):
        self.broadcast_layout_update()

