"""
TouchDeck / VENTRIX - Medal.tv Database Auto-Sync Service
Directly configures Medal's SQLite settings database so that each clip duration
(15s, 30s, 1m, 2m, 5m, Full Recording, Bookmark) has its own dedicated hotkey,
bypassing Medal's single-duration dropdown limitation.

Ensures seamless automatic background synchronization whenever a Medal button
is created or modified in TouchDeck.
"""

import os
import glob
import json
import re
import logging
import threading
from typing import Tuple, List, Dict, Optional, Callable
from pathlib import Path

try:
    import sqlite3
except ImportError:
    sqlite3 = None

from shared.constants import (
    MEDAL_CLIP_15S, MEDAL_CLIP_30S, MEDAL_CLIP_1M, MEDAL_CLIP_2M, MEDAL_CLIP_5M,
    MEDAL_CLIP_CUSTOM, MEDAL_RECORD_TOGGLE, MEDAL_BOOKMARK, MEDAL_DEFAULT_HOTKEYS
)

logger = logging.getLogger("TouchDeck.MedalSync")

# Mapping from TouchDeck sub-action identifiers to Medal's internal action names
SUB_ACTION_TO_MEDAL_ACTION: Dict[str, str] = {
    MEDAL_CLIP_15S: "clip;length=15",
    MEDAL_CLIP_30S: "clip;length=30",
    MEDAL_CLIP_1M: "clip;length=60",
    MEDAL_CLIP_2M: "clip;length=120",
    MEDAL_CLIP_5M: "clip;length=300",
    MEDAL_RECORD_TOGGLE: "segment_toggle",
    MEDAL_BOOKMARK: "bookmark",
}

DEFAULT_MEDAL_HOTKEYS: List[Dict[str, str]] = [
    {"action": "clip;length=15", "device": "keyboard", "type": "short_press", "inputs": "CTRL + F8"},
    {"action": "clip;length=30", "device": "keyboard", "type": "short_press", "inputs": "F8"},
    {"action": "clip;length=60", "device": "keyboard", "type": "short_press", "inputs": "CTRL + F9"},
    {"action": "clip;length=120", "device": "keyboard", "type": "short_press", "inputs": "CTRL + F10"},
    {"action": "clip;length=300", "device": "keyboard", "type": "short_press", "inputs": "CTRL + F11"},
    {"action": "segment_toggle", "device": "keyboard", "type": "short_press", "inputs": "ALT + F7"},
    {"action": "bookmark", "device": "keyboard", "type": "short_press", "inputs": "F10"}
]


def format_medal_hotkey(hotkey: str) -> str:
    """
    Normalizes a hotkey string into Medal's expected representation:
    e.g. 'Ctrl+F8' -> 'CTRL + F8', 'Alt+F7' -> 'ALT + F7', 'F8' -> 'F8'
    """
    if not hotkey:
        return "F8"
    parts = [p.strip().upper() for p in re.split(r"\s*\+\s*", hotkey.strip()) if p.strip()]
    return " + ".join(parts)


def find_medal_databases() -> List[str]:
    """
    Finds active Medal SQLite databases in %APPDATA%/Medal, %LOCALAPPDATA%/Medal,
    or test override paths.
    """
    # Check test override first
    env_override = os.environ.get("MEDAL_DB_PATH")
    if env_override and os.path.exists(env_override):
        return [env_override]

    candidate_dirs = []
    appdata = os.environ.get("APPDATA", "")
    if appdata:
        candidate_dirs.append(os.path.join(appdata, "Medal"))
        candidate_dirs.append(os.path.join(appdata, "Medal", "databases"))
        candidate_dirs.append(os.path.join(appdata, "Medal", "store"))

    localappdata = os.environ.get("LOCALAPPDATA", "")
    if localappdata:
        candidate_dirs.append(os.path.join(localappdata, "Medal"))
        candidate_dirs.append(os.path.join(localappdata, "Programs", "Medal"))

    userprofile = os.environ.get("USERPROFILE", "")
    if userprofile:
        candidate_dirs.append(os.path.join(userprofile, ".medal"))

    found_dbs = []
    for cdir in candidate_dirs:
        if not os.path.exists(cdir):
            continue
        # Search for medal-*.db or any .db
        patterns = [
            os.path.join(cdir, "medal-*.db"),
            os.path.join(cdir, "store*.db"),
            os.path.join(cdir, "*.db")
        ]
        for pat in patterns:
            for match in glob.glob(pat):
                if match not in found_dbs:
                    found_dbs.append(match)

    # Filter out guest dbs if user dbs exist
    user_dbs = [d for d in found_dbs if "guest" not in os.path.basename(d).lower()]
    if user_dbs:
        return user_dbs
    if found_dbs:
        return found_dbs

    # If Medal folder exists in APPDATA, initialize default user database so Medal picks it up
    if appdata:
        medal_dir = os.path.join(appdata, "Medal")
        try:
            os.makedirs(medal_dir, exist_ok=True)
            default_db = os.path.join(medal_dir, "medal-user-default.db")
            if sqlite3:
                conn = sqlite3.connect(default_db)
                conn.execute("CREATE TABLE IF NOT EXISTS key_values (key TEXT PRIMARY KEY, value BLOB);")
                conn.commit()
                conn.close()
                return [default_db]
        except Exception as e:
            logger.debug(f"Could not initialize default Medal db: {e}")

    return []


def read_medal_hotkeys(db_path: Optional[str] = None) -> List[Dict[str, str]]:
    """Reads the current hotkey configuration from Medal's database."""
    if sqlite3 is None:
        return []

    dbs = [db_path] if db_path else find_medal_databases()
    if not dbs:
        return []

    for path in dbs:
        try:
            conn = sqlite3.connect(path, timeout=3.0)
            cur = conn.cursor()
            raw_val = None
            try:
                cur.execute("SELECT json(value) FROM key_values WHERE key = 'Hotkeys'")
                row = cur.fetchone()
                if row and row[0]:
                    raw_val = row[0]
            except Exception:
                cur.execute("SELECT value FROM key_values WHERE key = 'Hotkeys'")
                row = cur.fetchone()
                if row and row[0]:
                    raw_val = row[0]
            conn.close()

            if raw_val:
                if isinstance(raw_val, bytes):
                    raw_val = raw_val.decode("utf-8", errors="replace")
                parsed = json.loads(raw_val)
                if isinstance(parsed, list):
                    return parsed
        except Exception as e:
            logger.debug(f"Error reading Medal hotkeys from {path}: {e}")
    return []


def sync_hotkeys_to_medal(specific_sub: Optional[str] = None, custom_key: Optional[str] = None) -> Tuple[bool, str]:
    """
    Injects or updates multi-duration hotkeys into Medal's SQLite database.
    Preserves all existing user hotkeys in Medal while ensuring TouchDeck's
    clip durations (15s, 30s, 60s, 120s, 300s, segment_toggle, bookmark) are configured.
    """
    if sqlite3 is None:
        return False, "sqlite3 modul ikke tilgængeligt i denne proces."

    dbs = find_medal_databases()
    if not dbs:
        return False, "Ingen Medal database fundet. Kontroller at Medal er installeret."

    # Build target actions to apply
    target_entries = list(DEFAULT_MEDAL_HOTKEYS)
    if specific_sub:
        action_name = SUB_ACTION_TO_MEDAL_ACTION.get(specific_sub)
        if action_name and custom_key:
            fmt_key = format_medal_hotkey(custom_key)
            target_entries = [
                e if e["action"] != action_name else {**e, "inputs": fmt_key}
                for e in target_entries
            ]

    updated_count = 0

    for db_path in dbs:
        try:
            # Read existing hotkeys to preserve user's other configurations
            existing_hotkeys = read_medal_hotkeys(db_path)
            merged_dict: Dict[str, Dict[str, str]] = {}
            for item in existing_hotkeys:
                act = item.get("action")
                if act:
                    merged_dict[act] = item

            # Merge target TouchDeck actions
            for item in target_entries:
                act = item.get("action")
                if act:
                    merged_dict[act] = item

            final_list = list(merged_dict.values())
            hotkeys_json = json.dumps(final_list, ensure_ascii=False)

            conn = sqlite3.connect(db_path, timeout=5.0)
            cur = conn.cursor()
            cur.execute("PRAGMA busy_timeout = 5000;")
            try:
                cur.execute("PRAGMA journal_mode = WAL;")
            except Exception:
                pass
            cur.execute("CREATE TABLE IF NOT EXISTS key_values (key TEXT PRIMARY KEY, value BLOB);")

            # Try SQLite native jsonb function if available, fallback to raw text
            try:
                cur.execute("INSERT OR REPLACE INTO key_values VALUES ('Hotkeys', jsonb(?))", (hotkeys_json,))
            except Exception:
                cur.execute("INSERT OR REPLACE INTO key_values VALUES ('Hotkeys', ?)", (hotkeys_json,))

            conn.commit()
            conn.close()
            updated_count += 1
            logger.info(f"Successfully injected Medal hotkeys into: {db_path}")
        except Exception as e:
            logger.error(f"Error updating Medal database at {db_path}: {e}")

    if updated_count > 0:
        return True, f"Genveje synkroniseret med succes til Medal ({updated_count} profil). Genstart Medal hvis det allerede kører."
    return False, "Kunne ikke skrive til Medal databasen."


def auto_sync_medal_button(
    sub_action: Optional[str] = None,
    custom_hotkey: Optional[str] = None,
    callback: Optional[Callable[[bool, str], None]] = None
):
    """
    Triggers asynchronous background synchronization of Medal hotkeys so the
    TouchDeck UI remains fluid and responsive.
    """
    def _worker():
        ok, msg = sync_hotkeys_to_medal(sub_action, custom_hotkey)
        if callback:
            callback(ok, msg)

    t = threading.Thread(target=_worker, daemon=True, name="MedalAutoSyncThread")
    t.start()
