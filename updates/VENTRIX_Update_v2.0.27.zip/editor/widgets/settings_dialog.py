"""
TouchDeck / VENTRIX - Apple Settings Window & In-Window View
Strict Monochromatic Black, White & Real Translucent Glass.
Categories: General, Account, Devices & Pairing, USB Creator, Appearance, Shortcuts, Network, About.
Author: VENTRIX
"""

import os
from pathlib import Path
from typing import Optional, List

from PySide6.QtWidgets import (
    QWidget, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QSpinBox, QCheckBox, QPushButton, QFileDialog, QComboBox,
    QFrame, QListWidget, QListWidgetItem, QStackedWidget,
    QTableWidget, QTableWidgetItem, QHeaderView, QProgressBar
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QPixmap, QIcon, QColor

from shared.constants import (
    APP_NAME, APP_VERSION, APP_AUTHOR,
    COLOR_BG, COLOR_CARD, COLOR_BORDER, COLOR_PRIMARY_BLUE,
    COLOR_BRIGHT_BLUE, COLOR_SUCCESS, COLOR_ERROR, COLOR_TEXT_MUTED
)
from shared.config_store import ConfigStore
from editor.auth.google_auth import GoogleAuthManager
from editor.widgets.glass_widgets import GlassCard, GlassButton, GlassAvatar
from editor.widgets.apple_dialogs import AppleGlassConfirmDialog


CHECKBOX_STYLE = """
    QCheckBox {
        color: #FFFFFF !important;
        font-size: 13px;
        font-weight: 500;
        spacing: 10px;
        background: transparent;
    }
    QCheckBox:hover {
        color: #FFFFFF !important;
    }
    QCheckBox::indicator {
        width: 18px;
        height: 18px;
        border-radius: 5px;
        border: 1.5px solid rgba(255, 255, 255, 0.30);
        background: rgba(255, 255, 255, 0.05);
    }
    QCheckBox::indicator:hover {
        border-color: rgba(255, 255, 255, 0.60);
        background: rgba(255, 255, 255, 0.12);
    }
    QCheckBox::indicator:checked {
        background: #FFFFFF;
        border-color: #FFFFFF;
    }
"""


class SettingsView(QWidget):
    """
    Built-in visionOS / Apple macOS System Settings view.
    Lives directly inside the main application window - NO external popups or white OS titlebars.
    """
    back_to_studio_requested = Signal()
    replay_welcome_requested = Signal()

    def __init__(self, config_store: ConfigStore, server=None, parent=None):
        super().__init__(parent)
        self.config_store = config_store
        self.server = server
        self.auth_mgr = GoogleAuthManager.get_instance()

        self._init_ui()
        self._load_values()

        # Connect auth signals
        self.auth_mgr.auth_success.connect(self._on_auth_changed)
        self.auth_mgr.auth_logged_out.connect(self._on_auth_changed)
        self.auth_mgr.auth_failed.connect(self._on_auth_failed)

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(20, 16, 20, 20)
        root_lay.setSpacing(14)

        # ----------------------------------------------------
        # Top Apple Header Bar: [← Tilbage til Studio]   [VENTRIX Indstillinger]   [Gem & Luk]
        # ----------------------------------------------------
        top_bar = QFrame()
        top_bar.setObjectName("floatingTopBar")
        top_bar.setFixedHeight(50)
        top_lay = QHBoxLayout(top_bar)
        top_lay.setContentsMargins(16, 6, 16, 6)
        top_lay.setSpacing(12)

        self.back_btn = QPushButton("← Tilbage til Studio")
        self.back_btn.setCursor(Qt.PointingHandCursor)
        self.back_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.14);
                border-radius: 8px;
                padding: 6px 14px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.16);
                border-color: rgba(255, 255, 255, 0.28);
            }
        """)
        self.back_btn.clicked.connect(self.back_to_studio_requested.emit)
        top_lay.addWidget(self.back_btn)

        top_lay.addStretch()

        # Center Title with Logo
        center_box = QHBoxLayout()
        center_box.setSpacing(8)
        logo_path = Path(__file__).parent.parent.parent / "assets" / "ventrix.png"
        if logo_path.exists():
            logo_lbl = QLabel()
            pix = QPixmap(str(logo_path)).scaled(20, 20, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            logo_lbl.setPixmap(pix)
            center_box.addWidget(logo_lbl)

        title_lbl = QLabel(f"{APP_NAME} Indstillinger")
        title_lbl.setStyleSheet("color: #FFFFFF; font-size: 14px; font-weight: 600; letter-spacing: 0.5px;")
        center_box.addWidget(title_lbl)
        top_lay.addLayout(center_box)

        top_lay.addStretch()

        self.save_btn = QPushButton("Gem Indstillinger")
        self.save_btn.setObjectName("pushBtn")
        self.save_btn.setCursor(Qt.PointingHandCursor)
        self.save_btn.clicked.connect(self._save_and_return)
        top_lay.addWidget(self.save_btn)

        root_lay.addWidget(top_bar)

        # ----------------------------------------------------
        # Main Body: Sidebar (Left) + Content Stack (Right)
        # ----------------------------------------------------
        body_lay = QHBoxLayout()
        body_lay.setSpacing(14)

        # Left Category Sidebar
        sidebar = QFrame()
        sidebar.setObjectName("cardFrame")
        sidebar.setFixedWidth(200)
        side_lay = QVBoxLayout(sidebar)
        side_lay.setContentsMargins(10, 14, 10, 14)
        side_lay.setSpacing(6)

        side_title = QLabel("SYSTEMKATEGORIER")
        side_title.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 600; letter-spacing: 1px; margin-bottom: 6px; padding-left: 8px;")
        side_lay.addWidget(side_title)

        self.category_list = QListWidget()
        self.category_list.setStyleSheet("""
            QListWidget {
                background: transparent;
                border: none;
            }
            QListWidget::item {
                color: #8E8E93;
                padding: 9px 12px;
                border-radius: 8px;
                font-size: 12px;
                font-weight: 500;
            }
            QListWidget::item:hover {
                background: rgba(255, 255, 255, 0.07);
                color: #FFFFFF;
            }
            QListWidget::item:selected {
                background: rgba(255, 255, 255, 0.16);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.20);
                font-weight: 600;
            }
        """)

        from shared.i18n import t, set_language, get_current_language

        categories = [
            ("Generelt", 0),
            ("Google Konto", 1),
            ("Enheder & Parring", 2),
            ("USB Surface Creator", 3),
            ("Udseende & Glass", 4),
            ("Tastaturgenveje", 5),
            ("Netværk & Server", 6),
            ("Om VENTRIX", 7)
        ]
        for name, _ in categories:
            item = QListWidgetItem(name)
            self.category_list.addItem(item)

        self.category_list.currentRowChanged.connect(self._on_category_changed)
        side_lay.addWidget(self.category_list)
        body_lay.addWidget(sidebar)

        # Right Stacked Content Panels
        content_frame = QFrame()
        content_frame.setObjectName("cardFrame")
        content_lay = QVBoxLayout(content_frame)
        content_lay.setContentsMargins(24, 24, 24, 24)
        content_lay.setSpacing(16)

        self.stack = QStackedWidget()
        self.stack.addWidget(self._build_general_page())
        self.stack.addWidget(self._build_account_page())
        self.stack.addWidget(self._build_devices_page())
        self.stack.addWidget(self._build_usb_page())
        self.stack.addWidget(self._build_appearance_page())
        self.stack.addWidget(self._build_shortcuts_page())
        self.stack.addWidget(self._build_advanced_page())
        self.stack.addWidget(self._build_about_page())

        content_lay.addWidget(self.stack, stretch=1)
        body_lay.addWidget(content_frame, stretch=1)

        root_lay.addLayout(body_lay, stretch=1)
        self.category_list.setCurrentRow(0)

    def _on_category_changed(self, row: int):
        self.stack.setCurrentIndex(row)
        if row == 2:
            self._refresh_devices_table()
        elif row == 3:
            self._scan_usb_drives()

    # ----------------------------------------------------
    # Page Builders
    # ----------------------------------------------------
    def _build_general_page(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(16)

        t_lbl = QLabel("Generelle Indstillinger")
        t_lbl.setStyleSheet("font-size: 16px; font-weight: 600; color: #FFFFFF;")
        lay.addWidget(t_lbl)

        sub = QLabel("Konfigurer sprog, personalisering og opstart for VENTRIX.")
        sub.setStyleSheet("font-size: 12px; color: #8E8E93; margin-bottom: 4px;")
        lay.addWidget(sub)

        # Language Selector Row
        lang_row = QHBoxLayout()
        lang_lbl = QLabel("Sprog / Language:")
        lang_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 500;")
        lang_row.addWidget(lang_lbl)

        self.lang_combo = QComboBox()
        self.lang_combo.addItem("Dansk", "da")
        self.lang_combo.addItem("English", "en")
        self.lang_combo.setFixedWidth(160)
        lang_row.addWidget(self.lang_combo)
        lang_row.addStretch()
        lay.addLayout(lang_row)

        # User Name Personalization Row
        name_row = QHBoxLayout()
        name_lbl = QLabel("Dit Navn (Personalisering):")
        name_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 500;")
        name_row.addWidget(name_lbl)

        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("Indtast dit navn...")
        self.name_edit.setFixedWidth(220)
        self.name_edit.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.16);
                border-radius: 8px;
                color: #FFFFFF;
                padding: 6px 10px;
                font-size: 12px;
            }
        """)
        name_row.addWidget(self.name_edit)
        name_row.addStretch()
        lay.addLayout(name_row)

        # Checkboxes
        self.always_welcome_cb = QCheckBox("Vis altid startskærm ved opstart")
        self.always_welcome_cb.setStyleSheet(CHECKBOX_STYLE)
        lay.addWidget(self.always_welcome_cb)

        self.start_win_cb = QCheckBox(f"Start {APP_NAME} automatisk med Windows")
        self.start_win_cb.setStyleSheet(CHECKBOX_STYLE)
        lay.addWidget(self.start_win_cb)

        self.min_tray_cb = QCheckBox("Minimer til systembakke ved lukning af vinduet")
        self.min_tray_cb.setStyleSheet(CHECKBOX_STYLE)
        lay.addWidget(self.min_tray_cb)

        self.haptic_cb = QCheckBox("Aktiver haptisk flash-respons på Surface-klienter ved tryk")
        self.haptic_cb.setStyleSheet(CHECKBOX_STYLE)
        lay.addWidget(self.haptic_cb)

        self.app_status_cb = QCheckBox("Vis applikationsstatus på knapper (Aktiv / Lukket indikator)")
        self.app_status_cb.setStyleSheet(CHECKBOX_STYLE)
        lay.addWidget(self.app_status_cb)

        lay.addStretch()
        return w

    def _build_account_page(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(14)

        t = QLabel("Google Konto & Profil-Synkronisering")
        t.setStyleSheet("font-size: 16px; font-weight: 600; color: #FFFFFF;")
        lay.addWidget(t)

        # User Info Glass Card
        user_card = QFrame()
        user_card.setStyleSheet("background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 12px;")
        uc_lay = QHBoxLayout(user_card)
        uc_lay.setSpacing(14)

        self.account_avatar = GlassAvatar(size=44)
        uc_lay.addWidget(self.account_avatar)

        user_text_box = QVBoxLayout()
        user_text_box.setSpacing(2)
        self.user_name_lbl = QLabel("Ikke logget ind")
        self.user_name_lbl.setStyleSheet("font-size: 13px; font-weight: 600; color: #FFFFFF;")
        self.user_email_lbl = QLabel("Log ind med Google for at synkronisere dine profiler i skyen")
        self.user_email_lbl.setStyleSheet("font-size: 11px; color: #8E8E93;")
        user_text_box.addWidget(self.user_name_lbl)
        user_text_box.addWidget(self.user_email_lbl)
        uc_lay.addLayout(user_text_box, stretch=1)

        self.auth_action_btn = QPushButton("Continue with Google")
        self.auth_action_btn.clicked.connect(self._toggle_auth)
        uc_lay.addWidget(self.auth_action_btn)
        lay.addWidget(user_card)

        # Google Cloud Credentials configuration
        cred_title = QLabel("Google Cloud OAuth 2.0 Konfiguration:")
        cred_title.setStyleSheet("font-size: 11px; font-weight: 600; color: #8E8E93; margin-top: 10px;")
        lay.addWidget(cred_title)

        c_id_box = QVBoxLayout()
        c_id_box.setSpacing(4)
        cid_lbl = QLabel("Client ID:")
        cid_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px;")
        c_id_box.addWidget(cid_lbl)
        self.client_id_input = QLineEdit()
        self.client_id_input.setPlaceholderText("XXXX.apps.googleusercontent.com")
        c_id_box.addWidget(self.client_id_input)
        lay.addLayout(c_id_box)

        c_sec_box = QVBoxLayout()
        c_sec_box.setSpacing(4)
        csec_lbl = QLabel("Client Secret (valgfri til Desktop App):")
        csec_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px;")
        c_sec_box.addWidget(csec_lbl)
        self.client_secret_input = QLineEdit()
        self.client_secret_input.setEchoMode(QLineEdit.Password)
        self.client_secret_input.setPlaceholderText("GOCSPX-XXXX...")
        c_sec_box.addWidget(self.client_secret_input)
        lay.addLayout(c_sec_box)

        guide_lbl = QLabel("Redirect URI til Google Cloud Console: http://127.0.0.1:18890/callback")
        guide_lbl.setStyleSheet("font-size: 10px; color: #8E8E93;")
        lay.addWidget(guide_lbl)

        lay.addStretch()
        return w

    def _build_devices_page(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(14)

        t = QLabel("Enheder & Parring")
        t.setStyleSheet("font-size: 16px; font-weight: 600; color: #FFFFFF;")
        lay.addWidget(t)

        code_card = QFrame()
        code_card.setStyleSheet("background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255,255,255,0.12); border-radius: 12px; padding: 16px;")
        cc_lay = QHBoxLayout(code_card)
        cc_lay.setSpacing(16)

        pin_box = QVBoxLayout()
        pin_lbl_title = QLabel("AKTIV PARRINGSKODE (PIN):")
        pin_lbl_title.setStyleSheet("font-size: 10px; font-weight: 600; color: #8E8E93; letter-spacing: 1px;")
        pin_box.addWidget(pin_lbl_title)

        pairing_code = self.server.active_pairing_code if self.server else "123456"
        self.pairing_pin_lbl = QLabel(pairing_code)
        self.pairing_pin_lbl.setStyleSheet("font-size: 26px; font-weight: 700; color: #FFFFFF; letter-spacing: 4px;")
        pin_box.addWidget(self.pairing_pin_lbl)
        cc_lay.addLayout(pin_box, stretch=1)

        new_pin_btn = QPushButton("Generer Ny Kode")
        new_pin_btn.clicked.connect(self._regenerate_pin)
        cc_lay.addWidget(new_pin_btn)
        lay.addWidget(code_card)

        # Paired devices list
        dev_hdr = QHBoxLayout()
        dev_lbl = QLabel("PARREDE SURFACES")
        dev_lbl.setStyleSheet("font-size: 10px; font-weight: 600; color: #8E8E93; letter-spacing: 1px;")
        dev_hdr.addWidget(dev_lbl)
        dev_hdr.addStretch()

        ref_btn = QPushButton("↻ Opdater")
        ref_btn.clicked.connect(self._refresh_devices_table)
        dev_hdr.addWidget(ref_btn)
        lay.addLayout(dev_hdr)

        self.devices_table = QTableWidget(0, 4)
        self.devices_table.setHorizontalHeaderLabels(["Navn", "IP Adresse", "Status", "Handling"])
        self.devices_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.devices_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.devices_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.devices_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.devices_table.setStyleSheet("""
            QTableWidget {
                background: rgba(0, 0, 0, 0.25);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 8px;
                color: #FFFFFF;
                gridline-color: rgba(255, 255, 255, 0.05);
            }
            QHeaderView::section {
                background: rgba(255, 255, 255, 0.05);
                color: #8E8E93;
                font-size: 11px;
                font-weight: 600;
                padding: 6px;
                border: none;
            }
        """)
        lay.addWidget(self.devices_table, stretch=1)
        return w

    def _build_usb_page(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(14)

        t = QLabel("USB Surface Boot Creator")
        t.setStyleSheet("font-size: 16px; font-weight: 600; color: #FFFFFF;")
        lay.addWidget(t)

        desc = QLabel(
            "Opret et bootbart USB-drev til din Microsoft Surface eller tablet. "
            "Enheden booter direkte ind i VENTRIX Surface interfacet uden normalt Windows skrivebord."
        )
        desc.setWordWrap(True)
        desc.setStyleSheet("color: #8E8E93; font-size: 12px;")
        lay.addWidget(desc)

        # Drive scan section
        drives_row = QHBoxLayout()
        d_lbl = QLabel("FUNDNE USB-DREV")
        d_lbl.setStyleSheet("font-size: 10px; font-weight: 600; color: #8E8E93; letter-spacing: 1px;")
        drives_row.addWidget(d_lbl)
        drives_row.addStretch()

        scan_btn = QPushButton("↻ Scan USB Drev")
        scan_btn.clicked.connect(self._scan_usb_drives)
        drives_row.addWidget(scan_btn)
        lay.addLayout(drives_row)

        self.usb_table = QTableWidget(0, 4)
        self.usb_table.setHorizontalHeaderLabels(["Drev", "Navn / Label", "Størrelse", "Status"])
        self.usb_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.usb_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.usb_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.usb_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.usb_table.setStyleSheet("""
            QTableWidget {
                background: rgba(0, 0, 0, 0.25);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 8px;
                color: #FFFFFF;
                gridline-color: rgba(255, 255, 255, 0.05);
            }
            QHeaderView::section {
                background: rgba(255, 255, 255, 0.05);
                color: #8E8E93;
                font-size: 11px;
                font-weight: 600;
                padding: 6px;
                border: none;
            }
        """)
        lay.addWidget(self.usb_table, stretch=1)

        # Actions
        act_row = QHBoxLayout()
        act_row.addStretch()

        build_iso_btn = QPushButton("Byg VENTRIX.iso Fil...")
        build_iso_btn.clicked.connect(self._build_iso)
        act_row.addWidget(build_iso_btn)

        write_usb_btn = QPushButton("Opret Bootbart USB Drev")
        write_usb_btn.setObjectName("pushBtn")
        write_usb_btn.clicked.connect(self._write_usb)
        act_row.addWidget(write_usb_btn)

        lay.addLayout(act_row)
        return w

    def _build_appearance_page(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(14)

        t = QLabel("Udseende & Tema")
        t.setStyleSheet("font-size: 16px; font-weight: 600; color: #FFFFFF;")
        lay.addWidget(t)

        theme_card = QFrame()
        theme_card.setStyleSheet("background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 14px;")
        tc_lay = QVBoxLayout(theme_card)
        tc_lay.setSpacing(6)

        theme_lbl = QLabel("Designretning: Translucent Glass (Sort / Hvid)")
        theme_lbl.setStyleSheet("font-size: 13px; color: #FFFFFF; font-weight: 600;")
        tc_lay.addWidget(theme_lbl)

        p_desc = QLabel(
            f"{APP_NAME} anvender en ren sort/hvid farvepalet med ægte translucent glass, "
            "subtile rim highlights, bløde dybdelag og højkontrast white typography. "
            "Ingen distraherende neon- eller SaaS-farver."
        )
        p_desc.setWordWrap(True)
        p_desc.setStyleSheet("font-size: 11px; color: #8E8E93;")
        tc_lay.addWidget(p_desc)
        lay.addWidget(theme_card)

        lay.addStretch()
        return w

    def _build_shortcuts_page(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(12)

        t = QLabel("Tastaturgenveje")
        t.setStyleSheet("font-size: 16px; font-weight: 600; color: #FFFFFF;")
        lay.addWidget(t)

        for key, desc in [
            ("← (Venstre Pil)", "Skift til forrige side"),
            ("→ (Højre Pil)", "Skift til næste side"),
            ("Ctrl + N", "Opret en ny side"),
            ("Ctrl + S", "Gem og send øjeblikkeligt til Surface"),
            ("Esc", "Fravælg knap / gå tilbage til Studio")
        ]:
            row = QHBoxLayout()
            k_lbl = QLabel(key)
            k_lbl.setStyleSheet("background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); border-radius: 6px; padding: 4px 10px; font-weight: 600; color: #FFFFFF; font-size: 12px;")
            k_lbl.setFixedWidth(140)
            row.addWidget(k_lbl)

            d_lbl = QLabel(desc)
            d_lbl.setStyleSheet("color: #8E8E93; font-size: 12px;")
            row.addWidget(d_lbl, stretch=1)
            lay.addLayout(row)

        lay.addStretch()
        return w

    def _build_advanced_page(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(14)

        t = QLabel("Avancerede Netværksindstillinger")
        t.setStyleSheet("font-size: 16px; font-weight: 600; color: #FFFFFF;")
        lay.addWidget(t)

        p_row = QHBoxLayout()
        p_lbl = QLabel("WebSocket Port:")
        p_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px;")
        p_row.addWidget(p_lbl)
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1024, 65535)
        p_row.addWidget(self.port_spin)
        p_row.addStretch()
        lay.addLayout(p_row)

        d_row = QHBoxLayout()
        d_lbl = QLabel("UDP Discovery Port:")
        d_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px;")
        d_row.addWidget(d_lbl)
        self.disc_spin = QSpinBox()
        self.disc_spin.setRange(1024, 65535)
        d_row.addWidget(self.disc_spin)
        d_row.addStretch()
        lay.addLayout(d_row)

        self.auto_disc_cb = QCheckBox("Aktiver UDP LAN automatisk discovery-broadcaster")
        self.auto_disc_cb.setStyleSheet(CHECKBOX_STYLE)
        lay.addWidget(self.auto_disc_cb)

        open_cfg_btn = QPushButton("Åbn konfigurationsmappe i Stifinder")
        open_cfg_btn.clicked.connect(lambda: os.startfile(str(self.config_store.config_dir)))
        lay.addWidget(open_cfg_btn)

        lay.addStretch()
        return w

    def _build_about_page(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(16)
        lay.setAlignment(Qt.AlignCenter)

        # VENTRIX Hero Logo
        logo_path = Path(__file__).parent.parent.parent / "assets" / "ventrix.png"
        if logo_path.exists():
            hero_logo = QLabel()
            hero_logo.setAlignment(Qt.AlignCenter)
            pix = QPixmap(str(logo_path)).scaled(80, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            hero_logo.setPixmap(pix)
            lay.addWidget(hero_logo)

        t = QLabel(f"{APP_NAME} Studio v{APP_VERSION}")
        t.setStyleSheet("font-size: 20px; font-weight: 700; color: #FFFFFF; letter-spacing: 1px;")
        t.setAlignment(Qt.AlignCenter)
        lay.addWidget(t)

        author_lbl = QLabel("VENTRIX Studio • Glass Design System")
        author_lbl.setStyleSheet("color: #8E8E93; font-size: 12px;")
        author_lbl.setAlignment(Qt.AlignCenter)
        lay.addWidget(author_lbl)

        lay.addSpacing(10)

        replay_btn = QPushButton("Vis Velkomstskærm Igen")
        replay_btn.setCursor(Qt.PointingHandCursor)
        replay_btn.clicked.connect(self._replay_welcome)
        lay.addWidget(replay_btn, alignment=Qt.AlignCenter)

        lay.addStretch()
        return w

    # ----------------------------------------------------
    # State & Handlers
    # ----------------------------------------------------
    def _load_values(self):
        s = self.config_store.settings
        self.start_win_cb.setChecked(getattr(s, "start_with_windows", False))
        self.min_tray_cb.setChecked(getattr(s, "minimize_to_tray", True))
        self.haptic_cb.setChecked(getattr(s, "haptic_feedback", True))
        self.app_status_cb.setChecked(getattr(s, "show_app_status", True))
        self.always_welcome_cb.setChecked(getattr(s, "always_show_welcome", True))

        self.name_edit.setText(getattr(s, "user_name", "") or "")
        cur_lang = getattr(s, "language", "da") or "da"
        lang_idx = self.lang_combo.findData(cur_lang)
        if lang_idx >= 0:
            self.lang_combo.setCurrentIndex(lang_idx)

        self.port_spin.setValue(getattr(s, "ws_port", 18880) or 18880)
        self.disc_spin.setValue(getattr(s, "discovery_port", 18881) or 18881)
        self.auto_disc_cb.setChecked(getattr(s, "auto_discovery", True))

        # Credentials
        cid, csec = self.auth_mgr.get_credentials()
        self.client_id_input.setText(cid)
        self.client_secret_input.setText(csec)

        self._on_auth_changed()

    def _save_and_return(self):
        from shared.i18n import set_language
        s = self.config_store.settings
        s.start_with_windows = self.start_win_cb.isChecked()
        s.minimize_to_tray = self.min_tray_cb.isChecked()
        s.haptic_feedback = self.haptic_cb.isChecked()
        s.show_app_status = self.app_status_cb.isChecked()
        s.always_show_welcome = self.always_welcome_cb.isChecked()

        s.user_name = self.name_edit.text().strip()
        selected_lang = self.lang_combo.currentData() or "da"
        s.language = selected_lang
        set_language(selected_lang)

        s.ws_port = self.port_spin.value()
        s.discovery_port = self.disc_spin.value()
        s.auto_discovery = self.auto_disc_cb.isChecked()

        self.config_store.save_settings()

        self.auth_mgr.save_credentials(
            client_id=self.client_id_input.text().strip(),
            client_secret=self.client_secret_input.text().strip()
        )

        self.back_to_studio_requested.emit()

    def _regenerate_pin(self):
        if self.server:
            new_code = self.server.generate_new_pairing_code()
            self.pairing_pin_lbl.setText(new_code)

    def _refresh_devices_table(self):
        self.devices_table.setRowCount(0)
        devices = getattr(self.config_store, "devices", [])
        active_ids = [info.get("device_id") for info in self.server.active_connections.values()] if self.server else []

        for dev in devices:
            r = self.devices_table.rowCount()
            self.devices_table.insertRow(r)

            self.devices_table.setItem(r, 0, QTableWidgetItem(getattr(dev, "name", "Surface Device")))
            self.devices_table.setItem(r, 1, QTableWidgetItem(getattr(dev, "last_ip", "Ukendt") or "Ukendt"))

            dev_id = getattr(dev, "device_id", "")
            is_online = dev_id in active_ids
            status_item = QTableWidgetItem("● Online" if is_online else "○ Offline")
            status_item.setForeground(QColor("#22C55E" if is_online else "#8E8E93"))
            self.devices_table.setItem(r, 2, status_item)

            unpair_btn = QPushButton("Fjern Parring")
            unpair_btn.setStyleSheet("""
                QPushButton {
                    background: rgba(239, 68, 68, 0.12);
                    color: #EF4444;
                    border: 1px solid rgba(239, 68, 68, 0.25);
                    border-radius: 6px;
                    padding: 3px 8px;
                    font-size: 11px;
                }
                QPushButton:hover {
                    background: rgba(239, 68, 68, 0.22);
                }
            """)
            unpair_btn.clicked.connect(lambda checked=False, d_id=dev_id: self._unpair_device(d_id))
            self.devices_table.setCellWidget(r, 3, unpair_btn)

    def _unpair_device(self, dev_id: str):
        if AppleGlassConfirmDialog.ask(self, "Fjern Parring", "Er du sikker på, at du vil fjerne parringen med denne enhed?"):
            if hasattr(self.config_store, "devices"):
                self.config_store.devices = [d for d in self.config_store.devices if getattr(d, "device_id", "") != dev_id]
                self.config_store.save_devices()
            self._refresh_devices_table()

    def _scan_usb_drives(self):
        self.usb_table.setRowCount(0)
        from deployment.usb_creator import UsbDeploymentManager
        mgr = UsbDeploymentManager()
        drives = mgr.detect_usb_drives()
        for d in drives:
            r = self.usb_table.rowCount()
            self.usb_table.insertRow(r)
            self.usb_table.setItem(r, 0, QTableWidgetItem(d.drive_letter))
            self.usb_table.setItem(r, 1, QTableWidgetItem(d.volume_label or "(Unavngivet)"))
            self.usb_table.setItem(r, 2, QTableWidgetItem(f"{d.size_gb:.1f} GB"))
            self.usb_table.setItem(r, 3, QTableWidgetItem("Klar"))

    def _build_iso(self):
        from editor.widgets.apple_dialogs import AppleGlassConfirmDialog
        AppleGlassConfirmDialog.ask(self, "VENTRIX.iso", "VENTRIX.iso bygges til deployment/output mappen.")

    def _write_usb(self):
        from editor.widgets.apple_dialogs import AppleGlassConfirmDialog
        AppleGlassConfirmDialog.ask(self, "USB Skrivning", "Vælg et drev fra listen for at skrive boot-miljøet.")

    def _toggle_auth(self):
        if self.auth_mgr.is_logged_in():
            self.auth_mgr.sign_out()
        else:
            cid = self.client_id_input.text().strip()
            csec = self.client_secret_input.text().strip()
            if cid:
                self.auth_mgr.save_credentials(client_id=cid, client_secret=csec)
            self.auth_action_btn.setEnabled(False)
            self.auth_action_btn.setText("Connecting...")
            self.auth_mgr.start_desktop_oauth_flow()

    def _on_auth_changed(self):
        self.auth_action_btn.setEnabled(True)
        if self.auth_mgr.is_logged_in():
            user = self.auth_mgr.get_user()
            name = user.get("name", "Google Bruger")
            email = user.get("email", "")
            self.user_name_lbl.setText(name)
            self.user_email_lbl.setText(email)
            self.auth_action_btn.setText("Sign Out")
            self.auth_action_btn.setObjectName("dangerBtn")

            avatar_path = self.auth_mgr.get_avatar_path()
            if avatar_path and avatar_path.exists():
                self.account_avatar.set_image(str(avatar_path))
            else:
                self.account_avatar.set_initials(name)
        else:
            self.user_name_lbl.setText("Ikke logget ind")
            self.user_email_lbl.setText("Log ind med Google for at synkronisere dine profiler i skyen")
            self.auth_action_btn.setText("Continue with Google")
            self.auth_action_btn.setObjectName("")
            self.account_avatar.set_image(None)

    def _on_auth_failed(self, error_msg: str):
        self.auth_action_btn.setEnabled(True)
        self.auth_action_btn.setText("Continue with Google")
        from editor.widgets.apple_dialogs import AppleGlassConfirmDialog
        AppleGlassConfirmDialog.ask(self, "Google Sign-In", f"Kunne ikke gennemføre Google Sign-In:\n{error_msg}")

    def _replay_welcome(self):
        self.replay_welcome_requested.emit()


class SettingsDialog(QDialog):
    """Backwards-compatibility wrapper that renders SettingsView inside a frameless glass sheet."""
    replay_welcome_requested = Signal()

    def __init__(self, config_store: ConfigStore, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.resize(780, 560)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.view = SettingsView(config_store, parent=self)
        self.view.back_to_studio_requested.connect(self.accept)
        self.view.replay_welcome_requested.connect(self.replay_welcome_requested.emit)
        lay.addWidget(self.view)
