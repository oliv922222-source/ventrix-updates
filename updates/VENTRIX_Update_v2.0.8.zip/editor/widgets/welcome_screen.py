"""
VENTRIX - Welcome Screen
Minimal Apple-inspired dark composition.
Content floats centered on near-black — no card wrapper.
Author: VENTRIX
"""

from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QFrame, QGraphicsOpacityEffect, QStackedWidget,
)
from PySide6.QtGui import (
    QFont, QPixmap, QPainter, QColor, QPen, QPainterPath,
    QLinearGradient
)
from PySide6.QtCore import Qt, Signal, QPropertyAnimation, QEasingCurve, QRectF, QPointF, Property

from shared.i18n import t, set_language, I18nManager
from shared.license_manager import verify_license_key, save_license, is_licensed, get_license_info


# ─────────────────────────────────────────────────────────────────────────────
# Language Segmented Control
# ─────────────────────────────────────────────────────────────────────────────

class LanguageSegmentedButton(QWidget):
    """
    Slim Apple glass segmented pill: Dansk | English.
    100% custom-painted QPainter control with smooth sliding glass thumb.
    Eliminates all QSS margin, padding, border-radius and clipping issues.
    """
    language_changed = Signal(str)

    def __init__(self, current_lang: str = "da", parent=None):
        super().__init__(parent)
        self.current_lang = "en" if current_lang.lower().startswith("en") else "da"
        self.setFixedSize(176, 32)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)
        self.setStyleSheet("background: transparent; border: none;")

        self._hover_half = 0  # 0=none, 1=da, 2=en
        self._target_x = 3.0 if self.current_lang == "da" else 88.0
        self._thumb_x = self._target_x
        self._anim = None

    def get_thumb_x(self) -> float:
        return self._thumb_x

    def set_thumb_x(self, val: float):
        self._thumb_x = val
        self.update()

    thumb_x = Property(float, get_thumb_x, set_thumb_x)

    def _select_language(self, lang: str, animate: bool = True):
        target = 3.0 if lang == "da" else 88.0
        if self.current_lang != lang:
            self.current_lang = lang
            if animate:
                if self._anim:
                    self._anim.stop()
                self._anim = QPropertyAnimation(self, b"thumb_x")
                self._anim.setDuration(160)
                self._anim.setStartValue(self._thumb_x)
                self._anim.setEndValue(target)
                self._anim.setEasingCurve(QEasingCurve.OutCubic)
                self._anim.start()
            else:
                self._thumb_x = target
                self.update()
            self.language_changed.emit(lang)
        else:
            self._thumb_x = target
            self.update()

    def set_language(self, lang: str):
        self._select_language(lang, animate=False)

    def mouseMoveEvent(self, e):
        prev = self._hover_half
        if e.pos().x() < self.width() / 2:
            self._hover_half = 1
        else:
            self._hover_half = 2
        if prev != self._hover_half:
            self.update()
        super().mouseMoveEvent(e)

    def leaveEvent(self, e):
        self._hover_half = 0
        self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            if e.pos().x() < self.width() / 2:
                self._select_language("da")
            else:
                self._select_language("en")
        super().mousePressEvent(e)

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)

        w = float(self.width())
        h = float(self.height())

        # 1. Outer capsule
        outer_rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        outer_path = QPainterPath()
        outer_path.addRoundedRect(outer_rect, (h - 1.0) / 2.0, (h - 1.0) / 2.0)

        p.fillPath(outer_path, QColor(255, 255, 255, 12))
        p.strokePath(outer_path, QPen(QColor(255, 255, 255, 26), 1.0))

        # 2. Sliding thumb (active segment)
        thumb_w = 85.0
        thumb_h = h - 6.0   # 26.0
        thumb_r = thumb_h / 2.0  # 13.0

        thumb_rect = QRectF(self._thumb_x, 3.0, thumb_w, thumb_h)
        thumb_path = QPainterPath()
        thumb_path.addRoundedRect(thumb_rect, thumb_r, thumb_r)

        # Subtle glass gradient for thumb
        grad = QLinearGradient(0, 3, 0, 3 + thumb_h)
        grad.setColorAt(0.0, QColor(255, 255, 255, 48))
        grad.setColorAt(1.0, QColor(255, 255, 255, 28))
        p.fillPath(thumb_path, grad)
        p.strokePath(thumb_path, QPen(QColor(255, 255, 255, 65), 1.0))

        # 3. Text labels
        font_active = QFont("-apple-system", 10)
        font_active.setStyleHint(QFont.SansSerif)
        font_active.setWeight(QFont.DemiBold)

        font_inactive = QFont("-apple-system", 10)
        font_inactive.setStyleHint(QFont.SansSerif)
        font_inactive.setWeight(QFont.Medium)

        # Left label: Dansk
        da_rect = QRectF(3.0, 3.0, thumb_w, thumb_h)
        if self.current_lang == "da":
            p.setFont(font_active)
            p.setPen(QColor(255, 255, 255, 255))
        else:
            p.setFont(font_inactive)
            if self._hover_half == 1:
                p.setPen(QColor(255, 255, 255, 210))
            else:
                p.setPen(QColor(255, 255, 255, 120))
        p.drawText(da_rect, Qt.AlignCenter, "Dansk")

        # Right label: English
        en_rect = QRectF(3.0 + thumb_w, 3.0, thumb_w, thumb_h)
        if self.current_lang == "en":
            p.setFont(font_active)
            p.setPen(QColor(255, 255, 255, 255))
        else:
            p.setFont(font_inactive)
            if self._hover_half == 2:
                p.setPen(QColor(255, 255, 255, 210))
            else:
                p.setPen(QColor(255, 255, 255, 120))
        p.drawText(en_rect, Qt.AlignCenter, "English")


# ─────────────────────────────────────────────────────────────────────────────
# Open Studio Button  (custom-painted glass pill)
# ─────────────────────────────────────────────────────────────────────────────

class OpenStudioButton(QPushButton):
    """Solid white Apple pill — painted, not QSS."""

    def __init__(self, text: str = "", parent=None):
        super().__init__(text, parent)
        self.setFixedHeight(46)
        self.setFixedWidth(224)
        self.setCursor(Qt.PointingHandCursor)
        self._hovered = False
        self._pressed = False
        # suppress QSS from parent stylesheet
        self.setStyleSheet("QPushButton { border: none; background: transparent; }")

    def enterEvent(self, e):
        self._hovered = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hovered = False
        self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._pressed = True
            self.update()
        super().mousePressEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._pressed = False
            self.update()
        super().mouseReleaseEvent(e)

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        radius = r.height() / 2.0

        path = QPainterPath()
        path.addRoundedRect(r, radius, radius)

        if self._pressed:
            fill = QColor(208, 208, 212)
        elif self._hovered:
            fill = QColor(234, 234, 238)
        else:
            fill = QColor(255, 255, 255)

        p.fillPath(path, fill)

        # Subtle top sheen
        if not self._pressed:
            sheen = QLinearGradient(0, r.top(), 0, r.top() + r.height() * 0.45)
            sheen.setColorAt(0.0, QColor(255, 255, 255, 28))
            sheen.setColorAt(1.0, QColor(255, 255, 255, 0))
            p.fillPath(path, sheen)

        # Hairline border
        bc = QColor(195, 195, 200) if self._pressed else QColor(215, 215, 220)
        p.strokePath(path, QPen(bc, 0.8))

        # Label
        p.setPen(QColor(0, 0, 0))
        f = QFont()
        f.setFamily("Segoe UI Variable Text")
        f.setPixelSize(14)
        f.setWeight(QFont.DemiBold)
        p.setFont(f)
        p.drawText(r.toRect(), Qt.AlignCenter, self.text())


# ─────────────────────────────────────────────────────────────────────────────
# Apple Toggle Switch  (custom-painted)
# ─────────────────────────────────────────────────────────────────────────────

class AppleToggle(QWidget):
    """Painted Apple-style toggle switch replacing QCheckBox."""
    toggled = Signal(bool)

    def __init__(self, checked: bool = False, parent=None):
        super().__init__(parent)
        self._checked = checked
        self._hovered = False
        self.setFixedSize(38, 22)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("background: transparent;")

    def isChecked(self) -> bool:
        return self._checked

    def setChecked(self, value: bool):
        self._checked = value
        self.update()

    def enterEvent(self, e):
        self._hovered = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hovered = False
        self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._checked = not self._checked
            self.toggled.emit(self._checked)
            self.update()
        super().mousePressEvent(e)

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        # Track
        track = QRectF(0, 1, 38, 20)
        track_path = QPainterPath()
        track_path.addRoundedRect(track, 10.0, 10.0)

        if self._checked:
            track_fill = QColor(255, 255, 255, 210)
        elif self._hovered:
            track_fill = QColor(255, 255, 255, 38)
        else:
            track_fill = QColor(255, 255, 255, 26)

        p.fillPath(track_path, track_fill)

        if not self._checked:
            p.strokePath(track_path, QPen(QColor(255, 255, 255, 50), 1.0))

        # Knob
        knob_d = 16.0
        knob_x = (38.0 - 2.0 - knob_d) if self._checked else 2.0
        knob_y = 1.0 + (20.0 - knob_d) / 2.0

        knob_path = QPainterPath()
        knob_path.addEllipse(QRectF(knob_x, knob_y, knob_d, knob_d))

        if self._checked:
            p.fillPath(knob_path, QColor(10, 10, 12))
        else:
            p.fillPath(knob_path, QColor(255, 255, 255, 190))
            p.strokePath(knob_path, QPen(QColor(255, 255, 255, 60), 0.6))


# ─────────────────────────────────────────────────────────────────────────────
# Welcome Screen
# ─────────────────────────────────────────────────────────────────────────────

class WelcomeScreen(QFrame):
    """
    Minimal Apple-inspired welcome composition.
    Floats content on near-black background — no surrounding card.
    All signals and functionality unchanged.
    """
    continue_clicked = Signal(str, str, bool)  # (user_name, language, always_show)

    def __init__(self, user_name: str = "", language: str = "da",
                 always_show: bool = True, parent=None):
        super().__init__(parent)
        self.user_name = user_name
        self.current_lang = language or "da"
        self.always_show = always_show
        self.is_editing_name = False

        self._init_ui()
        I18nManager.get_instance().language_changed.connect(self._on_language_changed)

    # ── paint solid background ────────────────────────────────────────────────
    def paintEvent(self, event):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(10, 10, 12))

    # ── UI construction ───────────────────────────────────────────────────────
    def _init_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setAlignment(Qt.AlignCenter)

        # Fixed-width center column — transparent
        center = QWidget()
        center.setFixedWidth(420)
        center.setAttribute(Qt.WA_TransparentForMouseEvents, False)
        center.setStyleSheet("background: transparent; border: none;")

        col = QVBoxLayout(center)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(0)
        col.setAlignment(Qt.AlignCenter)

        # ── 1. Language selector ──────────────────────────────────────────────
        self.lang_toggle = LanguageSegmentedButton(current_lang=self.current_lang)
        self.lang_toggle.language_changed.connect(self._on_lang_toggled)
        col.addWidget(self.lang_toggle, alignment=Qt.AlignCenter)

        col.addSpacing(34)

        # ── 2. Logo ───────────────────────────────────────────────────────────
        self.logo_lbl = QLabel()
        self.logo_lbl.setAlignment(Qt.AlignCenter)
        self.logo_lbl.setFixedSize(110, 110)
        self.logo_lbl.setStyleSheet("background: transparent; border: none;")

        logo_path = Path(__file__).parent.parent.parent / "assets" / "ventrix.png"
        if logo_path.exists():
            pix = QPixmap(str(logo_path)).scaled(
                110, 110, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.logo_lbl.setPixmap(pix)
        col.addWidget(self.logo_lbl, alignment=Qt.AlignCenter)

        col.addSpacing(12)

        # ── 3. Wordmark ───────────────────────────────────────────────────────
        self.brand_lbl = QLabel("VENTRIX")
        self.brand_lbl.setAlignment(Qt.AlignCenter)
        self.brand_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color: rgba(255,255,255,0.50); font-size:10px; "
            "font-weight:700; letter-spacing:4px;"
        )
        col.addWidget(self.brand_lbl, alignment=Qt.AlignCenter)

        col.addSpacing(30)

        # ── 4. Headline ───────────────────────────────────────────────────────
        self.title_lbl = QLabel()
        self.title_lbl.setAlignment(Qt.AlignCenter)
        self.title_lbl.setWordWrap(True)
        self.title_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color:#FFFFFF; font-size:27px; font-weight:600; letter-spacing:-0.5px;"
        )
        col.addWidget(self.title_lbl)

        col.addSpacing(8)

        # ── 5. Tagline ────────────────────────────────────────────────────────
        self.tagline_lbl = QLabel()
        self.tagline_lbl.setAlignment(Qt.AlignCenter)
        self.tagline_lbl.setWordWrap(True)
        self.tagline_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color: rgba(255,255,255,0.40); font-size:13px; font-weight:400;"
        )
        col.addWidget(self.tagline_lbl)

        col.addSpacing(18)

        # ── 6. Account & License section ──────────────────────────────────────
        self.name_stack = QStackedWidget()
        self.name_stack.setStyleSheet("background:transparent; border:none;")

        # Page 0: Name input (first-time / edit mode)
        name_input_widget = QWidget()
        name_input_widget.setStyleSheet("background:transparent; border:none;")
        name_in_lay = QVBoxLayout(name_input_widget)
        name_in_lay.setContentsMargins(0, 0, 0, 0)
        name_in_lay.setSpacing(4)
        name_in_lay.setAlignment(Qt.AlignCenter)

        self.name_prompt_lbl = QLabel()
        self.name_prompt_lbl.setAlignment(Qt.AlignCenter)
        self.name_prompt_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color:rgba(255,255,255,0.50); font-size:11px; font-weight:400;"
        )
        name_in_lay.addWidget(self.name_prompt_lbl)

        self.name_input = QLineEdit()
        self.name_input.setText(self.user_name)
        self.name_input.setFixedSize(260, 32)
        self.name_input.setAlignment(Qt.AlignCenter)
        self.name_input.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.07);
                border: 1px solid rgba(255, 255, 255, 0.14);
                border-radius: 16px;
                color: #FFFFFF;
                padding: 0 16px;
                font-size: 13px;
                font-weight: 500;
            }
            QLineEdit:focus {
                background: rgba(255, 255, 255, 0.11);
                border-color: rgba(255, 255, 255, 0.32);
            }
        """)
        self.name_input.returnPressed.connect(self._on_continue_clicked)
        name_in_lay.addWidget(self.name_input, alignment=Qt.AlignCenter)
        self.name_stack.addWidget(name_input_widget)

        # Page 1: Greeting + "Skift navn" text link
        name_greet_widget = QWidget()
        name_greet_widget.setStyleSheet("background:transparent; border:none;")
        greet_lay = QHBoxLayout(name_greet_widget)
        greet_lay.setContentsMargins(0, 4, 0, 4)
        greet_lay.setSpacing(6)
        greet_lay.setAlignment(Qt.AlignCenter)

        self.logged_in_lbl = QLabel()
        self.logged_in_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color:rgba(255,255,255,0.62); font-size:13px; font-weight:400;"
        )
        greet_lay.addWidget(self.logged_in_lbl)

        _dot = QLabel("·")
        _dot.setStyleSheet(
            "background:transparent; border:none; "
            "color:rgba(255,255,255,0.22); font-size:13px;"
        )
        greet_lay.addWidget(_dot)

        self.edit_name_btn = QPushButton()
        self.edit_name_btn.setCursor(Qt.PointingHandCursor)
        self.edit_name_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                color: rgba(255, 255, 255, 0.35);
                font-size: 12px;
                font-weight: 400;
                padding: 0;
                text-decoration: underline;
            }
            QPushButton:hover { color: rgba(255, 255, 255, 0.70); }
        """)
        self.edit_name_btn.clicked.connect(self._enable_name_edit)
        greet_lay.addWidget(self.edit_name_btn)
        self.name_stack.addWidget(name_greet_widget)

        col.addWidget(self.name_stack, alignment=Qt.AlignCenter)

        col.addSpacing(10)

        # ── License Section Stack ─────────────────────────────────────────────
        self.license_stack = QStackedWidget()
        self.license_stack.setStyleSheet("background:transparent; border:none;")

        # Page 0: Unlicensed -> input box + status
        lic_input_widget = QWidget()
        lic_input_widget.setStyleSheet("background:transparent; border:none;")
        lic_in_lay = QVBoxLayout(lic_input_widget)
        lic_in_lay.setContentsMargins(0, 0, 0, 0)
        lic_in_lay.setSpacing(4)
        lic_in_lay.setAlignment(Qt.AlignCenter)

        self.license_prompt_lbl = QLabel()
        self.license_prompt_lbl.setAlignment(Qt.AlignCenter)
        self.license_prompt_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color:rgba(255,255,255,0.50); font-size:11px; font-weight:400;"
        )
        lic_in_lay.addWidget(self.license_prompt_lbl)

        self.license_input = QLineEdit()
        self.license_input.setFixedSize(260, 32)
        self.license_input.setAlignment(Qt.AlignCenter)
        self._reset_license_input_style()
        self.license_input.textChanged.connect(self._on_license_text_changed)
        self.license_input.returnPressed.connect(self._on_continue_clicked)
        lic_in_lay.addWidget(self.license_input, alignment=Qt.AlignCenter)

        self.license_status_lbl = QLabel("")
        self.license_status_lbl.setAlignment(Qt.AlignCenter)
        self.license_status_lbl.setStyleSheet("background:transparent; border:none; font-size:11px; font-weight:500;")
        lic_in_lay.addWidget(self.license_status_lbl)
        self.license_stack.addWidget(lic_input_widget)

        # Page 1: Licensed -> Green active pill
        lic_active_widget = QWidget()
        lic_active_widget.setStyleSheet("background:transparent; border:none;")
        lic_act_lay = QVBoxLayout(lic_active_widget)
        lic_act_lay.setContentsMargins(0, 2, 0, 2)
        lic_act_lay.setAlignment(Qt.AlignCenter)

        self.licensed_pill_lbl = QLabel()
        self.licensed_pill_lbl.setAlignment(Qt.AlignCenter)
        self.licensed_pill_lbl.setStyleSheet("background:transparent; border:none;")
        lic_act_lay.addWidget(self.licensed_pill_lbl)
        self.license_stack.addWidget(lic_active_widget)

        col.addWidget(self.license_stack, alignment=Qt.AlignCenter)

        col.addSpacing(18)

        # ── 7. Open Studio button ─────────────────────────────────────────────
        self.continue_btn = OpenStudioButton()
        self.continue_btn.clicked.connect(self._on_continue_clicked)
        col.addWidget(self.continue_btn, alignment=Qt.AlignCenter)

        col.addSpacing(16)

        # ── 8. Always show toggle row ─────────────────────────────────────────
        toggle_row = QHBoxLayout()
        toggle_row.setSpacing(10)
        toggle_row.setAlignment(Qt.AlignCenter)

        self.always_show_toggle = AppleToggle(checked=self.always_show)
        self.always_show_toggle.toggled.connect(self._on_toggle_changed)
        toggle_row.addWidget(self.always_show_toggle)

        self.always_show_lbl = QLabel()
        self.always_show_lbl.setStyleSheet(
            "background:transparent; border:none; "
            "color:rgba(255,255,255,0.40); font-size:12px; font-weight:400;"
        )
        toggle_row.addWidget(self.always_show_lbl)

        col.addLayout(toggle_row)

        outer.addWidget(center, alignment=Qt.AlignCenter)

        self._refresh_texts()

    def showEvent(self, event):
        super().showEvent(event)
        # Fade-in animation
        self.setGraphicsEffect(None)  # reset
        effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(effect)

        anim = QPropertyAnimation(effect, b"opacity")
        anim.setDuration(380)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.start()
        self._fade_anim = anim

    # ── Public API ────────────────────────────────────────────────────────────

    def set_user_data(self, user_name: str, language: str = "da", always_show: bool = True):
        self.user_name = user_name.strip()
        self.current_lang = language or "da"
        self.always_show = always_show
        self.name_input.setText(self.user_name)
        self.always_show_toggle.setChecked(self.always_show)
        self.lang_toggle._select_language(self.current_lang)
        self._refresh_texts()

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _reset_license_input_style(self):
        self.license_input.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.07);
                border: 1px solid rgba(255, 255, 255, 0.14);
                border-radius: 16px;
                color: #FFFFFF;
                font-family: 'Consolas', 'Courier New', monospace;
                padding: 0 14px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: 1px;
            }
            QLineEdit:focus {
                background: rgba(255, 255, 255, 0.11);
                border-color: rgba(255, 255, 255, 0.35);
            }
        """)

    def _highlight_license_error(self):
        self.license_input.setStyleSheet("""
            QLineEdit {
                background: rgba(239, 68, 68, 0.12);
                border: 1px solid rgba(239, 68, 68, 0.65);
                border-radius: 16px;
                color: #FFFFFF;
                font-family: 'Consolas', 'Courier New', monospace;
                padding: 0 14px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: 1px;
            }
            QLineEdit:focus {
                background: rgba(239, 68, 68, 0.18);
                border-color: #EF4444;
            }
        """)
        self.license_input.setFocus()

    def _on_license_text_changed(self, text: str):
        clean = text.upper().replace(" ", "")
        if clean != text:
            self.license_input.blockSignals(True)
            self.license_input.setText(clean)
            self.license_input.blockSignals(False)
        self.license_status_lbl.setText("")
        self._reset_license_input_style()

    def _refresh_texts(self):
        has_name = bool(self.user_name and self.user_name.strip())

        # 1. Name stack logic
        if has_name and not self.is_editing_name:
            self.title_lbl.setText(t("welcome_title_return", name=self.user_name))
            self.tagline_lbl.setText(t("welcome_tagline_return"))
            self.logged_in_lbl.setText(f"{t('welcome_logged_in_as')} {self.user_name}")
            self.edit_name_btn.setText(t("welcome_change_name"))
            self.name_stack.setCurrentIndex(1)
            self.name_stack.setFixedHeight(30)
        else:
            self.title_lbl.setText(t("welcome_title_first"))
            self.tagline_lbl.setText(t("welcome_tagline_first"))
            self.name_prompt_lbl.setText(t("welcome_name_label"))
            self.name_input.setPlaceholderText(t("welcome_name_placeholder"))
            self.name_stack.setCurrentIndex(0)
            self.name_stack.setFixedHeight(54)

        # 2. License stack logic
        self.license_prompt_lbl.setText(t("welcome_license_label"))
        self.license_input.setPlaceholderText(t("welcome_license_placeholder"))

        if is_licensed():
            self.licensed_pill_lbl.setText(t("welcome_license_active"))
            self.licensed_pill_lbl.setStyleSheet("color: #22C55E; font-size: 12px; font-weight: 500;")
            self.license_stack.setCurrentIndex(1)
            self.license_stack.setFixedHeight(26)
        else:
            self.license_stack.setCurrentIndex(0)
            self.license_stack.setFixedHeight(72)

        self.continue_btn.setText(t("welcome_open_studio"))
        self.always_show_lbl.setText(t("welcome_always_show"))

    def _enable_name_edit(self):
        self.is_editing_name = True
        self.name_stack.setCurrentIndex(0)
        self.name_input.selectAll()
        self.name_input.setFocus()
        if is_licensed():
            self.license_status_lbl.setText(t("welcome_license_active"))
            self.license_status_lbl.setStyleSheet("color: #22C55E; font-size: 11px; font-weight: 500;")

    def _on_lang_toggled(self, lang: str):
        set_language(lang)
        self.current_lang = lang

    def _on_language_changed(self, lang: str):
        self.current_lang = lang
        self._refresh_texts()

    def _on_toggle_changed(self, checked: bool):
        self.always_show = checked

    def _on_continue_clicked(self):
        entered = self.name_input.text().strip()
        if entered:
            self.user_name = entered

        # License validation: Must be licensed or provide valid key
        if not is_licensed():
            key = self.license_input.text().strip().upper().replace(" ", "")
            if not key:
                self.license_status_lbl.setText(t("welcome_license_required"))
                self.license_status_lbl.setStyleSheet("color: #EF4444; font-size: 11px; font-weight: 500;")
                self._highlight_license_error()
                return

            if not verify_license_key(key):
                self.license_status_lbl.setText(t("welcome_license_invalid"))
                self.license_status_lbl.setStyleSheet("color: #EF4444; font-size: 11px; font-weight: 500;")
                self._highlight_license_error()
                return

            # Save valid license
            save_license(key)
            self.license_status_lbl.setText(t("welcome_license_active"))
            self.license_status_lbl.setStyleSheet("color: #22C55E; font-size: 11px; font-weight: 600;")

        self.always_show = self.always_show_toggle.isChecked()
        self.continue_clicked.emit(self.user_name, self.current_lang, self.always_show)
