"""
TouchDeck - Stream Deck Editor v2.0.0
Apple-Grade Desktop Interface: Pure Black, White, Real Translucent Glass.
Author: VENTRIX
"""

import os
from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QSplitter, QFrame,
    QSystemTrayIcon, QMenu, QApplication, QStackedWidget
)
from PySide6.QtGui import QIcon, QPixmap, QCloseEvent, QKeySequence, QShortcut
from PySide6.QtCore import Qt, QSize, Signal, QTimer, QPoint

from shared.models import ProfileModel, PageModel, ButtonModel, DeviceModel
from shared.config_store import ConfigStore
from shared.constants import (
    APP_NAME, APP_VERSION, APP_AUTHOR, COLOR_BG, COLOR_TEXT_MAIN
)
from editor.ui.styles import DARK_THEME_QSS
from editor.actions.action_engine import ActionEngine
from editor.networking.server import TouchDeckServer
from editor.utils.process_monitor import ProcessMonitor
from editor.auth.google_auth import GoogleAuthManager
from editor.widgets.glass_widgets import (
    GlassCard, GlassButton, GlassStatusPill, GlassAvatar, GlassToast, AppleSettingsButton
)
from editor.widgets.apple_dialogs import (
    AppleGlassInputDialog, AppleGlassConfirmDialog
)
from editor.widgets.page_switcher_bar import PageSwitcherBar
from editor.widgets.page_dock import PageDock
from editor.widgets.live_surface_preview import LiveSurfacePreview
from editor.widgets.button_inspector import ButtonInspector
from editor.widgets.device_manager_dialog import DeviceManagerDialog
from editor.widgets.connect_device_dialog import ConnectDeviceDialog
from editor.widgets.usb_deployment_dialog import UsbDeploymentDialog
from editor.widgets.settings_dialog import SettingsDialog, SettingsView
from editor.widgets.welcome_screen import WelcomeScreen
from editor.widgets.license_dialog import LicenseActivationDialog
from shared.license_manager import is_licensed, get_license_info
from shared.i18n import t, set_language, get_current_language, I18nManager



class MainWindow(QMainWindow):
    """
    Main TouchDeck Studio Window.
    Monochromatic Apple glass aesthetic: sleek top bar, Stream Deck hardware preview,
    floating bottom dock, and floating settings inspector.
    """

    def __init__(self, config_store: ConfigStore, action_engine: ActionEngine, server: TouchDeckServer):
        super().__init__()
        self.config_store = config_store
        self.action_engine = action_engine
        self.server = server
        self.auth_mgr = GoogleAuthManager.get_instance()

        self.setWindowTitle(f"{APP_NAME} — Stream Deck Studio")
        self.resize(1380, 880)
        self.setMinimumSize(1080, 700)

        # Window Icon & Branding
        self.icon_path = Path(__file__).parent.parent.parent / "assets" / "ventrix.ico"
        if not self.icon_path.exists():
            self.icon_path = Path(__file__).parent.parent.parent / "assets" / "touchdeck.ico"
        self.logo_png_path = Path(__file__).parent.parent.parent / "assets" / "ventrix.png"

        if self.icon_path.exists():
            self.app_icon = QIcon(str(self.icon_path))
            self.setWindowIcon(self.app_icon)
        elif self.logo_png_path.exists():
            self.app_icon = QIcon(str(self.logo_png_path))
            self.setWindowIcon(self.app_icon)
        else:
            self.app_icon = QIcon()

        self.setStyleSheet(DARK_THEME_QSS)

        # Initialize i18n
        saved_lang = getattr(self.config_store.settings, "language", "da") or "da"
        set_language(saved_lang)
        I18nManager.get_instance().language_changed.connect(self._on_language_changed)

        # Process monitor for button status
        self.process_monitor = ProcessMonitor()
        self.process_monitor.start()
        self.server.process_monitor = self.process_monitor

        self._active_toasts = []

        self._init_ui()
        self._init_shortcuts()
        self._init_networking_signals()
        self._init_auth_signals()
        self._init_system_tray()
        self._load_active_profile()

        # Welcome screen state: show every time if always_show_welcome is True (default True)
        if getattr(self.config_store.settings, "always_show_welcome", True):
            self.main_stack.setCurrentIndex(0)
            self.welcome_screen.fade_in()
        else:
            self.main_stack.setCurrentIndex(1)

    def _init_ui(self):
        self.central = QWidget()
        self.setCentralWidget(self.central)
        root_lay = QVBoxLayout(self.central)
        root_lay.setContentsMargins(14, 12, 14, 14)
        root_lay.setSpacing(10)

        self.main_stack = QStackedWidget()

        # ----------------------------------------------------
        # STACK 0: Welcome / Onboarding Screen
        # ----------------------------------------------------
        user_name = getattr(self.config_store.settings, "user_name", "") or ""
        always_show = getattr(self.config_store.settings, "always_show_welcome", True)
        cur_lang = getattr(self.config_store.settings, "language", "da") or "da"
        self.welcome_screen = WelcomeScreen(
            user_name=user_name,
            language=cur_lang,
            always_show=always_show
        )
        self.welcome_screen.continue_clicked.connect(self._on_welcome_continued)
        self.main_stack.addWidget(self.welcome_screen)

        # ----------------------------------------------------
        # STACK 1: Studio Workspace
        # ----------------------------------------------------
        studio_widget = QWidget()
        studio_lay = QVBoxLayout(studio_widget)
        studio_lay.setContentsMargins(0, 0, 0, 0)
        studio_lay.setSpacing(10)

        # 1. FLOATING GLASS TOP NAVIGATION BAR
        top_bar = QFrame()
        top_bar.setObjectName("floatingTopBar")
        top_bar.setFixedHeight(50)
        top_lay = QHBoxLayout(top_bar)
        top_lay.setContentsMargins(16, 6, 16, 6)
        top_lay.setSpacing(12)

        # Left Branding
        brand_row = QHBoxLayout()
        brand_row.setSpacing(8)

        brand_icon = QLabel()
        brand_icon.setStyleSheet("background: transparent; border: none;")
        if self.logo_png_path.exists():
            brand_icon.setPixmap(QPixmap(str(self.logo_png_path)).scaled(22, 22, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        elif self.icon_path.exists():
            brand_icon.setPixmap(QPixmap(str(self.icon_path)).scaled(22, 22, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        brand_row.addWidget(brand_icon)

        brand_lbl = QLabel(APP_NAME)
        brand_lbl.setObjectName("brandTitle")
        brand_lbl.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 600; letter-spacing: 0.5px; background: transparent; border: none;")
        brand_row.addWidget(brand_lbl)

        # Version badge as GlassButton (properly renders rounded background)
        ver_badge = GlassButton(f"v{APP_VERSION}", is_primary=False, corner_radius=8)
        ver_badge.setFixedHeight(22)
        ver_badge.setFixedWidth(52)
        ver_badge.setCursor(Qt.ArrowCursor)
        brand_row.addWidget(ver_badge)

        # License status pill
        self.license_badge = GlassButton("Aktiver", is_primary=False, corner_radius=8)
        self.license_badge.setFixedHeight(22)
        self.license_badge.clicked.connect(self._open_license_dialog)
        self._update_license_badge()
        brand_row.addWidget(self.license_badge)

        top_lay.addLayout(brand_row)

        top_lay.addSpacing(10)

        # Discreet Status Pill: ● Connected
        self.status_pill = GlassStatusPill()
        top_lay.addWidget(self.status_pill)

        self.device_count_lbl = QLabel("0 Enheder")
        self.device_count_lbl.setStyleSheet("color: #8E8E93; font-size: 11px; font-weight: 500; background: transparent; border: none;")
        top_lay.addWidget(self.device_count_lbl)

        top_lay.addStretch()

        # Profile Switcher Pill
        self.prof_lbl = QLabel(t("topbar_profile"))
        self.prof_lbl.setStyleSheet("color: #8E8E93; font-size: 11px; background: transparent; border: none;")
        top_lay.addWidget(self.prof_lbl)

        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumWidth(140)
        self.profile_combo.currentIndexChanged.connect(self._on_profile_combo_changed)
        top_lay.addWidget(self.profile_combo)

        top_lay.addSpacing(8)

        # Primary Action: Send til Surface (Apple Solid White Pill)
        self.push_btn = QPushButton(t("topbar_push_surface"))
        self.push_btn.setObjectName("pushBtn")
        self.push_btn.setToolTip(t("topbar_push_surface_tooltip"))
        self.push_btn.clicked.connect(self._on_push_to_surface)
        top_lay.addWidget(self.push_btn)

        top_lay.addSpacing(6)

        # Forbind Enhed & USB knapper
        self.devices_btn = QPushButton(t("topbar_connect_device"))
        self.devices_btn.setToolTip(t("topbar_connect_device"))
        self.devices_btn.clicked.connect(self._open_connect_device_dialog)
        top_lay.addWidget(self.devices_btn)

        self.usb_btn = QPushButton(t("topbar_usb"))
        self.usb_btn.setToolTip(t("topbar_usb"))
        self.usb_btn.clicked.connect(self._open_usb_dialog)
        top_lay.addWidget(self.usb_btn)

        # In-App Update Button
        self.update_btn = QPushButton(t("topbar_update"))
        self.update_btn.setToolTip(t("topbar_update"))
        self.update_btn.clicked.connect(self._open_update_dialog)
        top_lay.addWidget(self.update_btn)

        # Google Account Avatar
        self.topbar_avatar = GlassAvatar(size=30)
        self.topbar_avatar.setToolTip("Google Account")
        self.topbar_avatar.clicked.connect(self._open_account_menu)
        top_lay.addWidget(self.topbar_avatar)

        # Settings Button (Apple Vector Sliders - Guaranteed never to break into 'c')
        self.settings_btn = AppleSettingsButton()
        self.settings_btn.setToolTip(t("topbar_settings_tooltip"))
        self.settings_btn.clicked.connect(self._open_settings_dialog)
        top_lay.addWidget(self.settings_btn)

        studio_lay.addWidget(top_bar)

        # 2. CENTER SPLITTER WORKSPACE (Canvas + Inspector)
        workspace = QSplitter(Qt.Horizontal)
        workspace.setHandleWidth(1)
        workspace.setStyleSheet("QSplitter::handle { background-color: rgba(255, 255, 255, 0.05); }")

        # Center Column: Switcher + Surface Preview + Bottom Dock
        center_col = QWidget()
        center_lay = QVBoxLayout(center_col)
        center_lay.setContentsMargins(0, 0, 0, 0)
        center_lay.setSpacing(10)

        # Live Hardware Preview (Center Stage)
        self.preview = LiveSurfacePreview()
        self.preview.button_selected.connect(self._on_button_selected_in_preview)
        self.preview.layout_changed.connect(self._on_layout_changed)
        self.preview.button_test_requested.connect(self._on_button_test_requested)
        center_lay.addWidget(self.preview, stretch=1)

        # Floating Bottom Page Dock (Navigation and + New Page at bottom)
        self.dock = PageDock()
        self.dock.page_selected.connect(self._on_dock_page_selected)
        self.dock.prev_requested.connect(self._prev_page)
        self.dock.next_requested.connect(self._next_page)
        self.dock.page_created.connect(self._create_new_page)
        self.dock.page_renamed.connect(self._on_page_renamed)
        self.dock.page_duplicated.connect(self._duplicate_page)
        self.dock.page_deleted.connect(self._delete_page)
        self.dock.page_moved.connect(self._move_page)
        center_lay.addWidget(self.dock)

        workspace.addWidget(center_col)

        # Right Panel: Floating Translucent Inspector
        self.inspector = ButtonInspector(self)
        self.inspector.setMinimumWidth(380)
        self.inspector.setMaximumWidth(460)
        self.inspector.button_updated.connect(self._on_button_updated_in_inspector)
        self.inspector.button_deleted.connect(self._on_button_deleted_in_inspector)
        self.inspector.button_test_requested.connect(self._on_button_test_requested)
        self.inspector.push_requested.connect(self._on_push_to_surface)
        workspace.addWidget(self.inspector)

        workspace.setSizes([860, 420])
        studio_lay.addWidget(workspace, stretch=1)

        self.main_stack.addWidget(studio_widget)

        # ----------------------------------------------------
        # STACK 2: In-Window Settings Workspace
        # ----------------------------------------------------
        self.settings_view = SettingsView(self.config_store, self.server, self)
        self.settings_view.back_to_studio_requested.connect(lambda: self.main_stack.setCurrentIndex(1))
        self.settings_view.replay_welcome_requested.connect(lambda: self.main_stack.setCurrentIndex(0))
        self.main_stack.addWidget(self.settings_view)

        root_lay.addWidget(self.main_stack)

    def _init_shortcuts(self):
        """Bind keyboard shortcuts for fluent navigation."""
        QShortcut(QKeySequence(Qt.Key_Left), self, self._prev_page)
        QShortcut(QKeySequence(Qt.Key_Right), self, self._next_page)
        QShortcut(QKeySequence("Ctrl+N"), self, self._create_new_page)
        QShortcut(QKeySequence("Ctrl+S"), self, self._on_push_to_surface)

    def _init_networking_signals(self):
        self.server.on_client_connected = lambda d: QTimer.singleShot(0, lambda: self._handle_client_connected(d))
        self.server.on_client_disconnected = lambda did: QTimer.singleShot(0, lambda: self._handle_client_disconnected(did))
        self.server.on_button_pressed = lambda bid, t: QTimer.singleShot(0, lambda: self._handle_button_pressed(bid, t))

        # Periodic live check of connected devices on GUI thread
        self.connection_poll_timer = QTimer(self)
        self.connection_poll_timer.timeout.connect(self._refresh_connection_status)
        self.connection_poll_timer.start(1500)
        self._refresh_connection_status()

    def _refresh_connection_status(self):
        count = self.server.get_connected_devices_count() if self.server else 0
        is_conn = (count > 0)
        if self.status_pill.is_connected != is_conn:
            self.status_pill.set_connected(is_conn)
        self.device_count_lbl.setText(f"{count} Enhed{'er' if count != 1 else ''}")

    def _init_auth_signals(self):
        self.auth_mgr.auth_success.connect(self._update_auth_avatar)
        self.auth_mgr.auth_logged_out.connect(self._update_auth_avatar)
        self._update_auth_avatar()

    def _update_auth_avatar(self, *args):
        if self.auth_mgr.is_logged_in():
            u = self.auth_mgr.current_user or {}
            av_path = u.get("avatar_path")
            if av_path and os.path.exists(av_path):
                self.topbar_avatar.set_image(av_path)
            else:
                self.topbar_avatar.set_initials(u.get("name", "TD"))
            self.topbar_avatar.setToolTip(f"Logget ind som: {u.get('name', 'Google Bruger')} ({u.get('email', '')})")
        else:
            self.topbar_avatar.set_image(None)
            self.topbar_avatar.set_initials("TD")
            self.topbar_avatar.setToolTip("Google Sign-In & Profil")

    def _open_account_menu(self):
        menu = QMenu(self)
        if self.auth_mgr.is_logged_in():
            u = self.auth_mgr.current_user or {}
            name_act = menu.addAction(u.get('name', 'Google Bruger'))
            name_act.setEnabled(False)
            email_act = menu.addAction(u.get('email', ''))
            email_act.setEnabled(False)
            menu.addSeparator()
            pref_act = menu.addAction("Indstillinger...")
            signout_act = menu.addAction("Log Ud")
            chosen = menu.exec(self.topbar_avatar.mapToGlobal(QPoint(0, 36)))
            if chosen == signout_act:
                self.auth_mgr.sign_out()
                self.show_toast("Logget ud af Google")
            elif chosen == pref_act:
                self._open_settings_dialog(page_index=1)
        else:
            login_act = menu.addAction("Continue with Google...")
            pref_act = menu.addAction("Konfigurer OAuth...")
            chosen = menu.exec(self.topbar_avatar.mapToGlobal(QPoint(0, 36)))
            if chosen == login_act:
                cid, _ = self.auth_mgr.get_credentials()
                if not cid:
                    self._open_settings_dialog(page_index=1)
                else:
                    self.auth_mgr.start_desktop_oauth_flow()
            elif chosen == pref_act:
                self._open_settings_dialog(page_index=1)

    def _update_license_badge(self):
        info = get_license_info()
        if info.get("licensed", False):
            self.license_badge.setText("Pro ✓")
            self.license_badge.setToolTip(f"VENTRIX Pro Aktiveret ({info.get('key', '')})")
        else:
            self.license_badge.setText("Få Licens")
            self.license_badge.setToolTip("Klik for at indtaste eller hente din gratis licensnøgle")

    def _open_license_dialog(self):
        dlg = LicenseActivationDialog(parent=self)
        dlg.activated.connect(lambda k: self._update_license_badge())
        dlg.exec()

    def _on_welcome_continued(self, user_name: str, language: str, always_show: bool):
        self.config_store.settings.user_name = user_name
        self.config_store.settings.language = language
        self.config_store.settings.always_show_welcome = always_show
        self.config_store.settings.has_seen_welcome = True
        self.config_store.save_settings()
        set_language(language)
        self._update_license_badge()
        self.main_stack.setCurrentIndex(1)
        if not is_licensed():
            from PySide6.QtCore import QTimer
            QTimer.singleShot(400, self._open_license_dialog)

    def _on_language_changed(self, lang: str):
        self.prof_lbl.setText(t("topbar_profile"))
        self.push_btn.setText(t("topbar_push_surface"))
        self.push_btn.setToolTip(t("topbar_push_surface_tooltip"))
        self.devices_btn.setText(t("topbar_devices"))
        self.devices_btn.setToolTip(t("topbar_devices"))
        self.usb_btn.setText(t("topbar_usb"))
        self.usb_btn.setToolTip(t("topbar_usb"))
        self.settings_btn.setToolTip(t("topbar_settings_tooltip"))

        count = self.server.get_connected_devices_count() if self.server else 0
        self.device_count_lbl.setText(t("topbar_devices_count", count=count))

    def show_toast(self, message: str):
        """Displays floating translucent glass toast pill."""
        toast = GlassToast(message, self)
        toast.adjustSize()
        x = (self.width() - toast.width()) // 2
        y = 65 + len(self._active_toasts) * 42
        toast.move(x, y)
        toast.show()
        self._active_toasts.append(toast)
        QTimer.singleShot(2500, lambda: self._active_toasts.remove(toast) if toast in self._active_toasts else None)

    def _handle_client_connected(self, device: DeviceModel):
        count = self.server.get_connected_devices_count()
        self.status_pill.set_connected(True)
        self.device_count_lbl.setText(f"{count} Enhed{'er' if count != 1 else ''}")
        self.show_toast(f"Surface forbundet: {device.name}")

    def _handle_client_disconnected(self, device_id: str):
        count = self.server.get_connected_devices_count()
        if count == 0:
            self.status_pill.set_connected(False)
            self.device_count_lbl.setText("0 Enheder")
            self.show_toast("Surface afbrudt")
        else:
            self.device_count_lbl.setText(f"{count} Enhed{'er' if count != 1 else ''}")

    def _handle_button_pressed(self, button_id: str, title: str):
        pass

    def _load_active_profile(self):
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        active_idx = 0
        for idx, p in enumerate(self.config_store.profiles):
            self.profile_combo.addItem(p.name, p.id)
            if p.id == self.config_store.settings.active_profile_id:
                active_idx = idx
        self.profile_combo.setCurrentIndex(active_idx)
        self.profile_combo.blockSignals(False)

        self._refresh_pages()
        self.process_monitor.set_profile(self.config_store.get_active_profile())

    def _refresh_pages(self):
        active = self.config_store.get_active_profile()
        if not active or not active.pages:
            return

        cur_idx = min(active.active_page_index, len(active.pages) - 1)
        cur_page = active.pages[cur_idx]

        # Update preview
        self.preview.set_page(cur_page)
        self.inspector.set_button(None)

        # Update floating dock
        self.dock.set_pages(active.pages, active_index=cur_idx)

    def _on_profile_combo_changed(self, index: int):
        if index < 0 or index >= len(self.config_store.profiles):
            return
        prof = self.config_store.profiles[index]
        self.config_store.settings.active_profile_id = prof.id
        self.config_store.save_settings()
        self._refresh_pages()
        self.server.broadcast_layout_update()
        self.show_toast(f"Profil aktiveret: {prof.name}")

    def _create_new_profile(self):
        name, ok = AppleGlassInputDialog.get_text(self, "Ny Profil", "Navn på den nye profil:")
        if ok and name.strip():
            new_prof = ProfileModel(
                name=name.strip(),
                pages=[PageModel(name="Home", rows=3, cols=4, buttons=[])]
            )
            self.config_store.profiles.append(new_prof)
            self.config_store.settings.active_profile_id = new_prof.id
            self.config_store.save_profiles()
            self.config_store.save_settings()
            self._load_active_profile()
            self.server.broadcast_layout_update()
            self.show_toast(f"Profil oprettet: {new_prof.name}")

    def _delete_active_profile(self):
        if len(self.config_store.profiles) <= 1:
            AppleGlassConfirmDialog.alert(self, "Kan Ikke Slettes", "Du skal have mindst én profil.")
            return

        reply = AppleGlassConfirmDialog.ask(
            self, "Slet Profil", "Er du sikker på, at du vil slette den aktive profil?",
            confirm_text="Slet", is_danger=True
        )
        if reply:
            active = self.config_store.get_active_profile()
            self.config_store.profiles = [p for p in self.config_store.profiles if p.id != active.id]
            self.config_store.settings.active_profile_id = self.config_store.profiles[0].id
            self.config_store.save_profiles()
            self.config_store.save_settings()
            self._load_active_profile()
            self.server.broadcast_layout_update()
            self.show_toast("Profil slettet")

    # ----------------------------------------------------
    # Page Navigation (Horizontal & Dock)
    # ----------------------------------------------------
    def _switch_to_page(self, index: int):
        active = self.config_store.get_active_profile()
        if not active or index < 0 or index >= len(active.pages):
            return

        active.active_page_index = index
        self.config_store.save_profiles(create_backup=False)

        cur_page = active.pages[index]
        self.preview.set_page(cur_page)
        self.inspector.set_button(None)
        self.dock.set_active_index(index)
        self.server.broadcast_layout_update()

    def _prev_page(self):
        active = self.config_store.get_active_profile()
        if not active or not active.pages:
            return
        idx = (active.active_page_index - 1) % len(active.pages)
        self._switch_to_page(idx)

    def _next_page(self):
        active = self.config_store.get_active_profile()
        if not active or not active.pages:
            return
        idx = (active.active_page_index + 1) % len(active.pages)
        self._switch_to_page(idx)

    def _on_dock_page_selected(self, index: int):
        self._switch_to_page(index)

    def _create_new_page(self):
        active = self.config_store.get_active_profile()
        if not active:
            return

        name, ok = AppleGlassInputDialog.get_text(self, "Ny Side", "Navn på den nye side:")
        if ok and name.strip():
            new_page = PageModel(name=name.strip(), rows=3, cols=4, buttons=[])
            active.pages.append(new_page)
            self.config_store.save_profiles()
            self._refresh_pages()
            self._switch_to_page(len(active.pages) - 1)
            self.show_toast(f"Side '{new_page.name}' oprettet")

    def _on_page_renamed(self, index: int, new_name: str):
        active = self.config_store.get_active_profile()
        if active and 0 <= index < len(active.pages):
            active.pages[index].name = new_name
            self.config_store.save_profiles(create_backup=False)
            self._refresh_pages()
            self.server.broadcast_layout_update()
            self.show_toast("Side omdøbt")

    def _duplicate_page(self, index: int):
        active = self.config_store.get_active_profile()
        if not active or index < 0 or index >= len(active.pages):
            return

        source = active.pages[index]
        d = source.to_dict()
        d["id"] = ""
        d["name"] = f"{source.name} (Kopi)"
        dup = PageModel.from_dict(d)

        active.pages.insert(index + 1, dup)
        self.config_store.save_profiles()
        self._refresh_pages()
        self._switch_to_page(index + 1)
        self.show_toast("Side duplikeret")

    def _delete_page(self, index: int):
        active = self.config_store.get_active_profile()
        if not active or index < 0 or index >= len(active.pages):
            return

        if len(active.pages) <= 1:
            AppleGlassConfirmDialog.alert(self, "Kan Ikke Slettes", "En profil skal have mindst én side.")
            return

        del_name = active.pages[index].name
        reply = AppleGlassConfirmDialog.ask(
            self, "Slet Side", f"Er du sikker på, at du vil slette siden '{del_name}'?",
            confirm_text="Slet", is_danger=True
        )
        if reply:
            del active.pages[index]
            active.active_page_index = max(0, min(active.active_page_index, len(active.pages) - 1))
            self.config_store.save_profiles()
            self._refresh_pages()
            self._switch_to_page(active.active_page_index)
            self.show_toast("Side slettet")

    def _move_page(self, from_idx: int, to_idx: int):
        active = self.config_store.get_active_profile()
        if not active:
            return
        if 0 <= from_idx < len(active.pages) and 0 <= to_idx < len(active.pages):
            item = active.pages.pop(from_idx)
            active.pages.insert(to_idx, item)
            self.config_store.save_profiles(create_backup=False)
            self._refresh_pages()
            self._switch_to_page(to_idx)

    # ----------------------------------------------------
    # Button & Inspector Handlers
    # ----------------------------------------------------
    def _on_button_selected_in_preview(self, button: Optional[ButtonModel]):
        self.inspector.set_button(button)

    def _on_button_updated_in_inspector(self, button: ButtonModel):
        self.preview.refresh_grid()
        self.config_store.save_profiles(create_backup=False)
        self.server.broadcast_layout_update()

    def _on_button_deleted_in_inspector(self, button_id: str):
        # Find and remove button
        active = self.config_store.get_active_profile()
        if active and active.pages:
            cur_page = active.pages[active.active_page_index]
            tgt = next((b for b in cur_page.buttons if b.id == button_id), None)
            if tgt:
                self.preview._delete_button(tgt)
        self.inspector.set_button(None)
        self.show_toast("Knap slettet")

    def _on_layout_changed(self):
        self.config_store.save_profiles(create_backup=False)
        self.server.broadcast_layout_update()

    def _on_button_test_requested(self, button: ButtonModel):
        if button and button.action:
            self.action_engine.execute_action_async(button.action, button_id=button.id)
            self.show_toast(f"Test udført: {button.title}")

    # ----------------------------------------------------
    # Push to Surface Primary Action (Apple Feedback Flow)
    # ----------------------------------------------------
    def _on_push_to_surface(self):
        """
        Saves all configurations and broadcasts instant layout sync.
        Transitions: Preparing... -> Sending... -> Done ✓
        """
        self.config_store.save_all()
        self.server.broadcast_layout_sync()
        self.preview.refresh_grid()

        self.push_btn.setText("Preparing...")
        self.push_btn.setEnabled(False)

        def step_sending():
            self.push_btn.setText("Sending...")
            QTimer.singleShot(250, step_done)

        def step_done():
            self.push_btn.setText("Done ✓")
            self.show_toast("Done ✓")

            QTimer.singleShot(1500, step_restore)

        def step_restore():
            self.push_btn.setText("↗ Send til Surface")
            self.push_btn.setEnabled(True)

        QTimer.singleShot(150, step_sending)

    # ----------------------------------------------------
    # In-Window View Navigation (Zero External Popups)
    # ----------------------------------------------------
    def _open_connect_device_dialog(self):
        dlg = ConnectDeviceDialog(self.config_store, self.server, self)
        dlg.exec()
        self._refresh_connection_status()

    def _open_update_dialog(self):
        from editor.widgets.update_dialog import UpdateDialog
        dlg = UpdateDialog(self)
        dlg.exec()

    def _open_devices_dialog(self):
        self.settings_view.category_list.setCurrentRow(2)
        self.main_stack.setCurrentIndex(2)

    def _open_usb_dialog(self):
        self.settings_view.category_list.setCurrentRow(3)
        self.main_stack.setCurrentIndex(2)

    def _open_settings_dialog(self, page_index: int = 0):
        self.settings_view.category_list.setCurrentRow(page_index)
        self.main_stack.setCurrentIndex(2)

    def _init_system_tray(self):
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray = QSystemTrayIcon(self.app_icon, self)
        menu = QMenu()
        open_act = menu.addAction(f"Open {APP_NAME}")
        open_act.triggered.connect(self.showNormal)
        menu.addSeparator()
        quit_act = menu.addAction("Quit")
        quit_act.triggered.connect(QApplication.instance().quit)
        self.tray.setContextMenu(menu)
        self.tray.show()

    def closeEvent(self, event: QCloseEvent):
        if self.config_store.settings.minimize_to_tray:
            event.ignore()
            self.hide()
            if hasattr(self, "tray"):
                self.tray.showMessage(APP_NAME, f"{APP_NAME} kører i baggrunden.", QSystemTrayIcon.Information, 1500)
        else:
            event.accept()

    def showEvent(self, event):
        super().showEvent(event)
        self._apply_windows_dark_titlebar()

    def _apply_windows_dark_titlebar(self):
        """Forces Windows 10/11 OS titlebar to pitch dark mode (#0A0A0C) with white text, eliminating the white bar."""
        import sys
        if sys.platform != "win32":
            return
        try:
            import ctypes
            from ctypes import c_int, byref, sizeof
            hwnd = int(self.winId())
            if hwnd:
                dark_val = c_int(1)
                # DWMWA_USE_IMMERSIVE_DARK_MODE (20 on Win11/Win10 2004+, 19 on older Win10)
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 20, byref(dark_val), sizeof(dark_val))
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 19, byref(dark_val), sizeof(dark_val))

                # DWMWA_CAPTION_COLOR = 35 (Win11) -> 0x000C0A0A (#0A0A0C)
                caption_col = c_int(0x000C0A0A)
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 35, byref(caption_col), sizeof(caption_col))

                # DWMWA_TEXT_COLOR = 36 (Win11) -> 0x00FFFFFF (#FFFFFF)
                text_col = c_int(0x00FFFFFF)
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 36, byref(text_col), sizeof(text_col))
        except Exception:
            pass
