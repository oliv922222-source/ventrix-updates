"""
VENTRIX Studio - License Manager
Handles cryptographic license key validation, local license persistence,
and duration/expiration verification (Lifetime, 1 Måned, 1 Uge).
Format: VTX-XXXX-XXXX-XXXX-YYYY
"""

import os
import json
import hashlib
from datetime import datetime, timezone, timedelta
from pathlib import Path

ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
SALT = "VENTRIX_STUDIO_SALT_2026"


def _get_license_file() -> Path:
    """Returns the persistent path where the license key is stored."""
    base = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "VENTRIX"
    base.mkdir(parents=True, exist_ok=True)
    return base / "license.json"


def compute_checksum(payload: str) -> str:
    """Computes a 4-character cryptographic checksum from 12 payload characters."""
    h = hashlib.sha256((payload + SALT).encode("utf-8")).hexdigest()
    val = int(h[:8], 16)
    chk = []
    for _ in range(4):
        chk.append(ALPHABET[val % len(ALPHABET)])
        val //= len(ALPHABET)
    return "".join(chk)


def verify_license_key(key: str) -> bool:
    """Validates if a given license key is cryptographically genuine."""
    if not key or not isinstance(key, str):
        return False
    clean = key.strip().upper().replace(" ", "")
    parts = clean.split("-")
    if len(parts) != 5:
        return False
    if parts[0] != "VTX":
        return False
    for p in parts[1:]:
        if len(p) != 4 or any(c not in ALPHABET for c in p):
            return False
    payload = "".join(parts[1:4])
    expected_chk = compute_checksum(payload)
    return parts[4] == expected_chk


def get_license_tier_and_duration(key: str) -> tuple[str, int | None]:
    """
    Decodes tier and duration (in seconds) from the cryptographic key.
    - 'WK' prefix: 1 Uge (7 days = 604,800s)
    - 'MN' prefix: 1 Måned (30 days = 2,592,000s)
    - 'LF' prefix or other genuine key: Lifetime (never expires, duration=None)
    """
    clean = key.strip().upper().replace(" ", "")
    parts = clean.split("-")
    if len(parts) >= 2:
        part1 = parts[1]
        if part1.startswith("WK"):
            return "1 Uge", 7 * 86400
        elif part1.startswith("MN"):
            return "1 Måned", 30 * 86400
        elif part1.startswith("LF"):
            return "Lifetime", None
    return "Lifetime", None


def is_licensed() -> bool:
    """
    Checks if the application currently has a valid, unexpired license.
    Automatically returns False if expired or invalid.
    """
    lic_file = _get_license_file()
    if not lic_file.exists():
        return False
    try:
        data = json.loads(lic_file.read_text(encoding="utf-8"))
        saved_key = data.get("license_key", "")
        if not verify_license_key(saved_key):
            return False

        expires_at_str = data.get("expires_at")
        if expires_at_str:
            expires_at = datetime.fromisoformat(expires_at_str)
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
            now = datetime.now(timezone.utc)

            # Check if license duration has elapsed
            if now > expires_at:
                return False

            # Anti-tamper clock rollback check
            last_verified_str = data.get("last_verified_at")
            if last_verified_str:
                last_verified = datetime.fromisoformat(last_verified_str)
                if last_verified.tzinfo is None:
                    last_verified = last_verified.replace(tzinfo=timezone.utc)
                if now < last_verified - timedelta(hours=1):
                    # Clock wound back by more than an hour
                    return False

            # Update last verified timestamp
            try:
                data["last_verified_at"] = now.isoformat()
                lic_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
            except Exception:
                pass

        return True
    except Exception:
        return False


def save_license(key: str) -> bool:
    """
    Validates, calculates expiration based on tier, and permanently stores the license.
    - Lifetime: expires_at = None (never expires)
    - 1 Måned: expires_at = now + 30 days
    - 1 Uge: expires_at = now + 7 days
    """
    if not verify_license_key(key):
        return False
    clean = key.strip().upper().replace(" ", "")
    lic_file = _get_license_file()

    tier, duration_sec = get_license_tier_and_duration(clean)
    now = datetime.now(timezone.utc)
    expires_at = (now + timedelta(seconds=duration_sec)).isoformat() if duration_sec else None

    try:
        data = {
            "license_key": clean,
            "product": "VENTRIX Stream Deck",
            "tier": tier,
            "activated_at": now.isoformat(),
            "expires_at": expires_at,
            "last_verified_at": now.isoformat()
        }
        lic_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False


def get_license_info() -> dict:
    """Returns details about current license status including expiration and days left."""
    lic_file = _get_license_file()
    if not lic_file.exists():
        return {"licensed": False, "key": None, "tier": "Uaktiveret", "expired": False, "days_left": None}
    try:
        data = json.loads(lic_file.read_text(encoding="utf-8"))
        key = data.get("license_key", "")
        if verify_license_key(key):
            masked = f"{key[:8]}****-****{key[-5:]}"
            tier = data.get("tier") or get_license_tier_and_duration(key)[0]
            expires_at_str = data.get("expires_at")
            expired = False
            days_left = None

            if expires_at_str:
                expires_at = datetime.fromisoformat(expires_at_str)
                if expires_at.tzinfo is None:
                    expires_at = expires_at.replace(tzinfo=timezone.utc)
                now = datetime.now(timezone.utc)
                if now > expires_at:
                    expired = True
                else:
                    diff = expires_at - now
                    days_left = max(0, diff.days)

            is_valid = not expired

            return {
                "licensed": is_valid,
                "key": masked,
                "raw_key": key,
                "tier": tier,
                "expired": expired,
                "expires_at": expires_at_str,
                "days_left": days_left
            }
    except Exception:
        pass
    return {"licensed": False, "key": None, "tier": "Uaktiveret", "expired": False, "days_left": None}


def remove_license() -> bool:
    """Deactivates and removes current license."""
    lic_file = _get_license_file()
    if lic_file.exists():
        try:
            lic_file.unlink()
            return True
        except Exception:
            return False
    return True
