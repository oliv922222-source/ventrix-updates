"""
TouchDeck - Modular Action Engine
Executes application launches, Windows hotkeys, media controls, mouse actions, system tasks, scripts, and macros.
Author: VENTRIX
"""

import os
import sys
import time
import subprocess
import threading
import webbrowser
import logging
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, Callable
import ctypes
from ctypes import wintypes

from shared.models import ActionModel, MacroStepModel
from shared.constants import (
    ACTION_TYPE_APPLICATION, ACTION_TYPE_HOTKEY, ACTION_TYPE_MEDIA,
    ACTION_TYPE_MOUSE, ACTION_TYPE_SYSTEM, ACTION_TYPE_FILE_FOLDER_URL,
    ACTION_TYPE_SCRIPT, ACTION_TYPE_MACRO,
    ACTION_TYPE_DISCORD, ACTION_TYPE_MEDAL,
    DISCORD_MUTE_MIC, DISCORD_DEAFEN, DISCORD_PUSH_TO_TALK, DISCORD_STREAM_TOGGLE,
    MEDAL_CLIP_15S, MEDAL_CLIP_30S, MEDAL_CLIP_1M, MEDAL_CLIP_2M, MEDAL_CLIP_5M,
    MEDAL_CLIP_CUSTOM, MEDAL_RECORD_TOGGLE, MEDAL_BOOKMARK, MEDAL_DEFAULT_HOTKEYS,
    MEDIA_PLAY_PAUSE, MEDIA_NEXT, MEDIA_PREV, MEDIA_VOLUME_UP,
    MEDIA_VOLUME_DOWN, MEDIA_VOLUME_MUTE,
    SYSTEM_LOCK, SYSTEM_SLEEP, SYSTEM_SHUTDOWN, SYSTEM_RESTART,
    SYSTEM_OPEN_SETTINGS, SYSTEM_TASK_MANAGER,
    MOUSE_LEFT_CLICK, MOUSE_RIGHT_CLICK, MOUSE_DOUBLE_CLICK
)

logger = logging.getLogger("TouchDeck.ActionEngine")

# Win32 Virtual Key Constants
VK_VOLUME_MUTE = 0xAD
VK_VOLUME_DOWN = 0xAE
VK_VOLUME_UP = 0xAF
VK_MEDIA_NEXT_TRACK = 0xB0
VK_MEDIA_PREV_TRACK = 0xB1
VK_MEDIA_STOP = 0xB2
VK_MEDIA_PLAY_PAUSE = 0xB3

VK_LWIN = 0x5B
VK_LCONTROL = 0xA2
VK_LMENU = 0x12  # Alt
VK_LSHIFT = 0xA0
VK_TAB = 0x09
VK_ESCAPE = 0x1B
VK_RETURN = 0x0D
VK_SPACE = 0x20

# Key mapping dictionary
KEY_MAP = {
    "win": 0x5B, "lwin": 0x5B, "rwin": 0x5C, "windows": 0x5B,
    "ctrl": 0x11, "control": 0x11, "lctrl": 0xA2, "rctrl": 0xA3,
    "alt": 0x12, "lalt": 0xA4, "ralt": 0xA5,
    "shift": 0x10, "lshift": 0xA0, "rshift": 0xA1,
    "tab": 0x09, "enter": 0x0D, "return": 0x0D, "esc": 0x1B, "escape": 0x1B,
    "space": 0x20, "backspace": 0x08, "delete": 0x2E, "insert": 0x2D,
    "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22,
    "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27,
    "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73, "f5": 0x74, "f6": 0x75,
    "f7": 0x76, "f8": 0x77, "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,
    "f13": 0x7C, "f14": 0x7D, "f15": 0x7E, "f16": 0x7F, "f17": 0x80, "f18": 0x81,
    "f19": 0x82, "f20": 0x83, "f21": 0x84, "f22": 0x85, "f23": 0x86, "f24": 0x87,
    "printscreen": 0x2C, "capslock": 0x14, "numlock": 0x90, "scrolllock": 0x91
}

# Add 0-9 and A-Z
for i in range(10):
    KEY_MAP[str(i)] = 0x30 + i
for c in "abcdefghijklmnopqrstuvwxyz":
    KEY_MAP[c] = ord(c.upper())


if sys.platform == "win32":
    class _MOUSEINPUT(ctypes.Structure):
        _fields_ = [
            ("dx", wintypes.LONG),
            ("dy", wintypes.LONG),
            ("mouseData", wintypes.DWORD),
            ("dwFlags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.c_size_t),
        ]

    class _KEYBDINPUT(ctypes.Structure):
        _fields_ = [
            ("wVk", wintypes.WORD),
            ("wScan", wintypes.WORD),
            ("dwFlags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.c_size_t),
        ]

    class _HARDWAREINPUT(ctypes.Structure):
        _fields_ = [
            ("uMsg", wintypes.DWORD),
            ("wParamL", wintypes.WORD),
            ("wParamH", wintypes.WORD),
        ]

    class _INPUT_UNION(ctypes.Union):
        _fields_ = [
            ("mi", _MOUSEINPUT),
            ("ki", _KEYBDINPUT),
            ("hi", _HARDWAREINPUT),
        ]

    class _INPUT(ctypes.Structure):
        _anonymous_ = ("u",)
        _fields_ = [
            ("type", wintypes.DWORD),
            ("u", _INPUT_UNION),
        ]


class Win32KeyboardMouse:
    """Low-level Windows user32 keyboard and mouse event wrapper with hardware scan codes."""

    @staticmethod
    def _attach_input_desktop():
        """Ensures worker thread is attached to the interactive input desktop."""
        if sys.platform == "win32":
            try:
                user32 = ctypes.windll.user32
                h_desk = user32.OpenInputDesktop(0, False, 0x01FF)
                if h_desk:
                    user32.SetThreadDesktop(h_desk)
            except Exception:
                pass

    @classmethod
    def send_key_down(cls, vk_code: int):
        if sys.platform == "win32":
            cls._attach_input_desktop()
            user32 = ctypes.windll.user32
            scan = user32.MapVirtualKeyW(vk_code, 0)
            ext_flag = 1 if vk_code in (
                0x5B, 0x5C, 0xA4, 0xA5, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28,
                0x2D, 0x2E, 0xAD, 0xAE, 0xAF, 0xB0, 0xB1, 0xB2, 0xB3
            ) else 0

            # Try SendInput with hardware scan code first
            try:
                inp = _INPUT()
                inp.type = 1  # INPUT_KEYBOARD
                inp.ki.wVk = vk_code
                inp.ki.wScan = scan
                inp.ki.dwFlags = ext_flag
                if user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT)) > 0:
                    return
            except Exception:
                pass

            # Fallback to keybd_event
            try:
                user32.keybd_event(vk_code, scan, ext_flag, 0)
            except Exception as e:
                logger.error(f"Error in send_key_down: {e}")

    @classmethod
    def send_key_up(cls, vk_code: int):
        if sys.platform == "win32":
            cls._attach_input_desktop()
            user32 = ctypes.windll.user32
            scan = user32.MapVirtualKeyW(vk_code, 0)
            ext_flag = 1 if vk_code in (
                0x5B, 0x5C, 0xA4, 0xA5, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28,
                0x2D, 0x2E, 0xAD, 0xAE, 0xAF, 0xB0, 0xB1, 0xB2, 0xB3
            ) else 0

            try:
                inp = _INPUT()
                inp.type = 1  # INPUT_KEYBOARD
                inp.ki.wVk = vk_code
                inp.ki.wScan = scan
                inp.ki.dwFlags = 2 | ext_flag  # KEYEVENTF_KEYUP
                if user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT)) > 0:
                    return
            except Exception:
                pass

            try:
                user32.keybd_event(vk_code, scan, 2 | ext_flag, 0)
            except Exception as e:
                logger.error(f"Error in send_key_up: {e}")

    @classmethod
    def tap_key(cls, vk_code: int, delay: float = 0.08):
        if sys.platform == "win32":
            try:
                cls._attach_input_desktop()
                user32 = ctypes.windll.user32
                ext = 1 if vk_code in (
                    0x5B, 0x5C, 0xA4, 0xA5, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28,
                    0x2D, 0x2E, 0xAD, 0xAE, 0xAF, 0xB0, 0xB1, 0xB2, 0xB3
                ) else 0
                scan = user32.MapVirtualKeyW(vk_code, 0)
                user32.keybd_event(vk_code, scan, ext, 0)
                time.sleep(delay)
                user32.keybd_event(vk_code, scan, ext | 2, 0)
                return
            except Exception as e:
                logger.error(f"Error in tap_key keybd_event: {e}")

        cls.send_key_down(vk_code)
        time.sleep(delay)
        cls.send_key_up(vk_code)

    @classmethod
    def send_hotkey_combo(cls, combo_str: str):
        """Simulates simultaneous key combination like Ctrl+Shift+Esc or Win+D with reliable hold time."""
        parts = [p.strip().lower() for p in combo_str.split("+") if p.strip()]
        if not parts:
            return

        vk_list = []
        for p in parts:
            if p in KEY_MAP:
                vk_list.append(KEY_MAP[p])
            elif len(p) == 1 and p.isalnum():
                vk_list.append(ord(p.upper()))

        if not vk_list:
            logger.warning(f"No valid keys recognized in combo: {combo_str}")
            return

        # Press down in order
        for vk in vk_list:
            cls.send_key_down(vk)
            time.sleep(0.02)

        # Hold keys long enough (75ms) for background hooks (Medal, Discord, Games) to register
        time.sleep(0.075)

        # Release in reverse order
        for vk in reversed(vk_list):
            cls.send_key_up(vk)
            time.sleep(0.02)

    @classmethod
    def send_discord_hotkey(cls, combo: str):
        """Targets Discord's desktop window directly so keybinds trigger reliably without browser focus stealing."""
        if sys.platform != "win32":
            cls.send_hotkey_combo(combo)
            return

        try:
            cls._attach_input_desktop()
            user32 = ctypes.windll.user32
            h_desk = user32.OpenInputDesktop(0, False, 0x01FF)
            if h_desk:
                user32.SetThreadDesktop(h_desk)

            discord_hwnd = None
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.wintypes.BOOL, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
            user32.EnumDesktopWindows.argtypes = [ctypes.wintypes.HANDLE, WNDENUMPROC, ctypes.wintypes.LPARAM]

            def cb(hwnd, lparam):
                nonlocal discord_hwnd
                length = user32.GetWindowTextLengthW(hwnd)
                if length > 0:
                    buff = ctypes.create_unicode_buffer(length + 1)
                    user32.GetWindowTextW(hwnd, buff, length + 1)
                    t = buff.value.lower()
                    if "discord" in t and "overlay" not in t:
                        discord_hwnd = hwnd
                        return False
                return True

            user32.EnumDesktopWindows(h_desk, WNDENUMPROC(cb), 0)

            prev_fg = user32.GetForegroundWindow()

            if discord_hwnd:
                user32.ShowWindow(discord_hwnd, 9)  # SW_RESTORE
                user32.SetForegroundWindow(discord_hwnd)
                time.sleep(0.06)

            cls.send_hotkey_combo(combo)
            time.sleep(0.04)

            if prev_fg and discord_hwnd and prev_fg != discord_hwnd:
                user32.SetForegroundWindow(prev_fg)
        except Exception as e:
            logger.error(f"Error targeting Discord window: {e}")
            cls.send_hotkey_combo(combo)

    @staticmethod
    def send_mouse_click(button_type: str = MOUSE_LEFT_CLICK):
        if sys.platform == "win32":
            try:
                # MOUSEEVENTF_LEFTDOWN = 0x0002, MOUSEEVENTF_LEFTUP = 0x0004
                # MOUSEEVENTF_RIGHTDOWN = 0x0008, MOUSEEVENTF_RIGHTUP = 0x0010
                if button_type == MOUSE_LEFT_CLICK:
                    ctypes.windll.user32.mouse_event(0x0002, 0, 0, 0, 0)
                    time.sleep(0.03)
                    ctypes.windll.user32.mouse_event(0x0004, 0, 0, 0, 0)
                elif button_type == MOUSE_RIGHT_CLICK:
                    ctypes.windll.user32.mouse_event(0x0008, 0, 0, 0, 0)
                    time.sleep(0.03)
                    ctypes.windll.user32.mouse_event(0x0010, 0, 0, 0, 0)
                elif button_type == MOUSE_DOUBLE_CLICK:
                    ctypes.windll.user32.mouse_event(0x0002, 0, 0, 0, 0)
                    ctypes.windll.user32.mouse_event(0x0004, 0, 0, 0, 0)
                    time.sleep(0.05)
                    ctypes.windll.user32.mouse_event(0x0002, 0, 0, 0, 0)
                    ctypes.windll.user32.mouse_event(0x0004, 0, 0, 0, 0)
            except Exception as e:
                logger.error(f"Error in mouse click: {e}")


class ActionEngine:
    """Central action execution engine for TouchDeck."""

    def __init__(self):
        self.callbacks = []

    def register_feedback_callback(self, cb: Callable[[str, bool, str], None]):
        """Callback format: cb(button_id, success, message)"""
        self.callbacks.append(cb)

    def execute_action_async(self, action: ActionModel, button_id: str = "") -> threading.Thread:
        """Runs the action in a background thread to never block GUI or WebSocket event loops."""
        thread = threading.Thread(
            target=self._execute_action_worker,
            args=(action, button_id),
            daemon=True
        )
        thread.start()
        return thread

    def execute_action(self, action: ActionModel, button_id: str = ""):
        """Synchronously executes the action."""
        return self._execute_action_worker(action, button_id)

    def _notify(self, button_id: str, success: bool, message: str):
        for cb in self.callbacks:
            try:
                cb(button_id, success, message)
            except Exception:
                pass

    def _execute_action_worker(self, action: ActionModel, button_id: str = "") -> Tuple[bool, str]:
        if not action:
            return False, "Empty action"

        try:
            atype = action.action_type
            logger.info(f"Executing action type: {atype}, target: {action.target}")

            if atype == ACTION_TYPE_APPLICATION:
                return self._exec_application(action, button_id)

            elif atype == ACTION_TYPE_HOTKEY:
                return self._exec_hotkey(action, button_id)

            elif atype == ACTION_TYPE_MEDIA:
                return self._exec_media(action, button_id)

            elif atype == ACTION_TYPE_MOUSE:
                return self._exec_mouse(action, button_id)

            elif atype == ACTION_TYPE_SYSTEM:
                return self._exec_system(action, button_id)

            elif atype == ACTION_TYPE_FILE_FOLDER_URL:
                return self._exec_file_folder_url(action, button_id)

            elif atype == ACTION_TYPE_SCRIPT:
                return self._exec_script(action, button_id)

            elif atype == ACTION_TYPE_MACRO:
                return self._exec_macro(action, button_id)

            elif atype == ACTION_TYPE_DISCORD:
                return self._exec_discord(action, button_id)

            elif atype == ACTION_TYPE_MEDAL:
                return self._exec_medal(action, button_id)

            else:
                msg = f"Unknown action type: {atype}"
                self._notify(button_id, False, msg)
                return False, msg

        except Exception as e:
            err_msg = f"Action execution error: {str(e)}"
            logger.exception(err_msg)
            self._notify(button_id, False, err_msg)
            return False, err_msg

    def _exec_application(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        target = action.target.strip().strip('"').strip("'")
        if not target:
            msg = "No application path specified."
            self._notify(button_id, False, msg)
            return False, msg

        norm_target = os.path.normpath(target)
        try:
            if sys.platform == "win32":
                # Use ShellExecuteW — the same API Windows Explorer uses.
                # Works for .exe, .lnk shortcuts, URLs, folders — no UAC prompt, no ding.
                args_str = action.args.strip() if action.args else None
                ret = ctypes.windll.shell32.ShellExecuteW(
                    None,           # hwnd (no parent window)
                    "open",         # verb
                    norm_target,    # file / shortcut / exe
                    args_str,       # parameters (None if no args)
                    None,           # working directory (None = default)
                    1               # SW_SHOWNORMAL
                )
                if ret > 32:
                    self._notify(button_id, True, f"Launched {Path(norm_target).name}")
                    return True, f"Launched {Path(norm_target).name}"
                else:
                    err_msg = f"ShellExecuteW returned error code {ret} for: {norm_target}"
                    logger.error(err_msg)
                    self._notify(button_id, False, err_msg)
                    return False, err_msg

            # Non-Windows fallback
            cmd = f'"{norm_target}"'
            if action.args:
                cmd += f" {action.args}"

            cwd = action.working_dir if action.working_dir and os.path.exists(action.working_dir) else None
            subprocess.Popen(cmd, cwd=cwd, shell=True)
            self._notify(button_id, True, f"Launched {norm_target}")
            return True, f"Launched {norm_target}"
        except Exception as e:
            err_msg = f"Failed to launch application {target}: {str(e)}"
            logger.error(err_msg)
            self._notify(button_id, False, err_msg)
            return False, err_msg

    def _exec_file_folder_url(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        target = action.target.strip().strip('"').strip("'")
        if not target:
            msg = "No target specified."
            self._notify(button_id, False, msg)
            return False, msg

        try:
            if target.startswith(("http://", "https://")):
                webbrowser.open(target)
                self._notify(button_id, True, f"Opened URL: {target}")
                return True, f"Opened URL: {target}"
            else:
                norm_target = os.path.normpath(target)
                if sys.platform == "win32":
                    ctypes.windll.shell32.ShellExecuteW(None, "open", norm_target, None, None, 1)
                else:
                    webbrowser.open(norm_target)
                self._notify(button_id, True, f"Opened {norm_target}")
                return True, f"Opened {norm_target}"
        except Exception as e:
            err_msg = f"Failed to open {target}: {str(e)}"
            logger.error(err_msg)
            self._notify(button_id, False, err_msg)
            return False, err_msg

    def _focus_window(self, name_fragment: str):
        if sys.platform != "win32":
            return
        try:
            user32 = ctypes.windll.user32
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)

            found_hwnds = []
            def enum_cb(hwnd, lparam):
                if user32.IsWindowVisible(hwnd):
                    length = user32.GetWindowTextLengthW(hwnd)
                    if length > 0:
                        buff = ctypes.create_unicode_buffer(length + 1)
                        user32.GetWindowTextW(hwnd, buff, length + 1)
                        if name_fragment in buff.value.lower():
                            found_hwnds.append(hwnd)
                return True

            user32.EnumWindows(WNDENUMPROC(enum_cb), 0)
            for h in found_hwnds:
                user32.ShowWindow(h, 9)  # SW_RESTORE (9)
                user32.SetForegroundWindow(h)
        except Exception:
            pass

    def _exec_hotkey(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        combo = action.target.strip()
        if not combo:
            msg = "No hotkey combo specified."
            self._notify(button_id, False, msg)
            return False, msg

        Win32KeyboardMouse.send_hotkey_combo(combo)
        self._notify(button_id, True, f"Sent hotkey {combo}")
        return True, f"Sent hotkey {combo}"

    def _exec_media(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        sub = action.sub_action or action.target
        sub = sub.lower().strip()

        vk_map = {
            # Play / Pause
            MEDIA_PLAY_PAUSE: VK_MEDIA_PLAY_PAUSE,
            "play_pause": VK_MEDIA_PLAY_PAUSE,
            "play": VK_MEDIA_PLAY_PAUSE,
            "pause": VK_MEDIA_PLAY_PAUSE,
            "playpause": VK_MEDIA_PLAY_PAUSE,

            # Next Track
            MEDIA_NEXT: VK_MEDIA_NEXT_TRACK,
            "next_track": VK_MEDIA_NEXT_TRACK,
            "nexttrack": VK_MEDIA_NEXT_TRACK,
            "next": VK_MEDIA_NEXT_TRACK,

            # Previous Track
            MEDIA_PREV: VK_MEDIA_PREV_TRACK,
            "prev_track": VK_MEDIA_PREV_TRACK,
            "prevtrack": VK_MEDIA_PREV_TRACK,
            "prev": VK_MEDIA_PREV_TRACK,
            "previous": VK_MEDIA_PREV_TRACK,
            "previous_track": VK_MEDIA_PREV_TRACK,
            "previoustrack": VK_MEDIA_PREV_TRACK,

            # Stop
            "stop": VK_MEDIA_STOP,

            # Volume
            MEDIA_VOLUME_UP: VK_VOLUME_UP,
            "volume_up": VK_VOLUME_UP,
            "volumeup": VK_VOLUME_UP,
            "vol_up": VK_VOLUME_UP,

            MEDIA_VOLUME_DOWN: VK_VOLUME_DOWN,
            "volume_down": VK_VOLUME_DOWN,
            "volumedown": VK_VOLUME_DOWN,
            "vol_down": VK_VOLUME_DOWN,

            MEDIA_VOLUME_MUTE: VK_VOLUME_MUTE,
            "volume_mute": VK_VOLUME_MUTE,
            "volumemute": VK_VOLUME_MUTE,
            "mute": VK_VOLUME_MUTE,
        }

        if sub in vk_map:
            Win32KeyboardMouse.tap_key(vk_map[sub])
            self._notify(button_id, True, f"Media action: {sub}")
            return True, f"Media action: {sub}"
        else:
            msg = f"Unknown media sub-action: {sub}"
            self._notify(button_id, False, msg)
            return False, msg

    def _exec_mouse(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        sub = action.sub_action or action.target or MOUSE_LEFT_CLICK
        Win32KeyboardMouse.send_mouse_click(sub)
        self._notify(button_id, True, f"Mouse action: {sub}")
        return True, f"Mouse action: {sub}"

    def _exec_system(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        sub = (action.sub_action or action.target).lower().strip()

        if sub == SYSTEM_LOCK:
            if sys.platform == "win32":
                ctypes.windll.user32.LockWorkStation()
            self._notify(button_id, True, "System Locked")
            return True, "System Locked"

        elif sub == SYSTEM_TASK_MANAGER:
            Win32KeyboardMouse.send_hotkey_combo("Ctrl+Shift+Esc")
            self._notify(button_id, True, "Opened Task Manager")
            return True, "Opened Task Manager"

        elif sub == SYSTEM_OPEN_SETTINGS:
            if sys.platform == "win32":
                os.system("start ms-settings:")
            self._notify(button_id, True, "Opened Settings")
            return True, "Opened Settings"

        elif sub == SYSTEM_SLEEP:
            if sys.platform == "win32":
                os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
            self._notify(button_id, True, "PC Sleeping")
            return True, "PC Sleeping"

        elif sub == SYSTEM_SHUTDOWN:
            if sys.platform == "win32":
                os.system("shutdown /s /t 10 /c \"TouchDeck Shutdown initiated\"")
            self._notify(button_id, True, "Shutdown scheduled")
            return True, "Shutdown scheduled"

        elif sub == SYSTEM_RESTART:
            if sys.platform == "win32":
                os.system("shutdown /r /t 10 /c \"TouchDeck Restart initiated\"")
            self._notify(button_id, True, "Restart scheduled")
            return True, "Restart scheduled"

        else:
            msg = f"Unknown system command: {sub}"
            self._notify(button_id, False, msg)
            return False, msg

    def _exec_file_folder_url(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        target = action.target.strip()
        if not target:
            msg = "No file, folder or URL specified."
            self._notify(button_id, False, msg)
            return False, msg

        if target.startswith("http://") or target.startswith("https://"):
            webbrowser.open(target)
            self._notify(button_id, True, f"Opened URL: {target}")
            return True, f"Opened URL: {target}"
        elif os.path.exists(target):
            if sys.platform == "win32":
                os.startfile(target)
            else:
                subprocess.Popen(["xdg-open", target])
            self._notify(button_id, True, f"Opened: {target}")
            return True, f"Opened: {target}"
        else:
            msg = f"Path not found: {target}"
            self._notify(button_id, False, msg)
            return False, msg

    def _exec_script(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        target = action.target.strip()
        if not target:
            msg = "No script content or path."
            self._notify(button_id, False, msg)
            return False, msg

        # Detect PowerShell or CMD
        if target.endswith(".ps1") or "powershell" in action.args.lower():
            cmd = f'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "{target}"'
        elif target.endswith(".py") or target.startswith("python "):
            cmd = target if target.startswith("python") else f"python {target}"
        else:
            cmd = target

        try:
            subprocess.Popen(
                cmd,
                shell=True,
                creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
            )
            self._notify(button_id, True, "Script executed")
            return True, "Script executed"
        except Exception as e:
            msg = f"Script execution error: {e}"
            self._notify(button_id, False, msg)
            return False, msg

    def _exec_macro(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        steps = action.macro_steps
        if not steps:
            msg = "Macro has no steps."
            self._notify(button_id, False, msg)
            return False, msg

        logger.info(f"Starting macro execution with {len(steps)} steps")
        for i, step in enumerate(steps):
            logger.info(f"Macro step {i+1}/{len(steps)}: {step.step_type} - {step.target}")
            step_action = ActionModel(
                action_type=step.step_type,
                target=step.target,
                args=step.args,
                sub_action=step.target if step.step_type in (ACTION_TYPE_MEDIA, ACTION_TYPE_SYSTEM) else ""
            )
            # Execute step
            self._execute_action_worker(step_action, button_id)

            # Wait delay if specified
            if step.delay_ms > 0:
                time.sleep(step.delay_ms / 1000.0)

        self._notify(button_id, True, f"Macro completed ({len(steps)} steps)")
        return True, f"Macro completed ({len(steps)} steps)"

    def _exec_discord(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        sub = (action.sub_action or action.target).strip().lower()
        custom_key = action.args.strip() if action.args else ""
        if sub == DISCORD_MUTE_MIC:
            combo = custom_key if (custom_key and custom_key != "Ctrl+Shift+D") else "Ctrl+Shift+M"
            label = "Discord Mikrofon Mute"
        elif sub == DISCORD_DEAFEN:
            combo = custom_key if (custom_key and custom_key != "Ctrl+Shift+M") else "Ctrl+Shift+D"
            label = "Discord Dæmp Alt"
        elif sub == DISCORD_STREAM_TOGGLE:
            combo = custom_key if (custom_key and custom_key != "Ctrl+Shift+M") else "Ctrl+Shift+S"
            label = "Discord Skærmdeling"
        elif sub == DISCORD_PUSH_TO_TALK:
            combo = custom_key if (custom_key and custom_key != "Ctrl+Shift+M") else "Ctrl"
            label = "Discord Push-To-Talk"
        else:
            combo = action.target or custom_key or "Ctrl+Shift+M"
            label = "Discord"

        Win32KeyboardMouse.send_discord_hotkey(combo)
        self._notify(button_id, True, f"{label} ({combo})")
        return True, f"{label} ({combo})"

    def _exec_medal(self, action: ActionModel, button_id: str) -> Tuple[bool, str]:
        sub = (action.sub_action or "").strip().lower()
        if not sub and action.target:
            sub = action.target.strip().lower()

        default_combo = MEDAL_DEFAULT_HOTKEYS.get(sub, "F8")
        custom_key = action.args.strip() if action.args else ""
        known_defaults = [k.upper() for k in MEDAL_DEFAULT_HOTKEYS.values()]

        # Only use custom_key if user deliberately entered a non-default key override
        if custom_key and custom_key.upper() not in known_defaults:
            combo = custom_key
        else:
            combo = default_combo

        Win32KeyboardMouse.send_hotkey_combo(combo)
        dur_label = "Klip"
        if "15" in sub: dur_label = "Klip 15s"
        elif "30" in sub: dur_label = "Klip 30s"
        elif "1m" in sub: dur_label = "Klip 1 min"
        elif "2m" in sub: dur_label = "Klip 2 min"
        elif "5m" in sub: dur_label = "Klip 5 min"
        elif sub == MEDAL_RECORD_TOGGLE: dur_label = "Optagelse Toggle"
        elif sub == MEDAL_BOOKMARK: dur_label = "Bogmærke"

        self._notify(button_id, True, f"Medal {dur_label} ({combo})")
        return True, f"Medal {dur_label} ({combo})"

