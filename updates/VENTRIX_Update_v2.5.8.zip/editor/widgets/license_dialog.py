"""
VENTRIX Studio - Apple Glass License Activation Dialog
Frameless frosted obsidian glass modal for entering and verifying license keys.
Styled identically to the Update Dialog and Stream Deck chassis.
Author: VENTRIX
"""

import os
import sys
import webbrowser
from pathlib import Path
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFrame
)
from PySide6.QtGui import (
    QPainter, QColor, QFont, QPen, QRadialGradient, QLinearGradient,
    QPainterPath, QPixmap
)
from PySide6.QtCore import Qt, Signal, QPoint, QRectF

from shared.license_manager import verify_license_key, save_license, get_license_info


def get_resource_path(relative_path: str) -> Path:
    """Get absolute path to resource, compatible with dev and PyInstaller."""
    if hasattr(sys, "_MEIPASS"):
        p = Path(sys._MEIPASS) / relative_path
        if p.exists():
            return p
    p = Path(__file__).parent.parent.parent / relative_path
    if p.exists():
        return p
    return Path(relative_path)


class CircleCloseButton(QPushButton):
    """Vector-rendered Apple close button: perfectly centered, crisp anti-aliased cross."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(28, 28)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("background: transparent; border: none; outline: none;")
        self._hover = False

    def enterEvent(self, event):
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        rect = self.rect()

        # Zero circle background! ONLY the floating cross
        x_pen = QPen(QColor(255, 255, 255, 255) if self._hover else QColor(160, 160, 168, 220), 1.8)
        x_pen.setCapStyle(Qt.RoundCap)
        p.setPen(x_pen)

        cx = rect.center().x()
        cy = rect.center().y()
        offset = 5
        p.drawLine(cx - offset, cy - offset, cx + offset, cy + offset)
        p.drawLine(cx + offset, cy - offset, cx - offset, cy + offset)
        p.end()


class LicenseGlassCard(QFrame):
    """Deep frosted obsidian glass card with ambient Apple halo, matching UpdateDialog."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("licenseGlassCard")

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect()
        path = QPainterPath()
        path.addRoundedRect(rect.adjusted(1, 1, -1, -1), 24, 24)

        # Obsidian frosted background
        painter.fillPath(path, QColor(16, 18, 24, 245))

        # Soft top lighting halo
        halo = QRadialGradient(rect.center().x(), rect.top() + 20, rect.width() * 0.7)
        halo.setColorAt(0.0, QColor(255, 255, 255, 20))
        halo.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.setPen(Qt.NoPen)
        painter.setBrush(halo)
        painter.drawRoundedRect(rect.adjusted(2, 2, -2, int(rect.height() * 0.45)), 24, 24)

        # Subtle white rim border
        border_pen = QPen(QColor(255, 255, 255, 30), 1.2)
        painter.setPen(border_pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(path)


class LicenseActivationDialog(QDialog):
    """
    Apple Glass modal dialog for activating VENTRIX Studio.
    """

    activated = Signal(str)

    def __init__(self, parent=None, cancellable: bool = True):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setModal(True)
        self.setFixedSize(480, 500)

        self._drag_pos = QPoint()
        self.cancellable = cancellable
        self._is_activated = False

        self._init_ui()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and not self._drag_pos.isNull():
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(10, 10, 10, 10)

        self.card = LicenseGlassCard(parent=self)
        card_lay = QVBoxLayout(self.card)
        card_lay.setContentsMargins(32, 22, 32, 26)
        card_lay.setSpacing(12)
        card_lay.setAlignment(Qt.AlignCenter)

        # Top Close Button Row
        top_row = QHBoxLayout()
        top_row.addStretch()
        if self.cancellable:
            close_btn = CircleCloseButton()
            close_btn.clicked.connect(self.reject)
            top_row.addWidget(close_btn)
        else:
            dummy = QFrame()
            dummy.setFixedHeight(28)
            top_row.addWidget(dummy)
        card_lay.addLayout(top_row)

        # 1. Authentic 3D Stream Deck Hardware Logo
        self.logo_lbl = QLabel()
        self.logo_lbl.setFixedSize(72, 72)
        self.logo_lbl.setAlignment(Qt.AlignCenter)
        logo_path = get_resource_path("assets/ventrix.png")
        if logo_path.exists():
            pix = QPixmap(str(logo_path)).scaled(64, 64, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.logo_lbl.setPixmap(pix)
        card_lay.addWidget(self.logo_lbl, alignment=Qt.AlignCenter)

        # 2. Titles
        title_lbl = QLabel("VENTRIX Studio")
        title_lbl.setStyleSheet("""
            background: transparent;
            border: none;
            font-size: 22px;
            font-weight: 700;
            color: #FFFFFF;
            letter-spacing: -0.4px;
            font-family: 'Segoe UI Variable Display', 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
        """)
        title_lbl.setAlignment(Qt.AlignCenter)
        card_lay.addWidget(title_lbl)

        subtitle_lbl = QLabel("Licensaktivering")
        subtitle_lbl.setStyleSheet("""
            background: transparent;
            border: none;
            font-size: 12px;
            color: #8E8E93;
            font-weight: 500;
            font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif;
        """)
        subtitle_lbl.setAlignment(Qt.AlignCenter)
        card_lay.addWidget(subtitle_lbl)

        # 3. Description
        desc_lbl = QLabel("Indtast din personlige licensnøgle fra hjemmesiden for at låse op for alle pro-funktioner.")
        desc_lbl.setWordWrap(True)
        desc_lbl.setAlignment(Qt.AlignCenter)
        desc_lbl.setStyleSheet("""
            background: transparent;
            border: none;
            color: #A1A1AA;
            font-size: 12px;
            line-height: 1.45;
            font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif;
        """)
        card_lay.addWidget(desc_lbl)

        # 4. Key Input Box
        self.key_input = QLineEdit()
        self.key_input.setObjectName("keyInput")
        self.key_input.setPlaceholderText("VTX-XXXX-XXXX-XXXX-XXXX")
        self.key_input.setAlignment(Qt.AlignCenter)
        self.key_input.setFixedHeight(44)
        self.key_input.setStyleSheet("""
            QLineEdit {
                background: rgba(22, 22, 26, 0.85);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.16);
                border-radius: 14px;
                font-family: 'Consolas', 'Cascadia Code', monospace;
                font-size: 14px;
                font-weight: 600;
                letter-spacing: 2px;
                padding: 0 14px;
            }
            QLineEdit:hover {
                border: 1px solid rgba(255, 255, 255, 0.28);
                background: rgba(28, 28, 34, 0.90);
            }
            QLineEdit:focus {
                border: 1px solid #FFFFFF;
                background: rgba(30, 30, 36, 0.95);
            }
        """)
        self.key_input.textChanged.connect(self._format_key)
        self.key_input.returnPressed.connect(self._attempt_activation)
        card_lay.addWidget(self.key_input)

        # Feedback label
        info = get_license_info()
        if info.get("expired", False):
            self.feedback_lbl = QLabel("⚠️ Din forrige licens er udløbet. Indtast en ny nøgle:")
            self.feedback_lbl.setStyleSheet("color: #EF4444; font-size: 12px; font-weight: 500; min-height: 18px;")
        else:
            self.feedback_lbl = QLabel("")
            self.feedback_lbl.setStyleSheet("font-size: 12px; font-weight: 500; min-height: 18px;")
        self.feedback_lbl.setAlignment(Qt.AlignCenter)
        card_lay.addWidget(self.feedback_lbl)

        # 5. Action Buttons (Clean rounded pill matching update dialog)
        self.activate_btn = QPushButton("Aktiver VENTRIX Studio")
        self.activate_btn.setObjectName("activateBtn")
        self.activate_btn.setFixedHeight(42)
        self.activate_btn.setCursor(Qt.PointingHandCursor)
        self.activate_btn.setStyleSheet("""
            QPushButton#activateBtn {
                background: #FFFFFF;
                color: #0A0A0C;
                border: 1px solid transparent;
                border-radius: 12px;
                font-size: 13px;
                font-weight: 700;
                font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;
            }
            QPushButton#activateBtn:hover {
                background: #EBEBF5;
            }
            QPushButton#activateBtn:pressed {
                background: #D1D1D6;
            }
            QPushButton#activateBtn:disabled {
                background: rgba(255, 255, 255, 0.22);
                color: rgba(0, 0, 0, 0.35);
            }
        """)
        self.activate_btn.clicked.connect(self._attempt_activation)
        card_lay.addWidget(self.activate_btn)

        # Get Free License link button
        self.web_btn = QPushButton("Hent Gratis Licens på Hjemmesiden →")
        self.web_btn.setCursor(Qt.PointingHandCursor)
        self.web_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #8E8E93;
                border: none;
                font-size: 12px;
                font-weight: 500;
                font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif;
            }
            QPushButton:hover {
                color: #FFFFFF;
                text-decoration: underline;
            }
        """)
        self.web_btn.clicked.connect(self._open_website)
        card_lay.addWidget(self.web_btn)

        root_lay.addWidget(self.card)

    def _format_key(self, text: str):
        clean = text.upper().replace(" ", "")
        self.key_input.blockSignals(True)
        self.key_input.setText(clean)
        self.key_input.blockSignals(False)

    def _attempt_activation(self):
        key = self.key_input.text().strip()
        if not key:
            self.feedback_lbl.setText("Indtast venligst en licensnøgle.")
            self.feedback_lbl.setStyleSheet("color: #EF4444; font-size: 12px;")
            return

        if verify_license_key(key):
            save_license(key)
            self._is_activated = True
            info = get_license_info()
            tier = info.get("tier", "Lifetime")
            if tier == "Lifetime":
                self.feedback_lbl.setText("✓ Lifetime licens godkendt! Udløber aldrig.")
            elif tier == "1 Måned":
                self.feedback_lbl.setText("✓ 1 Måned licens godkendt! Gyldig i 30 dage.")
            elif tier == "1 Uge":
                self.feedback_lbl.setText("✓ 1 Uge licens godkendt! Gyldig i 7 dage.")
            else:
                self.feedback_lbl.setText("✓ Licens godkendt! Låser op...")
            self.feedback_lbl.setStyleSheet("color: #22C55E; font-size: 12px; font-weight: 600;")
            self.activate_btn.setEnabled(False)
            self.key_input.setEnabled(False)
            self.activated.emit(key)
            from PySide6.QtCore import QTimer
            QTimer.singleShot(700, self.accept)
        else:
            self.feedback_lbl.setText("Ugyldig licensnøgle. Tjek formatet og prøv igen.")
            self.feedback_lbl.setStyleSheet("color: #EF4444; font-size: 12px; font-weight: 500;")

    def _open_website(self):
        local_site = Path(r"C:\Users\olive\Desktop\ventrix-website\index.html")
        if local_site.exists():
            webbrowser.open(local_site.as_uri())
        else:
            webbrowser.open("https://ventrix-website.vercel.app")
