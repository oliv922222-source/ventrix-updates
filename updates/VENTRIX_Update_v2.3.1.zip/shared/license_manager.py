"""
VENTRIX Studio - License Manager
Handles cryptographic license key validation and local license persistence.
Format: VTX-XXXX-XXXX-XXXX-YYYY
"""

import os
import json
import hashlib
from pathlib import Path

ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
SALT = "VENTRIX_STUDIO_SALT_2026"


def _get_license_file() -> Path:
    """Returns the persistent path where the license key is stored."""
    base = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "VENTRIX"
    base.mkdir(parents=True, exist_ok=True)
    return base / "license.json"


def compute_checksum(payload: str) -> str:
    """Computes a 4-character cryptographic checksum from 12 payload characters."""
    h = hashlib.sha256((payload + SALT).encode("utf-8")).hexdigest()
    val = int(h[:8], 16)
    chk = []
    for _ in range(4):
        chk.append(ALPHABET[val % len(ALPHABET)])
        val //= len(ALPHABET)
    return "".join(chk)


def verify_license_key(key: str) -> bool:
    """Validates if a given license key is cryptographically genuine."""
    if not key or not isinstance(key, str):
        return False
    clean = key.strip().upper().replace(" ", "")
    parts = clean.split("-")
    if len(parts) != 5:
        return False
    if parts[0] != "VTX":
        return False
    for p in parts[1:]:
        if len(p) != 4 or any(c not in ALPHABET for c in p):
            return False
    payload = "".join(parts[1:4])
    expected_chk = compute_checksum(payload)
    return parts[4] == expected_chk


def is_licensed() -> bool:
    """Checks if the application currently has a valid, stored license."""
    lic_file = _get_license_file()
    if not lic_file.exists():
        return False
    try:
        data = json.loads(lic_file.read_text(encoding="utf-8"))
        saved_key = data.get("license_key", "")
        return verify_license_key(saved_key)
    except Exception:
        return False


def save_license(key: str) -> bool:
    """Validates and permanently stores the license key."""
    if not verify_license_key(key):
        return False
    clean = key.strip().upper().replace(" ", "")
    lic_file = _get_license_file()
    try:
        data = {
            "license_key": clean,
            "product": "VENTRIX Studio",
            "tier": "Pro Lifetime",
            "activated_at": os.environ.get("LOCALTIME", "")
        }
        lic_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False


def get_license_info() -> dict:
    """Returns details about current license status."""
    lic_file = _get_license_file()
    if not lic_file.exists():
        return {"licensed": False, "key": None, "tier": "Uaktiveret"}
    try:
        data = json.loads(lic_file.read_text(encoding="utf-8"))
        key = data.get("license_key", "")
        if verify_license_key(key):
            masked = f"{key[:8]}****-****{key[-5:]}"
            return {"licensed": True, "key": masked, "tier": "VENTRIX Studio Pro"}
    except Exception:
        pass
    return {"licensed": False, "key": None, "tier": "Uaktiveret"}


def remove_license() -> bool:
    """Deactivates and removes current license."""
    lic_file = _get_license_file()
    if lic_file.exists():
        try:
            lic_file.unlink()
            return True
        except Exception:
            return False
    return True
