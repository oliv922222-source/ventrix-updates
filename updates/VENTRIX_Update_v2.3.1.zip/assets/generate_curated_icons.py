"""
Script to generate ultra-sharp white monochrome vector icons for VENTRIX.
Includes media controls, system controls, navigation, and popular apps.
"""
from pathlib import Path
from PIL import Image, ImageDraw

ICONS_DIR = Path(__file__).parent / "icons"
ICONS_DIR.mkdir(exist_ok=True, parents=True)

SIZE = 128  # High-res master size

def create_icon_canvas():
    return Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))

def save_icon(img: Image.Image, name: str):
    # Save 128x128 high-res
    out_path = ICONS_DIR / f"{name}.png"
    img.save(out_path, "PNG")
    print(f"Generated {out_path.name}")

def gen_play():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Triangle pointing right
    points = [(42, 28), (42, 100), (98, 64)]
    d.polygon(points, fill=(255, 255, 255, 240))
    save_icon(im, "play")

def gen_pause():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Two vertical bars
    d.rounded_rectangle([36, 28, 54, 100], radius=5, fill=(255, 255, 255, 240))
    d.rounded_rectangle([74, 28, 92, 100], radius=5, fill=(255, 255, 255, 240))
    save_icon(im, "pause")

def gen_play_pause():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Left: small play triangle, Right: pause bar
    d.polygon([(30, 36), (30, 92), (64, 64)], fill=(255, 255, 255, 240))
    d.rounded_rectangle([76, 36, 86, 92], radius=3, fill=(255, 255, 255, 240))
    d.rounded_rectangle([94, 36, 104, 92], radius=3, fill=(255, 255, 255, 240))
    save_icon(im, "play_pause")

def gen_next():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Next: triangle + bar
    d.polygon([(36, 32), (36, 96), (78, 64)], fill=(255, 255, 255, 240))
    d.rounded_rectangle([84, 32, 94, 96], radius=3, fill=(255, 255, 255, 240))
    save_icon(im, "next")

def gen_prev():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Prev: bar + triangle pointing left
    d.rounded_rectangle([34, 32, 44, 96], radius=3, fill=(255, 255, 255, 240))
    d.polygon([(92, 32), (92, 96), (50, 64)], fill=(255, 255, 255, 240))
    save_icon(im, "prev")

def gen_stop():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([34, 34, 94, 94], radius=8, fill=(255, 255, 255, 240))
    save_icon(im, "stop")

def gen_volume_up():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Speaker body
    d.polygon([(26, 48), (44, 48), (66, 30), (66, 98), (44, 80), (26, 80)], fill=(255, 255, 255, 240))
    # Sound arcs
    d.arc([52, 42, 86, 86], -50, 50, fill=(255, 255, 255, 240), width=6)
    d.arc([46, 26, 106, 102], -50, 50, fill=(255, 255, 255, 240), width=6)
    save_icon(im, "volume_up")

def gen_volume_down():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Speaker body
    d.polygon([(28, 48), (46, 48), (68, 30), (68, 98), (46, 80), (28, 80)], fill=(255, 255, 255, 240))
    # Single small arc
    d.arc([54, 44, 88, 84], -50, 50, fill=(255, 255, 255, 240), width=6)
    save_icon(im, "volume_down")

def gen_volume_mute():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.polygon([(24, 48), (42, 48), (64, 30), (64, 98), (42, 80), (24, 80)], fill=(255, 255, 255, 240))
    # X cross
    d.line([(80, 50), (104, 78)], fill=(255, 255, 255, 240), width=6)
    d.line([(104, 50), (80, 78)], fill=(255, 255, 255, 240), width=6)
    save_icon(im, "volume_mute")

def gen_power():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Circle arc open at top
    d.arc([30, 30, 98, 98], -60, 240, fill=(255, 255, 255, 240), width=8)
    # Center vertical line
    d.rounded_rectangle([60, 20, 68, 62], radius=4, fill=(255, 255, 255, 240))
    save_icon(im, "power")

def gen_lock():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Shackle
    d.arc([44, 24, 84, 68], 180, 360, fill=(255, 255, 255, 240), width=7)
    d.line([(44, 46), (44, 60)], fill=(255, 255, 255, 240), width=7)
    d.line([(84, 46), (84, 60)], fill=(255, 255, 255, 240), width=7)
    # Padlock body
    d.rounded_rectangle([34, 58, 94, 104], radius=10, fill=(255, 255, 255, 240))
    # Keyhole
    d.ellipse([59, 72, 69, 82], fill=(20, 20, 24, 255))
    d.rectangle([62, 78, 66, 92], fill=(20, 20, 24, 255))
    save_icon(im, "lock")

def gen_sleep():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Crescent moon
    d.arc([28, 28, 100, 100], -90, 150, fill=(255, 255, 255, 240), width=10)
    save_icon(im, "sleep")

def gen_mic():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Capsule
    d.rounded_rectangle([52, 24, 76, 74], radius=12, fill=(255, 255, 255, 240))
    # Cradle arc
    d.arc([40, 44, 88, 88], 0, 180, fill=(255, 255, 255, 240), width=6)
    # Stand
    d.line([(64, 88), (64, 102)], fill=(255, 255, 255, 240), width=6)
    d.line([(48, 102), (80, 102)], fill=(255, 255, 255, 240), width=6)
    save_icon(im, "mic")

def gen_mic_mute():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([52, 24, 76, 74], radius=12, fill=(255, 255, 255, 240))
    d.arc([40, 44, 88, 88], 0, 180, fill=(255, 255, 255, 240), width=6)
    d.line([(64, 88), (64, 102)], fill=(255, 255, 255, 240), width=6)
    d.line([(48, 102), (80, 102)], fill=(255, 255, 255, 240), width=6)
    # Red/white slash across
    d.line([(32, 30), (96, 98)], fill=(239, 68, 68, 240), width=7)
    save_icon(im, "mic_mute")

def gen_screenshot():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Viewfinder corners
    s = 28
    e = 100
    len_arm = 18
    w = 7
    # Top-left
    d.line([(s, s), (s + len_arm, s)], fill=(255, 255, 255, 240), width=w)
    d.line([(s, s), (s, s + len_arm)], fill=(255, 255, 255, 240), width=w)
    # Top-right
    d.line([(e, s), (e - len_arm, s)], fill=(255, 255, 255, 240), width=w)
    d.line([(e, s), (e, s + len_arm)], fill=(255, 255, 255, 240), width=w)
    # Bottom-left
    d.line([(s, e), (s + len_arm, e)], fill=(255, 255, 255, 240), width=w)
    d.line([(s, e), (s, e - len_arm)], fill=(255, 255, 255, 240), width=w)
    # Bottom-right
    d.line([(e, e), (e - len_arm, e)], fill=(255, 255, 255, 240), width=w)
    d.line([(e, e), (e, e - len_arm)], fill=(255, 255, 255, 240), width=w)
    # Center dot
    d.ellipse([58, 58, 70, 70], fill=(255, 255, 255, 240))
    save_icon(im, "screenshot")

def gen_camera():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([26, 42, 102, 98], radius=10, fill=(255, 255, 255, 240))
    d.rounded_rectangle([48, 30, 80, 42], radius=4, fill=(255, 255, 255, 240))
    d.ellipse([50, 56, 78, 84], fill=(20, 20, 24, 255))
    save_icon(im, "camera")

def gen_nav_arrows():
    # Left
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.line([(88, 64), (40, 64)], fill=(255, 255, 255, 240), width=8)
    d.line([(60, 44), (40, 64), (60, 84)], fill=(255, 255, 255, 240), width=8)
    save_icon(im, "arrow_left")

    # Right
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.line([(40, 64), (88, 64)], fill=(255, 255, 255, 240), width=8)
    d.line([(68, 44), (88, 64), (68, 84)], fill=(255, 255, 255, 240), width=8)
    save_icon(im, "arrow_right")

    # Up
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.line([(64, 88), (64, 40)], fill=(255, 255, 255, 240), width=8)
    d.line([(44, 60), (64, 40), (84, 60)], fill=(255, 255, 255, 240), width=8)
    save_icon(im, "arrow_up")

    # Down
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.line([(64, 40), (64, 88)], fill=(255, 255, 255, 240), width=8)
    d.line([(44, 68), (64, 88), (84, 68)], fill=(255, 255, 255, 240), width=8)
    save_icon(im, "arrow_down")

def gen_home():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Roof
    d.polygon([(64, 26), (28, 58), (100, 58)], fill=(255, 255, 255, 240))
    # Walls
    d.rectangle([38, 58, 90, 100], fill=(255, 255, 255, 240))
    # Door
    d.rounded_rectangle([54, 72, 74, 100], radius=3, fill=(20, 20, 24, 255))
    save_icon(im, "home")

def gen_refresh():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.arc([32, 32, 96, 96], 40, 310, fill=(255, 255, 255, 240), width=8)
    # Arrowhead
    d.polygon([(82, 30), (102, 38), (88, 58)], fill=(255, 255, 255, 240))
    save_icon(im, "refresh")

def gen_brightness():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Center circle
    d.ellipse([46, 46, 82, 82], fill=(255, 255, 255, 240))
    # 8 rays
    rays = [
        [(64, 22), (64, 34)],
        [(64, 94), (64, 106)],
        [(22, 64), (34, 64)],
        [(94, 64), (106, 64)],
        [(34, 34), (43, 43)],
        [(85, 85), (94, 94)],
        [(94, 34), (85, 43)],
        [(34, 94), (43, 85)]
    ]
    for r in rays:
        d.line(r, fill=(255, 255, 255, 240), width=6)
    save_icon(im, "brightness")

def gen_discord():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Controller shape
    d.rounded_rectangle([28, 36, 100, 92], radius=16, fill=(255, 255, 255, 240))
    # Eyes
    d.ellipse([44, 54, 58, 72], fill=(20, 20, 24, 255))
    d.ellipse([70, 54, 84, 72], fill=(20, 20, 24, 255))
    save_icon(im, "discord")

def gen_medal():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Medal ribbon ribbons
    d.polygon([(40, 22), (56, 22), (64, 52), (48, 52)], fill=(255, 255, 255, 200))
    d.polygon([(88, 22), (72, 22), (64, 52), (80, 52)], fill=(255, 255, 255, 200))
    # Medal circle
    d.ellipse([34, 46, 94, 106], fill=(255, 255, 255, 240))
    # Inner border
    d.ellipse([43, 55, 85, 97], outline=(20, 20, 24, 255), width=4)
    # Center 'M'
    d.polygon([(52, 84), (52, 68), (64, 78), (76, 68), (76, 84), (70, 84), (70, 75), (64, 81), (58, 75), (58, 84)], fill=(20, 20, 24, 255))
    save_icon(im, "medal")

def gen_spotify():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.ellipse([26, 26, 102, 102], fill=(255, 255, 255, 240))
    # Sound curves
    d.arc([36, 42, 92, 82], 200, 340, fill=(20, 20, 24, 255), width=7)
    d.arc([42, 54, 86, 90], 200, 340, fill=(20, 20, 24, 255), width=6)
    d.arc([48, 66, 80, 98], 200, 340, fill=(20, 20, 24, 255), width=5)
    save_icon(im, "spotify")

def gen_youtube():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([26, 36, 102, 92], radius=16, fill=(255, 255, 255, 240))
    # Play triangle inside
    d.polygon([(54, 48), (54, 80), (80, 64)], fill=(20, 20, 24, 255))
    save_icon(im, "youtube")

def gen_obs():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Three concentric spinning blades/ring
    d.ellipse([28, 28, 100, 100], outline=(255, 255, 255, 240), width=8)
    d.ellipse([46, 46, 82, 82], fill=(255, 255, 255, 240))
    save_icon(im, "obs")

def gen_code():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # < > and /
    d.line([(48, 44), (32, 64), (48, 84)], fill=(255, 255, 255, 240), width=7)
    d.line([(80, 44), (96, 64), (80, 84)], fill=(255, 255, 255, 240), width=7)
    d.line([(70, 40), (58, 88)], fill=(255, 255, 255, 240), width=7)
    save_icon(im, "code")

def gen_terminal():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([24, 30, 104, 98], radius=10, outline=(255, 255, 255, 240), width=7)
    # Prompt > _
    d.line([(38, 52), (52, 64), (38, 76)], fill=(255, 255, 255, 240), width=6)
    d.line([(60, 78), (76, 78)], fill=(255, 255, 255, 240), width=6)
    save_icon(im, "terminal")

def gen_browser():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.ellipse([28, 28, 100, 100], outline=(255, 255, 255, 240), width=7)
    d.line([(28, 64), (100, 64)], fill=(255, 255, 255, 240), width=6)
    d.ellipse([44, 28, 84, 100], outline=(255, 255, 255, 240), width=6)
    save_icon(im, "browser")

def gen_steam():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.ellipse([26, 26, 102, 102], outline=(255, 255, 255, 240), width=8)
    d.ellipse([64, 40, 88, 64], fill=(255, 255, 255, 240))
    d.line([(44, 82), (72, 54)], fill=(255, 255, 255, 240), width=10)
    d.ellipse([34, 72, 54, 92], fill=(255, 255, 255, 240))
    save_icon(im, "steam")

def gen_game():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    # Gamepad body
    d.rounded_rectangle([24, 38, 104, 90], radius=18, fill=(255, 255, 255, 240))
    # D-pad
    d.line([(40, 64), (56, 64)], fill=(20, 20, 24, 255), width=5)
    d.line([(48, 56), (48, 72)], fill=(20, 20, 24, 255), width=5)
    # Action buttons
    d.ellipse([78, 56, 84, 62], fill=(20, 20, 24, 255))
    d.ellipse([88, 66, 94, 72], fill=(20, 20, 24, 255))
    save_icon(im, "game")

def gen_folder():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.polygon([(26, 40), (52, 40), (62, 50), (102, 50), (102, 92), (26, 92)], fill=(255, 255, 255, 240))
    save_icon(im, "folder")

def gen_settings():
    im = create_icon_canvas()
    d = ImageDraw.Draw(im)
    d.ellipse([46, 46, 82, 82], fill=(255, 255, 255, 240))
    d.ellipse([54, 54, 74, 74], fill=(20, 20, 24, 255))
    save_icon(im, "settings")

def main():
    gen_play()
    gen_pause()
    gen_play_pause()
    gen_next()
    gen_prev()
    gen_stop()
    gen_volume_up()
    gen_volume_down()
    gen_volume_mute()
    gen_power()
    gen_lock()
    gen_sleep()
    gen_mic()
    gen_mic_mute()
    gen_screenshot()
    gen_camera()
    gen_nav_arrows()
    gen_home()
    gen_refresh()
    gen_brightness()
    gen_discord()
    gen_medal()
    gen_spotify()
    gen_youtube()
    gen_obs()
    gen_code()
    gen_terminal()
    gen_browser()
    gen_steam()
    gen_game()
    gen_folder()
    gen_settings()
    print("All icons successfully generated!")

if __name__ == "__main__":
    main()
