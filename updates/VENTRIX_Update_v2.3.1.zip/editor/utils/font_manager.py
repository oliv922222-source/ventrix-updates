"""
TouchDeck - Font Manager & Visual Typography Catalog
Loads embedded TrueType fonts into QFontDatabase and provides
a curated catalog with visual previews and metadata.
"""

from pathlib import Path
from typing import List, Dict, Any, Optional
from PySide6.QtGui import QFontDatabase, QFont

_FONTS_INITIALIZED = False

FONT_CATALOG: List[Dict[str, Any]] = [
    {
        "id": "Fredoka",
        "name": "Fredoka Bubble",
        "category": "Bubble",
        "sample": "Bubble",
        "tag": "Sjov & Rund",
        "badge_color": "#EC4899",  # Pink
    },
    {
        "id": "Comic Sans MS",
        "name": "Comic Sans",
        "category": "Bubble",
        "sample": "Comic",
        "tag": "Tegneserie",
        "badge_color": "#F43F5E",
    },
    {
        "id": "Press Start 2P",
        "name": "Press Start",
        "category": "Gaming",
        "sample": "8-BIT",
        "tag": "Retro Pixel",
        "badge_color": "#10B981",  # Emerald
    },
    {
        "id": "Impact",
        "name": "Impact",
        "category": "Gaming",
        "sample": "HEAVY",
        "tag": "Esports / Meme",
        "badge_color": "#EAB308",  # Amber
    },
    {
        "id": "Orbitron",
        "name": "Orbitron",
        "category": "Cyber",
        "sample": "CYBER",
        "tag": "Sci-Fi HUD",
        "badge_color": "#06B6D4",  # Cyan
    },
    {
        "id": "Righteous",
        "name": "Righteous",
        "category": "Retro",
        "sample": "SYNTH",
        "tag": "80s Retro",
        "badge_color": "#8B5CF6",  # Violet
    },
    {
        "id": "Bungee",
        "name": "Bungee",
        "category": "Display",
        "sample": "BLOCK",
        "tag": "Ultra Block",
        "badge_color": "#F97316",  # Orange
    },
    {
        "id": "Pacifico",
        "name": "Pacifico",
        "category": "Cursive",
        "sample": "Script",
        "tag": "Neon Håndskrift",
        "badge_color": "#3B82F6",  # Blue
    },
    {
        "id": "Consolas",
        "name": "Consolas",
        "category": "Tech",
        "sample": "CODE",
        "tag": "Terminal Hacker",
        "badge_color": "#14B8A6",  # Teal
    },
    {
        "id": "Arial Black",
        "name": "Arial Black",
        "category": "Display",
        "sample": "BOLD",
        "tag": "Massiv Blok",
        "badge_color": "#64748B",  # Slate
    },
    {
        "id": "Segoe Script",
        "name": "Segoe Script",
        "category": "Cursive",
        "sample": "Flow",
        "tag": "Kalligrafi",
        "badge_color": "#A855F7",  # Purple
    },
    {
        "id": "Segoe UI",
        "name": "Segoe UI",
        "category": "Clean",
        "sample": "Clean",
        "tag": "Apple Glass Minimal",
        "badge_color": "#94A3B8",  # Gray
    },
    {
        "id": "Georgia",
        "name": "Georgia",
        "category": "Serif",
        "sample": "Serif",
        "tag": "Klassisk Elegance",
        "badge_color": "#D97706",  # Gold
    },
    {
        "id": "Trebuchet MS",
        "name": "Trebuchet",
        "category": "Clean",
        "sample": "Modern",
        "tag": "Høj Læselighed",
        "badge_color": "#38BDF8",  # Sky
    },
]


def init_application_fonts(custom_dir: Optional[Path] = None):
    """Load all TTF fonts from assets/fonts into QFontDatabase."""
    global _FONTS_INITIALIZED
    if _FONTS_INITIALIZED:
        return

    if not custom_dir:
        custom_dir = Path(__file__).parent.parent.parent / "assets" / "fonts"

    if custom_dir.exists() and custom_dir.is_dir():
        for font_file in custom_dir.glob("*.ttf"):
            try:
                QFontDatabase.addApplicationFont(str(font_file))
            except Exception:
                pass

    _FONTS_INITIALIZED = True


def get_font_catalog() -> List[Dict[str, Any]]:
    """Returns the list of all available fonts with display metadata."""
    init_application_fonts()
    return FONT_CATALOG


def resolve_button_font(font_family: Optional[str], font_size: int = 12, bold: bool = True) -> QFont:
    """Creates a QFont instance with fallback handling."""
    init_application_fonts()
    fam = font_family or "Segoe UI"
    weight = QFont.Bold if bold else QFont.Normal
    return QFont(fam, max(8, font_size), weight)
