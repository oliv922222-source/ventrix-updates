"""
TouchDeck - Macro Sequence Editor Dialog
Author: VENTRIX
"""

from typing import List
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QComboBox,
    QLineEdit, QSpinBox, QMessageBox, QFrame
)
from PySide6.QtCore import Qt, Signal

from shared.models import MacroStepModel, ActionModel
from shared.constants import (
    ACTION_TYPE_APPLICATION, ACTION_TYPE_HOTKEY, ACTION_TYPE_MEDIA,
    ACTION_TYPE_SCRIPT, COLOR_CARD, COLOR_BORDER, COLOR_PRIMARY_BLUE
)
from editor.actions.action_engine import ActionEngine


class MacroEditorDialog(QDialog):
    steps_saved = Signal(list)

    def __init__(self, steps: List[MacroStepModel], action_engine: ActionEngine, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Macro Sequence Builder")
        self.setFixedSize(680, 460)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)

        self.action_engine = action_engine
        self.steps = [MacroStepModel.from_dict(s.to_dict()) for s in steps]

        self._init_ui()
        self._refresh_table()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        header = QLabel("Configure Macro Steps")
        header.setStyleSheet("font-size: 15px; font-weight: 700;")
        layout.addWidget(header)

        sub = QLabel("Steps are executed sequentially from top to bottom with custom delays.")
        sub.setStyleSheet("color: #8B95A7; font-size: 12px;")
        layout.addWidget(sub)

        # Table of steps
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Step Type", "Target / Command", "Arguments", "Delay (ms)"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        layout.addWidget(self.table)

        # Action Buttons for table
        btn_bar = QHBoxLayout()
        add_btn = QPushButton("+ Add Step")
        add_btn.clicked.connect(self._add_step)
        btn_bar.addWidget(add_btn)

        remove_btn = QPushButton("- Remove Step")
        remove_btn.clicked.connect(self._remove_step)
        btn_bar.addWidget(remove_btn)

        up_btn = QPushButton("▲ Move Up")
        up_btn.clicked.connect(self._move_up)
        btn_bar.addWidget(up_btn)

        down_btn = QPushButton("▼ Move Down")
        down_btn.clicked.connect(self._move_down)
        btn_bar.addWidget(down_btn)

        btn_bar.addStretch()

        test_btn = QPushButton("▶ Test Run Macro")
        test_btn.clicked.connect(self._test_macro)
        btn_bar.addWidget(test_btn)

        layout.addLayout(btn_bar)

        # Dialog control buttons
        bottom_bar = QHBoxLayout()
        bottom_bar.addStretch()

        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        bottom_bar.addWidget(cancel_btn)

        save_btn = QPushButton("Save Macro")
        save_btn.setObjectName("primaryBtn")
        save_btn.clicked.connect(self._save_macro)
        bottom_bar.addWidget(save_btn)

        layout.addLayout(bottom_bar)

    def _refresh_table(self):
        self.table.setRowCount(len(self.steps))
        for row, step in enumerate(self.steps):
            # Step Type Combo
            type_combo = QComboBox()
            type_combo.addItems(["hotkey", "application", "media", "script", "delay"])
            type_combo.setCurrentText(step.step_type)
            type_combo.currentTextChanged.connect(lambda txt, r=row: self._on_type_changed(r, txt))
            self.table.setCellWidget(row, 0, type_combo)

            # Target Input
            target_edit = QLineEdit(step.target)
            target_edit.setPlaceholderText("e.g. Ctrl+Shift+Esc, obs64.exe, etc.")
            target_edit.textChanged.connect(lambda txt, r=row: self._on_target_changed(r, txt))
            self.table.setCellWidget(row, 1, target_edit)

            # Args Input
            args_edit = QLineEdit(step.args)
            args_edit.setPlaceholderText("Optional args")
            args_edit.textChanged.connect(lambda txt, r=row: self._on_args_changed(r, txt))
            self.table.setCellWidget(row, 2, args_edit)

            # Delay SpinBox
            delay_spin = QSpinBox()
            delay_spin.setRange(0, 30000)
            delay_spin.setSingleStep(50)
            delay_spin.setValue(step.delay_ms)
            delay_spin.valueChanged.connect(lambda val, r=row: self._on_delay_changed(r, val))
            self.table.setCellWidget(row, 3, delay_spin)

    def _on_type_changed(self, row: int, val: str):
        if row < len(self.steps):
            self.steps[row].step_type = val

    def _on_target_changed(self, row: int, val: str):
        if row < len(self.steps):
            self.steps[row].target = val

    def _on_args_changed(self, row: int, val: str):
        if row < len(self.steps):
            self.steps[row].args = val

    def _on_delay_changed(self, row: int, val: int):
        if row < len(self.steps):
            self.steps[row].delay_ms = val

    def _add_step(self):
        new_step = MacroStepModel(step_type="hotkey", target="Ctrl+C", delay_ms=250)
        self.steps.append(new_step)
        self._refresh_table()

    def _remove_step(self):
        cur = self.table.currentRow()
        if 0 <= cur < len(self.steps):
            del self.steps[cur]
            self._refresh_table()

    def _move_up(self):
        cur = self.table.currentRow()
        if cur > 0:
            self.steps[cur], self.steps[cur - 1] = self.steps[cur - 1], self.steps[cur]
            self._refresh_table()
            self.table.selectRow(cur - 1)

    def _move_down(self):
        cur = self.table.currentRow()
        if 0 <= cur < len(self.steps) - 1:
            self.steps[cur], self.steps[cur + 1] = self.steps[cur + 1], self.steps[cur]
            self._refresh_table()
            self.table.selectRow(cur + 1)

    def _test_macro(self):
        action = ActionModel(action_type="macro", macro_steps=self.steps)
        self.action_engine.execute_action_async(action, button_id="test_macro")

    def _save_macro(self):
        self.steps_saved.emit(self.steps)
        self.accept()
