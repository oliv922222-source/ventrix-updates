"""
TouchDeck - USB Deployment Tool Dialog
Safely detects removable USB media (e.g. ESD-USB) and creates bootable media with explicit confirmation guards.
Author: VENTRIX
"""

import os
import subprocess
from pathlib import Path
from typing import List, Optional

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QFrame,
    QMessageBox, QProgressBar
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor

try:
    from deployment.usb_creator import UsbDeploymentManager, UsbDriveInfo
except ImportError:
    UsbDeploymentManager = None
    UsbDriveInfo = None
from shared.constants import (
    COLOR_BG, COLOR_CARD, COLOR_BORDER, COLOR_PRIMARY_BLUE,
    COLOR_BRIGHT_BLUE, COLOR_WARNING, COLOR_ERROR, COLOR_SUCCESS,
    COLOR_TEXT_MAIN, COLOR_TEXT_MUTED
)


class UsbDeploymentDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("TouchDeck USB Creator & Deployment Tool")
        self.setFixedSize(660, 520)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)

        self.detected_drives: List[UsbDriveInfo] = []
        self.selected_drive: Optional[UsbDriveInfo] = None

        self._init_ui()
        self._scan_drives()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        # Header Info Card
        header_card = QFrame()
        header_card.setStyleSheet(f"background-color: #11141C; border: 1px solid {COLOR_BORDER}; border-radius: 10px; padding: 12px;")
        header_lay = QVBoxLayout(header_card)
        header_lay.setSpacing(6)

        title = QLabel("SURFACE BOOT MEDIA DEPLOYMENT")
        title.setStyleSheet("font-size: 13px; font-weight: 700; color: #F5F7FA; letter-spacing: 0.5px;")
        header_lay.addWidget(title)

        desc = QLabel(
            "Create bootable media for your Microsoft Surface. The Surface can boot directly into the "
            "dedicated TouchDeck appliance interface without showing the normal Windows desktop."
        )
        desc.setStyleSheet("color: #8B95A7; font-size: 11px;")
        desc.setWordWrap(True)
        header_lay.addWidget(desc)

        layout.addWidget(header_card)

        # Drive List Section
        drives_header = QHBoxLayout()
        lbl = QLabel("DETECTED REMOVABLE DRIVES")
        lbl.setStyleSheet("font-size: 11px; font-weight: 700; color: #8B95A7;")
        drives_header.addWidget(lbl)
        drives_header.addStretch()

        refresh_btn = QPushButton("↻ Refresh Drives")
        refresh_btn.clicked.connect(self._scan_drives)
        drives_header.addWidget(refresh_btn)
        layout.addLayout(drives_header)

        # Table
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Drive", "Volume Label", "Size", "Physical Disk", "Status"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.itemSelectionChanged.connect(self._on_drive_selection_changed)
        layout.addWidget(self.table)

        # Action Buttons
        action_box = QFrame()
        action_box.setStyleSheet(f"background-color: #11141C; border: 1px solid {COLOR_BORDER}; border-radius: 8px; padding: 10px;")
        action_lay = QHBoxLayout(action_box)
        action_lay.setSpacing(10)

        self.build_iso_btn = QPushButton("BUILD ISO")
        self.build_iso_btn.clicked.connect(self._build_iso)
        action_lay.addWidget(self.build_iso_btn)

        self.write_usb_btn = QPushButton("WRITE TO USB")
        self.write_usb_btn.setObjectName("primaryBtn")
        self.write_usb_btn.setEnabled(False)
        self.write_usb_btn.clicked.connect(self._write_to_usb_with_safety_guard)
        action_lay.addWidget(self.write_usb_btn)

        self.verify_usb_btn = QPushButton("VERIFY USB")
        self.verify_usb_btn.setEnabled(False)
        self.verify_usb_btn.clicked.connect(self._verify_usb)
        action_lay.addWidget(self.verify_usb_btn)

        self.open_usb_btn = QPushButton("OPEN USB")
        self.open_usb_btn.setEnabled(False)
        self.open_usb_btn.clicked.connect(self._open_usb)
        action_lay.addWidget(self.open_usb_btn)

        layout.addWidget(action_box)

        # Status / Progress
        self.status_label = QLabel("Select a removable USB drive to begin.")
        self.status_label.setStyleSheet("color: #8B95A7; font-size: 11px;")
        layout.addWidget(self.status_label)

        # Close button
        bottom_row = QHBoxLayout()
        bottom_row.addStretch()
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        bottom_row.addWidget(close_btn)
        layout.addLayout(bottom_row)

    def _scan_drives(self):
        if UsbDeploymentManager is None:
            self.detected_drives = []
            self.table.setRowCount(0)
            return
        self.detected_drives = UsbDeploymentManager.get_removable_drives()
        self.table.setRowCount(len(self.detected_drives))

        selected_row = -1
        for row, drv in enumerate(self.detected_drives):
            self.table.setItem(row, 0, QTableWidgetItem(drv.drive_letter))
            
            lbl_item = QTableWidgetItem(drv.volume_name)
            if drv.is_esd_usb():
                lbl_item.setForeground(QColor(COLOR_BRIGHT_BLUE))
                selected_row = row
            self.table.setItem(row, 1, lbl_item)

            self.table.setItem(row, 2, QTableWidgetItem(f"{drv.size_gb} GB"))
            self.table.setItem(row, 3, QTableWidgetItem(drv.physical_disk))

            status_item = QTableWidgetItem("Ready" if drv.is_esd_usb() else "Available")
            status_item.setForeground(QColor(COLOR_SUCCESS if drv.is_esd_usb() else COLOR_TEXT_MUTED))
            self.table.setItem(row, 4, status_item)

        if selected_row >= 0:
            self.table.selectRow(selected_row)
        elif len(self.detected_drives) > 0:
            self.table.selectRow(0)
        else:
            self.status_label.setText("No removable USB drives detected. Insert your ESD-USB drive and click Refresh.")

    def _on_drive_selection_changed(self):
        cur_row = self.table.currentRow()
        if 0 <= cur_row < len(self.detected_drives):
            self.selected_drive = self.detected_drives[cur_row]
            self.write_usb_btn.setEnabled(True)
            self.verify_usb_btn.setEnabled(True)
            self.open_usb_btn.setEnabled(True)
            self.status_label.setText(
                f"Selected: {self.selected_drive.drive_letter} ({self.selected_drive.volume_name}, {self.selected_drive.size_gb} GB)"
            )
        else:
            self.selected_drive = None
            self.write_usb_btn.setEnabled(False)
            self.verify_usb_btn.setEnabled(False)
            self.open_usb_btn.setEnabled(False)

    def _build_iso(self):
        self.status_label.setText("Building TouchDeck.iso boot environment...")
        iso_script = Path(__file__).parent.parent.parent / "boot" / "build_iso.py"
        try:
            res = subprocess.run([sys.executable, str(iso_script)], capture_output=True, text=True, timeout=30)
            if res.returncode == 0:
                QMessageBox.information(self, "ISO Build Complete", "TouchDeck.iso created successfully in boot/ output directory.")
                self.status_label.setText("TouchDeck.iso built successfully.")
            else:
                QMessageBox.warning(self, "ISO Build Warning", f"Build message:\n{res.stdout}\n{res.stderr}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not run ISO builder: {e}")

    def _write_to_usb_with_safety_guard(self):
        if not self.selected_drive:
            return

        # CRITICAL SAFETY GUARD CONFIRMATION
        warning_msg = (
            "WARNING:\n"
            "This operation will modify the selected USB drive.\n"
            "All data on the drive may be deleted.\n\n"
            f"Physical Disk: {self.selected_drive.physical_disk}\n"
            f"Drive Letter: {self.selected_drive.drive_letter}\n"
            f"Volume Label: {self.selected_drive.volume_name}\n"
            f"Capacity: {self.selected_drive.size_gb} GB\n\n"
            "Do you want to continue?"
        )

        reply = QMessageBox.warning(
            self,
            "CRITICAL USB CONFIRMATION",
            warning_msg,
            QMessageBox.Yes | QMessageBox.Cancel,
            QMessageBox.Cancel
        )

        if reply == QMessageBox.Yes:
            self.status_label.setText(f"Writing TouchDeck deployment files to {self.selected_drive.drive_letter}...")
            ok, msg = UsbDeploymentManager.stage_usb_deployment_files(
                self.selected_drive.drive_letter,
                Path(__file__).parent.parent.parent
            )
            if ok:
                QMessageBox.information(self, "USB Ready", f"TouchDeck USB created successfully on {self.selected_drive.drive_letter}!")
                self.status_label.setText("TouchDeck USB created successfully.")
            else:
                QMessageBox.critical(self, "Error", f"Failed to write to USB: {msg}")
                self.status_label.setText(f"Error: {msg}")

    def _verify_usb(self):
        if not self.selected_drive:
            return
        td_dir = Path(self.selected_drive.drive_letter) / "TouchDeck"
        if td_dir.exists():
            QMessageBox.information(self, "USB Verification", f"TouchDeck deployment folder verified on {self.selected_drive.drive_letter}.")
        else:
            QMessageBox.warning(self, "USB Verification", f"No TouchDeck deployment folder found on {self.selected_drive.drive_letter}.")

    def _open_usb(self):
        if self.selected_drive and os.path.exists(self.selected_drive.drive_letter):
            os.startfile(self.selected_drive.drive_letter)
