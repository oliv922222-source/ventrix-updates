"""
TouchDeck - Apple Glass Modal Dialogs & Sheets
Frameless, translucent glass modal dialogs that feel like native macOS sheets.
Replaces ugly Windows QInputDialog and QMessageBox with pure Apple glass.
Author: VENTRIX
"""

from typing import Tuple, Optional
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QWidget, QFrame, QGraphicsDropShadowEffect
)
from PySide6.QtGui import QPainter, QColor, QFont, QPen, QLinearGradient, QPainterPath
from PySide6.QtCore import Qt, Signal, QRectF

from editor.widgets.glass_widgets import GlassCard, GlassButton


class AppleGlassInputDialog(QDialog):
    """
    Frameless, translucent glass input dialog.
    Feels like a macOS sheet floating over the main window.
    """

    def __init__(self, title: str, prompt: str, text: str = "", parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setModal(True)
        self.setFixedSize(380, 210)

        self._result_text = ""
        self._accepted = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)

        # Translucent Glass Card
        self.card = GlassCard(corner_radius=18, parent=self)
        card_lay = QVBoxLayout(self.card)
        card_lay.setContentsMargins(24, 20, 24, 20)
        card_lay.setSpacing(12)

        # Title
        self.title_lbl = QLabel(title)
        self.title_lbl.setStyleSheet("color: #FFFFFF; font-size: 15px; font-weight: 600; letter-spacing: -0.2px;")
        card_lay.addWidget(self.title_lbl)

        # Prompt
        self.prompt_lbl = QLabel(prompt)
        self.prompt_lbl.setStyleSheet("color: #8E8E93; font-size: 12px;")
        card_lay.addWidget(self.prompt_lbl)

        # Text input
        self.input_field = QLineEdit(text)
        self.input_field.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.07);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 8px;
                padding: 8px 12px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border: 1px solid rgba(255, 255, 255, 0.4);
                background: rgba(255, 255, 255, 0.10);
            }
        """)
        self.input_field.returnPressed.connect(self._on_confirm)
        card_lay.addWidget(self.input_field)

        card_lay.addSpacing(6)

        # Bottom Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        btn_row.addStretch()

        self.cancel_btn = QPushButton("Annuller")
        self.cancel_btn.setFixedSize(85, 30)
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 7px;
                font-size: 12px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.12);
            }
        """)
        self.cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(self.cancel_btn)

        self.confirm_btn = QPushButton("Gem")
        self.confirm_btn.setObjectName("pushBtn")
        self.confirm_btn.setFixedSize(85, 30)
        self.confirm_btn.setCursor(Qt.PointingHandCursor)
        self.confirm_btn.clicked.connect(self._on_confirm)
        btn_row.addWidget(self.confirm_btn)

        card_lay.addLayout(btn_row)
        lay.addWidget(self.card)

        # Center over parent if available
        if parent:
            parent_rect = parent.geometry()
            self.move(
                parent_rect.center().x() - self.width() // 2,
                parent_rect.center().y() - self.height() // 2
            )

        self.input_field.setFocus()
        self.input_field.selectAll()

    def _on_confirm(self):
        self._result_text = self.input_field.text().strip()
        self._accepted = True
        self.accept()

    @classmethod
    def get_text(cls, parent, title: str, prompt: str, text: str = "") -> Tuple[str, bool]:
        dlg = cls(title, prompt, text, parent)
        res = dlg.exec()
        if res == QDialog.Accepted and dlg._accepted:
            return dlg._result_text, True
        return "", False


class AppleGlassConfirmDialog(QDialog):
    """
    Frameless, translucent glass confirmation modal dialog.
    Used for delete warnings and notices without opening native OS dialogs.
    """

    def __init__(self, title: str, message: str, confirm_text: str = "Bekræft", is_danger: bool = False, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setModal(True)
        self.setFixedSize(380, 180)

        self._confirmed = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)

        self.card = GlassCard(corner_radius=18, parent=self)
        card_lay = QVBoxLayout(self.card)
        card_lay.setContentsMargins(24, 20, 24, 20)
        card_lay.setSpacing(10)

        self.title_lbl = QLabel(title)
        self.title_lbl.setStyleSheet("color: #FFFFFF; font-size: 15px; font-weight: 600; letter-spacing: -0.2px;")
        card_lay.addWidget(self.title_lbl)

        self.msg_lbl = QLabel(message)
        self.msg_lbl.setWordWrap(True)
        self.msg_lbl.setStyleSheet("color: #8E8E93; font-size: 12px; line-height: 1.4;")
        card_lay.addWidget(self.msg_lbl)

        card_lay.addSpacing(6)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        btn_row.addStretch()

        self.cancel_btn = QPushButton("Annuller")
        self.cancel_btn.setFixedSize(85, 30)
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 7px;
                font-size: 12px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.12);
            }
        """)
        self.cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(self.cancel_btn)

        self.confirm_btn = QPushButton(confirm_text)
        if is_danger:
            self.confirm_btn.setObjectName("dangerBtn")
        else:
            self.confirm_btn.setObjectName("pushBtn")
        self.confirm_btn.setFixedSize(85, 30)
        self.confirm_btn.clicked.connect(self._on_confirm)
        btn_row.addWidget(self.confirm_btn)

        card_lay.addLayout(btn_row)
        lay.addWidget(self.card)

        if parent:
            parent_rect = parent.geometry()
            self.move(
                parent_rect.center().x() - self.width() // 2,
                parent_rect.center().y() - self.height() // 2
            )

    def _on_confirm(self):
        self._confirmed = True
        self.accept()

    @classmethod
    def ask(cls, parent, title: str, message: str, confirm_text: str = "Bekræft", is_danger: bool = False) -> bool:
        dlg = cls(title, message, confirm_text, is_danger, parent)
        res = dlg.exec()
        return res == QDialog.Accepted and dlg._confirmed

    @classmethod
    def alert(cls, parent, title: str, message: str):
        dlg = cls(title, message, confirm_text="OK", is_danger=False, parent=parent)
        dlg.cancel_btn.setVisible(False)
        dlg.exec()
