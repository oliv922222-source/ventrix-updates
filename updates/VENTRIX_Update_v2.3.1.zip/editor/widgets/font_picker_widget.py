"""
TouchDeck - Visual Apple Glass Font Picker Widget
Interactive gallery with live rendered font sample cards, category tags,
and real-time selection.
"""

from typing import Optional, List, Dict, Any
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea,
    QFrame, QButtonGroup, QPushButton
)
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QFont
from PySide6.QtCore import Qt, Signal, QRectF, QPoint

from editor.utils.font_manager import get_font_catalog, init_application_fonts


class FontCard(QFrame):
    """
    Individual tactile font preview card.
    Renders actual font geometry with category tag and selection halo.
    """
    clicked = Signal(str)  # font_id

    def __init__(self, font_info: Dict[str, Any], is_selected: bool = False, parent=None):
        super().__init__(parent)
        self.font_info = font_info
        self.font_id = font_info["id"]
        self.is_selected = is_selected
        self.is_hovered = False

        self.setFixedHeight(54)
        self.setCursor(Qt.PointingHandCursor)
        self.setAttribute(Qt.WA_Hover, True)

        self._init_ui()

    def _init_ui(self):
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 6, 12, 6)
        lay.setSpacing(10)

        # 1. Left side: Category badge + Font title
        info_col = QVBoxLayout()
        info_col.setSpacing(2)
        info_col.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)

        badge_row = QHBoxLayout()
        badge_row.setSpacing(6)
        badge_row.setAlignment(Qt.AlignLeft)

        cat_lbl = QLabel(self.font_info.get("category", "").upper())
        cat_lbl.setStyleSheet(f"""
            QLabel {{
                color: {self.font_info.get("badge_color", "#3B82F6")};
                font-size: 8.5px;
                font-weight: 700;
                letter-spacing: 0.8px;
                background: transparent;
            }}
        """)
        badge_row.addWidget(cat_lbl)

        info_col.addLayout(badge_row)

        name_lbl = QLabel(self.font_info["name"])
        name_lbl.setStyleSheet("""
            QLabel {
                color: rgba(255, 255, 255, 0.70);
                font-size: 11px;
                font-weight: 500;
                background: transparent;
            }
        """)
        info_col.addWidget(name_lbl)
        lay.addLayout(info_col)

        lay.addStretch()

        # 2. Right side: The actual live rendered font preview
        preview_lbl = QLabel(self.font_info.get("sample", "Aa Bb"))
        preview_lbl.setAlignment(Qt.AlignVCenter | Qt.AlignRight)
        preview_lbl.setStyleSheet("color: #FFFFFF; background: transparent;")
        preview_lbl.setFont(QFont(self.font_id, 14, QFont.Bold))
        lay.addWidget(preview_lbl)

        # 3. Selection checkmark icon
        self.check_lbl = QLabel("✓" if self.is_selected else "")
        self.check_lbl.setFixedWidth(16)
        self.check_lbl.setAlignment(Qt.AlignCenter)
        self.check_lbl.setStyleSheet("color: #38BDF8; font-size: 13px; font-weight: bold; background: transparent;")
        lay.addWidget(self.check_lbl)

    def set_selected(self, selected: bool):
        if self.is_selected != selected:
            self.is_selected = selected
            self.check_lbl.setText("✓" if self.is_selected else "")
            self.update()

    def enterEvent(self, event):
        self.is_hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.is_hovered = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self.font_id)
        super().mousePressEvent(event)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        rect = self.rect().adjusted(1, 1, -1, -1)

        path = QPainterPath()
        path.addRoundedRect(QRectF(rect), 10.0, 10.0)

        if self.is_selected:
            # Active selection: subtle blue halo + glow
            p.fillPath(path, QColor(59, 130, 246, 28))
            p.strokePath(path, QPen(QColor(59, 130, 246, 180), 1.5))
        elif self.is_hovered:
            p.fillPath(path, QColor(255, 255, 255, 18))
            p.strokePath(path, QPen(QColor(255, 255, 255, 50), 1.0))
        else:
            p.fillPath(path, QColor(255, 255, 255, 8))
            p.strokePath(path, QPen(QColor(255, 255, 255, 18), 1.0))


class FontGalleryWidget(QWidget):
    """
    Scrollable gallery of font cards with category filters.
    """
    font_selected = Signal(str)  # font_id

    def __init__(self, current_font: str = "Segoe UI", parent=None):
        super().__init__(parent)
        self.current_font = current_font or "Segoe UI"
        self.cards: Dict[str, FontCard] = {}
        self.current_filter = "Alle"

        init_application_fonts()
        self._init_ui()

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(0, 0, 0, 0)
        root_lay.setSpacing(8)

        # 1. Category Filter Pills
        filter_bar = QHBoxLayout()
        filter_bar.setSpacing(4)
        filter_bar.setContentsMargins(0, 0, 0, 2)

        categories = ["Alle", "Bubble", "Gaming", "Cyber", "Retro", "Cursive"]
        self.filter_buttons = []
        for cat in categories:
            btn = QPushButton(cat)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFixedHeight(22)
            btn.setCheckable(True)
            btn.setChecked(cat == "Alle")
            btn.setStyleSheet("""
                QPushButton {
                    background: rgba(255, 255, 255, 0.05);
                    border: 1px solid rgba(255, 255, 255, 0.08);
                    border-radius: 11px;
                    color: rgba(255, 255, 255, 0.55);
                    font-size: 10px;
                    font-weight: 500;
                    padding: 0 8px;
                }
                QPushButton:hover {
                    background: rgba(255, 255, 255, 0.10);
                    color: #FFFFFF;
                }
                QPushButton:checked {
                    background: rgba(255, 255, 255, 0.20);
                    border-color: rgba(255, 255, 255, 0.40);
                    color: #FFFFFF;
                    font-weight: 600;
                }
            """)
            btn.clicked.connect(lambda checked, c=cat: self._filter_by_category(c))
            filter_bar.addWidget(btn)
            self.filter_buttons.append(btn)

        filter_bar.addStretch()
        root_lay.addLayout(filter_bar)

        # 2. Scroll Area containing cards
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(210)
        scroll.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: 1px solid rgba(255, 255, 255, 0.06);
                border-radius: 12px;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 5px;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 0.18);
                border-radius: 2px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

        container = QWidget()
        container.setStyleSheet("background: transparent;")
        self.cards_lay = QVBoxLayout(container)
        self.cards_lay.setContentsMargins(4, 4, 4, 4)
        self.cards_lay.setSpacing(6)

        catalog = get_font_catalog()
        for item in catalog:
            is_sel = (item["id"].lower() == self.current_font.lower())
            card = FontCard(item, is_selected=is_sel, parent=container)
            card.clicked.connect(self._on_card_clicked)
            self.cards_lay.addWidget(card)
            self.cards[item["id"]] = card

        self.cards_lay.addStretch()
        scroll.setWidget(container)
        root_lay.addWidget(scroll)

    def _filter_by_category(self, cat: str):
        self.current_filter = cat
        for btn in self.filter_buttons:
            btn.setChecked(btn.text() == cat)

        catalog = get_font_catalog()
        for item in catalog:
            card = self.cards.get(item["id"])
            if card:
                if cat == "Alle" or item.get("category", "") == cat:
                    card.show()
                else:
                    card.hide()

    def _on_card_clicked(self, font_id: str):
        self.current_font = font_id
        for fid, card in self.cards.items():
            card.set_selected(fid.lower() == font_id.lower())
        self.font_selected.emit(font_id)

    def set_selected_font(self, font_id: str):
        self.current_font = font_id or "Segoe UI"
        for fid, card in self.cards.items():
            card.set_selected(fid.lower() == self.current_font.lower())
