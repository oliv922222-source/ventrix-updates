"""
TouchDeck / VENTRIX - Apple Glass In-Window Icon Picker
Pure visionOS / Apple glass aesthetic with category filter pills,
instant search, responsive grid of crisp monochrome glyphs, and custom file picker.
"""
from pathlib import Path
from typing import Optional, Dict, List

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QLineEdit, QFileDialog, QScrollArea, QFrame,
    QSizePolicy
)
from PySide6.QtGui import QIcon, QPixmap, QColor, QPainter, QBrush, QPen
from PySide6.QtCore import Qt, QSize, Signal


# Category mapping for organized browsing
ICON_CATEGORIES: Dict[str, List[str]] = {
    "Medier": ["play", "pause", "play_pause", "next", "prev", "stop", "volume_up", "volume_down", "volume_mute"],
    "System": ["power", "lock", "sleep", "mic", "mic_mute", "camera", "screenshot", "brightness", "settings"],
    "Navigation": ["arrow_left", "arrow_right", "arrow_up", "arrow_down", "home", "refresh"],
    "Apps": ["discord", "spotify", "youtube", "obs", "steam", "game", "code", "terminal", "browser", "folder"],
}

ICON_DISPLAY_NAMES = {
    "play": "Play (Afspil)",
    "pause": "Pause",
    "play_pause": "Play / Pause",
    "next": "Frem (Næste)",
    "prev": "Tilbage (Forrige)",
    "stop": "Stop",
    "volume_up": "Lydstyrke Op (+)",
    "volume_down": "Lydstyrke Ned (-)",
    "volume_mute": "Lyd Fra (Mute)",
    "power": "Sluk / Tænd",
    "lock": "Lås Computer",
    "sleep": "Dvale / Sleep",
    "mic": "Mikrofon Til",
    "mic_mute": "Mikrofon Mute",
    "camera": "Kamera",
    "screenshot": "Skærmbillede",
    "brightness": "Lysstyrke",
    "settings": "Indstillinger",
    "arrow_left": "Venstre Pil (←)",
    "arrow_right": "Højre Pil (→)",
    "arrow_up": "Op Pil (↑)",
    "arrow_down": "Ned Pil (↓)",
    "home": "Hjem (Home)",
    "refresh": "Genindlæs (Refresh)",
    "discord": "Discord",
    "spotify": "Spotify",
    "youtube": "YouTube",
    "obs": "OBS Studio",
    "steam": "Steam",
    "game": "Spil / Gaming",
    "code": "Visual Studio Code",
    "terminal": "Terminal / CMD",
    "browser": "Browser / Web",
    "folder": "Mappe / Fil",
}


class AppleGlassIconTile(QPushButton):
    """Frosted Apple glass icon button."""
    def __init__(self, icon_name: str, icon_path: Path, is_selected: bool = False, parent=None):
        super().__init__(parent)
        self.icon_name = icon_name
        self.icon_path = icon_path
        self._is_selected = is_selected

        self.setFixedSize(42, 42)
        self.setCursor(Qt.PointingHandCursor)
        display_title = ICON_DISPLAY_NAMES.get(icon_name, icon_name.replace("_", " ").title())
        self.setToolTip(display_title)

        if icon_path.exists():
            self.setIcon(QIcon(str(icon_path)))
            self.setIconSize(QSize(22, 22))

        self.update_style()

    def set_selected(self, selected: bool):
        self._is_selected = selected
        self.update_style()

    def update_style(self):
        if self._is_selected:
            self.setStyleSheet("""
                QPushButton {
                    background: rgba(255, 255, 255, 0.22);
                    border: 1.5px solid #FFFFFF;
                    border-radius: 9px;
                }
                QPushButton:hover {
                    background: rgba(255, 255, 255, 0.30);
                }
            """)
        else:
            self.setStyleSheet("""
                QPushButton {
                    background: rgba(255, 255, 255, 0.05);
                    border: 1px solid rgba(255, 255, 255, 0.08);
                    border-radius: 9px;
                }
                QPushButton:hover {
                    background: rgba(255, 255, 255, 0.14);
                    border: 1px solid rgba(255, 255, 255, 0.22);
                }
                QPushButton:pressed {
                    background: rgba(255, 255, 255, 0.08);
                }
            """)


class AppleGlassIconPicker(QWidget):
    """
    Inline visionOS / Apple Glass Icon Picker.
    Embedded directly in ButtonInspector - zero popups or OS windows.
    """
    icon_selected = Signal(str)  # Emits icon name (e.g. 'play') or file path
    custom_file_requested = Signal()

    def __init__(self, current_icon: str = "", parent=None):
        super().__init__(parent)
        self.current_icon = current_icon
        self.assets_icons_dir = Path(__file__).parent.parent.parent / "assets" / "icons"
        self.tiles: Dict[str, AppleGlassIconTile] = {}
        self.active_category = "Alle"

        self._init_ui()

    def _init_ui(self):
        main_lay = QVBoxLayout(self)
        main_lay.setContentsMargins(0, 0, 0, 0)
        main_lay.setSpacing(8)

        from shared.i18n import t
        # 1. Search Bar
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(t("picker_search_placeholder"))
        self.search_input.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.06);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 8px;
                color: #FFFFFF;
                padding: 6px 10px;
                font-size: 11px;
            }
            QLineEdit:focus {
                background: rgba(255, 255, 255, 0.10);
                border: 1px solid rgba(255, 255, 255, 0.35);
            }
        """)
        self.search_input.textChanged.connect(self._filter_icons)
        self.search_input.returnPressed.connect(self._on_search_return_pressed)
        main_lay.addWidget(self.search_input)

        # 1a. Instant Google Logo Suggestion Button (appears on search)
        self.google_suggest_btn = QPushButton(t("picker_google_fetch_action", query=""))
        self.google_suggest_btn.setCursor(Qt.PointingHandCursor)
        self.google_suggest_btn.setFixedHeight(28)
        self.google_suggest_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.16);
                border-radius: 8px;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 600;
                text-align: left;
                padding-left: 10px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.18);
                border-color: rgba(255, 255, 255, 0.35);
            }
        """)
        self.google_suggest_btn.clicked.connect(self._on_suggest_btn_clicked)
        self.google_suggest_btn.hide()
        main_lay.addWidget(self.google_suggest_btn)

        # 1b. Google Web Logo Finder
        web_box = QHBoxLayout()
        web_box.setSpacing(6)
        self.web_input = QLineEdit()
        self.web_input.setPlaceholderText(t("picker_google_placeholder"))
        self.web_input.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.09);
                border-radius: 8px;
                color: #FFFFFF;
                padding: 5px 9px;
                font-size: 11px;
            }
            QLineEdit:focus {
                background: rgba(255, 255, 255, 0.09);
                border-color: rgba(255, 255, 255, 0.30);
            }
        """)
        self.web_input.returnPressed.connect(self._fetch_web_logo)
        web_box.addWidget(self.web_input, stretch=1)

        self.web_fetch_btn = QPushButton(t("picker_google_fetch_btn"))
        self.web_fetch_btn.setCursor(Qt.PointingHandCursor)
        self.web_fetch_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.14);
                border-radius: 8px;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 600;
                padding: 5px 12px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.16);
            }
        """)
        self.web_fetch_btn.clicked.connect(self._fetch_web_logo)
        web_box.addWidget(self.web_fetch_btn)
        main_lay.addLayout(web_box)

        # 2. Category Filter Pills
        cat_scroll = QScrollArea()
        cat_scroll.setWidgetResizable(True)
        cat_scroll.setFixedHeight(32)
        cat_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        cat_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        cat_scroll.setStyleSheet("background: transparent; border: none;")

        cat_widget = QWidget()
        cat_lay = QHBoxLayout(cat_widget)
        cat_lay.setContentsMargins(0, 0, 0, 0)
        cat_lay.setSpacing(5)

        self.cat_buttons = {}
        categories = ["Alle", "Medier", "System", "Navigation", "Apps"]
        for cat in categories:
            btn = QPushButton(cat)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFixedHeight(24)
            btn.clicked.connect(lambda checked=False, c=cat: self._set_category(c))
            cat_lay.addWidget(btn)
            self.cat_buttons[cat] = btn

        cat_lay.addStretch()
        cat_scroll.setWidget(cat_widget)
        main_lay.addWidget(cat_scroll)
        self._update_category_styles()

        # 3. Icon Grid in Scroll Area
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFixedHeight(150)
        self.scroll.setStyleSheet("""
            QScrollArea {
                background: rgba(0, 0, 0, 0.25);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 6px;
                margin: 4px 2px 4px 2px;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 0.20);
                border-radius: 3px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background: rgba(255, 255, 255, 0.35);
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

        self.grid_container = QWidget()
        self.grid_container.setStyleSheet("background: transparent;")
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setContentsMargins(8, 8, 8, 8)
        self.grid_layout.setSpacing(6)

        self._populate_grid()
        self.scroll.setWidget(self.grid_container)
        main_lay.addWidget(self.scroll)

        from shared.i18n import t
        # 4. Action Row: Custom file & Clear icon
        act_row = QHBoxLayout()
        act_row.setSpacing(6)

        self.custom_btn = QPushButton(t("picker_browse_file"))
        self.custom_btn.setCursor(Qt.PointingHandCursor)
        self.custom_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 8px;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 500;
                padding: 6px 10px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.12);
                border: 1px solid rgba(255, 255, 255, 0.24);
            }
        """)
        self.custom_btn.clicked.connect(self._browse_custom_file)
        act_row.addWidget(self.custom_btn, stretch=1)

        self.clear_btn = QPushButton(t("picker_clear"))
        self.clear_btn.setCursor(Qt.PointingHandCursor)
        self.clear_btn.setStyleSheet("""
            QPushButton {
                background: rgba(239, 68, 68, 0.10);
                border: 1px solid rgba(239, 68, 68, 0.25);
                border-radius: 8px;
                color: #EF4444;
                font-size: 11px;
                font-weight: 500;
                padding: 6px 10px;
            }
            QPushButton:hover {
                background: rgba(239, 68, 68, 0.22);
            }
        """)
        self.clear_btn.clicked.connect(self._clear_icon)
        act_row.addWidget(self.clear_btn)

        main_lay.addLayout(act_row)

    def _set_category(self, cat: str):
        self.active_category = cat
        self._update_category_styles()
        self._filter_icons(self.search_input.text())

    def _update_category_styles(self):
        for cat, btn in self.cat_buttons.items():
            if cat == self.active_category:
                btn.setStyleSheet("""
                    QPushButton {
                        background: rgba(255, 255, 255, 0.22);
                        border: 1px solid rgba(255, 255, 255, 0.40);
                        border-radius: 12px;
                        color: #FFFFFF;
                        font-size: 10px;
                        font-weight: 600;
                        padding: 2px 10px;
                    }
                """)
            else:
                btn.setStyleSheet("""
                    QPushButton {
                        background: rgba(255, 255, 255, 0.05);
                        border: 1px solid rgba(255, 255, 255, 0.08);
                        border-radius: 12px;
                        color: #8E8E93;
                        font-size: 10px;
                        font-weight: 500;
                        padding: 2px 10px;
                    }
                    QPushButton:hover {
                        background: rgba(255, 255, 255, 0.12);
                        color: #FFFFFF;
                    }
                """)

    def _populate_grid(self):
        # Clear existing
        for tile in self.tiles.values():
            tile.deleteLater()
        self.tiles.clear()

        # Load all PNG files in assets/icons
        if not self.assets_icons_dir.exists():
            return

        icon_files = sorted(list(self.assets_icons_dir.glob("*.png")))
        # Prioritize curated icons in order
        all_ordered = []
        for cat, list_icons in ICON_CATEGORIES.items():
            all_ordered.extend(list_icons)

        # Sort files so standard ones come first
        def sort_key(p: Path):
            stem = p.stem.lower()
            if stem in all_ordered:
                return (0, all_ordered.index(stem))
            return (1, stem)

        sorted_files = sorted(icon_files, key=sort_key)

        # Include any dynamically downloaded Google / web logos from extracted directory
        extracted_dir = self.assets_icons_dir / "extracted"
        if extracted_dir.exists():
            for p in sorted(list(extracted_dir.glob("*.png"))):
                if p not in sorted_files:
                    sorted_files.insert(0, p)  # Show newest web logos first!

        col_count = 5
        row = 0
        col = 0

        for icon_path in sorted_files:
            icon_name = icon_path.stem
            is_sel = (self.current_icon == icon_name)
            tile = AppleGlassIconTile(icon_name, icon_path, is_selected=is_sel, parent=self.grid_container)
            tile.clicked.connect(lambda checked=False, name=icon_name: self._on_tile_clicked(name))
            self.tiles[icon_name] = tile
            self.grid_layout.addWidget(tile, row, col)

            col += 1
            if col >= col_count:
                col = 0
                row += 1

    def _on_tile_clicked(self, icon_name: str):
        self.current_icon = icon_name
        for name, tile in self.tiles.items():
            tile.set_selected(name == icon_name)
        self.icon_selected.emit(icon_name)

    def set_current_icon(self, icon_val: str):
        self.current_icon = icon_val or ""
        for name, tile in self.tiles.items():
            tile.set_selected(name == self.current_icon)

    def _filter_icons(self, query: str):
        query = query.strip().lower()
        visible_tiles = []

        if query:
            self.google_suggest_btn.setText(f"Hent '{query}' logo fra Google")
            self.google_suggest_btn.show()
        else:
            self.google_suggest_btn.hide()

        for name, tile in self.tiles.items():
            # Check category
            match_cat = True
            if self.active_category != "Alle":
                allowed = ICON_CATEGORIES.get(self.active_category, [])
                match_cat = (name in allowed)

            # Check query
            match_q = True
            if query:
                display_name = ICON_DISPLAY_NAMES.get(name, name).lower()
                match_q = (query in name.lower() or query in display_name)

            if match_cat and match_q:
                tile.show()
                visible_tiles.append(tile)
            else:
                tile.hide()

        # Re-layout visible tiles
        for i, tile in enumerate(visible_tiles):
            self.grid_layout.removeWidget(tile)
            self.grid_layout.addWidget(tile, i // 5, i % 5)

    def _on_search_return_pressed(self):
        query = self.search_input.text().strip()
        if query:
            self._fetch_query_logo(query)

    def _on_suggest_btn_clicked(self):
        query = self.search_input.text().strip()
        if query:
            self._fetch_query_logo(query)

    def _fetch_query_logo(self, query: str):
        self.google_suggest_btn.setEnabled(False)
        self.google_suggest_btn.setText(f"Henter '{query}' logo...")

        from editor.utils.web_icon_fetcher import WebLogoFetchWorker
        self._search_worker = WebLogoFetchWorker(query, parent=self)
        self._search_worker.success.connect(self._on_search_logo_success)
        self._search_worker.failure.connect(self._on_search_logo_failure)
        self._search_worker.start()

    def _on_search_logo_success(self, filename: str, domain: str):
        self.google_suggest_btn.setEnabled(True)
        self.google_suggest_btn.setText(f"✓ Logo for {domain} fundet!")
        self.search_input.clear()
        self.google_suggest_btn.hide()
        self._populate_grid()
        self.set_current_icon(filename)
        self.icon_selected.emit(filename)

    def _on_search_logo_failure(self, error: str):
        self.google_suggest_btn.setEnabled(True)
        self.google_suggest_btn.setText(f"Kunne ikke finde logo: {error}")

    def _browse_custom_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Vælg Logo / Billede", "", "Billeder (*.png *.jpg *.jpeg *.ico *.svg *.webp)"
        )
        if file_path:
            self.current_icon = file_path
            for tile in self.tiles.values():
                tile.set_selected(False)
            self.icon_selected.emit(file_path)

    def _clear_icon(self):
        self.current_icon = ""
        for tile in self.tiles.values():
            tile.set_selected(False)
        self.icon_selected.emit("")

    def _fetch_web_logo(self):
        query = self.web_input.text().strip()
        if not query:
            return
        self.web_fetch_btn.setEnabled(False)
        self.web_fetch_btn.setText("Henter...")

        from editor.utils.web_icon_fetcher import WebLogoFetchWorker
        self._worker = WebLogoFetchWorker(query, parent=self)
        self._worker.success.connect(self._on_web_logo_success)
        self._worker.failure.connect(self._on_web_logo_failure)
        self._worker.start()

    def _on_web_logo_success(self, filename: str, domain: str):
        self.web_fetch_btn.setEnabled(True)
        self.web_fetch_btn.setText("Hent")
        self.web_input.clear()
        self._populate_grid()
        self.set_current_icon(filename)
        self.icon_selected.emit(filename)

    def _on_web_logo_failure(self, error: str):
        self.web_fetch_btn.setEnabled(True)
        self.web_fetch_btn.setText("Hent")
