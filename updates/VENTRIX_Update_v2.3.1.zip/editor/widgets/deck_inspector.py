"""
TouchDeck - Stream Deck Surface Customizer & Layout Inspector
Allows users to customize the physical deck appearance:
- Background image (drag & drop or file picker)
- Background color tint
- Button spacing / gap (live slider)
- Button corner radius (live slider)
- Grid padding / margin (live slider)
All changes immediately update the live preview.
Author: VENTRIX
"""

import os
from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QSlider, QFrame, QFileDialog,
    QScrollArea
)
from PySide6.QtCore import Qt, Signal, QSize, QPoint, QRectF
from PySide6.QtGui import (
    QColor, QFont, QPixmap, QPainter, QLinearGradient,
    QPainterPath, QPen, QDragEnterEvent, QDropEvent
)

from shared.models import PageModel
from editor.utils.icon_storage import save_custom_image, resolve_icon_path
from shared.i18n import t


class AppleDivider(QFrame):
    """Subtle 1px hairline divider."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.HLine)
        self.setFrameShadow(QFrame.Plain)
        self.setFixedHeight(1)
        self.setStyleSheet("background: rgba(255, 255, 255, 0.08); border: none;")


class BackgroundDropZone(QFrame):
    """
    Interactive Drag & Drop zone and preview for deck background image.
    Accepts image file drops directly or opens file dialog on click.
    """
    image_selected = Signal(str)      # Absolute path to image
    image_removed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(120)
        self.image_path: str = ""
        self._is_drag_over = False

    def set_image(self, path: str):
        self.image_path = path or ""
        self.update()

    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                ext = Path(url.toLocalFile()).suffix.lower()
                if ext in (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"):
                    event.acceptProposedAction()
                    self._is_drag_over = True
                    self.update()
                    return
        event.ignore()

    def dragLeaveEvent(self, event):
        self._is_drag_over = False
        self.update()

    def dropEvent(self, event: QDropEvent):
        self._is_drag_over = False
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                local_path = url.toLocalFile()
                ext = Path(local_path).suffix.lower()
                if ext in (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif") and os.path.exists(local_path):
                    saved = save_custom_image(local_path)
                    if saved:
                        self.image_path = saved
                        self.image_selected.emit(saved)
                        self.update()
                        event.acceptProposedAction()
                        return
        self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            # Open file dialog
            path, _ = QFileDialog.getOpenFileName(
                self, "Vælg Baggrundsbillede", "",
                "Billedfiler (*.png *.jpg *.jpeg *.webp *.bmp *.gif);;Alle filer (*.*)"
            )
            if path and os.path.exists(path):
                saved = save_custom_image(path)
                if saved:
                    self.image_path = saved
                    self.image_selected.emit(saved)
                    self.update()
        super().mousePressEvent(event)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)

        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        radius = 12.0
        path = QPainterPath()
        path.addRoundedRect(r, radius, radius)

        # Draw current background preview or drop placeholder
        resolved = None
        if self.image_path:
            p_obj = Path(self.image_path)
            if p_obj.exists() and p_obj.is_file():
                resolved = p_obj
            else:
                resolved = resolve_icon_path(self.image_path)

        if resolved and resolved.exists():
            pix = QPixmap(str(resolved))
            if not pix.isNull():
                p.save()
                p.setClipPath(path)
                # Scaled to fill/cover
                scaled = pix.scaled(int(r.width()), int(r.height()), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                sx = int(r.center().x() - scaled.width() / 2)
                sy = int(r.center().y() - scaled.height() / 2)
                p.drawPixmap(sx, sy, scaled)
                # Dark glass gradient overlay for readability
                overlay = QLinearGradient(0, r.top(), 0, r.bottom())
                overlay.setColorAt(0.0, QColor(0, 0, 0, 80))
                overlay.setColorAt(1.0, QColor(0, 0, 0, 160))
                p.fillRect(r, overlay)
                p.restore()

                # Label on top
                p.setPen(QColor(255, 255, 255, 230))
                p.setFont(QFont("Segoe UI Variable Text", 11, QFont.DemiBold))
                p.drawText(r.adjusted(10, 10, -10, -32), Qt.AlignCenter, "Klik eller træk for at skifte")
                p.setPen(QColor(255, 255, 255, 140))
                p.setFont(QFont("Segoe UI Variable Text", 9))
                p.drawText(r.adjusted(10, 36, -10, -10), Qt.AlignCenter, Path(self.image_path).name[:28])

                # Border
                border_pen = QPen(QColor(59, 130, 246, 200) if self._is_drag_over else QColor(255, 255, 255, 35), 1.2)
                p.strokePath(path, border_pen)
                return

        # Empty dropzone state
        bg_col = QColor(59, 130, 246, 25) if self._is_drag_over else QColor(255, 255, 255, 8)
        p.fillPath(path, bg_col)

        pen = QPen(QColor(59, 130, 246, 230) if self._is_drag_over else QColor(255, 255, 255, 45), 1.4, Qt.DashLine)
        p.strokePath(path, pen)

        # Icon and text
        p.setPen(QColor(255, 255, 255, 220 if self._is_drag_over else 170))
        p.setFont(QFont("Segoe UI Variable Text", 12, QFont.DemiBold))
        text1 = "Slip billede her" if self._is_drag_over else "Træk & slip baggrund her"
        p.drawText(r.adjusted(10, 18, -10, -40), Qt.AlignCenter, text1)

        p.setPen(QColor(255, 255, 255, 120))
        p.setFont(QFont("Segoe UI Variable Text", 10))
        p.drawText(r.adjusted(10, 52, -10, -14), Qt.AlignCenter, "eller klik for at vælge fra PC (PNG, JPG, WEBP)")


class DeckInspector(QFrame):
    """
    Right-hand panel inspector for customizing the Stream Deck hardware surface:
    - Custom background (Drag & Drop or file picker)
    - Button gap spacing slider (px)
    - Button corner radius slider (px)
    - Grid padding margin slider (px)
    """
    page_style_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("cardFrame")
        self.current_page: Optional[PageModel] = None

        self._init_ui()

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(16, 14, 16, 14)
        root_lay.setSpacing(12)

        # ── Header ────────────────────────────────────────────────────────────
        header_row = QHBoxLayout()
        header_row.setContentsMargins(0, 0, 0, 0)

        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        title_lbl = QLabel("STREAM DECK DESIGN")
        title_lbl.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 700; letter-spacing: 1.2px;")
        title_col.addWidget(title_lbl)

        self.page_sub_lbl = QLabel("Tilpasning af overflade")
        self.page_sub_lbl.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 600;")
        title_col.addWidget(self.page_sub_lbl)
        header_row.addLayout(title_col)
        header_row.addStretch()

        root_lay.addLayout(header_row)
        root_lay.addWidget(AppleDivider())

        # ── Scroll Area for Controls ──────────────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")

        container = QWidget()
        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 4, 0, 4)
        lay.setSpacing(14)

        # ── 1. Baggrund ───────────────────────────────────────────────────────
        bg_header_row = QHBoxLayout()
        bg_title = QLabel("BAGGRUND")
        bg_title.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 700; letter-spacing: 0.8px;")
        bg_header_row.addWidget(bg_title)
        bg_header_row.addStretch()

        self.clear_bg_btn = QPushButton("Fjern")
        self.clear_bg_btn.setCursor(Qt.PointingHandCursor)
        self.clear_bg_btn.setStyleSheet("""
            QPushButton {
                background: rgba(239, 68, 68, 0.12);
                color: #EF4444;
                border: 1px solid rgba(239, 68, 68, 0.25);
                border-radius: 6px;
                font-size: 10px;
                font-weight: 600;
                padding: 2px 8px;
            }
            QPushButton:hover {
                background: rgba(239, 68, 68, 0.22);
            }
        """)
        self.clear_bg_btn.clicked.connect(self._clear_background)
        self.clear_bg_btn.hide()
        bg_header_row.addWidget(self.clear_bg_btn)
        lay.addLayout(bg_header_row)

        self.drop_zone = BackgroundDropZone(self)
        self.drop_zone.image_selected.connect(self._on_image_selected)
        lay.addWidget(self.drop_zone)

        # Presets for background tint
        tint_row = QHBoxLayout()
        tint_row.setSpacing(6)
        presets = [
            ("Standard", "#0A0A0C"),
            ("Grafit", "#18181B"),
            ("Midnat", "#0F172A"),
            ("Indigo", "#1E1B4B"),
            ("Smaragd", "#064E3B"),
        ]
        for name, col_hex in presets:
            btn = QPushButton(name)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: {col_hex};
                    color: rgba(255, 255, 255, 0.75);
                    border: 1px solid rgba(255, 255, 255, 0.14);
                    border-radius: 7px;
                    font-size: 10px;
                    font-weight: 600;
                    padding: 4px 6px;
                }}
                QPushButton:hover {{
                    border-color: rgba(255, 255, 255, 0.40);
                    color: #FFFFFF;
                }}
            """)
            btn.clicked.connect(lambda checked=False, c=col_hex: self._set_background_color(c))
            tint_row.addWidget(btn)
        lay.addLayout(tint_row)

        lay.addSpacing(4)
        lay.addWidget(AppleDivider())
        lay.addSpacing(4)

        # ── 2. Knap-afstande & Mellemrum ──────────────────────────────────────
        layout_title = QLabel("LAYOUT & MELLEMRUM")
        layout_title.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 700; letter-spacing: 0.8px;")
        lay.addWidget(layout_title)

        # Mellemrum (Button Gap)
        gap_header = QHBoxLayout()
        gap_lbl = QLabel("Mellemrum mellem knapper:")
        gap_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 500;")
        gap_header.addWidget(gap_lbl)
        gap_header.addStretch()
        self.gap_val_lbl = QLabel("14 px")
        self.gap_val_lbl.setStyleSheet("color: #3B82F6; font-size: 12px; font-weight: 700;")
        gap_header.addWidget(self.gap_val_lbl)
        lay.addLayout(gap_header)

        self.gap_slider = QSlider(Qt.Horizontal)
        self.gap_slider.setRange(4, 32)
        self.gap_slider.setValue(14)
        self.gap_slider.setStyleSheet("""
            QSlider::groove:horizontal {
                height: 4px;
                background: rgba(255, 255, 255, 0.12);
                border-radius: 2px;
            }
            QSlider::sub-page:horizontal {
                background: #3B82F6;
                border-radius: 2px;
            }
            QSlider::handle:horizontal {
                width: 16px;
                margin-top: -6px;
                margin-bottom: -6px;
                border-radius: 8px;
                background: #FFFFFF;
                border: 1px solid rgba(0, 0, 0, 0.2);
            }
        """)
        self.gap_slider.valueChanged.connect(self._on_gap_changed)
        lay.addWidget(self.gap_slider)

        lay.addSpacing(6)

        # Knap-afrunding (Button Radius)
        radius_header = QHBoxLayout()
        radius_lbl = QLabel("Knap-afrunding (hjørner):")
        radius_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 500;")
        radius_header.addWidget(radius_lbl)
        radius_header.addStretch()
        self.radius_val_lbl = QLabel("28 px")
        self.radius_val_lbl.setStyleSheet("color: #3B82F6; font-size: 12px; font-weight: 700;")
        radius_header.addWidget(self.radius_val_lbl)
        lay.addLayout(radius_header)

        self.radius_slider = QSlider(Qt.Horizontal)
        self.radius_slider.setRange(6, 36)
        self.radius_slider.setValue(28)
        self.radius_slider.setStyleSheet("""
            QSlider::groove:horizontal {
                height: 4px;
                background: rgba(255, 255, 255, 0.12);
                border-radius: 2px;
            }
            QSlider::sub-page:horizontal {
                background: #3B82F6;
                border-radius: 2px;
            }
            QSlider::handle:horizontal {
                width: 16px;
                margin-top: -6px;
                margin-bottom: -6px;
                border-radius: 8px;
                background: #FFFFFF;
                border: 1px solid rgba(0, 0, 0, 0.2);
            }
        """)
        self.radius_slider.valueChanged.connect(self._on_radius_changed)
        lay.addWidget(self.radius_slider)

        lay.addSpacing(6)

        # Gitter-margin (Grid Padding)
        padding_header = QHBoxLayout()
        padding_lbl = QLabel("Gitter-margin (ydre afstand):")
        padding_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 500;")
        padding_header.addWidget(padding_lbl)
        padding_header.addStretch()
        self.padding_val_lbl = QLabel("16 px")
        self.padding_val_lbl.setStyleSheet("color: #3B82F6; font-size: 12px; font-weight: 700;")
        padding_header.addWidget(self.padding_val_lbl)
        lay.addLayout(padding_header)

        self.padding_slider = QSlider(Qt.Horizontal)
        self.padding_slider.setRange(0, 40)
        self.padding_slider.setValue(16)
        self.padding_slider.setStyleSheet("""
            QSlider::groove:horizontal {
                height: 4px;
                background: rgba(255, 255, 255, 0.12);
                border-radius: 2px;
            }
            QSlider::sub-page:horizontal {
                background: #3B82F6;
                border-radius: 2px;
            }
            QSlider::handle:horizontal {
                width: 16px;
                margin-top: -6px;
                margin-bottom: -6px;
                border-radius: 8px;
                background: #FFFFFF;
                border: 1px solid rgba(0, 0, 0, 0.2);
            }
        """)
        self.padding_slider.valueChanged.connect(self._on_padding_changed)
        lay.addWidget(self.padding_slider)

        lay.addSpacing(10)
        lay.addWidget(AppleDivider())
        lay.addSpacing(6)

        # Nulstil layout knap
        reset_btn = QPushButton("Nulstil til Standard")
        reset_btn.setCursor(Qt.PointingHandCursor)
        reset_btn.setFixedHeight(34)
        reset_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                border: 1px solid rgba(255, 255, 255, 0.14);
                border-radius: 8px;
                color: rgba(255, 255, 255, 0.85);
                font-size: 11px;
                font-weight: 600;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.12);
                border-color: rgba(255, 255, 255, 0.28);
                color: #FFFFFF;
            }
        """)
        reset_btn.clicked.connect(self._reset_to_default)
        lay.addWidget(reset_btn)

        lay.addStretch()
        scroll.setWidget(container)
        root_lay.addWidget(scroll, stretch=1)

    def set_page(self, page: Optional[PageModel]):
        self.current_page = page
        if not page:
            self.setEnabled(False)
            self.page_sub_lbl.setText("Ingen side valgt")
            self.drop_zone.set_image("")
            self.clear_bg_btn.hide()
            return

        self.setEnabled(True)
        self.page_sub_lbl.setText(f"Side: {page.name}")

        bg_img = getattr(page, "bg_image", "") or ""
        self.drop_zone.set_image(bg_img)
        self.clear_bg_btn.setVisible(bool(bg_img))

        gap = getattr(page, "button_gap", 14) or 14
        self.gap_slider.blockSignals(True)
        self.gap_slider.setValue(gap)
        self.gap_val_lbl.setText(f"{gap} px")
        self.gap_slider.blockSignals(False)

        rad = getattr(page, "button_radius", 28) or 28
        self.radius_slider.blockSignals(True)
        self.radius_slider.setValue(rad)
        self.radius_val_lbl.setText(f"{rad} px")
        self.radius_slider.blockSignals(False)

        pad = getattr(page, "grid_padding", 16) or 16
        self.padding_slider.blockSignals(True)
        self.padding_slider.setValue(pad)
        self.padding_val_lbl.setText(f"{pad} px")
        self.padding_slider.blockSignals(False)

    def _on_image_selected(self, path: str):
        if self.current_page:
            self.current_page.bg_image = path
            self.clear_bg_btn.setVisible(bool(path))
            self.page_style_changed.emit()

    def _clear_background(self):
        if self.current_page:
            self.current_page.bg_image = ""
            self.drop_zone.set_image("")
            self.clear_bg_btn.hide()
            self.page_style_changed.emit()

    def _set_background_color(self, hex_color: str):
        if self.current_page:
            self.current_page.bg_color = hex_color
            self.page_style_changed.emit()

    def _on_gap_changed(self, val: int):
        self.gap_val_lbl.setText(f"{val} px")
        if self.current_page:
            self.current_page.button_gap = val
            self.page_style_changed.emit()

    def _on_radius_changed(self, val: int):
        self.radius_val_lbl.setText(f"{val} px")
        if self.current_page:
            self.current_page.button_radius = val
            self.page_style_changed.emit()

    def _on_padding_changed(self, val: int):
        self.padding_val_lbl.setText(f"{val} px")
        if self.current_page:
            self.current_page.grid_padding = val
            self.page_style_changed.emit()

    def _reset_to_default(self):
        if self.current_page:
            self.current_page.bg_image = ""
            self.current_page.bg_color = ""
            self.current_page.button_gap = 14
            self.current_page.button_radius = 28
            self.current_page.grid_padding = 16
            self.set_page(self.current_page)
            self.page_style_changed.emit()
