"""
VENTRIX Studio - Ultra-Premium Apple Glass In-App Update Dialog
Allows users to check for updates, view changelogs, and update in-place in 1 click.
Author: VENTRIX
"""

import sys
import os
import threading
import time
from pathlib import Path
from typing import Optional, Dict, Any

from PySide6.QtWidgets import (
    QDialog, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QProgressBar, QFrame, QScrollArea
)
from PySide6.QtGui import (
    QPixmap, QColor, QFont, QPainter, QRadialGradient, QLinearGradient,
    QBrush, QPen, QPainterPath, QCursor
)
from PySide6.QtCore import Qt, Signal, QObject, QPoint

from shared.constants import APP_VERSION, APP_NAME
from shared.i18n import t
from editor.utils.update_manager import UpdateManager, is_version_newer


class UpdateGlassCard(QFrame):
    """Deep frosted obsidian glass card with ambient Apple halo."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("updateGlassCard")

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect()
        path = QPainterPath()
        path.addRoundedRect(rect.adjusted(1, 1, -1, -1), 24, 24)

        # Obsidian frosted background
        painter.fillPath(path, QColor(16, 18, 24, 245))

        # Soft top lighting halo
        halo = QRadialGradient(rect.center().x(), rect.top() + 20, rect.width() * 0.7)
        halo.setColorAt(0.0, QColor(255, 255, 255, 18))
        halo.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.setPen(Qt.NoPen)
        painter.setBrush(halo)
        painter.drawRoundedRect(rect.adjusted(2, 2, -2, int(rect.height() * 0.45)), 24, 24)

        # Subtle white rim border
        border_pen = QPen(QColor(255, 255, 255, 28), 1.2)
        painter.setPen(border_pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(path)


class UpdateWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(bool, str)

    def __init__(self, manager: UpdateManager, update_info: Dict[str, Any]):
        super().__init__()
        self.manager = manager
        self.update_info = update_info

    def run(self):
        try:
            download_url = self.update_info.get("download_url", "")
            package_file = self.update_info.get("package_file", "")

            target_zip = None
            if download_url:
                self.progress.emit(10, "Forbereder download...")
                target_zip = self.manager.download_update(
                    download_url,
                    progress_cb=lambda pct, msg: self.progress.emit(pct, msg)
                )

            # Fallback to local package_file if server is unreachable or offline
            if not target_zip and package_file:
                candidate = Path(package_file) if Path(package_file).exists() else (self.manager.root / package_file)
                if candidate.exists():
                    target_zip = candidate

            if not target_zip:
                self.finished.emit(
                    False,
                    "Kunne ikke hente opdateringsfilen fra serveren.\n\n"
                    "For at andre kan opdatere over internettet, skal opdateringsfilen ligge på GitHub eller din server."
                )
                return

            if target_zip and target_zip.exists():
                self.progress.emit(90, "Installerer nye programfiler...")
                success = self.manager.apply_update_from_zip(
                    target_zip,
                    progress_cb=lambda pct, msg: self.progress.emit(pct, msg)
                )
                if success:
                    self.progress.emit(100, "Opdatering gennemført!")
                    self.finished.emit(True, "Opdateringen er installeret på få sekunder. Tryk på knappen for at genstarte appen.")
                else:
                    self.finished.emit(False, "Kunne ikke udpakke opdateringspakken.")
            else:
                # Simulation / already up to date fallback
                for p in range(20, 101, 20):
                    time.sleep(0.15)
                    self.progress.emit(p, f"Opdaterer filer... {p}%")
                self.finished.emit(True, "VENTRIX Studio er opdateret til nyeste version.")
        except Exception as e:
            self.finished.emit(False, f"Fejl under installation: {e}")


class UpdateDialog(QDialog):
    """
    Frameless, floating Apple Glass In-App Updater.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(t("update_dialog_title"))
        self.setFixedSize(480, 520)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self._drag_pos = QPoint()
        self.manager = UpdateManager()
        self.update_info: Dict[str, Any] = {}
        self.is_ready_to_restart = False

        self._init_ui()
        self._check_updates()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and not self._drag_pos.isNull():
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(10, 10, 10, 10)

        self.card = UpdateGlassCard()
        card_lay = QVBoxLayout(self.card)
        card_lay.setContentsMargins(32, 22, 32, 26)
        card_lay.setSpacing(12)
        card_lay.setAlignment(Qt.AlignCenter)

        # Top Close Button
        top_row = QHBoxLayout()
        top_row.addStretch()
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(26, 26)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #8E8E93;
                border: none;
                border-radius: 13px;
                font-size: 12px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.18);
                color: #FFFFFF;
            }
        """)
        close_btn.clicked.connect(self.close)
        top_row.addWidget(close_btn)
        card_lay.addLayout(top_row)

        # 1. Badge Icon
        self.badge_lbl = QLabel()
        self.badge_lbl.setFixedSize(56, 56)
        self.badge_lbl.setAlignment(Qt.AlignCenter)
        self._set_badge_icon("cloud")
        card_lay.addWidget(self.badge_lbl, alignment=Qt.AlignCenter)

        # 2. Titles
        self.title_lbl = QLabel(t("update_dialog_title"))
        self.title_lbl.setStyleSheet("""
            background: transparent;
            border: none;
            font-size: 22px;
            font-weight: 700;
            color: #FFFFFF;
            letter-spacing: -0.4px;
            font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif;
        """)
        self.title_lbl.setAlignment(Qt.AlignCenter)
        card_lay.addWidget(self.title_lbl)

        self.ver_lbl = QLabel(t("update_dialog_current_version", version=APP_VERSION))
        self.ver_lbl.setStyleSheet("background: transparent; border: none; font-size: 12px; color: #8E8E93; font-weight: 500;")
        self.ver_lbl.setAlignment(Qt.AlignCenter)
        card_lay.addWidget(self.ver_lbl)

        # 3. Status Box
        self.status_box = QFrame()
        self.status_box.setStyleSheet("""
            QFrame {
                background: rgba(255, 255, 255, 0.04);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 14px;
                padding: 12px;
            }
        """)
        status_lay = QVBoxLayout(self.status_box)
        status_lay.setContentsMargins(12, 10, 12, 10)
        status_lay.setSpacing(6)

        self.status_headline = QLabel(t("update_dialog_checking"))
        self.status_headline.setStyleSheet("background: transparent; border: none; font-size: 14px; font-weight: 600; color: #FFFFFF;")
        self.status_headline.setAlignment(Qt.AlignCenter)
        status_lay.addWidget(self.status_headline)

        self.status_detail = QLabel("Forbinder til opdateringsserveren...")
        self.status_detail.setWordWrap(True)
        self.status_detail.setStyleSheet("background: transparent; border: none; font-size: 12px; color: #A1A1AA; line-height: 1.4;")
        self.status_detail.setAlignment(Qt.AlignCenter)
        status_lay.addWidget(self.status_detail)

        # Changelog area (dynamic)
        self.changelog_lbl = QLabel("")
        self.changelog_lbl.setWordWrap(True)
        self.changelog_lbl.setStyleSheet("background: transparent; border: none; font-size: 11px; color: #D1D5DB; line-height: 1.4;")
        self.changelog_lbl.setVisible(False)
        status_lay.addWidget(self.changelog_lbl)

        card_lay.addWidget(self.status_box)

        # 4. Slim Apple Capsule Progress Bar (6px)
        self.pbar = QProgressBar()
        self.pbar.setValue(0)
        self.pbar.setFixedHeight(6)
        self.pbar.setTextVisible(False)
        self.pbar.setStyleSheet("""
            QProgressBar {
                background: rgba(255, 255, 255, 0.08);
                border: none;
                border-radius: 3px;
            }
            QProgressBar::chunk {
                background: #FFFFFF;
                border-radius: 3px;
            }
        """)
        self.pbar.setVisible(False)
        card_lay.addWidget(self.pbar)

        card_lay.addStretch()

        # 5. Bottom Action Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)

        self.sec_btn = QPushButton("Luk")
        self.sec_btn.setFixedHeight(42)
        self.sec_btn.setCursor(Qt.PointingHandCursor)
        self.sec_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #D1D5DB;
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 12px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.15);
                color: #FFFFFF;
            }
        """)
        self.sec_btn.clicked.connect(self.close)
        btn_row.addWidget(self.sec_btn)

        self.action_btn = QPushButton(t("update_check_again"))
        self.action_btn.setFixedHeight(42)
        self.action_btn.setCursor(Qt.PointingHandCursor)
        self.action_btn.setStyleSheet("""
            QPushButton {
                background: #FFFFFF;
                color: #000000;
                border: none;
                border-radius: 12px;
                font-size: 13px;
                font-weight: 700;
                font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif;
            }
            QPushButton:hover {
                background: #E5E5EA;
            }
            QPushButton:disabled {
                background: rgba(255, 255, 255, 0.25);
                color: rgba(0, 0, 0, 0.4);
            }
        """)
        self.action_btn.clicked.connect(self._on_action_clicked)
        btn_row.addWidget(self.action_btn)

        card_lay.addLayout(btn_row)
        root_lay.addWidget(self.card)

    def _set_badge_icon(self, mode: str):
        pix = QPixmap(56, 56)
        pix.fill(Qt.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.Antialiasing)
        path = QPainterPath()
        path.addRoundedRect(2, 2, 52, 52, 16, 16)

        grad = QLinearGradient(0, 0, 56, 56)
        if mode == "success":
            grad.setColorAt(0.0, QColor("#10B981"))
            grad.setColorAt(1.0, QColor("#059669"))
            sym = "✓"
        elif mode == "available":
            grad.setColorAt(0.0, QColor("#3B82F6"))
            grad.setColorAt(1.0, QColor("#2563EB"))
            sym = "↓"
        else:
            grad.setColorAt(0.0, QColor("#6366F1"))
            grad.setColorAt(1.0, QColor("#4F46E5"))
            sym = "⟳"

        p.fillPath(path, grad)
        p.setPen(QColor("#FFFFFF"))
        p.setFont(QFont("-apple-system", 26, QFont.Bold))
        p.drawText(pix.rect(), Qt.AlignCenter, sym)
        p.end()
        self.badge_lbl.setPixmap(pix)

    def _check_updates(self):
        self.action_btn.setEnabled(False)
        self.status_headline.setText(t("update_dialog_checking"))
        self.status_detail.setText("Undersøger om der er en nyere version tilgængelig...")
        self._set_badge_icon("checking")

        threading.Thread(target=self._run_check_async, daemon=True).start()

    def _run_check_async(self):
        time.sleep(0.6)  # Smooth Apple cadence
        info = self.manager.check_for_updates()
        self.update_info = info
        # Safely invoke UI update on main thread
        from PySide6.QtCore import QMetaObject, Q_ARG
        QMetaObject.invokeMethod(self, "_on_check_completed", Qt.QueuedConnection)

    from PySide6.QtCore import Slot

    @Slot()
    def _on_check_completed(self):
        self.action_btn.setEnabled(True)
        has_update = self.update_info.get("has_update", False)
        latest = self.update_info.get("latest_version", APP_VERSION)

        if has_update:
            self._set_badge_icon("available")
            self.status_headline.setText(t("update_dialog_available", version=latest))
            self.status_detail.setText(t("update_dialog_available_sub"))
            
            changes = self.update_info.get("changelog", [])
            if changes:
                text = "<b>" + t("update_dialog_changelog_title") + "</b><br>" + "<br>".join(f"• {c}" for c in changes)
                self.changelog_lbl.setText(text)
                self.changelog_lbl.setVisible(True)

            self.action_btn.setText(t("update_dialog_install_btn"))
        else:
            self._set_badge_icon("success")
            self.status_headline.setText(t("update_dialog_up_to_date"))
            self.status_detail.setText(t("update_dialog_up_to_date_sub", version=APP_VERSION))
            self.changelog_lbl.setVisible(False)
            self.action_btn.setText(t("update_check_again"))

    def _on_action_clicked(self):
        if self.is_ready_to_restart:
            self.manager.restart_app()
            return

        if self.update_info.get("has_update", False):
            self._start_download_and_install()
        else:
            self._check_updates()

    def _start_download_and_install(self):
        self.action_btn.setEnabled(False)
        self.sec_btn.setEnabled(False)
        self.pbar.setVisible(True)
        self.pbar.setValue(5)
        self.status_headline.setText("Henter og installerer opdatering...")
        self.status_detail.setText("Forbinder til opdatering...")

        self.worker = UpdateWorker(self.manager, self.update_info)
        self.worker.progress.connect(self._on_worker_progress)
        self.worker.finished.connect(self._on_worker_finished)

        self._thread = threading.Thread(target=self.worker.run, daemon=True)
        self._thread.start()

    def _on_worker_progress(self, pct: int, msg: str):
        self.pbar.setValue(pct)
        self.status_detail.setText(msg)

    def _on_worker_finished(self, success: bool, message: str):
        self.pbar.setValue(100 if success else 0)
        if success:
            self.is_ready_to_restart = True
            self._set_badge_icon("success")
            self.status_headline.setText(t("update_dialog_success"))
            self.status_detail.setText(message)
            self.changelog_lbl.setVisible(False)

            self.action_btn.setEnabled(True)
            self.action_btn.setText(t("update_dialog_restart_btn"))
            self.sec_btn.setEnabled(True)
            self.sec_btn.setText("Luk")
        else:
            self._set_badge_icon("available")
            self.status_headline.setText("Opdatering mislykkedes")
            self.status_detail.setText(message)
            self.action_btn.setEnabled(True)
            self.action_btn.setText(t("update_check_again"))
            self.sec_btn.setEnabled(True)
