"""
TouchDeck / VENTRIX - Apple macOS Segmented Button Inspector
Clean, calm, uncrowded architecture:
- Segmented Apple Tabs: [ Indhold | Handling | Design ]
- Zero visual clutter: Only 2-4 focused controls visible at a time
- Zero emojis: Clean typography and subtle glass geometry
- Full bilingual Danish & English support via shared.i18n
Author: VENTRIX
"""

import os
from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QComboBox, QSlider, QFrame, QFileDialog,
    QScrollArea, QStackedWidget
)
from PySide6.QtCore import Qt, Signal, QSize, QPoint, QRect, QRectF, QTimer, Property, QPropertyAnimation, QEasingCurve
from PySide6.QtGui import (
    QIcon, QColor, QFont, QPixmap, QPainter, QLinearGradient,
    QPainterPath, QPen, QBrush
)

from editor.widgets.apple_color_picker import AppleGlassColorPicker
from editor.widgets.apple_icon_picker import AppleGlassIconPicker
from editor.widgets.macro_editor_dialog import MacroEditorDialog
from editor.widgets.font_picker_widget import FontGalleryWidget

from shared.constants import (
    ACTION_TYPE_APPLICATION, ACTION_TYPE_HOTKEY, ACTION_TYPE_MEDIA,
    ACTION_TYPE_MOUSE, ACTION_TYPE_SYSTEM, ACTION_TYPE_FILE_FOLDER_URL,
    ACTION_TYPE_SCRIPT, ACTION_TYPE_MACRO, ACTION_TYPE_DISCORD, ACTION_TYPE_MEDAL,
    DISCORD_MUTE_MIC, DISCORD_DEAFEN, DISCORD_PUSH_TO_TALK, DISCORD_STREAM_TOGGLE,
    MEDAL_CLIP_15S, MEDAL_CLIP_30S, MEDAL_CLIP_1M, MEDAL_CLIP_2M, MEDAL_CLIP_5M,
    MEDAL_RECORD_TOGGLE, MEDAL_BOOKMARK
)
from shared.models import ButtonModel, ActionModel
from editor.utils.icon_storage import save_custom_image, resolve_icon_path
from shared.i18n import t, I18nManager


class AppleDivider(QFrame):
    """Subtle 1px hairline divider."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.HLine)
        self.setFrameShadow(QFrame.Plain)
        self.setFixedHeight(1)
        self.setStyleSheet("background: rgba(255, 255, 255, 0.08); border: none;")


class MiniButtonPreview(QFrame):
    """Clean visionOS-inspired mini live button preview."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.button: Optional[ButtonModel] = None
        self.setFixedHeight(110)
        self.setCursor(Qt.ArrowCursor)

    def set_button(self, button: Optional[ButtonModel]):
        self.button = button
        self.update()

    def paintEvent(self, event):
        if not self.button:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)

        rect = self.rect().adjusted(14, 10, -14, -10)
        radius = float(self.button.border_radius or 28)
        if radius <= 16:
            radius = 28.0

        # Background Fill
        bg_col = QColor(self.button.bg_color or "#141416")
        path = QPainterPath()
        path.addRoundedRect(QRectF(rect), radius, radius)
        painter.fillPath(path, QBrush(bg_col))

        # Soft top sheen (clipped to squircle)
        painter.save()
        painter.setClipPath(path)
        sheen_height = rect.height() * 0.45
        sheen_rect = QRectF(rect.x(), rect.y(), rect.width(), sheen_height)
        sheen_grad = QLinearGradient(0, rect.top(), 0, rect.top() + sheen_height)
        sheen_grad.setColorAt(0.0, QColor(255, 255, 255, 32))
        sheen_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.fillRect(sheen_rect, sheen_grad)
        painter.restore()

        # Hairline Rim
        border_pen = QPen(QColor(255, 255, 255, 25), 1.0)
        painter.strokePath(path, border_pen)

        # Custom Logo / Icon
        icon_drawn = False
        resolved_icon_path = resolve_icon_path(self.button.icon)

        if resolved_icon_path and resolved_icon_path.exists():
            pix = QPixmap(str(resolved_icon_path))
            if not pix.isNull():
                max_icon_size = min(int(rect.height() * 0.44), 44)
                scaled_pix = pix.scaled(max_icon_size, max_icon_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                ix = rect.center().x() - scaled_pix.width() // 2
                iy = rect.top() + int(rect.height() * 0.32) - scaled_pix.height() // 2
                painter.drawPixmap(ix, iy, scaled_pix)
                icon_drawn = True

        # Typography
        painter.setPen(QColor(self.button.text_color or "#FFFFFF"))
        font_size = self.button.font_size or 12
        font_fam = self.button.font_family or "Segoe UI Variable Text"
        painter.setFont(QFont(font_fam, font_size, QFont.Bold))

        if icon_drawn:
            text_rect = QRect(
                rect.left() + 4,
                rect.top() + int(rect.height() * 0.50),
                rect.width() - 8,
                int(rect.height() * 0.46)
            )
        else:
            text_rect = rect.adjusted(6, 6, -6, -6)

        painter.drawText(text_rect, Qt.AlignCenter | Qt.TextWordWrap, self.button.title or "Button")


class SegmentedTabControl(QWidget):
    """
    Custom-painted capsule tab bar: [ Indhold | Handling | Design ].
    100% custom-painted QPainter control with smooth sliding glass thumb.
    Eliminates all QSS margin, padding, border-radius and clipping issues.
    """
    tab_changed = Signal(int)

    def __init__(self, tabs: list, current_index: int = 0, parent=None):
        super().__init__(parent)
        self.tabs = list(tabs)
        self.current_index = current_index
        self.setFixedHeight(34)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)
        self.setStyleSheet("background: transparent; border: none;")

        self._hover_idx = -1
        self._indicator_x = 3.0
        self._target_x = 3.0
        self._anim = None

    def get_indicator_x(self) -> float:
        return self._indicator_x

    def set_indicator_x(self, val: float):
        self._indicator_x = val
        self.update()

    indicator_x = Property(float, get_indicator_x, set_indicator_x)

    def _calc_target_x(self, idx: int) -> float:
        if not self.tabs:
            return 3.0
        num = len(self.tabs)
        tab_w = (float(self.width()) - 6.0) / num
        return 3.0 + idx * tab_w

    def _select_tab(self, idx: int, animate: bool = True):
        if 0 <= idx < len(self.tabs):
            self.current_index = idx
            target = self._calc_target_x(idx)
            if animate and self.isVisible():
                if self._anim:
                    self._anim.stop()
                self._anim = QPropertyAnimation(self, b"indicator_x")
                self._anim.setDuration(160)
                self._anim.setStartValue(self._indicator_x)
                self._anim.setEndValue(target)
                self._anim.setEasingCurve(QEasingCurve.OutCubic)
                self._anim.start()
            else:
                self._indicator_x = target
                self.update()
            self.tab_changed.emit(idx)

    def set_current_index(self, idx: int):
        self._select_tab(idx, animate=False)

    def set_tab_texts(self, texts: list):
        self.tabs = list(texts)
        self.update()

    def resizeEvent(self, e):
        self._indicator_x = self._calc_target_x(self.current_index)
        super().resizeEvent(e)

    def mouseMoveEvent(self, e):
        if self.tabs:
            num = len(self.tabs)
            tab_w = (float(self.width()) - 6.0) / num
            hovered = int((e.pos().x() - 3.0) / max(1.0, tab_w))
            hovered = max(0, min(num - 1, hovered))
            if hovered != self._hover_idx:
                self._hover_idx = hovered
                self.update()
        super().mouseMoveEvent(e)

    def leaveEvent(self, e):
        self._hover_idx = -1
        self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and self.tabs:
            num = len(self.tabs)
            tab_w = (float(self.width()) - 6.0) / num
            clicked = int((e.pos().x() - 3.0) / max(1.0, tab_w))
            clicked = max(0, min(num - 1, clicked))
            self._select_tab(clicked, animate=True)
        super().mousePressEvent(e)

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)

        w = float(self.width())
        h = float(self.height())
        if w < 10 or not self.tabs:
            return

        # Outer capsule
        outer_r = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        outer_path = QPainterPath()
        outer_path.addRoundedRect(outer_r, 11.0, 11.0)
        p.fillPath(outer_path, QColor(255, 255, 255, 12))
        p.strokePath(outer_path, QPen(QColor(255, 255, 255, 24), 1.0))

        num = len(self.tabs)
        tab_w = (w - 6.0) / num
        tab_h = h - 6.0

        # Sliding thumb
        thumb_r = QRectF(self._indicator_x, 3.0, tab_w, tab_h)
        thumb_path = QPainterPath()
        thumb_path.addRoundedRect(thumb_r, 9.0, 9.0)

        grad = QLinearGradient(0, 3, 0, 3 + tab_h)
        grad.setColorAt(0.0, QColor(255, 255, 255, 52))
        grad.setColorAt(1.0, QColor(255, 255, 255, 30))
        p.fillPath(thumb_path, grad)
        p.strokePath(thumb_path, QPen(QColor(255, 255, 255, 75), 1.0))

        # Tab text labels
        font_active = QFont("-apple-system", 10)
        font_active.setStyleHint(QFont.SansSerif)
        font_active.setWeight(QFont.DemiBold)

        font_inactive = QFont("-apple-system", 10)
        font_inactive.setStyleHint(QFont.SansSerif)
        font_inactive.setWeight(QFont.Medium)

        for i, text in enumerate(self.tabs):
            text_rect = QRectF(3.0 + i * tab_w, 3.0, tab_w, tab_h)
            if i == self.current_index:
                p.setFont(font_active)
                p.setPen(QColor(255, 255, 255, 255))
            else:
                p.setFont(font_inactive)
                if i == self._hover_idx:
                    p.setPen(QColor(255, 255, 255, 220))
                else:
                    p.setPen(QColor(255, 255, 255, 125))
            p.drawText(text_rect, Qt.AlignCenter, text)


class CategoryPillButton(QPushButton):
    """
    An elongated category bar with rounded corners for the inspector:
    - Normal: subtle glass background, clean typography.
    - Hover: lighter glass, high contrast.
    - Selected: white text, 1.5px glowing green border (#22C55E),
      glass background, and a bright emerald green dot on the right side.
    """
    def __init__(self, text: str, data: str = "", parent=None):
        super().__init__(text, parent)
        self.data = data
        self.setFixedHeight(36)
        self.setCursor(Qt.PointingHandCursor)
        self._is_selected = False
        self._update_style()

    def set_selected(self, selected: bool):
        self._is_selected = selected
        self._update_style()
        self.update()

    def _update_style(self):
        if self._is_selected:
            self.setStyleSheet("""
                QPushButton {
                    background: rgba(255, 255, 255, 0.15);
                    color: #FFFFFF;
                    border: 1.5px solid #22C55E;
                    border-radius: 9px;
                    padding-left: 14px;
                    padding-right: 28px;
                    text-align: left;
                    font-size: 13px;
                    font-weight: 700;
                }
                QPushButton:hover {
                    background: rgba(255, 255, 255, 0.20);
                }
            """)
        else:
            self.setStyleSheet("""
                QPushButton {
                    background: rgba(255, 255, 255, 0.04);
                    color: rgba(255, 255, 255, 0.70);
                    border: 1px solid rgba(255, 255, 255, 0.08);
                    border-radius: 9px;
                    padding-left: 14px;
                    padding-right: 14px;
                    text-align: left;
                    font-size: 13px;
                    font-weight: 500;
                }
                QPushButton:hover {
                    background: rgba(255, 255, 255, 0.09);
                    color: #FFFFFF;
                    border-color: rgba(255, 255, 255, 0.22);
                }
            """)

    def paintEvent(self, event):
        super().paintEvent(event)
        if self._is_selected:
            p = QPainter(self)
            p.setRenderHint(QPainter.Antialiasing)
            p.setPen(Qt.NoPen)
            # Glowing green dot on the right side
            cx = self.width() - 16
            cy = self.height() // 2
            p.setBrush(QColor(34, 197, 94, 60))
            p.drawEllipse(QPoint(cx, cy), 6, 6)
            p.setBrush(QColor("#22C55E"))
            p.drawEllipse(QPoint(cx, cy), 3, 3)
            p.end()


class ActionCategorySelector(QFrame):
    """
    Vertical category bar with rounded corners where each action is an elongated pill.
    Drop-in replacement for QComboBox with identical methods:
    addItem, clear, currentIndex, currentData, findData, setCurrentIndex, blockSignals,
    and currentIndexChanged signal.
    """
    currentIndexChanged = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("actionCategoryContainer")
        self.setStyleSheet("""
            QFrame#actionCategoryContainer {
                background: rgba(255, 255, 255, 0.03);
                border: 1px solid rgba(255, 255, 255, 0.09);
                border-radius: 12px;
            }
        """)
        self._items = []  # List of CategoryPillButton
        self._current_index = 0
        self._signals_blocked = False

        self._lay = QVBoxLayout(self)
        self._lay.setContentsMargins(6, 6, 6, 6)
        self._lay.setSpacing(5)

    def addItem(self, text: str, data: str = ""):
        idx = len(self._items)
        btn = CategoryPillButton(text, data, self)
        btn.clicked.connect(lambda checked=False, i=idx: self.setCurrentIndex(i))
        self._items.append(btn)
        self._lay.addWidget(btn)
        if idx == self._current_index:
            btn.set_selected(True)

    def clear(self):
        for btn in self._items:
            self._lay.removeWidget(btn)
            btn.deleteLater()
        self._items.clear()
        self._current_index = 0

    def blockSignals(self, b: bool):
        self._signals_blocked = b

    def signalsBlocked(self) -> bool:
        return self._signals_blocked

    def currentIndex(self) -> int:
        return self._current_index

    def currentData(self) -> str:
        if 0 <= self._current_index < len(self._items):
            return self._items[self._current_index].data
        return ""

    def findData(self, data: str) -> int:
        for i, btn in enumerate(self._items):
            if btn.data == data:
                return i
        return -1

    def setCurrentIndex(self, idx: int):
        if not (0 <= idx < len(self._items)):
            return
        self._current_index = idx
        for i, btn in enumerate(self._items):
            btn.set_selected(i == idx)
        if not self._signals_blocked:
            self.currentIndexChanged.emit(idx)


class ButtonInspector(QFrame):
    """
    Calm, elegant Apple Settings panel for button editing.
    Segmented into 3 tranquil tabs: [ Indhold | Handling | Design ].
    Zero visual noise, zero emojis, pure macOS glass.
    """
    button_updated = Signal(object)        # ButtonModel
    button_deleted = Signal(str)           # button_id
    button_test_requested = Signal(object) # ButtonModel
    push_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("cardFrame")
        self.button: Optional[ButtonModel] = None

        # Auto-fetch timer for website URLs (700ms debounce)
        self.url_fetch_timer = QTimer(self)
        self.url_fetch_timer.setSingleShot(True)
        self.url_fetch_timer.setInterval(700)
        self.url_fetch_timer.timeout.connect(self._auto_fetch_url_logo)

        self._init_ui()

        # Listen to language changes
        I18nManager.get_instance().language_changed.connect(self._on_language_changed)

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(16, 14, 16, 14)
        root_lay.setSpacing(12)

        # ----------------------------------------------------
        # Top Header: Title & Delete Action
        # ----------------------------------------------------
        header_row = QHBoxLayout()
        header_row.setContentsMargins(0, 0, 0, 0)

        self.title_lbl = QLabel(t("inspector_title"))
        self.title_lbl.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 600; letter-spacing: 1px; background: transparent; border: none;")
        header_row.addWidget(self.title_lbl)
        header_row.addStretch()

        self.delete_btn = QPushButton(t("inspector_delete"))
        self.delete_btn.setObjectName("dangerBtn")
        self.delete_btn.setFixedHeight(28)
        self.delete_btn.setCursor(Qt.PointingHandCursor)
        self.delete_btn.clicked.connect(self._on_delete_clicked)
        header_row.addWidget(self.delete_btn)
        root_lay.addLayout(header_row)

        # ----------------------------------------------------
        # Apple Segmented Tabs: [ Indhold | Handling | Design ]
        # ----------------------------------------------------
        tab_names = [t("inspector_tab_content"), t("inspector_tab_action"), t("inspector_tab_design")]
        self.segmented_tabs = SegmentedTabControl(tab_names, current_index=0)
        self.segmented_tabs.tab_changed.connect(self._on_tab_changed)
        root_lay.addWidget(self.segmented_tabs)

        # ----------------------------------------------------
        # Stacked Pages: Content | Action | Design
        # ----------------------------------------------------
        self.stack = QStackedWidget()
        self.stack.addWidget(self._build_content_tab())
        self.stack.addWidget(self._build_action_tab())
        self.stack.addWidget(self._build_design_tab())
        root_lay.addWidget(self.stack, stretch=1)

    # =========================================================================
    # TAB 1: INDHOLD (CONTENT)
    # =========================================================================
    def _build_content_tab(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")

        container = QWidget()
        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 4, 0, 4)
        lay.setSpacing(12)

        # 1. Mini Live Physical Button Preview
        self.mini_preview = MiniButtonPreview()
        lay.addWidget(self.mini_preview)

        lay.addWidget(AppleDivider())

        # 2. Button Title
        self.title_input_lbl = QLabel(t("inspector_title_label"))
        self.title_input_lbl.setStyleSheet("color: #A1A1AA; font-size: 11px; font-weight: 600; letter-spacing: 0.5px; background: transparent; border: none;")
        lay.addWidget(self.title_input_lbl)

        self.title_input = QLineEdit()
        self.title_input.setFixedHeight(38)
        self.title_input.setPlaceholderText(t("inspector_title_placeholder"))
        self.title_input.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                border: 1.5px solid rgba(255, 255, 255, 0.25);
                border-radius: 9px;
                padding: 0 12px;
                font-size: 13px;
                font-weight: 600;
            }
            QLineEdit:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: rgba(255, 255, 255, 0.40);
            }
            QLineEdit:focus {
                background-color: rgba(255, 255, 255, 0.16);
                border-color: #FFFFFF;
            }
        """)
        self.title_input.textChanged.connect(self._on_title_changed)
        lay.addWidget(self.title_input)

        lay.addWidget(AppleDivider())

        # 3. Compact Current Icon Card (With clean toggle)
        self.icon_sec_lbl = QLabel(t("inspector_icon_section"))
        self.icon_sec_lbl.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 600; letter-spacing: 0.8px; background: transparent; border: none;")
        lay.addWidget(self.icon_sec_lbl)

        icon_card = QFrame()
        icon_card.setStyleSheet("""
            QFrame {
                background: rgba(255, 255, 255, 0.04);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
            }
        """)
        icon_card_lay = QHBoxLayout(icon_card)
        icon_card_lay.setContentsMargins(10, 10, 10, 10)
        icon_card_lay.setSpacing(10)

        # Active icon preview squircle
        self.icon_thumb_lbl = QLabel()
        self.icon_thumb_lbl.setFixedSize(40, 40)
        self.icon_thumb_lbl.setAlignment(Qt.AlignCenter)
        self.icon_thumb_lbl.setStyleSheet("""
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.14);
            border-radius: 8px;
        """)
        icon_card_lay.addWidget(self.icon_thumb_lbl)

        # Active icon label info
        self.icon_name_lbl = QLabel(t("inspector_no_icon"))
        self.icon_name_lbl.setStyleSheet("color: #FFFFFF; font-size: 11px; font-weight: 500; background: transparent; border: none;")
        icon_card_lay.addWidget(self.icon_name_lbl, stretch=1)

        # Toggle icon picker button
        self.toggle_picker_btn = QPushButton(t("inspector_choose_icon"))
        self.toggle_picker_btn.setCursor(Qt.PointingHandCursor)
        self.toggle_picker_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.10);
                border: 1px solid rgba(255, 255, 255, 0.18);
                border-radius: 7px;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 600;
                padding: 6px 10px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.20);
            }
        """)
        self.toggle_picker_btn.clicked.connect(self._toggle_icon_picker)
        icon_card_lay.addWidget(self.toggle_picker_btn)

        # Remove icon button
        self.remove_icon_btn = QPushButton(t("inspector_remove_icon"))
        self.remove_icon_btn.setCursor(Qt.PointingHandCursor)
        self.remove_icon_btn.setStyleSheet("""
            QPushButton {
                background: rgba(239, 68, 68, 0.10);
                border: 1px solid rgba(239, 68, 68, 0.22);
                border-radius: 7px;
                color: #EF4444;
                font-size: 11px;
                font-weight: 500;
                padding: 6px 8px;
            }
            QPushButton:hover {
                background: rgba(239, 68, 68, 0.20);
            }
        """)
        self.remove_icon_btn.clicked.connect(self._clear_icon)
        icon_card_lay.addWidget(self.remove_icon_btn)

        lay.addWidget(icon_card)

        # Collapsible Icon Picker (Only shown when requested!)
        self.icon_picker = AppleGlassIconPicker(parent=self)
        self.icon_picker.icon_selected.connect(self._on_icon_selected)
        self.icon_picker.hide()
        lay.addWidget(self.icon_picker)

        lay.addStretch()
        scroll.setWidget(container)
        return scroll

    # =========================================================================
    # TAB 2: HANDLING (ACTION)
    # =========================================================================
    def _build_action_tab(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")

        container = QWidget()
        lay = QVBoxLayout(container)
        lay.setContentsMargins(2, 8, 2, 8)
        lay.setSpacing(18)

        # 1. Action Type Selection Section
        type_section = QWidget()
        type_lay = QVBoxLayout(type_section)
        type_lay.setContentsMargins(0, 0, 0, 0)
        type_lay.setSpacing(8)

        self.act_type_lbl = QLabel(t("inspector_action_type"))
        self.act_type_lbl.setStyleSheet("color: #A1A1AA; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px;")
        type_lay.addWidget(self.act_type_lbl)

        self.action_type_combo = ActionCategorySelector()
        self._populate_action_types()
        self.action_type_combo.currentIndexChanged.connect(self._on_action_type_changed)
        type_lay.addWidget(self.action_type_combo)
        lay.addWidget(type_section)

        # 2. Action Parameters Card Frame
        param_card = QFrame()
        param_card.setObjectName("actionParamCard")
        param_card.setStyleSheet("""
            QFrame#actionParamCard {
                background: rgba(255, 255, 255, 0.04);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 12px;
            }
        """)
        card_inner = QVBoxLayout(param_card)
        card_inner.setContentsMargins(14, 14, 14, 14)
        card_inner.setSpacing(10)

        # Action Parameters Stack
        self.action_stack = QStackedWidget()
        self.action_stack.setStyleSheet("background: transparent; border: none;")

        # Page 0: Application
        app_widget = QWidget()
        app_widget.setStyleSheet("background: transparent; border: none;")
        app_lay = QVBoxLayout(app_widget)
        app_lay.setContentsMargins(0, 0, 0, 0)
        app_lay.setSpacing(10)
        app_lbl = QLabel("Program (.exe) eller genvej:")
        app_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        app_lay.addWidget(app_lbl)

        self.pick_exe_btn = QPushButton(t("inspector_browse_exe"))
        self.pick_exe_btn.setFixedHeight(38)
        self.pick_exe_btn.setCursor(Qt.PointingHandCursor)
        self.pick_exe_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.18);
                border-radius: 9px;
                color: #FFFFFF;
                font-size: 12px;
                font-weight: 600;
                padding: 0 14px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.16);
                border-color: rgba(255, 255, 255, 0.30);
            }
        """)
        self.pick_exe_btn.clicked.connect(self._browse_application)
        app_lay.addWidget(self.pick_exe_btn)

        self.app_path_input = QLineEdit()
        self.app_path_input.setFixedHeight(40)
        self.app_path_input.setPlaceholderText(t("inspector_app_placeholder"))
        self.app_path_input.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.07);
                color: #FFFFFF;
                border: 1.5px solid rgba(255, 255, 255, 0.20);
                border-radius: 9px;
                padding: 0 12px;
                font-size: 13px;
                font-weight: 500;
            }
            QLineEdit:hover {
                background-color: rgba(255, 255, 255, 0.11);
                border-color: rgba(255, 255, 255, 0.35);
            }
            QLineEdit:focus {
                background-color: rgba(255, 255, 255, 0.15);
                border-color: #FFFFFF;
            }
        """)
        self.app_path_input.textChanged.connect(self._on_action_params_changed)
        app_lay.addWidget(self.app_path_input)
        self.action_stack.addWidget(app_widget)

        # Page 1: Hotkey
        hotkey_widget = QWidget()
        hotkey_widget.setStyleSheet("background: transparent; border: none;")
        hotkey_lay = QVBoxLayout(hotkey_widget)
        hotkey_lay.setContentsMargins(0, 0, 0, 0)
        hotkey_lay.setSpacing(10)

        hotkey_lbl = QLabel("Tastatur-kombination:")
        hotkey_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        hotkey_lay.addWidget(hotkey_lbl)

        self.hotkey_input = QLineEdit()
        self.hotkey_input.setFixedHeight(44)
        self.hotkey_input.setPlaceholderText(t("inspector_hotkey_placeholder"))
        self.hotkey_input.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                border: 1.5px solid rgba(255, 255, 255, 0.24);
                border-radius: 10px;
                padding: 0 14px;
                font-size: 14px;
                font-weight: 700;
                font-family: 'SF Mono', 'Consolas', monospace;
                letter-spacing: 0.5px;
            }
            QLineEdit:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: rgba(255, 255, 255, 0.45);
            }
            QLineEdit:focus {
                background-color: rgba(255, 255, 255, 0.16);
                border-color: #FFFFFF;
            }
        """)
        self.hotkey_input.textChanged.connect(self._on_action_params_changed)
        hotkey_lay.addWidget(self.hotkey_input)

        hint_lbl = QLabel("F.eks. Ctrl+Shift+M, Alt+F4, Media_Play eller F13")
        hint_lbl.setStyleSheet("color: rgba(255, 255, 255, 0.50); font-size: 11px; font-weight: 400;")
        hotkey_lay.addWidget(hint_lbl)
        self.action_stack.addWidget(hotkey_widget)

        # Page 2: Media
        media_widget = QWidget()
        media_widget.setStyleSheet("background: transparent; border: none;")
        media_lay = QVBoxLayout(media_widget)
        media_lay.setContentsMargins(0, 0, 0, 0)
        media_lay.setSpacing(10)
        media_lbl = QLabel("Mediehandling:")
        media_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        media_lay.addWidget(media_lbl)
        self.media_combo = QComboBox()
        self.media_combo.setFixedHeight(40)
        self.media_combo.setStyleSheet("""
            QComboBox {
                background-color: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                border: 1.5px solid rgba(255, 255, 255, 0.20);
                border-radius: 9px;
                padding: 0 12px;
                font-size: 13px;
                font-weight: 500;
            }
            QComboBox:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: rgba(255, 255, 255, 0.35);
            }
            QComboBox QAbstractItemView {
                background-color: #18181B;
                color: #FFFFFF;
                selection-background-color: rgba(255, 255, 255, 0.18);
                selection-color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.20);
                border-radius: 8px;
                padding: 4px;
            }
        """)
        self.media_combo.addItems(["play_pause", "next_track", "prev_track", "volume_up", "volume_down", "volume_mute"])
        self.media_combo.currentIndexChanged.connect(self._on_action_params_changed)
        media_lay.addWidget(self.media_combo)
        self.action_stack.addWidget(media_widget)

        # Page 3: URL
        url_widget = QWidget()
        url_widget.setStyleSheet("background: transparent; border: none;")
        url_lay = QVBoxLayout(url_widget)
        url_lay.setContentsMargins(0, 0, 0, 0)
        url_lay.setSpacing(10)
        url_lbl = QLabel("Webadresse / URL:")
        url_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        url_lay.addWidget(url_lbl)
        self.url_input = QLineEdit()
        self.url_input.setFixedHeight(40)
        self.url_input.setPlaceholderText(t("inspector_url_placeholder"))
        self.url_input.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.07);
                color: #FFFFFF;
                border: 1.5px solid rgba(255, 255, 255, 0.20);
                border-radius: 9px;
                padding: 0 12px;
                font-size: 13px;
                font-weight: 500;
            }
            QLineEdit:hover {
                background-color: rgba(255, 255, 255, 0.11);
                border-color: rgba(255, 255, 255, 0.35);
            }
            QLineEdit:focus {
                background-color: rgba(255, 255, 255, 0.15);
                border-color: #FFFFFF;
            }
        """)
        self.url_input.textChanged.connect(self._on_action_params_changed)
        url_lay.addWidget(self.url_input)

        self.fetch_url_logo_btn = QPushButton(t("inspector_fetch_logo"))
        self.fetch_url_logo_btn.setFixedHeight(36)
        self.fetch_url_logo_btn.setCursor(Qt.PointingHandCursor)
        self.fetch_url_logo_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.18);
                border-radius: 8px;
                color: #FFFFFF;
                font-size: 12px;
                font-weight: 600;
                padding: 6px 14px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.16);
                border-color: rgba(255, 255, 255, 0.30);
            }
        """)
        self.fetch_url_logo_btn.clicked.connect(self._fetch_logo_for_current_url)
        url_lay.addWidget(self.fetch_url_logo_btn)
        self.action_stack.addWidget(url_widget)

        # Page 4: System
        sys_widget = QWidget()
        sys_widget.setStyleSheet("background: transparent; border: none;")
        sys_lay = QVBoxLayout(sys_widget)
        sys_lay.setContentsMargins(0, 0, 0, 0)
        sys_lay.setSpacing(10)
        sys_lbl = QLabel("Systemhandling:")
        sys_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        sys_lay.addWidget(sys_lbl)
        self.sys_combo = QComboBox()
        self.sys_combo.setFixedHeight(40)
        self.sys_combo.setStyleSheet("""
            QComboBox {
                background-color: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                border: 1.5px solid rgba(255, 255, 255, 0.20);
                border-radius: 9px;
                padding: 0 12px;
                font-size: 13px;
                font-weight: 500;
            }
            QComboBox:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: rgba(255, 255, 255, 0.35);
            }
            QComboBox QAbstractItemView {
                background-color: #18181B;
                color: #FFFFFF;
                selection-background-color: rgba(255, 255, 255, 0.18);
                selection-color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.20);
                border-radius: 8px;
                padding: 4px;
            }
        """)
        self.sys_combo.addItems(["lock_workstation", "sleep", "screenshot", "task_manager"])
        self.sys_combo.currentIndexChanged.connect(self._on_action_params_changed)
        sys_lay.addWidget(self.sys_combo)
        self.action_stack.addWidget(sys_widget)

        # Page 5: Macro
        macro_widget = QWidget()
        macro_widget.setStyleSheet("background: transparent; border: none;")
        macro_lay = QVBoxLayout(macro_widget)
        macro_lay.setContentsMargins(0, 0, 0, 0)
        macro_lay.setSpacing(10)
        self.macro_btn = QPushButton(t("inspector_edit_macro"))
        self.macro_btn.setFixedHeight(40)
        self.macro_btn.setCursor(Qt.PointingHandCursor)
        self.macro_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.18);
                border-radius: 9px;
                color: #FFFFFF;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.16);
            }
        """)
        self.macro_btn.clicked.connect(self._open_macro_editor)
        macro_lay.addWidget(self.macro_btn)
        self.action_stack.addWidget(macro_widget)

        # Page 6: Discord
        discord_widget = QWidget()
        discord_widget.setStyleSheet("background: transparent; border: none;")
        discord_lay = QVBoxLayout(discord_widget)
        discord_lay.setContentsMargins(0, 0, 0, 0)
        discord_lay.setSpacing(10)
        d_lbl = QLabel("Discord Handling:")
        d_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        discord_lay.addWidget(d_lbl)
        self.discord_combo = QComboBox()
        self.discord_combo.setFixedHeight(40)
        self.discord_combo.addItem("Mikrofon Mute (Ctrl+Shift+M)", DISCORD_MUTE_MIC)
        self.discord_combo.addItem("Dæmp Alt / Deafen (Ctrl+Shift+D)", DISCORD_DEAFEN)
        self.discord_combo.addItem("Push-To-Talk (Ctrl)", DISCORD_PUSH_TO_TALK)
        self.discord_combo.addItem("Skærmdeling Toggle (Ctrl+Shift+S)", DISCORD_STREAM_TOGGLE)
        self.discord_combo.currentIndexChanged.connect(self._on_action_params_changed)
        discord_lay.addWidget(self.discord_combo)

        self.discord_key_input = QLineEdit()
        self.discord_key_input.setPlaceholderText("Brugerdefineret genvej (f.eks. Ctrl+Shift+M)")
        self.discord_key_input.setFixedHeight(36)
        self.discord_key_input.textChanged.connect(self._on_action_params_changed)
        discord_lay.addWidget(self.discord_key_input)
        self.action_stack.addWidget(discord_widget)

        # Page 7: Medal.tv
        medal_widget = QWidget()
        medal_widget.setStyleSheet("background: transparent; border: none;")
        medal_lay = QVBoxLayout(medal_widget)
        medal_lay.setContentsMargins(0, 0, 0, 0)
        medal_lay.setSpacing(10)
        m_lbl = QLabel("Medal.tv Handling:")
        m_lbl.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        medal_lay.addWidget(m_lbl)
        self.medal_combo = QComboBox()
        self.medal_combo.setFixedHeight(40)
        self.medal_combo.addItem("Klip 15 sekunder (F8)", MEDAL_CLIP_15S)
        self.medal_combo.addItem("Klip 30 sekunder (F8)", MEDAL_CLIP_30S)
        self.medal_combo.addItem("Klip 1 minut (F8)", MEDAL_CLIP_1M)
        self.medal_combo.addItem("Klip 2 minutter (F8)", MEDAL_CLIP_2M)
        self.medal_combo.addItem("Klip 5 minutter (F8)", MEDAL_CLIP_5M)
        self.medal_combo.addItem("Start/Stop Optagelse (F9)", MEDAL_RECORD_TOGGLE)
        self.medal_combo.addItem("Tilføj Bogmærke (F10)", MEDAL_BOOKMARK)
        self.medal_combo.currentIndexChanged.connect(self._on_action_params_changed)
        medal_lay.addWidget(self.medal_combo)

        self.medal_key_input = QLineEdit()
        self.medal_key_input.setPlaceholderText("Brugerdefineret tast (f.eks. F8)")
        self.medal_key_input.setFixedHeight(36)
        self.medal_key_input.textChanged.connect(self._on_action_params_changed)
        medal_lay.addWidget(self.medal_key_input)
        self.action_stack.addWidget(medal_widget)

        card_inner.addWidget(self.action_stack)
        lay.addWidget(param_card)

        lay.addSpacing(4)
        lay.addWidget(AppleDivider())
        lay.addSpacing(4)

        # 3. Test Button with spacious glass pill
        self.test_btn = QPushButton(t("inspector_test_button"))
        self.test_btn.setCursor(Qt.PointingHandCursor)
        self.test_btn.setFixedHeight(42)
        self.test_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.10);
                border: 1px solid rgba(255, 255, 255, 0.22);
                border-radius: 10px;
                color: #FFFFFF;
                font-size: 13px;
                font-weight: 600;
                padding: 0 16px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.18);
                border-color: rgba(255, 255, 255, 0.35);
            }
            QPushButton:pressed {
                background: rgba(255, 255, 255, 0.24);
            }
        """)
        self.test_btn.clicked.connect(self._on_test_clicked)
        lay.addWidget(self.test_btn)

        lay.addStretch()
        scroll.setWidget(container)
        return scroll

    # =========================================================================
    # TAB 3: DESIGN (APPEARANCE)
    # =========================================================================
    def _build_design_tab(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")

        container = QWidget()
        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 4, 0, 4)
        lay.setSpacing(14)

        # Color & Depth Picker
        self.color_sec_lbl = QLabel(t("inspector_color_section"))
        self.color_sec_lbl.setStyleSheet("color: #FFFFFF; font-size: 11px; font-weight: 500;")
        lay.addWidget(self.color_sec_lbl)

        self.color_picker = AppleGlassColorPicker(current_color="#141416", parent=self)
        self.color_picker.color_selected.connect(self._set_button_color)
        lay.addWidget(self.color_picker)

        lay.addWidget(AppleDivider())

        # Corner Radius Slider
        rad_row = QHBoxLayout()
        self.rad_lbl = QLabel(t("inspector_radius_label"))
        self.rad_lbl.setStyleSheet("color: #8E8E93; font-size: 11px;")
        rad_row.addWidget(self.rad_lbl)
        self.radius_slider = QSlider(Qt.Horizontal)
        self.radius_slider.setRange(8, 36)
        self.radius_slider.setValue(28)
        self.radius_slider.valueChanged.connect(self._on_radius_changed)
        rad_row.addWidget(self.radius_slider)
        lay.addLayout(rad_row)

        # Font Size Slider
        font_row = QHBoxLayout()
        self.font_lbl = QLabel(t("inspector_font_size_label"))
        self.font_lbl.setStyleSheet("color: #8E8E93; font-size: 11px;")
        font_row.addWidget(self.font_lbl)

        self.font_val_lbl = QLabel("12 px")
        self.font_val_lbl.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 600;")
        font_row.addWidget(self.font_val_lbl)

        self.font_slider = QSlider(Qt.Horizontal)
        self.font_slider.setRange(8, 30)
        self.font_slider.setValue(12)
        self.font_slider.valueChanged.connect(self._on_font_size_changed)
        font_row.addWidget(self.font_slider)
        lay.addLayout(font_row)

        lay.addSpacing(10)

        # Visual Font Family Gallery
        self.font_gallery_lbl = QLabel("Skrifttype & Stil")
        self.font_gallery_lbl.setStyleSheet("color: #8E8E93; font-size: 10.5px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;")
        lay.addWidget(self.font_gallery_lbl)

        self.font_gallery = FontGalleryWidget(parent=container)
        self.font_gallery.font_selected.connect(self._on_font_family_selected)
        lay.addWidget(self.font_gallery)

        lay.addStretch()
        scroll.setWidget(container)
        return scroll

    def _populate_action_types(self):
        self.action_type_combo.blockSignals(True)
        self.action_type_combo.clear()
        self.action_type_combo.addItem(t("action_application"), ACTION_TYPE_APPLICATION)
        self.action_type_combo.addItem(t("action_hotkey"), ACTION_TYPE_HOTKEY)
        self.action_type_combo.addItem(t("action_media"), ACTION_TYPE_MEDIA)
        self.action_type_combo.addItem(t("action_url"), ACTION_TYPE_FILE_FOLDER_URL)
        self.action_type_combo.addItem(t("action_system"), ACTION_TYPE_SYSTEM)
        self.action_type_combo.addItem(t("action_macro"), ACTION_TYPE_MACRO)
        self.action_type_combo.addItem("Discord", ACTION_TYPE_DISCORD)
        self.action_type_combo.addItem("Medal.tv", ACTION_TYPE_MEDAL)
        self.action_type_combo.blockSignals(False)

    def _on_tab_changed(self, idx: int):
        self.stack.setCurrentIndex(idx)

    def _toggle_icon_picker(self):
        if self.icon_picker.isVisible():
            self.icon_picker.hide()
            self.toggle_picker_btn.setText(t("inspector_choose_icon"))
        else:
            self.icon_picker.show()
            self.toggle_picker_btn.setText(t("inspector_close_icon_picker"))

    def _update_icon_thumb(self):
        if not self.button or not self.button.icon:
            self.icon_thumb_lbl.setPixmap(QPixmap())
            self.icon_thumb_lbl.setText("-")
            self.icon_thumb_lbl.setStyleSheet("color: #8E8E93; font-size: 14px; background: rgba(255, 255, 255, 0.04); border: 1px dashed rgba(255, 255, 255, 0.15); border-radius: 8px;")
            self.icon_name_lbl.setText(t("inspector_no_icon"))
            return

        resolved = resolve_icon_path(self.button.icon)
        if resolved and resolved.exists():
            pix = QPixmap(str(resolved)).scaled(32, 32, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.icon_thumb_lbl.setText("")
            self.icon_thumb_lbl.setPixmap(pix)
            self.icon_thumb_lbl.setStyleSheet("background: rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.20); border-radius: 8px;")
            self.icon_name_lbl.setText(Path(self.button.icon).stem.replace("_", " ").title())
        else:
            self.icon_thumb_lbl.setPixmap(QPixmap())
            self.icon_thumb_lbl.setText("?")
            self.icon_name_lbl.setText(self.button.icon)

    def set_button(self, button: Optional[ButtonModel]):
        self.button = button
        self.mini_preview.set_button(button)

        if not button:
            self.setEnabled(False)
            self.title_input.clear()
            self._update_icon_thumb()
            return

        self.setEnabled(True)
        self.title_input.blockSignals(True)
        self.title_input.setText(button.title or "")
        self.title_input.blockSignals(False)

        # Update Icon
        self._update_icon_thumb()
        self.icon_picker.set_current_icon(button.icon or "")

        # Update Color & Sliders
        self.color_picker.set_color(button.bg_color or "#141416")

        self.radius_slider.blockSignals(True)
        r_val = button.border_radius or 28
        if r_val <= 16:
            r_val = 28
        self.radius_slider.setValue(r_val)
        self.radius_slider.blockSignals(False)

        self.font_slider.blockSignals(True)
        f_val = button.font_size or 12
        self.font_slider.setValue(f_val)
        self.font_val_lbl.setText(f"{f_val} px")
        self.font_slider.blockSignals(False)

        self.font_gallery.blockSignals(True)
        self.font_gallery.set_selected_font(button.font_family or "Segoe UI")
        self.font_gallery.blockSignals(False)

        # Update Action
        self.action_type_combo.blockSignals(True)
        if button.action:
            act_type = button.action.action_type
            idx = self.action_type_combo.findData(act_type)
            if idx >= 0:
                self.action_type_combo.setCurrentIndex(idx)
                self.action_stack.setCurrentIndex(idx)
            else:
                self.action_type_combo.setCurrentIndex(0)
                self.action_stack.setCurrentIndex(0)

            # Fill inputs
            target = button.action.target or ""
            sub_act = button.action.sub_action or ""

            self.app_path_input.blockSignals(True)
            self.app_path_input.setText(target if act_type == ACTION_TYPE_APPLICATION else "")
            self.app_path_input.blockSignals(False)

            self.hotkey_input.blockSignals(True)
            self.hotkey_input.setText(target if act_type == ACTION_TYPE_HOTKEY else "")
            self.hotkey_input.blockSignals(False)

            self.url_input.blockSignals(True)
            self.url_input.setText(target if act_type == ACTION_TYPE_FILE_FOLDER_URL else "")
            self.url_input.blockSignals(False)

            if act_type == ACTION_TYPE_MEDIA:
                m_idx = self.media_combo.findText(sub_act)
                if m_idx >= 0:
                    self.media_combo.setCurrentIndex(m_idx)

            if act_type == ACTION_TYPE_SYSTEM:
                s_idx = self.sys_combo.findText(sub_act)
                if s_idx >= 0:
                    self.sys_combo.setCurrentIndex(s_idx)

            if act_type == ACTION_TYPE_DISCORD:
                d_idx = self.discord_combo.findData(sub_act)
                if d_idx >= 0:
                    self.discord_combo.setCurrentIndex(d_idx)
                self.discord_key_input.blockSignals(True)
                self.discord_key_input.setText(button.action.args or button.action.target or "")
                self.discord_key_input.blockSignals(False)

            if act_type == ACTION_TYPE_MEDAL:
                md_idx = self.medal_combo.findData(sub_act)
                if md_idx >= 0:
                    self.medal_combo.setCurrentIndex(md_idx)
                self.medal_key_input.blockSignals(True)
                self.medal_key_input.setText(button.action.args or button.action.target or "")
                self.medal_key_input.blockSignals(False)
        else:
            self.action_type_combo.setCurrentIndex(0)
            self.action_stack.setCurrentIndex(0)

        self.action_type_combo.blockSignals(False)

    def _on_title_changed(self, text: str):
        if self.button:
            self.button.title = text
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_icon_selected(self, icon_val: str):
        if not self.button:
            return
        self.button.icon = icon_val
        self._update_icon_thumb()
        self.mini_preview.update()
        self.button_updated.emit(self.button)

    def _clear_icon(self):
        if not self.button:
            return
        self.button.icon = ""
        self._update_icon_thumb()
        self.icon_picker.set_current_icon("")
        self.mini_preview.update()
        self.button_updated.emit(self.button)

    def _set_button_color(self, hex_color: str):
        if self.button:
            self.button.bg_color = hex_color
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_radius_changed(self, val: int):
        if self.button:
            self.button.border_radius = val
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_font_size_changed(self, val: int):
        self.font_val_lbl.setText(f"{val} px")
        if self.button:
            self.button.font_size = val
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_font_family_selected(self, font_id: str):
        if self.button:
            self.button.font_family = font_id
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_action_type_changed(self, index: int):
        if not self.button:
            return
        act_type = self.action_type_combo.currentData()
        self.action_stack.setCurrentIndex(index)
        if not self.button.action:
            self.button.action = ActionModel(action_type=act_type)
        else:
            self.button.action.action_type = act_type
        self._on_action_params_changed()

    def _on_action_params_changed(self):
        if not self.button:
            return
        act_type = self.action_type_combo.currentData()
        target = ""
        sub_action = ""

        if act_type == ACTION_TYPE_APPLICATION:
            target = self.app_path_input.text().strip()
        elif act_type == ACTION_TYPE_HOTKEY:
            target = self.hotkey_input.text().strip()
        elif act_type == ACTION_TYPE_MEDIA:
            sub_action = self.media_combo.currentText()
        elif act_type == ACTION_TYPE_FILE_FOLDER_URL:
            target = self.url_input.text().strip()
        elif act_type == ACTION_TYPE_SYSTEM:
            sub_action = self.sys_combo.currentText()
        elif act_type == ACTION_TYPE_DISCORD:
            sub_action = self.discord_combo.currentData() or DISCORD_MUTE_MIC
            args = self.discord_key_input.text().strip()
            target = args or "Ctrl+Shift+M"
        elif act_type == ACTION_TYPE_MEDAL:
            sub_action = self.medal_combo.currentData() or MEDAL_CLIP_30S
            args = self.medal_key_input.text().strip()
            target = args or "F8"

        if not self.button.action:
            self.button.action = ActionModel(action_type=act_type, target=target, sub_action=sub_action, args=args)
        else:
            self.button.action.action_type = act_type
            self.button.action.target = target
            self.button.action.sub_action = sub_action
            self.button.action.args = args

        # Auto-fetch web logo if URL has at least 3 characters and button doesn't have a logo yet
        if act_type == ACTION_TYPE_FILE_FOLDER_URL and len(target) >= 3:
            if not self.button.icon:
                self.url_fetch_timer.start()

        self.mini_preview.update()
        self.button_updated.emit(self.button)

    def _auto_fetch_url_logo(self):
        if not self.button or self.button.icon:
            return
        url = self.url_input.text().strip()
        if len(url) < 3:
            return
        self.fetch_url_logo_btn.setText(t("inspector_fetching_logo"))
        from editor.utils.web_icon_fetcher import WebLogoFetchWorker
        self._url_worker = WebLogoFetchWorker(url, parent=self)
        self._url_worker.success.connect(self._on_url_logo_success)
        self._url_worker.failure.connect(self._on_url_logo_failure)
        self._url_worker.start()

    def _fetch_logo_for_current_url(self):
        url = self.url_input.text().strip()
        if not url:
            return
        self.fetch_url_logo_btn.setEnabled(False)
        self.fetch_url_logo_btn.setText(t("inspector_fetching_logo"))

        from editor.utils.web_icon_fetcher import WebLogoFetchWorker
        self._url_worker = WebLogoFetchWorker(url, parent=self)
        self._url_worker.success.connect(self._on_url_logo_success)
        self._url_worker.failure.connect(self._on_url_logo_failure)
        self._url_worker.start()

    def _on_url_logo_success(self, filename: str, domain: str):
        self.fetch_url_logo_btn.setEnabled(True)
        self.fetch_url_logo_btn.setText(t("inspector_fetch_logo"))
        if not self.button:
            return
        self.button.icon = filename
        self._update_icon_thumb()
        self.icon_picker.set_current_icon(filename)
        # If title is empty or default, suggest domain name formatted
        if not self.button.title or self.button.title.startswith("Knap ") or self.button.title.startswith("Button "):
            clean_title = domain.split(".")[0].title()
            self.title_input.setText(clean_title)
            self.button.title = clean_title
        self.mini_preview.update()
        self.button_updated.emit(self.button)

    def _on_url_logo_failure(self, error: str):
        self.fetch_url_logo_btn.setEnabled(True)
        self.fetch_url_logo_btn.setText(t("inspector_fetch_logo"))

    def _browse_application(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Vælg Program", "", "Programmer (*.exe);;Alle Filer (*.*)"
        )
        if file_path:
            self.app_path_input.setText(file_path)

    def _open_macro_editor(self):
        if not self.button:
            return
        dialog = MacroEditorDialog(self.button.action, self)
        if dialog.exec():
            self.button.action = dialog.get_action()
            self.mini_preview.update()
            self.button_updated.emit(self.button)

    def _on_test_clicked(self):
        if self.button:
            self.button_test_requested.emit(self.button)

    def _on_delete_clicked(self):
        if self.button:
            self.button_deleted.emit(self.button.id)

    def _on_language_changed(self, lang: str):
        self.title_lbl.setText(t("inspector_title"))
        self.delete_btn.setText(t("inspector_delete"))
        self.segmented_tabs.set_tab_texts([
            t("inspector_tab_content"),
            t("inspector_tab_action"),
            t("inspector_tab_design")
        ])
        self.title_input_lbl.setText(t("inspector_title_label"))
        self.title_input.setPlaceholderText(t("inspector_title_placeholder"))
        self.icon_sec_lbl.setText(t("inspector_icon_section"))
        if self.icon_picker.isVisible():
            self.toggle_picker_btn.setText(t("inspector_close_icon_picker"))
        else:
            self.toggle_picker_btn.setText(t("inspector_choose_icon"))
        self.remove_icon_btn.setText(t("inspector_remove_icon"))
        self._update_icon_thumb()

        self.act_type_lbl.setText(t("inspector_action_type"))
        cur_act_data = self.action_type_combo.currentData()
        self._populate_action_types()
        act_idx = self.action_type_combo.findData(cur_act_data)
        if act_idx >= 0:
            self.action_type_combo.setCurrentIndex(act_idx)

        self.pick_exe_btn.setText(t("inspector_browse_exe"))
        self.app_path_input.setPlaceholderText(t("inspector_app_placeholder"))
        self.hotkey_input.setPlaceholderText(t("inspector_hotkey_placeholder"))
        self.url_input.setPlaceholderText(t("inspector_url_placeholder"))
        self.fetch_url_logo_btn.setText(t("inspector_fetch_logo"))
        self.macro_btn.setText(t("inspector_edit_macro"))
        self.test_btn.setText(t("inspector_test_button"))

        self.color_sec_lbl.setText(t("inspector_color_section"))
        self.rad_lbl.setText(t("inspector_radius_label"))
        self.font_lbl.setText(t("inspector_font_size_label"))
