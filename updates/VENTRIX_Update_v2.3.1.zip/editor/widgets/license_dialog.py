"""
VENTRIX Studio - Apple Glass License Activation Dialog
Frameless frosted glass modal for entering and verifying license keys.
Author: VENTRIX
"""

import os
import webbrowser
from pathlib import Path
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QWidget, QFrame
)
from PySide6.QtGui import QPainter, QColor, QFont, QPen, QLinearGradient, QPixmap
from PySide6.QtCore import Qt, Signal

from editor.widgets.glass_widgets import GlassCard, GlassButton
from shared.license_manager import verify_license_key, save_license, get_license_info


class LicenseActivationDialog(QDialog):
    """
    Apple Glass modal dialog for activating VENTRIX Studio.
    """

    activated = Signal(str)

    def __init__(self, parent=None, cancellable: bool = True):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setModal(True)
        self.setFixedSize(460, 380)

        self.cancellable = cancellable
        self._is_activated = False

        self._init_ui()

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(12, 12, 12, 12)

        self.card = GlassCard(corner_radius=22, parent=self)
        card_lay = QVBoxLayout(self.card)
        card_lay.setContentsMargins(28, 28, 28, 24)
        card_lay.setSpacing(14)

        # Header with Logo & Title
        header_row = QHBoxLayout()
        header_row.setSpacing(12)

        logo_lbl = QLabel()
        logo_path = Path(__file__).parent.parent.parent / "assets" / "ventrix.png"
        if logo_path.exists():
            pix = QPixmap(str(logo_path)).scaled(42, 42, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            logo_lbl.setPixmap(pix)
        header_row.addWidget(logo_lbl)

        title_box = QVBoxLayout()
        title_box.setSpacing(2)

        title_lbl = QLabel("VENTRIX Studio")
        title_lbl.setStyleSheet("color: #FFFFFF; font-size: 17px; font-weight: 700; letter-spacing: -0.3px;")
        subtitle_lbl = QLabel("Licensaktivering")
        subtitle_lbl.setStyleSheet("color: rgba(255, 255, 255, 0.5); font-size: 12px; font-weight: 500;")

        title_box.addWidget(title_lbl)
        title_box.addWidget(subtitle_lbl)
        header_row.addLayout(title_box)
        header_row.addStretch()

        if self.cancellable:
            close_btn = QPushButton("✕")
            close_btn.setFixedSize(28, 28)
            close_btn.setStyleSheet("""
                QPushButton {
                    color: rgba(255, 255, 255, 0.4);
                    background: rgba(255, 255, 255, 0.05);
                    border: 1px solid rgba(255, 255, 255, 0.08);
                    border-radius: 14px;
                    font-size: 13px;
                }
                QPushButton:hover {
                    color: #FFFFFF;
                    background: rgba(255, 255, 255, 0.12);
                }
            """)
            close_btn.clicked.connect(self.reject)
            header_row.addWidget(close_btn)

        card_lay.addLayout(header_row)

        # Description
        desc_lbl = QLabel("Indtast din personlige licensnøgle fra hjemmesiden for at låse op for alle pro-funktioner.")
        desc_lbl.setWordWrap(True)
        desc_lbl.setStyleSheet("color: #A1A1AA; font-size: 12.5px; line-height: 1.4;")
        card_lay.addWidget(desc_lbl)

        # Key Input
        self.key_input = QLineEdit()
        self.key_input.setPlaceholderText("VTX-XXXX-XXXX-XXXX-XXXX")
        self.key_input.setAlignment(Qt.AlignCenter)
        self.key_input.setFixedHeight(44)
        self.key_input.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.05);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.14);
                border-radius: 12px;
                font-family: 'Consolas', monospace;
                font-size: 14px;
                font-weight: 600;
                letter-spacing: 1.5px;
                padding: 0 12px;
            }
            QLineEdit:focus {
                border: 1px solid rgba(255, 255, 255, 0.35);
                background: rgba(255, 255, 255, 0.08);
            }
        """)
        self.key_input.textChanged.connect(self._format_key)
        self.key_input.returnPressed.connect(self._attempt_activation)
        card_lay.addWidget(self.key_input)

        # Feedback label
        self.feedback_lbl = QLabel("")
        self.feedback_lbl.setAlignment(Qt.AlignCenter)
        self.feedback_lbl.setStyleSheet("font-size: 12px; font-weight: 500;")
        card_lay.addWidget(self.feedback_lbl)

        # Action Buttons
        btn_col = QVBoxLayout()
        btn_col.setSpacing(8)

        self.activate_btn = QPushButton("Aktiver VENTRIX Studio")
        self.activate_btn.setFixedHeight(40)
        self.activate_btn.setStyleSheet("""
            QPushButton {
                background: #FFFFFF;
                color: #070709;
                border-radius: 20px;
                font-size: 13px;
                font-weight: 600;
                border: none;
            }
            QPushButton:hover {
                background: #F0F0F0;
            }
            QPushButton:pressed {
                background: #D8D8D8;
            }
        """)
        self.activate_btn.clicked.connect(self._attempt_activation)
        btn_col.addWidget(self.activate_btn)

        # Get Free License link button
        self.web_btn = QPushButton("Hent Gratis Licens på Hjemmesiden →")
        self.web_btn.setFixedHeight(34)
        self.web_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #8E8E93;
                border: none;
                font-size: 12px;
                font-weight: 500;
            }
            QPushButton:hover {
                color: #FFFFFF;
                text-decoration: underline;
            }
        """)
        self.web_btn.clicked.connect(self._open_website)
        btn_col.addWidget(self.web_btn)

        card_lay.addLayout(btn_col)
        root_lay.addWidget(self.card)

    def _format_key(self, text: str):
        clean = text.upper().replace(" ", "")
        self.key_input.blockSignals(True)
        self.key_input.setText(clean)
        self.key_input.blockSignals(False)

    def _attempt_activation(self):
        key = self.key_input.text().strip()
        if not key:
            self.feedback_lbl.setText("Indtast venligst en licensnøgle.")
            self.feedback_lbl.setStyleSheet("color: #EF4444; font-size: 12px;")
            return

        if verify_license_key(key):
            save_license(key)
            self._is_activated = True
            self.feedback_lbl.setText("✓ Licens godkendt! Låser op...")
            self.feedback_lbl.setStyleSheet("color: #22C55E; font-size: 12px; font-weight: 600;")
            self.activate_btn.setEnabled(False)
            self.key_input.setEnabled(False)
            self.activated.emit(key)
            # Close dialog after brief success flash
            from PySide6.QtCore import QTimer
            QTimer.singleShot(700, self.accept)
        else:
            self.feedback_lbl.setText("Ugyldig licensnøgle. Tjek formatet og prøv igen.")
            self.feedback_lbl.setStyleSheet("color: #EF4444; font-size: 12px;")

    def _open_website(self):
        # Open local or public website
        local_site = Path(r"C:\Users\olive\Desktop\ventrix-website\index.html")
        if local_site.exists():
            webbrowser.open(local_site.as_uri())
        else:
            webbrowser.open("https://ventrix-website.vercel.app")
