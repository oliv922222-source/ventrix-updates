"""
TouchDeck / VENTRIX - Discord Integration Inspector
Apple visionOS Glass aesthetic panel for configuring and quick-adding
Discord controls to TouchDeck (Mute mic, Deafen all, PTT, Screen share).
Author: VENTRIX
"""

import os
from pathlib import Path
from typing import Optional, Dict, Any

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFrame, QScrollArea
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QIcon, QPixmap

from shared.constants import (
    ACTION_TYPE_DISCORD,
    DISCORD_MUTE_MIC, DISCORD_DEAFEN, DISCORD_PUSH_TO_TALK, DISCORD_STREAM_TOGGLE
)
from shared.models import ButtonModel, ActionModel
from editor.actions.action_engine import Win32KeyboardMouse


class AppleDivider(QFrame):
    """Subtle 1px hairline divider."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.HLine)
        self.setFrameShadow(QFrame.Plain)
        self.setFixedHeight(1)
        self.setStyleSheet("background: rgba(255, 255, 255, 0.08); border: none;")


class DiscordActionCard(QFrame):
    """Glass card for a specific Discord action with trigger test and 1-click create on deck."""
    create_requested = Signal(dict)

    def __init__(self, title: str, subtitle: str, sub_action: str, default_key: str, icon_name: str, parent=None):
        super().__init__(parent)
        self.sub_action = sub_action
        self.default_key = default_key
        self.icon_name = icon_name
        self.title_text = title

        self.setObjectName("discordCard")
        self.setStyleSheet("""
            QFrame#discordCard {
                background: rgba(255, 255, 255, 0.035);
                border: 1px solid rgba(255, 255, 255, 0.09);
                border-radius: 14px;
                padding: 10px;
            }
            QFrame#discordCard:hover {
                background: rgba(255, 255, 255, 0.055);
                border-color: rgba(255, 255, 255, 0.16);
            }
        """)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        # Header with icon and title
        header_row = QHBoxLayout()
        header_row.setSpacing(10)

        # Icon badge
        icon_lbl = QLabel()
        icon_lbl.setFixedSize(30, 30)
        icon_lbl.setAlignment(Qt.AlignCenter)
        icon_lbl.setStyleSheet("background: rgba(88, 101, 242, 0.20); border: 1px solid rgba(88, 101, 242, 0.40); border-radius: 8px;")
        
        icon_path = Path(__file__).resolve().parent.parent.parent / "assets" / "icons" / f"{icon_name}.png"
        if icon_path.exists():
            pix = QPixmap(str(icon_path)).scaled(18, 18, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            icon_lbl.setPixmap(pix)
        else:
            icon_lbl.setText("")
        header_row.addWidget(icon_lbl)

        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        t_lbl = QLabel(title)
        t_lbl.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 600;")
        title_col.addWidget(t_lbl)

        s_lbl = QLabel(subtitle)
        s_lbl.setStyleSheet("color: #8E8E93; font-size: 11px;")
        s_lbl.setWordWrap(True)
        title_col.addWidget(s_lbl)
        header_row.addLayout(title_col, stretch=1)

        lay.addLayout(header_row)

        # Action Buttons Row
        btn_row = QHBoxLayout()
        btn_row.setSpacing(6)

        # Test trigger button
        self.test_btn = QPushButton("Test")
        self.test_btn.setCursor(Qt.PointingHandCursor)
        self.test_btn.setFixedHeight(28)
        self.test_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 9px;
                color: #A1A1AA;
                font-size: 11px;
                font-weight: 600;
                padding: 0 12px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.12);
                color: #FFFFFF;
                border-color: rgba(255, 255, 255, 0.22);
            }
        """)
        self.test_btn.clicked.connect(self._test_action)
        btn_row.addWidget(self.test_btn)

        # Create Button on Deck
        self.create_btn = QPushButton("+ Opret på Deck")
        self.create_btn.setCursor(Qt.PointingHandCursor)
        self.create_btn.setFixedHeight(28)
        self.create_btn.setStyleSheet("""
            QPushButton {
                background: rgba(88, 101, 242, 0.25);
                border: 1px solid rgba(88, 101, 242, 0.45);
                border-radius: 9px;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 600;
                padding: 0 14px;
            }
            QPushButton:hover {
                background: rgba(88, 101, 242, 0.45);
                border-color: #5865F2;
            }
            QPushButton:pressed {
                background: rgba(88, 101, 242, 0.60);
            }
        """)
        self.create_btn.clicked.connect(self._create_on_deck)
        btn_row.addWidget(self.create_btn, stretch=1)

        lay.addLayout(btn_row)

    def _test_action(self):
        Win32KeyboardMouse.send_hotkey_combo(self.default_key)

    def _create_on_deck(self):
        spec = {
            "title": self.title_text,
            "action_type": ACTION_TYPE_DISCORD,
            "sub_action": self.sub_action,
            "target": self.default_key,
            "args": self.default_key,
            "icon_name": self.icon_name,
            "bg_color": "#1E1F2A"
        }
        self.create_requested.emit(spec)


class DiscordInspector(QWidget):
    """
    Dedicated Discord configuration and quick-add inspector panel in the right stack.
    """
    close_requested = Signal()
    button_creation_requested = Signal(dict)

    def __init__(self, main_win=None, parent=None):
        super().__init__(parent)
        self.main_win = main_win
        self._init_ui()

    def _init_ui(self):
        root_lay = QVBoxLayout(self)
        root_lay.setContentsMargins(0, 0, 0, 0)
        root_lay.setSpacing(0)

        # Scroll Area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("background: transparent; border: none;")

        container = QWidget()
        container.setObjectName("discordInspectorContainer")
        container.setStyleSheet("background: transparent;")
        lay = QVBoxLayout(container)
        lay.setContentsMargins(18, 16, 18, 20)
        lay.setSpacing(14)

        # Top Header Row: Badge, Title & Close Button
        header_row = QHBoxLayout()
        header_row.setSpacing(10)

        # Discord Logo
        logo_lbl = QLabel()
        logo_lbl.setFixedSize(28, 28)
        logo_lbl.setAlignment(Qt.AlignCenter)
        discord_icon_path = Path(__file__).resolve().parent.parent.parent / "assets" / "icons" / "discord.png"
        if discord_icon_path.exists():
            pix = QPixmap(str(discord_icon_path)).scaled(24, 24, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            logo_lbl.setPixmap(pix)
        else:
            logo_lbl.setText("")
        header_row.addWidget(logo_lbl)

        header_title_col = QVBoxLayout()
        header_title_col.setSpacing(1)
        h_title = QLabel("Discord Kontrol")
        h_title.setStyleSheet("color: #FFFFFF; font-size: 15px; font-weight: 700; letter-spacing: -0.2px;")
        header_title_col.addWidget(h_title)

        h_sub = QLabel("Styr mikrofon, lyd & streaming")
        h_sub.setStyleSheet("color: #8E8E93; font-size: 11px;")
        header_title_col.addWidget(h_sub)
        header_row.addLayout(header_title_col, stretch=1)

        # Close Button
        close_btn = QPushButton("✕")
        close_btn.setObjectName("inspectorCloseBtn")
        close_btn.setToolTip("Luk Discord panel")
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.clicked.connect(self.close_requested.emit)
        header_row.addWidget(close_btn)

        lay.addLayout(header_row)
        lay.addWidget(AppleDivider())

        # Section: Handlinger
        sec_title = QLabel("DISCORD HANDLINGER")
        sec_title.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 700; letter-spacing: 0.8px;")
        lay.addWidget(sec_title)

        # 1. Mute Microphone
        card_mute = DiscordActionCard(
            title="Mikrofon Mute",
            subtitle="Slå mikrofon til og fra (Default: Ctrl+Shift+M)",
            sub_action=DISCORD_MUTE_MIC,
            default_key="Ctrl+Shift+M",
            icon_name="mic_mute",
            parent=self
        )
        card_mute.create_requested.connect(self._on_card_create)
        lay.addWidget(card_mute)

        # 2. Deafen ("Mude det hele")
        card_deafen = DiscordActionCard(
            title="Dæmp Alt (Deafen)",
            subtitle="Dæmp både høretelefoner og mikrofon (Default: Ctrl+Shift+D)",
            sub_action=DISCORD_DEAFEN,
            default_key="Ctrl+Shift+D",
            icon_name="volume_mute",
            parent=self
        )
        card_deafen.create_requested.connect(self._on_card_create)
        lay.addWidget(card_deafen)

        # 3. Push to Talk
        card_ptt = DiscordActionCard(
            title="Push-To-Talk",
            subtitle="Aktivér tale i Discord (Default tast: Ctrl)",
            sub_action=DISCORD_PUSH_TO_TALK,
            default_key="Ctrl",
            icon_name="mic",
            parent=self
        )
        card_ptt.create_requested.connect(self._on_card_create)
        lay.addWidget(card_ptt)

        # 4. Stream / Screen Share
        card_stream = DiscordActionCard(
            title="Skærmdeling Toggle",
            subtitle="Start eller stop skærmdeling (Default: Ctrl+Shift+S)",
            sub_action=DISCORD_STREAM_TOGGLE,
            default_key="Ctrl+Shift+S",
            icon_name="desktop",
            parent=self
        )
        card_stream.create_requested.connect(self._on_card_create)
        lay.addWidget(card_stream)

        lay.addSpacing(6)
        lay.addWidget(AppleDivider())
        lay.addSpacing(4)

        # Section: Genvejs Indstillinger
        kb_title = QLabel("TILPAS GENVEJSTASTER")
        kb_title.setStyleSheet("color: #8E8E93; font-size: 10px; font-weight: 700; letter-spacing: 0.8px;")
        lay.addWidget(kb_title)

        info_box = QFrame()
        info_box.setStyleSheet("background: rgba(88, 101, 242, 0.08); border: 1px solid rgba(88, 101, 242, 0.20); border-radius: 10px; padding: 8px;")
        info_lay = QVBoxLayout(info_box)
        info_lay.setContentsMargins(8, 8, 8, 8)
        info_txt = QLabel("<b>Tip:</b> Hvis du har tilpasset dine Discord genveje i <i>Discord > Indstillinger > Genvejstaster</i>, sendes disse taster direkte uden forsinkelse.")
        info_txt.setWordWrap(True)
        info_txt.setStyleSheet("color: #C7D2FE; font-size: 11px; line-height: 1.4;")
        info_lay.addWidget(info_txt)
        lay.addWidget(info_box)

        lay.addStretch(1)

        scroll.setWidget(container)
        root_lay.addWidget(scroll)

    def _on_card_create(self, spec: dict):
        self.button_creation_requested.emit(spec)
