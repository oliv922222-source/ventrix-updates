"""
TouchDeck - Reusable Apple / visionOS Glassmorphic Widgets
Strict Monochromatic Black, White & Subtle Glass Elements.
Author: VENTRIX
"""

import os
from pathlib import Path
from typing import Optional
from PySide6.QtWidgets import (
    QWidget, QFrame, QLabel, QPushButton, QHBoxLayout, QVBoxLayout,
    QGraphicsDropShadowEffect, QApplication
)
from PySide6.QtGui import (
    QPainter, QColor, QFont, QPen, QBrush, QLinearGradient,
    QPainterPath, QPixmap, QImage
)
from PySide6.QtCore import Qt, QRect, QRectF, QSize, QPoint, QPointF, Signal, QTimer, QPropertyAnimation, QEasingCurve

from editor.ui.glass_theme import (
    COLOR_BLACK, COLOR_BG_CARD, STATUS_CONNECTED, STATUS_DISCONNECTED,
    TEXT_PRIMARY, TEXT_SECONDARY, TEXT_MUTED
)


class GlassCard(QFrame):
    """Frosted translucent glass surface with subtle hairline specular border."""

    def __init__(self, corner_radius: int = 14, parent=None):
        super().__init__(parent)
        self.corner_radius = corner_radius
        self.setAttribute(Qt.WA_TranslucentBackground)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect().adjusted(1, 1, -1, -1)
        r = float(self.corner_radius)

        path = QPainterPath()
        path.addRoundedRect(QRectF(rect), r, r)

        # Subtle dark translucent fill
        fill = QColor(22, 22, 24, 185)
        painter.fillPath(path, fill)

        # Hairline specular top edge
        sheen_height = min(24, rect.height() // 3)
        sheen_rect = QRectF(rect.left(), rect.top(), rect.width(), sheen_height)
        sheen_path = QPainterPath()
        sheen_path.addRoundedRect(sheen_rect, r, r)
        sheen_grad = QLinearGradient(0, rect.top(), 0, rect.top() + sheen_height)
        sheen_grad.setColorAt(0.0, QColor(255, 255, 255, 14))
        sheen_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.fillPath(sheen_path, sheen_grad)

        # Hairline border
        border_pen = QPen(QColor(255, 255, 255, 22), 1.0)
        painter.strokePath(path, border_pen)


class GlassButton(QPushButton):
    """Tactile Apple-style glass button with subtle micro-states."""

    def __init__(self, text: str = "", is_primary: bool = False, corner_radius: int = 8, parent=None):
        super().__init__(text, parent)
        self.is_primary = is_primary
        self.corner_radius = corner_radius
        self.is_hovered = False
        self.is_pressed = False
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(32)

    def enterEvent(self, event):
        self.is_hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.is_hovered = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.is_pressed = True
            self.update()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.is_pressed = False
            self.update()
        super().mouseReleaseEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect().adjusted(1, 1, -1, -1)
        if self.is_pressed:
            rect = rect.adjusted(1, 1, -1, -1)

        r = float(self.corner_radius)
        path = QPainterPath()
        path.addRoundedRect(QRectF(rect), r, r)

        if self.is_primary:
            # Solid Apple White Pill
            bg_col = QColor(240, 240, 240) if self.is_hovered else QColor(255, 255, 255)
            if self.is_pressed:
                bg_col = QColor(215, 215, 215)
            painter.fillPath(path, bg_col)
            text_col = QColor(0, 0, 0)
        else:
            # Monochromatic translucent glass pill
            if self.is_hovered:
                bg_col = QColor(255, 255, 255, 30)
                border_col = QColor(255, 255, 255, 45)
            else:
                bg_col = QColor(255, 255, 255, 15)
                border_col = QColor(255, 255, 255, 22)
            if self.is_pressed:
                bg_col = QColor(255, 255, 255, 40)

            painter.fillPath(path, bg_col)
            painter.strokePath(path, QPen(border_col, 1.0))
            text_col = QColor(255, 255, 255)

        # Text & Icon
        painter.setPen(text_col)
        painter.setFont(QFont("Segoe UI Variable Text", 9, QFont.DemiBold if self.is_primary else QFont.Normal))

        icon = self.icon()
        text = self.text()

        if not icon.isNull():
            icon_size = 14
            ix = rect.left() + 10
            iy = rect.center().y() - icon_size // 2
            icon.paint(painter, ix, iy, icon_size, icon_size)
            text_rect = rect.adjusted(icon_size + 14, 0, -8, 0)
            painter.drawText(text_rect, Qt.AlignVCenter | Qt.AlignLeft, text)
        else:
            painter.drawText(rect, Qt.AlignCenter, text)


class GlassStatusPill(QFrame):
    """Discreet Apple-style status indicator: small dot + status text."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.is_connected = False
        self.setFixedHeight(26)
        self.setMinimumWidth(100)

    def set_connected(self, connected: bool):
        self.is_connected = connected
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect().adjusted(1, 1, -1, -1)
        r = float(rect.height()) / 2.0
        path = QPainterPath()
        path.addRoundedRect(QRectF(rect), r, r)

        # Subtle translucent pill
        painter.fillPath(path, QColor(255, 255, 255, 8))
        painter.strokePath(path, QPen(QColor(255, 255, 255, 14), 1.0))

        # Small dot (Apple green if connected, muted gray if disconnected)
        dot_x = rect.left() + 10
        dot_y = rect.center().y()
        dot_r = 3.5

        dot_col = QColor(STATUS_CONNECTED) if self.is_connected else QColor(STATUS_DISCONNECTED)
        painter.setPen(Qt.NoPen)
        painter.setBrush(dot_col)
        painter.drawEllipse(QRectF(dot_x - dot_r, dot_y - dot_r, dot_r * 2, dot_r * 2))

        # Text
        painter.setPen(QColor("#FFFFFF" if self.is_connected else "#8E8E93"))
        painter.setFont(QFont("Segoe UI Variable Text", 9, QFont.Normal))
        text = "Forbundet" if self.is_connected else "Afbrudt"
        text_rect = QRect(int(dot_x + dot_r + 6), rect.top(), int(rect.width() - dot_x - 12), rect.height())
        painter.drawText(text_rect, Qt.AlignVCenter | Qt.AlignLeft, text)


class GlassAvatar(QWidget):
    """Circular profile picture with subtle translucent ring."""

    clicked = Signal()

    def __init__(self, size: int = 30, parent=None):
        super().__init__(parent)
        self.avatar_size = size
        self.setFixedSize(size, size)
        self.setCursor(Qt.PointingHandCursor)
        self.pixmap: Optional[QPixmap] = None
        self.initials = "TD"

    def set_image(self, path_or_pixmap):
        if isinstance(path_or_pixmap, QPixmap):
            self.pixmap = path_or_pixmap
        elif isinstance(path_or_pixmap, str) and os.path.exists(path_or_pixmap):
            self.pixmap = QPixmap(path_or_pixmap)
        else:
            self.pixmap = None
        self.update()

    def set_initials(self, name_or_email: str):
        if name_or_email:
            parts = name_or_email.split()
            if len(parts) >= 2:
                self.initials = (parts[0][0] + parts[1][0]).upper()
            else:
                self.initials = name_or_email[:2].upper()
        else:
            self.initials = "TD"
        self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect().adjusted(1, 1, -1, -1)
        path = QPainterPath()
        path.addEllipse(QRectF(rect))

        if self.pixmap and not self.pixmap.isNull():
            painter.setClipPath(path)
            painter.drawPixmap(rect, self.pixmap.scaled(rect.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))
            painter.setClipping(False)
        else:
            # Monochromatic dark monogram
            painter.fillPath(path, QColor(255, 255, 255, 18))
            painter.setPen(QColor("#FFFFFF"))
            painter.setFont(QFont("Segoe UI Variable Text", 8, QFont.DemiBold))
            painter.drawText(rect, Qt.AlignCenter, self.initials)

        # Hairline specular ring
        painter.strokePath(path, QPen(QColor(255, 255, 255, 30), 1.0))


class GlassToast(QFrame):
    """Floating translucent Apple feedback pill."""

    def __init__(self, message: str, parent=None, duration_ms: int = 2500):
        super().__init__(parent)
        self.setFixedHeight(34)
        self.setObjectName("cardFrame")

        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 4, 16, 4)
        lay.setSpacing(8)

        lbl = QLabel(message)
        lbl.setStyleSheet("color: #FFFFFF; font-size: 11px; font-weight: 500;")
        lay.addWidget(lbl)

        self.adjustSize()
        QTimer.singleShot(duration_ms, self.close)


class AppleSettingsButton(QPushButton):
    """
    Crisp, resolution-independent Apple Settings & Preferences icon button.
    Paints smooth SF Symbols style gear icon via QPainter vector geometry.
    Guaranteed clean layout with no double-nested borders inside the dock.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(28, 28)
        self.setCursor(Qt.PointingHandCursor)
        self.is_hovered = False
        self.is_pressed = False
        self.gear_pixmap = None
        gear_path = Path(__file__).resolve().parent.parent.parent / "assets" / "icons" / "settings.png"
        if gear_path.exists():
            self.gear_pixmap = QPixmap(str(gear_path))

    def enterEvent(self, event):
        self.is_hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.is_hovered = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.is_pressed = True
            self.update()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.is_pressed = False
            self.update()
        super().mouseReleaseEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)

        rect = self.rect().adjusted(1, 1, -1, -1)
        w = rect.width()
        h = rect.height()
        cx = rect.center().x()
        cy = rect.center().y()

        # Only draw background and border on hover / pressed (eliminates double-ring against dock edge)
        if self.is_pressed:
            path = QPainterPath()
            path.addEllipse(QRectF(rect))
            painter.fillPath(path, QBrush(QColor(255, 255, 255, 36)))
            painter.strokePath(path, QPen(QColor(255, 255, 255, 60), 1.0))
        elif self.is_hovered:
            path = QPainterPath()
            path.addEllipse(QRectF(rect))
            painter.fillPath(path, QBrush(QColor(255, 255, 255, 20)))
            painter.strokePath(path, QPen(QColor(255, 255, 255, 36), 1.0))

        # Paint Apple Gear Icon
        if self.gear_pixmap and not self.gear_pixmap.isNull():
            icon_sz = 15
            scaled = self.gear_pixmap.scaled(icon_sz, icon_sz, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            target_rect = QRectF(cx - icon_sz / 2.0, cy - icon_sz / 2.0, icon_sz, icon_sz)
            painter.setOpacity(1.0 if self.is_hovered else 0.78)
            painter.drawPixmap(target_rect.toRect(), scaled)
            painter.setOpacity(1.0)



