"""
TouchDeck - Horizontal Surface Switcher Bar
Provides seamless ← Page Name → surface transitions with keyboard arrows.
Strict Monochromatic Black, White & Real Translucent Glass.
Author: VENTRIX
"""

from typing import Optional
from PySide6.QtWidgets import QWidget, QHBoxLayout, QPushButton, QLabel, QFrame
from PySide6.QtGui import QFont, QColor
from PySide6.QtCore import Qt, Signal

from shared.models import PageModel


class PageSwitcherBar(QFrame):
    """
    Floating horizontal page switcher located directly above the hardware preview.
    Features sleek translucent navigation buttons and page badges.
    """
    prev_requested = Signal()
    next_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(44)
        self.setStyleSheet("""
            QFrame {
                background: transparent;
                border: none;
            }
        """)

        self.current_page_name = "Home"
        self.page_index = 0
        self.total_pages = 1

        self._init_ui()

    def _init_ui(self):
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 2, 12, 2)
        lay.setSpacing(12)
        lay.setAlignment(Qt.AlignCenter)

        # Left Arrow
        self.prev_btn = QPushButton("←")
        self.prev_btn.setFixedSize(32, 28)
        self.prev_btn.setToolTip("Forrige side (← Venstre Piletast)")
        self.prev_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 6px;
                font-size: 16px;
                font-weight: bold;
                padding-bottom: 2px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.14);
                border-color: rgba(255, 255, 255, 0.18);
                color: #FFFFFF;
            }
            QPushButton:pressed {
                background: rgba(255, 255, 255, 0.20);
            }
        """)
        self.prev_btn.clicked.connect(self.prev_requested.emit)
        lay.addWidget(self.prev_btn)

        # Center Container
        center_box = QWidget()
        c_lay = QHBoxLayout(center_box)
        c_lay.setContentsMargins(8, 0, 8, 0)
        c_lay.setSpacing(8)

        self.page_title_lbl = QLabel("Home")
        self.page_title_lbl.setStyleSheet("""
            color: #FFFFFF;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: 0.3px;
        """)
        c_lay.addWidget(self.page_title_lbl)

        self.badge_lbl = QLabel("1 / 1")
        self.badge_lbl.setStyleSheet("""
            color: #8E8E93;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 6px;
            padding: 2px 7px;
            font-size: 11px;
            font-weight: 500;
        """)
        c_lay.addWidget(self.badge_lbl)
        lay.addWidget(center_box)

        # Right Arrow
        self.next_btn = QPushButton("→")
        self.next_btn.setFixedSize(32, 28)
        self.next_btn.setToolTip("Næste side (→ Højre Piletast)")
        self.next_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 6px;
                font-size: 16px;
                font-weight: bold;
                padding-bottom: 2px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.14);
                border-color: rgba(255, 255, 255, 0.18);
                color: #FFFFFF;
            }
            QPushButton:pressed {
                background: rgba(255, 255, 255, 0.20);
            }
        """)
        self.next_btn.clicked.connect(self.next_requested.emit)
        lay.addWidget(self.next_btn)

    def update_page_info(self, page_name: str, index: int, total: int):
        self.current_page_name = page_name
        self.page_index = index
        self.total_pages = total

        self.page_title_lbl.setText(page_name.upper())
        self.badge_lbl.setText(f"{index + 1} / {max(1, total)}")

        self.prev_btn.setEnabled(index > 0)
        self.next_btn.setEnabled(index < total - 1)

    def update_state(self, page_name: str, index: int, total: int):
        self.update_page_info(page_name, index, total)
