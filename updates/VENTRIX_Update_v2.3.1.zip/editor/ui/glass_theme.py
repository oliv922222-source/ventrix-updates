"""
TouchDeck - Apple-Grade Design System & Visual Tokens
Inspired by macOS, iOS, visionOS, and Apple professional desktop software.
Strict Black, White, and Real Translucent Glass.
Author: VENTRIX
"""

# Core Monochromatic Palette
COLOR_BLACK = "#000000"
COLOR_BG_DARK = "#0A0A0A"
COLOR_BG_ELEVATED = "#111111"
COLOR_BG_SURFACE = "#161618"
COLOR_BG_CARD = "#1C1C1E"
COLOR_BG_CARD_HOVER = "#242426"
COLOR_BG_CARD_ACTIVE = "#2C2C2E"

# Typography (Apple San Francisco / Segoe UI Variable hierarchy)
TEXT_PRIMARY = "#FFFFFF"
TEXT_SECONDARY = "#EBEBF5"
TEXT_MUTED = "#8E8E93"
TEXT_FAINT = "#48484A"

# Apple System Accents (used ONLY sparingly for status)
STATUS_CONNECTED = "#34C759"     # Apple Green
STATUS_WARNING = "#FF9F0A"       # Apple Orange
STATUS_ERROR = "#FF453A"         # Apple Red
STATUS_DISCONNECTED = "#636366"  # Apple Gray

# Translucent Glass Levels (Subtle, no exaggerated blur or neon)
GLASS_SURFACE_BASE = "rgba(22, 22, 24, 0.72)"
GLASS_SURFACE_ELEVATED = "rgba(28, 28, 30, 0.80)"
GLASS_SURFACE_FLOATING = "rgba(36, 36, 38, 0.85)"
GLASS_SURFACE_PILL = "rgba(255, 255, 255, 0.08)"
GLASS_SURFACE_PILL_HOVER = "rgba(255, 255, 255, 0.14)"
GLASS_SURFACE_PILL_ACTIVE = "rgba(255, 255, 255, 0.22)"

# Specular Rim Borders (Hairline 1px light reflection)
GLASS_BORDER_TOP = "rgba(255, 255, 255, 0.16)"
GLASS_BORDER_DEFAULT = "rgba(255, 255, 255, 0.08)"
GLASS_BORDER_MUTED = "rgba(255, 255, 255, 0.04)"
GLASS_BORDER_STRONG = "rgba(255, 255, 255, 0.24)"
GLASS_BORDER_SELECTION = "rgba(255, 255, 255, 0.85)"

# Stream Deck Physical Hardware Chassis
CHASSIS_BEZEL_DARK = "#0D0D0F"
CHASSIS_BEZEL_BORDER = "#1E1E22"
CHASSIS_CORNER_RADIUS = 20
BUTTON_CORNER_RADIUS = 14

# Subtle Depth & Shadows
SHADOW_AMBIENT = "rgba(0, 0, 0, 0.35)"
SHADOW_ELEVATED = "rgba(0, 0, 0, 0.55)"
